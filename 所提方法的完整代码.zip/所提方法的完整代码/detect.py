"""Online anomaly detection with the threshold-vector knowledge base.

A query window is assigned to its nearest cluster centroid in the encoder
space; its temporally-averaged reconstruction residual is then compared,
feature by feature, against that cluster's threshold vector.  The window is
flagged anomalous if any feature exceeds its threshold.
"""

import numpy as np
from scipy.spatial.distance import cdist
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score, roc_auc_score, confusion_matrix)

import config


def assign_clusters(latent, centroids):
    """Nearest-centroid assignment.  ``latent`` is (N, H)."""
    return cdist(latent, centroids).argmin(axis=1)


def detect(recon, x, latent, centroids, thresholds, eps=config.EPS):
    """Flag anomalous windows.

    recon/x : (N, T, D); latent : (N, H); centroids : (K, H); thresholds : (K, D).
    """
    c_ids = assign_clusters(latent, centroids)
    e = np.abs(x - recon)
    e_mean = e.mean(axis=1)                       # (N, D)
    preds = np.zeros(len(x), dtype=bool)
    for i in range(len(x)):
        c = int(c_ids[i])
        preds[i] = (e_mean[i] / (thresholds[c] + eps)).max() > 1.0
    return preds, c_ids


def score(y_true, y_pred, scores=None):
    """Compute the standard detection metrics."""
    n_normal = int(np.sum(y_true == 0))
    specificity = 1 - np.mean(y_pred[:n_normal])
    recall = np.mean(y_pred[n_normal:])
    out = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall,
        "specificity": specificity,
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    if scores is not None:
        out["auc_roc"] = roc_auc_score(y_true, scores)
    return out


def anomaly_scores(recon, x, latent, centroids, thresholds, eps=config.EPS):
    """Continuous anomaly score s_i = max_d (mean_t e / threshold)."""
    c_ids = assign_clusters(latent, centroids)
    e_mean = np.abs(x - recon).mean(axis=1)       # (N, D)
    s = np.zeros(len(x))
    for i in range(len(x)):
        c = int(c_ids[i])
        s[i] = (e_mean[i] / (thresholds[c] + eps)).max()
    return s


def print_report(y_true, y_pred, scores=None):
    m = score(y_true, y_pred, scores)
    print("\n[Detection metrics]")
    for k, v in m.items():
        print(f"  {k:<12s}: {v:.4f}")
    cm = confusion_matrix(y_true, y_pred)
    print("\n[Confusion matrix]  (rows=true, cols=pred)")
    print(f"  TN {cm[0, 0]:>5}  FP {cm[0, 1]:>5}")
    print(f"  FN {cm[1, 0]:>5}  TP {cm[1, 1]:>5}")
    return m
