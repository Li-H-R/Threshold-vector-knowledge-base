"""Dual-task LSTM autoencoder with an operating-condition classification head.

    x (B, T, D)
        └─ encoder (LSTM) ─→ last hidden ─→ latent h (B, H)
              ├─ decoder (LSTM) ─→ reconstruction x̂ (B, T, D)
              └─ classifier (MLP) ─→ soft condition z (B, C)

The encoder representation ``h`` is what gets clustered by the knowledge-base
construction stage; the reconstruction residuals |x - x̂| drive the per-cluster
feature-wise thresholds.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class DualTaskLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, latent_dim=64, num_layers=4,
                 num_classes=7, dropout=0.1, clf_hidden=None):
        super().__init__()
        self.encoder = nn.LSTM(input_dim, hidden_dim, num_layers=num_layers,
                               batch_first=True, dropout=dropout)
        self.to_latent = nn.Linear(hidden_dim, latent_dim)
        self.decoder = nn.LSTM(latent_dim, hidden_dim, num_layers=num_layers,
                               batch_first=True, dropout=dropout)
        self.output = nn.Linear(hidden_dim, input_dim)

        clf_hidden = clf_hidden or max(latent_dim // 2, num_classes)
        self.classifier = nn.Sequential(
            nn.Linear(latent_dim, clf_hidden),
            nn.ReLU(),
            nn.Linear(clf_hidden, num_classes),
        )

    def forward(self, x, return_latent=False):
        T = x.size(1)
        _, (hidden, _) = self.encoder(x)
        latent = self.to_latent(hidden[-1])                 # (B, H)
        decoded, _ = self.decoder(latent.unsqueeze(1).expand(-1, T, -1))
        recon = self.output(decoded)                        # (B, T, D)
        clf_logits = self.classifier(latent)                # (B, C)
        mode_w = F.softmax(clf_logits, dim=-1)              # (B, C)
        if return_latent:
            return recon, clf_logits, mode_w, latent
        return recon, clf_logits, mode_w

    @classmethod
    def from_checkpoint(cls, ckpt_path, device="cpu"):
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        cfg = ckpt["model_config"]
        model = cls(**cfg)
        model.load_state_dict(ckpt["model_state_dict"])
        return model
