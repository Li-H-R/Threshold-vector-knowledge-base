"""Data loading, standardisation, splitting, and a synthetic-data generator.

The pipeline expects two optional inputs (see data/README.md):

* ``data/raw_data.npy``     -- (T, D) normal SCADA feature matrix.
* ``data/anomaly_data.npy`` -- dict {name: (N, T, D)} of windowed anomaly
                               segments, used only for evaluation.

When no real data are available, :func:`generate_synthetic_data` creates a
toy wind-turbine SCADA series with realistic operating regimes so the whole
method can be exercised end-to-end.
"""

import os
from dataclasses import dataclass

import numpy as np
import torch
from torch.utils.data import Dataset

import config
from steady_state import extract_wind_turbine_modes


@dataclass
class Standardizer:
    """Per-feature z-score standardisation over the (T, D) window axis."""
    mean: np.ndarray  # (D,)
    std: np.ndarray   # (D,)
    eps: float = 1e-8

    def transform(self, x):
        # x: (N, T, D)
        return (x - self.mean[None, None, :]) / (self.std[None, None, :] + self.eps)

    def transform_2d(self, x):
        # x: (T, D) or (N, D)
        return (x - self.mean[None, :]) / (self.std[None, :] + self.eps)

    @staticmethod
    def fit(x):
        x2 = x.reshape(-1, x.shape[-1])
        mean = x2.mean(axis=0)
        std = x2.std(axis=0)
        std = np.where(std < 1e-8, 1.0, std)
        return Standardizer(mean=mean.astype(np.float32), std=std.astype(np.float32))


class ModeDataset(Dataset):
    def __init__(self, x, y):
        assert x.ndim == 3 and len(y) == len(x)
        self.x = torch.tensor(x, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]


# ---------------------------------------------------------------------------
# Operating-mode extraction + windowing
# ---------------------------------------------------------------------------
def load_raw_windows(raw_path, window_size, col_pitch, col_speed, col_power,
                     M, drop_tail_cols=0):
    """Load a raw (T, D) SCADA series and split it into the 7 operating modes.

    Returns a dict ``{mode_name: (N, window_size, D)}``.
    """
    if not os.path.exists(raw_path):
        raise FileNotFoundError(raw_path)
    data = np.load(raw_path, allow_pickle=True)
    data = np.asarray(data)
    if drop_tail_cols > 0:
        data = data[:, :-drop_tail_cols]

    mode0, mode1, mode2, mode3, bnd_spd, bnd_pitch, bnd_pwr = extract_wind_turbine_modes(
        data, col_pitch=col_pitch, col_speed=col_speed, col_power=col_power,
        window_size=window_size, M=M)

    out = {
        "mode0": _f32(mode0), "mode1": _f32(mode1), "mode2": _f32(mode2),
        "mode3": _f32(mode3), "bnd_spd": _f32(bnd_spd),
        "bnd_pitch": _f32(bnd_pitch), "bnd_pwr": _f32(bnd_pwr),
    }
    return out


def _f32(arr):
    return np.asarray(arr, dtype=np.float32)


def balance_classes(modes, method="oversample", seed=42):
    """Balance class sizes by oversampling or undersampling (per class)."""
    if method is None:
        return {k: v for k, v in modes.items()}
    counts = {cid: arr.shape[0] for cid, arr in modes.items() if arr.shape[0] > 0}
    if not counts:
        raise ValueError("No non-empty modes found; check raw data / column indices.")
    target = max(counts.values()) if method == "oversample" else min(counts.values())
    rng = np.random.RandomState(seed)
    out = {}
    for cid, arr in modes.items():
        n = arr.shape[0]
        if n == 0:
            out[cid] = arr
        elif n < target and method == "oversample":
            out[cid] = arr[rng.choice(n, target, replace=True)]
        elif n > target and method == "undersample":
            out[cid] = arr[rng.choice(n, target, replace=False)]
        else:
            out[cid] = arr
    return out


def modes_to_labeled(modes, mode_list=None):
    """Flatten a mode dict into (X, y) arrays."""
    mode_list = mode_list or config.CLASS_NAMES
    xs, ys = [], []
    for i, name in enumerate(mode_list):
        w = modes.get(name)
        if w is None or w.shape[0] == 0:
            continue
        xs.append(w)
        ys.append(np.full((w.shape[0],), i, dtype=np.int64))
    if not xs:
        raise ValueError("No data found in any mode.")
    return np.concatenate(xs, axis=0).astype(np.float32), np.concatenate(ys, axis=0).astype(np.int64)


def split_train_val_by_class(modes, val_ratio=0.2, seed=42, mode_list=None):
    """Per-class train/val split (each class split internally)."""
    mode_list = mode_list or config.CLASS_NAMES
    rng = np.random.default_rng(seed)
    xtr, ytr, xva, yva = [], [], [], []
    for i, name in enumerate(mode_list):
        w = modes.get(name)
        if w is None or w.shape[0] == 0:
            continue
        n = w.shape[0]
        idx = rng.permutation(n)
        n_val = int(n * val_ratio)
        val_idx, train_idx = idx[:n_val], idx[n_val:]
        if len(train_idx):
            xtr.append(w[train_idx])
            ytr.append(np.full((len(train_idx),), i, dtype=np.int64))
        if len(val_idx):
            xva.append(w[val_idx])
            yva.append(np.full((len(val_idx),), i, dtype=np.int64))
    if not xtr or not xva:
        raise ValueError("Train/val split empty; reduce val_ratio or check modes.")
    return (np.concatenate(xtr, axis=0).astype(np.float32),
            np.concatenate(ytr, axis=0).astype(np.int64)), \
           (np.concatenate(xva, axis=0).astype(np.float32),
            np.concatenate(yva, axis=0).astype(np.int64))


def load_anomaly_windows(path, window_size):
    """Load anomaly windows from a dict {name: (N, T, D)} or (N, T, D) array."""
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    data = np.load(path, allow_pickle=True)
    if isinstance(data, np.ndarray) and data.dtype == object:
        data = data.item()  # dict stored as 0-d object array
    if isinstance(data, dict):
        wins = []
        for v in data.values():
            v = np.asarray(v, dtype=np.float32)
            if v.ndim == 2:                      # (M, D) -> window it
                m = len(v) // window_size
                if m > 0:
                    v = v[:m * window_size].reshape(m, window_size, -1)
            if v.ndim == 3 and v.shape[1] == window_size:
                wins.append(v)
        return np.concatenate(wins, axis=0).astype(np.float32)
    return np.asarray(data, dtype=np.float32)


def build_balanced_test_set(x_normal, x_anomaly, seed=42):
    """Combine normal windows with an equal number of anomaly windows."""
    n_anom = len(x_anomaly)
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(x_normal), size=min(len(x_normal), n_anom), replace=False)
    x_norm = x_normal[idx]
    x = np.concatenate([x_norm, x_anomaly], axis=0)
    y = np.array([0] * len(x_norm) + [1] * len(x_anomaly), dtype=np.int64)
    return x, y


# ---------------------------------------------------------------------------
# Synthetic data (no real SCADA required)
# ---------------------------------------------------------------------------
def generate_synthetic_data(T=20000, D=8, window_size=10, seed=42):
    """Generate a toy wind-turbine SCADA series (T, D) plus anomaly windows.

    Column layout (D=8, matching config): 0=power, 1=rotor speed, 2=wind speed,
    3=wind direction, 4..6=pitch angles, 7=gearbox oil temperature.

    Returns ``(raw_normal, anomaly_windows)`` where ``raw_normal`` is (T, D)
    and ``anomaly_windows`` is (N_a, window_size, D).
    """
    rng = np.random.default_rng(seed)

    # Smooth wind speed random walk spanning the three classic regimes.
    v = np.empty(T)
    v[0] = 6.0
    for t in range(1, T):
        v[t] = np.clip(v[t - 1] + rng.normal(0, 0.15), 3.0, 13.0)
    v = np.convolve(v, np.ones(20) / 20, mode="same")  # smooth

    rated_speed = 11.0
    rated_power = 1.0
    # rotor speed: tracks wind below rated, saturates at rated speed
    speed = np.minimum(v / rated_speed, 1.0)
    # power: cubic tracking below rated, saturates at rated power
    power = np.minimum((v / rated_speed) ** 3, 1.0) * rated_power
    # pitch: 0 below rated wind, ramps up above for constant-power control
    pitch = np.clip((v - rated_speed) * 2.5, 0.0, 20.0)

    raw = np.zeros((T, D), dtype=np.float32)
    raw[:, 0] = power
    raw[:, 1] = speed
    raw[:, 2] = v
    raw[:, 3] = np.clip(rng.normal(0, 1, T).cumsum() * 0.01, -1, 1)  # wind direction
    for j in range(3):
        raw[:, 4 + j] = pitch + rng.normal(0, 0.05, T)              # three blades
    raw[:, 7] = 40 + v * 3 + rng.normal(0, 0.3, T)                   # gearbox oil temp

    # Anomaly windows: pitch-angle deviation injected on random windows.
    n_anom = 200
    starts = rng.integers(0, T - window_size, size=n_anom)
    anomaly = np.stack([raw[s:s + window_size].copy() for s in starts], axis=0)
    anomaly[:, :, 4] += rng.uniform(2.0, 6.0, size=(n_anom, window_size))  # blade-1 drift

    return raw.astype(np.float32), anomaly.astype(np.float32)
