"""Threshold-vector knowledge-base construction.

Given the encoder representations ``h_i`` and absolute reconstruction residuals
``e_{i,t,d}`` of the normal calibration windows, this module:

1. Selects the cluster count ``K*`` by a *within-cluster residual homogeneity*
   criterion (tail-ratio ``P98 / P50`` of the detection-sensitive residual),
   subject to three anti-fragmentation red lines.
2. Fits ``K*``-means on the encoder representations.
3. Estimates a per-cluster, per-feature threshold vector as the upper-tail
   quantile of the pooled absolute residuals.

The resulting knowledge base is ``{(centroid_k, threshold_k)}``.
"""

import os

import numpy as np
from sklearn.cluster import KMeans

import config


# ---------------------------------------------------------------------------
# K selection
# ---------------------------------------------------------------------------
def tail_ratio(e_tilde, labels, min_samples=2, eps=config.EPS):
    """Cluster-size-weighted P98/P50 tail-ratio of ``e_tilde``."""
    sizes = np.bincount(labels)
    valid = np.where(sizes >= min_samples)[0]
    if len(valid) == 0:
        return float("nan")
    num = den = 0.0
    for c in valid:
        vals = e_tilde[labels == c]
        r = np.percentile(vals, 98) / (np.percentile(vals, 50) + eps)
        num += sizes[c] * r
        den += sizes[c]
    return num / den


def select_cluster_count(latent, residual, k_candidates=None, seed=config.SEED,
                         verbose=True):
    """Select ``K*`` by residual homogeneity with anti-fragmentation constraints.

    Parameters
    ----------
    latent : (N, H) encoder representations of the calibration windows.
    residual : (N, T, D) absolute reconstruction residuals.
    """
    k_candidates = k_candidates or config.K_CANDIDATES
    # detection-sensitive residual: max over features of the temporal mean
    e_tilde = residual.mean(axis=1).max(axis=1)   # (N,)

    results = {}
    for k in k_candidates:
        kmeans = KMeans(n_clusters=k, n_init=config.N_INIT, max_iter=config.MAX_ITER,
                        random_state=seed).fit(latent)
        labels = kmeans.labels_
        sizes = np.bincount(labels)
        nonzero = sizes[sizes > 0]
        n = len(labels)

        singleton_ratio = np.sum(nonzero == 1) / len(nonzero)
        well_frac = np.sum(nonzero[nonzero >= config.WELL_POPULATED_SIZE]) / n
        median_size = np.median(nonzero)
        tail = tail_ratio(e_tilde, labels)

        admissible = (singleton_ratio <= config.MAX_SINGLETON_RATIO and
                      well_frac >= config.MIN_WELL_POPULATED_RATIO and
                      median_size >= config.MIN_MEDIAN_CLUSTER_SIZE)
        results[k] = {
            "tail": tail, "singleton_ratio": singleton_ratio,
            "well_frac": well_frac, "median_size": median_size,
            "admissible": admissible,
        }
        if verbose:
            mark = "OK" if admissible else "X"
            print(f"  K={k:>5d}  tail={tail:.4f}  singleton={singleton_ratio:.3f}  "
                  f"well_frac={well_frac:.3f}  median={median_size:>6.1f}  {mark}")

    admissible = {k: v for k, v in results.items() if v["admissible"]}
    if not admissible:
        raise RuntimeError("No admissible K: relax the red lines or extend K_CANDIDATES.")
    k_star = min(admissible, key=lambda k: admissible[k]["tail"])
    if verbose:
        print(f"  => selected K* = {k_star}  (tail={admissible[k_star]['tail']:.4f})")
    return k_star, results


# ---------------------------------------------------------------------------
# Knowledge-base construction
# ---------------------------------------------------------------------------
def build_knowledge_base(latent, residual, k_star, seed=config.SEED):
    """Fit K*-means and estimate the per-cluster feature-wise threshold vector."""
    kmeans = KMeans(n_clusters=k_star, n_init=config.N_INIT,
                    max_iter=config.MAX_ITER, random_state=seed).fit(latent)
    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_

    D = residual.shape[-1]
    thresholds = np.zeros((k_star, D), dtype=np.float32)
    for c in range(k_star):
        mask = labels == c
        flat = residual[mask].reshape(-1, D)          # pool over windows and time
        thresholds[c] = np.percentile(flat, config.QUANTILE * 100, axis=0)

    return {
        "centroids": centroids.astype(np.float32),
        "thresholds": thresholds,
        "labels": labels.astype(np.int64),
        "k": k_star,
    }


def save_knowledge_base(path, kb):
    np.savez(path, **kb)
    print(f"Knowledge base saved to {path}  (K={kb['k']}, D={kb['thresholds'].shape[1]})")


def load_knowledge_base(path):
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    return dict(np.load(path, allow_pickle=False))
