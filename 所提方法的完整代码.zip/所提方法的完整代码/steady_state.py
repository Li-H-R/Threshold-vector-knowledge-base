"""Steady-state operating-mode extraction for wind turbine SCADA.

Splits a multivariate SCADA series into the four physical regimes plus three
transition/boundary regimes, yielding the seven operating-condition classes
used as the classification targets of the dual-task model:

    mode0      constant pitch (pre-MPPT)
    mode1      maximum power point tracking (MPPT)
    mode2      constant rotor speed
    mode3      constant power
    bnd_spd    speed  transition boundary
    bnd_pitch  pitch  transition boundary
    bnd_pwr    power  transition boundary

The algorithm is unsupervised and only relies on the pitch / rotor-speed /
power columns given in ``config.py``.
"""

from collections import Counter

import numpy as np
from scipy.stats import rankdata


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def find_segments_in_range(x, low, high, w):
    """Return contiguous runs of ``x`` inside (low, high] with length >= w."""
    segments = []
    start = None
    n = len(x)
    k = 5
    for i, v in enumerate(x):
        if low < v <= high:
            if start is None:
                start = i
        else:
            if start is not None:
                if i - start >= k * w:
                    segments.append((start, i))
                elif i - start >= w:
                    segments.append((start, i))
                start = None
    if start is not None and n - start >= w:
        segments.append((start, n))
    return segments


def refine_low_recursive(x, low_new, high, w, max_iter=100):
    """Recursively refine the lower bound to the most stable (low-variance) segment."""
    n = len(x)
    if n < 2 * w:
        segs = find_segments_in_range(x, low_new, high, w)
        if not segs:
            return x
        s, e = segs[0]
        return x[s:e]

    xmin = np.min(x)
    span = high - low_new
    k = 1.0
    best_segments = None

    for _ in range(max_iter):
        segments = find_segments_in_range(x, low_new, high, w)
        if not segments:
            k *= 0.5
            low_new = xmin + span * k
            continue

        seg0_len = segments[0][1] - segments[0][0]
        if (len(segments) > 1 and any((e - s) >= w for s, e in segments)) or seg0_len == w:
            best_segments = segments
            break

        if seg0_len > w:
            s, e = segments[0]
            xmin = np.min(x[s:e])
            span = high - xmin
            k = 1.0
            low_new = xmin + span * (2.0 / 3.0)
            continue

        k *= 0.5
        low_new = xmin + span * k

    if best_segments is None:
        best_segments = segments if segments else []
    if not best_segments:
        return x

    vars_ = np.array([np.var(x[s:e]) for s, e in best_segments])
    meds_ = np.array([np.median(x[s:e]) for s, e in best_segments])
    lens_ = np.array([e - s for s, e in best_segments])
    med_rank = rankdata(meds_)
    len_rank = rankdata(lens_)
    vars_rank = rankdata(-vars_)
    scores = vars_rank + len_rank

    s, e = best_segments[np.argmax(scores)]
    x_new = x[s:e]
    return refine_low_recursive(x_new, np.min(x_new), high, w, max_iter)


def mesh_search_recursive(x_series, w, k=1.0):
    """Adaptive grid search returning the steady-state (lower_bound, upper_bound)."""
    x = np.asarray(x_series)
    base_min, base_max = np.min(x), np.max(x)

    init_low = base_min + (base_max - base_min) * (4.0 / 5.0)
    result_series = refine_low_recursive(x, init_low, base_max * k, w)

    mean = np.median(result_series)
    std = np.std(result_series)
    lower_bound = mean - (3 * std) * 3
    result_series = x[x > lower_bound]

    mean = np.median(result_series)
    std = np.std(result_series)
    lower_bound = mean - 3 * std
    upper_bound = mean + 3 * std

    if lower_bound == upper_bound:
        lower_bound = lower_bound * 0.99

    return lower_bound, upper_bound


# ---------------------------------------------------------------------------
# Run detection
# ---------------------------------------------------------------------------
def find_runs_above_threshold(x, thr, w, M=2 / 3):
    """Contiguous runs of ``x`` above ``thr`` lasting at least ``w * M`` steps."""
    x = np.asarray(x)
    min_len = int(w * M)

    padded = np.concatenate([[0], (x > thr).view(np.int8), [0]])
    diff = np.diff(padded)

    starts = np.where(diff == 1)[0]
    ends = np.where(diff == -1)[0] - 1
    lengths = ends - starts + 1

    valid = lengths >= min_len
    return list(zip(starts[valid].tolist(), ends[valid].tolist()))


# ---------------------------------------------------------------------------
# Interval operations
# ---------------------------------------------------------------------------
def complement_in_parent_intervals(select_seg, parent_intervals):
    """Complement of ``select_seg`` inside ``parent_intervals``."""
    res = []
    for ps, pe in parent_intervals:
        subs = sorted(
            (max(s, ps), min(e, pe))
            for s, e in select_seg
            if not (e < ps or s > pe)
        )
        prev = ps
        for s, e in subs:
            if s > prev:
                res.append((prev, s - 1))
            prev = e + 1
        if prev <= pe:
            res.append((prev, pe))
    return res


def filter_intervals_by_length(intervals, w):
    return [(s, e) for s, e in intervals if (e - s + 1) >= w]


def merge_close_segments(segments, k):
    """Merge adjacent segments whose gap is smaller than ``k``."""
    if not segments:
        return []
    sorted_segs = sorted(segments, key=lambda x: x[0])
    merged = [list(sorted_segs[0])]
    for cur_s, cur_e in sorted_segs[1:]:
        last = merged[-1]
        if cur_s - last[1] < k:
            last[1] = max(last[1], cur_e)
        else:
            merged.append([cur_s, cur_e])
    return [tuple(seg) for seg in merged]


# ---------------------------------------------------------------------------
# Sliding-window generation
# ---------------------------------------------------------------------------
def _boundary_windows_one_side(X, segments, win, step, M, side):
    T, D = X.shape
    windows, intervals, seg_ids = [], [], []
    cross = int(win)

    for seg_id, (s, e) in enumerate(segments):
        seg_len = e - s + 1
        if seg_len < win:
            center = (s + e) // 2
            w_start = max(0, center - win // 2)
            w_end = w_start + win - 1
            if w_end >= T:
                w_end = T - 1
                w_start = w_end - win + 1
            w = X[w_start:w_end + 1]
            if w.shape[0] == win:
                windows.append(w)
                intervals.append((w_start, w_end))
                seg_ids.append(seg_id)
            continue

        anchor = s if side == "left" else e
        w_end = min(T, anchor + cross - 1)
        w_start = max(0, anchor - cross + 1)

        for cur_start in range(w_start, w_end + 1, step):
            cur_end = cur_start + win - 1
            if cur_end < T:
                windows.append(X[cur_start:cur_end + 1])
                intervals.append((cur_start, cur_end))
                seg_ids.append(seg_id)
            else:
                break

    out = np.stack(windows) if windows else np.empty((0, win, D))
    return out, intervals, seg_ids


def left_boundary_windows(X, segments, win, step=1, M=0.5):
    return _boundary_windows_one_side(X, segments, win, step, M, "left")


def right_boundary_windows(X, segments, win, step=1, M=0.5):
    return _boundary_windows_one_side(X, segments, win, step, M, "right")


def boundary_windows_both_sides(X, segments, win, step=1):
    wl, il, sl = left_boundary_windows(X, segments, win, step)
    wr, ir, sr = right_boundary_windows(X, segments, win, step)
    return np.concatenate([wl, wr], axis=0), il + ir, sl + sr


def mode_windows(X, segments, win, step=1):
    """Sliding windows sampled inside each segment."""
    X = np.asarray(X)
    windows, index_map = [], []
    for seg_id, (s, e) in enumerate(segments):
        if e - s + 1 < win:
            continue
        for i in range(s, e - win + 1, step):
            windows.append(X[i:i + win])
            index_map.append((seg_id, i))
    return np.array(windows), index_map


def find_best_filtered_value(x, thr, window_size, find_runs_fn, M=2 / 3):
    """Search the best filtered value and merge overly-close segments."""
    x = np.asarray(x, dtype=np.float64)
    best_segments = find_runs_fn(x, thr, w=window_size, M=M)

    if len(best_segments) > 1:
        gaps = np.array([best_segments[i + 1][0] - best_segments[i][1]
                         for i in range(len(best_segments) - 1)])
        small_gaps = gaps[gaps < window_size]
        most_common = int(Counter(small_gaps).most_common(1)[0][0]) if len(small_gaps) else 1
        merge_k = max(most_common, int(M * window_size))
        best_segments = merge_close_segments(best_segments, k=merge_k)

    return 0, best_segments


# ---------------------------------------------------------------------------
# Main: wind-turbine operating-mode extraction
# ---------------------------------------------------------------------------
def extract_wind_turbine_modes(data, col_pitch, col_speed, col_power,
                               window_size, M=2 / 3):
    """Extract the seven operating regimes from a raw SCADA matrix (T, D).

    Returns ``(mode0, mode1, mode2, mode3, bnd_spd, bnd_pitch, bnd_pwr)`` where
    each element is a ``(N, window_size, D)`` array (possibly empty).
    """
    power = data[:, col_power]
    speed = data[:, col_speed]
    pitch = data[:, col_pitch]

    a_pitch, _ = mesh_search_recursive(pitch, w=window_size)
    a_speed, _ = mesh_search_recursive(speed, w=window_size)
    a_power, _ = mesh_search_recursive(power, w=window_size)

    _fn = lambda x, thr, w, M=M: find_runs_above_threshold(x, thr, w, M)

    _, select_seg_B = find_best_filtered_value(pitch, a_pitch, window_size, _fn, M)
    _, select_seg1 = find_best_filtered_value(speed, a_speed, window_size, _fn, M)

    select_seg_C = complement_in_parent_intervals(
        select_seg_B + select_seg1, [(0, len(pitch) - 1)])

    _, select_seg_P = find_best_filtered_value(power, a_power, window_size, _fn, M)

    res_seg = complement_in_parent_intervals(select_seg_P, select_seg1)
    select_seg_S = filter_intervals_by_length(res_seg, w=window_size)

    data_s = data

    boundary_data_speed, _, _ = boundary_windows_both_sides(data_s, select_seg_S, win=window_size)
    boundary_data_pitch, _, _ = boundary_windows_both_sides(data_s, select_seg_B, win=window_size)
    boundary_data_power, _, _ = boundary_windows_both_sides(data_s, select_seg_P, win=window_size)

    mode0, _ = mode_windows(data_s, select_seg_B, win=window_size)
    mode1, _ = mode_windows(data_s, select_seg_C, win=window_size)
    mode2, _ = mode_windows(data_s, select_seg_S, win=window_size)
    mode3, _ = mode_windows(data_s, select_seg_P, win=window_size)

    return mode0, mode1, mode2, mode3, boundary_data_speed, boundary_data_pitch, boundary_data_power
