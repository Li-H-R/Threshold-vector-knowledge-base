# Threshold-Vector Knowledge Base for Wind Turbine Anomaly Detection

Reference implementation of the method described in:

> *Addressing residual heterogeneity in wind turbine anomaly monitoring via a
> threshold vector knowledge base* (Applied Energy, preprint).

Reconstruction-based anomaly detectors usually apply a **single global
threshold** to the reconstruction residual. Because normal residuals are highly
heterogeneous across operating conditions, a global threshold inflates false
alarms in some regions and misses faults in others. This repository implements
a **threshold-vector knowledge base** that partitions the operating envelope
directly in the learned encoder space and assigns a *feature-wise* threshold
vector to each region.

## Method overview

1. **Dual-task model** — an LSTM autoencoder that jointly reconstructs SCADA
   windows and classifies operating conditions, producing a 64-d encoder
   representation `h`.
2. **Latent-space clustering** — `k`-means over the encoder representations.
   The cluster count `K*` is chosen by a *within-cluster residual homogeneity*
   criterion (tail-ratio `P98 / P50` of the detection-sensitive residual),
   subject to three anti-fragmentation red lines (singleton ratio, coverage of
   well-populated clusters, median cluster size).
3. **Threshold vectors** — for each cluster and each feature, the threshold is
   the `98th` percentile of the pooled absolute residuals of the normal windows
   assigned to that cluster.
4. **Online detection** — a query window is assigned to its nearest cluster
   centroid; it is flagged if any feature's temporal-mean residual exceeds that
   cluster's threshold.

## Repository structure

```
config.py               all hyperparameters in one place
model.py                dual-task LSTM (reconstruction + classification)
steady_state.py         unsupervised operating-mode extraction (7 regimes)
data.py                 loading / standardisation / splitting / synthetic data
knowledge_base.py       K selection + threshold-vector construction
detect.py               online detection + metrics
train.py                stage 1: train the dual-task model
build_knowledge_base.py stage 2: select K and build the knowledge base
evaluate.py             stage 3: detect anomalies and report metrics
run_demo.py             end-to-end demo on synthetic data
data/README.md          expected input format
```

## Installation

```bash
pip install -r requirements.txt
```

Tested with Python 3.9+ and PyTorch 2.x (CPU or CUDA).

## Quick start

### Synthetic data (no real data needed)

```bash
python run_demo.py
```

This generates a toy wind-turbine series, then runs the three stages below.

### Real data

1. Put your normal SCADA series at `data/raw_data.npy` and (optionally) your
   labelled anomaly windows at `data/anomaly_data.npy` — see `data/README.md`.
2. Adjust `COL_POWER`, `COL_SPEED`, `COL_PITCH` and `DROP_TAIL_COLS` in
   `config.py` to match your column layout.
3. Run the three stages:

```bash
python train.py                      # trains and saves output/model.pt
python build_knowledge_base.py       # selects K*, saves output/knowledge_base.npz
python evaluate.py                   # reports F1 / precision / recall / AUC-ROC
```

`train.py` fits the standardiser on the training split only and saves the
calibration windows, so `build_knowledge_base.py` reuses exactly the same data
(no information leakage). All hyperparameters are in `config.py`.

## Reproducing the reported results

The reported numbers used two full-year SCADA datasets (1-min and 6-s
resolutions, 8 and 13 features). Provide the matching `raw_data.npy` /
`anomaly_data.npy` files and run the three commands with the default
hyperparameters in `config.py` (60 epochs, `K_CANDIDATES` up to 5000). Training
was done on an NVIDIA GPU; the knowledge-base construction (`k`-means up to
`K=5000`) is the dominant offline cost.

## Notes

- Only the **proposed method** is included. Baseline comparisons
  (TS-TCC, PatchTST, EDAE, ST-GNN, DUA-SVDD, RESCINet, CAE, MDAE, MLP-AE,
  PITG, CA-SCINet) and the seven thresholding strategies referenced in the
  paper are not part of this repository.
- Trained weights and datasets are intentionally excluded; the scripts
  regenerate everything from the input `.npy` files.

## License

To be determined.
