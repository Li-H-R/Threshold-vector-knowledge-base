# Data format

The pipeline reads two optional files from this directory.  Neither is included
in the repository — drop your own files here and the scripts will pick them up.

## `raw_data.npy` — normal SCADA (required)

A single `.npy` file containing a 2-D float array of shape `(T, D)`:

* `T` — number of consecutive SCADA time steps (one full year or longer).
* `D` — number of columns.

By default the last two columns are treated as **non-feature** columns
(e.g. timestamps / IDs) and are dropped (`DROP_TAIL_COLS = 2` in `config.py`),
so for the Huanghua layout the file has `8 + 2 = 10` columns:

| index | 0       | 1          | 2        | 3            | 4–6          | 7            | 8–9         |
|-------|---------|------------|----------|--------------|--------------|--------------|-------------|
| signal| power   | rotor speed| wind speed| wind direction| pitch angles | gearbox oil temp | non-feature |

If your file already contains features only, set `DROP_TAIL_COLS = 0`.
The three columns used by the steady-state operating-mode extraction are
configured via `COL_POWER`, `COL_SPEED`, `COL_PITCH` in `config.py`.

Example:

```python
import numpy as np
raw = np.load("data/raw_data.npy")          # shape (T, 10)
```

## `anomaly_data.npy` — labelled anomalies (optional, evaluation only)

A `.npy` file containing either:

* a `dict` `{name: window_array}` where each `window_array` is a float array of
  shape `(N, T, D)` (already windowed with `T = WINDOW_SIZE`), or
* a single float array of shape `(N, T, D)`.

Only the feature columns `D` (without the trailing non-feature columns) are
expected here.  Anomaly windows are used solely to build the test set; they do
not participate in training, clustering or threshold estimation.

Example:

```python
import numpy as np
anom = np.load("data/anomaly_data.npy", allow_pickle=True).item()
# anom: {"pitch_fault_0": (N0, 10, 8), "pitch_fault_1": (N1, 10, 8), ...}
```

## No data?

Run `python run_demo.py`, which generates a synthetic wind-turbine series and
exercises the whole pipeline end-to-end.
