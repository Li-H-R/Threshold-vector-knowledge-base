"""Train the dual-task LSTM (reconstruction + operating-condition classification).

Saves ``output/model.pt`` (weights + config + standardizer) and
``output/calibration_X.npy`` (the standardised normal training windows used to
build the knowledge base), so the later stages reload exactly the same data.
"""

import argparse
import os
import random

import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader

import config
import data as data_mod
from model import DualTaskLSTM


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def train_one_epoch(model, loader, optimizer, device):
    model.train()
    rec_sum = clf_sum = 0.0
    correct = total = 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        optimizer.zero_grad()
        recon, clf_logits, _ = model(xb)
        loss_rec = F.mse_loss(recon, xb)
        loss_clf = F.cross_entropy(clf_logits, yb)
        loss = config.LAMBDA_REC * loss_rec + config.LAMBDA_CLF * loss_clf
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        rec_sum += loss_rec.item()
        clf_sum += loss_clf.item()
        correct += (clf_logits.argmax(1) == yb).sum().item()
        total += yb.size(0)
    n = len(loader)
    return rec_sum / n, clf_sum / n, correct / total


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    rec_sum = clf_sum = 0.0
    correct = total = 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        recon, clf_logits, _ = model(xb)
        rec_sum += F.mse_loss(recon, xb).item()
        clf_sum += F.cross_entropy(clf_logits, yb).item()
        correct += (clf_logits.argmax(1) == yb).sum().item()
        total += yb.size(0)
    n = len(loader)
    return rec_sum / n, clf_sum / n, correct / total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=config.RAW_DATA_PATH)
    ap.add_argument("--out", default=config.OUTPUT_DIR)
    ap.add_argument("--epochs", type=int, default=config.EPOCHS)
    ap.add_argument("--batch-size", type=int, default=config.BATCH_SIZE)
    ap.add_argument("--lr", type=float, default=config.LR)
    ap.add_argument("--seed", type=int, default=config.SEED)
    args = ap.parse_args()

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    os.makedirs(args.out, exist_ok=True)
    print(f"[Info] device={device}")

    # 1. load + extract operating modes
    modes = data_mod.load_raw_windows(
        args.data, config.WINDOW_SIZE, config.COL_PITCH, config.COL_SPEED,
        config.COL_POWER, config.M, drop_tail_cols=config.DROP_TAIL_COLS)
    print("[1/5] modes:", {k: v.shape[0] for k, v in modes.items()})

    # 2. balance + split
    modes = data_mod.balance_classes(modes, method=config.BALANCE_CLASSES, seed=args.seed)
    (x_train, y_train), (x_val, y_val) = data_mod.split_train_val_by_class(
        modes, val_ratio=config.VAL_RATIO, seed=args.seed)
    input_dim = x_train.shape[2]
    print(f"[2/5] train={x_train.shape} val={x_val.shape} input_dim={input_dim}")

    # 3. standardise (fit on training data only)
    std = data_mod.Standardizer.fit(x_train)
    x_train_n = std.transform(x_train).astype(np.float32)
    x_val_n = std.transform(x_val).astype(np.float32)

    train_loader = DataLoader(data_mod.ModeDataset(x_train_n, y_train),
                              batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(data_mod.ModeDataset(x_val_n, y_val),
                            batch_size=args.batch_size, shuffle=False)

    # 4. model
    model = DualTaskLSTM(
        input_dim, hidden_dim=config.HIDDEN_DIM, latent_dim=config.LATENT_DIM,
        num_layers=config.NUM_LAYERS, num_classes=config.NUM_CLASSES,
        dropout=config.DROPOUT).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=args.lr,
                            weight_decay=config.WEIGHT_DECAY)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs)

    # 5. train
    best_val_rec = float("inf")
    for epoch in range(1, args.epochs + 1):
        rec_l, clf_l, acc = train_one_epoch(model, train_loader, optimizer, device)
        val_rec, val_clf, val_acc = evaluate(model, val_loader, device)
        scheduler.step()
        is_best = val_rec < best_val_rec
        if epoch % 5 == 0 or is_best or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  Rec={rec_l:.4f} Clf={clf_l:.4f} "
                  f"Acc={acc:.4f}  ValRec={val_rec:.6f} ValClf={val_clf:.4f} "
                  f"ValAcc={val_acc:.4f}" + ("  <- best" if is_best else ""))
        if is_best:
            best_val_rec = val_rec
            torch.save({
                "model_state_dict": model.state_dict(),
                "model_config": {
                    "input_dim": input_dim,
                    "num_classes": config.NUM_CLASSES,
                    "hidden_dim": config.HIDDEN_DIM,
                    "latent_dim": config.LATENT_DIM,
                    "num_layers": config.NUM_LAYERS,
                    "dropout": config.DROPOUT,
                },
                "standardizer": {"mean": std.mean, "std": std.std},
                "best_val_rec": best_val_rec,
                "epoch": epoch,
            }, os.path.join(args.out, "model.pt"))
            # save the calibration (training) windows for knowledge-base building
            np.save(os.path.join(args.out, "calibration_X.npy"), x_train_n)

    # save the validation windows as the held-out normal set for evaluation
    np.save(os.path.join(args.out, "val_X.npy"), x_val_n)
    np.save(os.path.join(args.out, "val_y.npy"), y_val.astype(np.int64))

    print(f"\nTraining done. Best Val Rec MSE = {best_val_rec:.6f}")
    print(f"Saved model -> {os.path.join(args.out, 'model.pt')}")


if __name__ == "__main__":
    main()
