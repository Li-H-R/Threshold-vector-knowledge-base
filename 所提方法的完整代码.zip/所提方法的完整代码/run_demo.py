"""End-to-end demo on synthetic SCADA data (no real data required).

Generates a toy wind-turbine series with realistic operating regimes, then runs
the exact three-stage workflow a user would run on real data:

    python train.py                # train the dual-task model
    python build_knowledge_base.py # select K and build the threshold vectors
    python evaluate.py             # detect anomalies and report metrics

The results on synthetic data are illustrative only -- they confirm the
pipeline runs end-to-end, not the paper's reported numbers.
"""

import os
import subprocess
import sys

import numpy as np

import config
import data as data_mod


def main():
    os.makedirs("data", exist_ok=True)

    print("Generating synthetic SCADA data ...")
    raw, anomaly = data_mod.generate_synthetic_data(T=12000, D=8,
                                                    window_size=config.WINDOW_SIZE,
                                                    seed=config.SEED)
    # Append 2 trailing non-feature columns so the default DROP_TAIL_COLS=2 path
    # is exercised exactly as with the real Dataset-1 layout.
    tail = np.zeros((raw.shape[0], 2), dtype=np.float32)
    raw_with_tail = np.concatenate([raw, tail], axis=1)
    np.save(config.RAW_DATA_PATH, raw_with_tail)
    np.save(config.ANOMALY_DATA_PATH, {"pitch_anomaly": anomaly})
    print(f"  raw_data.npy    = {raw_with_tail.shape} (8 features + 2 tail cols)")
    print(f"  anomaly_data.npy= {anomaly.shape} windows\n")

    cmds = [
        [sys.executable, "train.py", "--epochs", "10", "--batch-size", "512"],
        [sys.executable, "build_knowledge_base.py",
         "--k-list", "1", "7", "15", "50", "100"],
        [sys.executable, "evaluate.py"],
    ]
    for cmd in cmds:
        print("$ " + " ".join(cmd) + "\n" + "-" * 60)
        r = subprocess.run(cmd, cwd=os.path.dirname(os.path.abspath(__file__)))
        if r.returncode != 0:
            raise SystemExit(f"Step failed: {' '.join(cmd)}")
        print("-" * 60 + "\n")

    print("Demo finished. Replace data/raw_data.npy and data/anomaly_data.npy "
          "with real SCADA data (see README.md) and rerun the three commands "
          "with the full hyperparameters in config.py.")


if __name__ == "__main__":
    main()
