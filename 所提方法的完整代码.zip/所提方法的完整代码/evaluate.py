"""Evaluate the threshold-vector knowledge base on held-out normal + anomaly data.

Loads the trained model, standardizer and knowledge base produced by
``train.py`` and ``build_knowledge_base.py``, then scores a balanced test set
built from the held-out normal windows (``output/val_X.npy``) and the anomaly
windows (``data/anomaly_data.npy``).
"""

import argparse
import os

import numpy as np
import torch

import config
import data as data_mod
import detect as detect_mod
import knowledge_base as kb
from model import DualTaskLSTM


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=config.OUTPUT_DIR)
    ap.add_argument("--anomaly", default=config.ANOMALY_DATA_PATH)
    ap.add_argument("--seed", type=int, default=config.SEED)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt = torch.load(os.path.join(args.out, "model.pt"), map_location=device,
                      weights_only=False)
    model = DualTaskLSTM(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    std = data_mod.Standardizer(
        mean=np.asarray(ckpt["standardizer"]["mean"], dtype=np.float32),
        std=np.asarray(ckpt["standardizer"]["std"], dtype=np.float32))

    kb_obj = kb.load_knowledge_base(os.path.join(args.out, "knowledge_base.npz"))
    centroids = kb_obj["centroids"]
    thresholds = kb_obj["thresholds"]

    # held-out normal windows + anomaly windows -> balanced test set
    x_norm = np.load(os.path.join(args.out, "val_X.npy"))
    x_anom = data_mod.load_anomaly_windows(args.anomaly, config.WINDOW_SIZE)
    x_test, y_true = data_mod.build_balanced_test_set(x_norm, x_anom, seed=args.seed)
    print(f"Balanced test set: {x_test.shape}  "
          f"(normal={int(np.sum(y_true == 0))}, anomaly={int(np.sum(y_true == 1))})")

    x_t = torch.from_numpy(x_test).to(device)
    with torch.no_grad():
        recon, _, _, latent = model(x_t, return_latent=True)
    recon = recon.cpu().numpy()
    latent = latent.cpu().numpy()

    preds, _ = detect_mod.detect(recon, x_test, latent, centroids, thresholds)
    scores = detect_mod.anomaly_scores(recon, x_test, latent, centroids, thresholds)
    detect_mod.print_report(y_true, preds, scores)


if __name__ == "__main__":
    main()
