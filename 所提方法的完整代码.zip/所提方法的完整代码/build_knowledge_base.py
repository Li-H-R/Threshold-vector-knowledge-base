"""Build the threshold-vector knowledge base from a trained dual-task model.

Loads ``output/model.pt`` and ``output/calibration_X.npy``, extracts encoder
representations and absolute residuals on the calibration windows, selects K*
via residual-homogeneity, and saves the knowledge base to
``output/knowledge_base.npz``.
"""

import argparse
import os

import numpy as np
import torch

import config
import data as data_mod
import knowledge_base as kb
from model import DualTaskLSTM


@torch.no_grad()
def extract_latent_residual(model, std, x_cal, device):
    """Return (latent, |x - x̂|) for the calibration windows."""
    model.eval()
    x = torch.from_numpy(std.transform(x_cal).astype(np.float32)).to(device)
    recon, _, _, latent = model(x, return_latent=True)
    return latent.cpu().numpy(), torch.abs(recon - x).cpu().numpy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=config.OUTPUT_DIR)
    ap.add_argument("--seed", type=int, default=config.SEED)
    ap.add_argument("--k-list", type=int, nargs="+", default=config.K_CANDIDATES)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt_path = os.path.join(args.out, "model.pt")
    cal_path = os.path.join(args.out, "calibration_X.npy")
    if not os.path.exists(ckpt_path):
        raise SystemExit(f"Missing {ckpt_path}; run train.py first.")

    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model = DualTaskLSTM(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    std = data_mod.Standardizer(
        mean=np.asarray(ckpt["standardizer"]["mean"], dtype=np.float32),
        std=np.asarray(ckpt["standardizer"]["std"], dtype=np.float32))

    x_cal = np.load(cal_path)
    print(f"Extracting latent + residuals for {len(x_cal)} calibration windows ...")
    latent, residual = extract_latent_residual(model, std, x_cal, device)
    print(f"  latent={latent.shape}  residual={residual.shape}")

    print("\nSelecting K by residual homogeneity (tail-ratio) ...")
    k_star, results = kb.select_cluster_count(latent, residual, k_candidates=args.k_list,
                                              seed=args.seed, verbose=True)

    print(f"\nBuilding knowledge base with K*={k_star} ...")
    kb_obj = kb.build_knowledge_base(latent, residual, k_star, seed=args.seed)
    kb.save_knowledge_base(os.path.join(args.out, "knowledge_base.npz"), kb_obj)


if __name__ == "__main__":
    main()
