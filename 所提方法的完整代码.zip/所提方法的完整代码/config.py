"""Central configuration for the threshold-vector knowledge base method.

All hyperparameters are gathered here so the method can be reproduced by
running the provided scripts without touching the source.  Adjust the data
column indices (``COL_*``) to match your own SCADA layout.
"""

# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
# Expected inputs (see data/README.md for the exact format):
#   data/raw_data.npy      : (T, D) normal SCADA feature matrix (or (T, D+2)
#                            when the last two columns are non-feature columns
#                            such as timestamps/ids -- set DROP_TAIL_COLS=2 then).
#   data/anomaly_data.npy  : dict {name: (N, T, D)} of already-windowed
#                            anomaly segments (optional; only used for evaluation).
RAW_DATA_PATH = "data/raw_data.npy"
ANOMALY_DATA_PATH = "data/anomaly_data.npy"

WINDOW_SIZE = 10          # T : time steps per window
DROP_TAIL_COLS = 2        # number of trailing non-feature columns to drop from raw_data.npy

# Column indices (0-based) of the three signals used by the steady-state
# operating-mode extraction.  Huanghua (1-min) layout: 0=power, 1=rotor speed,
# 4..6=pitch angles.
COL_POWER = 0
COL_SPEED = 1
COL_PITCH = 4
M = 2.0 / 3.0             # window purity threshold for steady-state extraction

# Operating-condition classes extracted by steady_state.py (always 7).
CLASS_NAMES = ["mode0", "mode1", "mode2", "mode3", "bnd_spd", "bnd_pitch", "bnd_pwr"]

# ---------------------------------------------------------------------------
# Model (dual-task LSTM: reconstruction + operating-condition classification)
# ---------------------------------------------------------------------------
HIDDEN_DIM = 128
LATENT_DIM = 64
NUM_LAYERS = 4
DROPOUT = 0.1
NUM_CLASSES = 7           # number of operating-condition classes

# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------
EPOCHS = 60
BATCH_SIZE = 1024
LR = 1e-3
WEIGHT_DECAY = 1e-4
LAMBDA_REC = 1.0          # weight of the reconstruction loss
LAMBDA_CLF = 1.0          # weight of the classification loss
VAL_RATIO = 0.2           # per-class validation fraction
BALANCE_CLASSES = "oversample"   # "oversample" | "undersample" | None
SEED = 42

# ---------------------------------------------------------------------------
# Clustering / knowledge-base construction
# ---------------------------------------------------------------------------
K_CANDIDATES = [1, 7, 10, 15, 50, 100, 500, 1000, 2000, 3000, 4000, 5000]
QUANTILE = 0.98           # upper-tail quantile for the per-cluster thresholds
EPS = 1e-8                # numerical guard for division

# Red-line (anti-fragmentation) constraints used by K selection.
MAX_SINGLETON_RATIO = 0.10        # singleton-cluster ratio
MIN_WELL_POPULATED_RATIO = 0.70   # fraction of windows in clusters with >= WELL_POPULATED_SIZE samples
WELL_POPULATED_SIZE = 30
MIN_MEDIAN_CLUSTER_SIZE = 10

N_INIT = 10               # k-means n_init
MAX_ITER = 300            # k-means max_iter

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
OUTPUT_DIR = "output"
