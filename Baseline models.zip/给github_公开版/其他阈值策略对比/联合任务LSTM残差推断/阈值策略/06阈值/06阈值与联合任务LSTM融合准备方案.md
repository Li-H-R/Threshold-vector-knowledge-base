# 06 阈值与联合任务 LSTM 融合：异常检测前准备方案

## 0. 本文档的范围与当前停止点

本文档说明如何把 06 论文提出的 **Uncertainty-informed Dynamic Threshold（UDT）**
接到本项目已经训练完成的联合任务 LSTM 后面。目标是保持模型、输入、残差和主异常得分
不变，只替换阈值策略，并为后续分别检测一个分钟级数据集和一个秒级数据集做好准备。

本轮只完成方案设计，不执行以下操作：

- 不读取 `测试集数据/**` 中的任何数组；
- 不读取既有 `*实验结果/**` 作为 06 的选参依据；
- 不计算测试得分；
- 不生成异常标签或报警；
- 不计算 Precision、Recall、F1、PR-AUC、误报率、检测延迟或事件级指标；
- 不根据测试表现选择 `alpha`、`beta`、`c` 或 MC Dropout 次数；
- 不创建或运行真实数据检测脚本。

当前允许使用的内容只有：

- 06 论文和作者公开代码，用于确认公式与实现边界；
- 已训练完成的两个联合任务 LSTM checkpoint；
- 两套纯正常阈值标定数据；
- 00 方案冻结的收缩 Mahalanobis 状态、正常标定得分和固定 98% 阈值；
- 固定随机种子生成的合成数组，用于将来的单元测试。

实现阶段最多推进到：

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1 / CALIBRATED_DATASET2
→ READY_FOR_TEST
→ 停止
```

`READY_FOR_TEST` 只表示 UDT 的正常参考 ECDF、不确定性尺度、正常验证统计量和阈值缩放
参数已经在纯正常数据上拟合并冻结，不表示已执行异常检测。

> 执行更新（2026-11-05）：上述内容是准备阶段的冻结边界。用户随后已明确授权异常检测，
> 分钟级与秒级各 5 个测试 seed 均已完成，结果独立保存于 `06实验结果/`；正常标定工件未被改写。

---

## 1. 参考依据与复现定位

### 1.1 统一实验约束

本方案遵循 `阈值策略/统一阈值实验工作流.md` 和 demo 的统一口径：

- 所有阈值方案共用同一个训练完成的联合任务 LSTM；
- 共用标准化空间绝对重构残差、窗口时间均值和收缩 Mahalanobis 主得分；
- 06 不重新训练 LSTM，不修改 checkpoint 权重和网络结构；
- 分钟级与秒级分别使用各自模型、正常标定数据、00 得分状态和 06 工件；
- 主实验固定 `K=1, M=1`；
- 最终分钟级与秒级分别检测、分别评价、分别报告；
- 06 增加的多次随机前向只用于估计不确定性，最终参与超阈值比较的主异常得分仍是统一的确定性 Mahalanobis 得分。

因此，06 的公平对照链路固定为：

```text
同一个确定性 Mahalanobis score
        │
        ├── 00：固定 98% 阈值
        │
        └── 06：固定 98% 阈值 - 不确定性修正量
```

不能把 MC Dropout 后验均值得分替换成 06 的主异常得分，否则实验同时改变了“得分”和
“阈值”，不能再把性能差异只归因于阈值策略。

### 1.2 06 论文方法卡

| 项目 | 内容 |
|---|---|
| 标题 | *Uncertainty-informed dynamic threshold for time series anomaly detection* |
| 作者 | Jungmin Lee, Jiyoon Lee, Seoung Bum Kim |
| 期刊 | Expert Systems with Applications, 278, 2025, 127379 |
| DOI | `10.1016/j.eswa.2025.127379` |
| 本地全文 | `阈值策略/06阈值/06.pdf` |
| PDF SHA-256 | `350ad34cf0539775dec37299ab340891c143a87c34cac3adae0c0c81749778c9` |
| 公开代码 | <https://github.com/jungminkr9195/UDT> |
| 方法简称 | UDT |
| 关键位置 | 第 3.1、3.2 节，公式 (2)-(8)，Algorithm 1 |
| 输入 | 固定异常得分、MC Dropout 后验得分、正常参考得分分布 |
| 输出 | 每个样本一个动态阈值 |
| 推理成本 | 每个样本需要多次随机前向，论文默认后验样本数为 10 |

论文链路为：

```text
训练完成的 backbone
→ MC Dropout 得到 M 个后验异常得分
→ 用正常参考得分 ECDF 转成 M 个异常概率
→ 计算 aleatoric uncertainty 和 epistemic uncertainty
→ 对齐两种不确定性的尺度并加权
→ 用正常验证不确定性的均值、标准差标准化
→ 修正固定阈值，得到逐样本动态阈值
```

### 1.3 复现类型

本项目应标记为 **UDT 阈值模块迁移实现**，不能写成完整严格复现，原因如下：

1. 论文基准实验使用 LSTM encoder-decoder 或 Anomaly Transformer，本项目固定使用联合任务 LSTM-AE；
2. 论文使用其 backbone 自身的异常得分，本项目固定使用收缩 Mahalanobis 得分；
3. 本项目必须复用 00 的固定 98% 阈值，而不是复制论文对不同数据集使用的不同异常比例；
4. 论文及公开代码中的 `alpha` 明显依赖数据集尺度，不能直接迁移；
5. 作者公开代码把测试不确定性参与两种不确定性的尺度对齐，本项目禁止这种测试泄漏；
6. 作者公开代码在评价阶段使用真实标签做 point-adjust，本项目主实验禁止使用；
7. 论文公式与公开代码对 `beta` 权重方向的写法不一致，需要在本项目中冻结唯一语义；
8. 本项目模型虽然包含 `dropout=0.1`，但现有公共推理函数始终调用 `eval()`，必须增加仅供 UDT 使用的随机推理适配层。

迁移保留的核心是：

> 在不改变确定性主异常得分的前提下，用同一已训练模型的 MC Dropout 后验得分估计逐样本不确定性，并用该不确定性对固定阈值做逐样本修正。

---

## 2. 固定模型、数据、残差与得分映射

### 2.1 分钟级和秒级的一一对应关系

| 项目 | 分钟级 | 秒级 |
|---|---|---|
| 数据集标识 | `dataset1` | `dataset2` |
| 时间尺度 | 1 分钟级 | 秒级 |
| checkpoint | `models/dataset1_joint_seed10.pth` | `models/dataset2_joint_seed10.pth` |
| checkpoint SHA-256 | `adc97f5c48eb4b8e15dab7fa7ac09afe54cc01f88dab8986c5f7340daa96a4fa` | `ec92a82289f8e0e1f497570eedc9c008e19b86d70a24982d4a9d83fb19718d61` |
| 模型窗口长度 | 10 | 10 |
| 特征维数 | 8 | 15 |
| LSTM 层数 | 4 | 4 |
| checkpoint dropout | 0.1 | 0.1 |
| 正常标定源 | `正常数据/阈值标定集.npz` | `正常数据/new_raw_阈值标定集.npz` |
| 正常窗口数 | 1960 | 20000 |
| 正常标定 SHA-256 | `99376a1f9cb781b0f51be4fe61f4cca64c880e27b5cf742cc942ccd8ac7cd42d` | `a95fd8ce46860252f2ea01bd33f26fc39f467be43316cd654cd3d0b6e62cfabc` |
| 标签审计 | 1960 个 `y=0` | 20000 个 `y=0` |
| 00 得分状态 | `00阈值/artifacts/formal_dataset1/score_state.npz` | `00阈值/artifacts/formal_dataset2/score_state.npz` |
| 00 正常得分 | `00阈值/artifacts/formal_dataset1/calibration_scores.npy` | `00阈值/artifacts/formal_dataset2/calibration_scores.npy` |
| 00 固定阈值 | `5.120514686100674` | `6.838050707446403` |
| 06 工件目录 | `06阈值/artifacts/formal_dataset1` | `06阈值/artifacts/formal_dataset2` |

固定映射为：

```text
分钟级正常标定数据
→ dataset1 模型
→ dataset1 的 00 Mahalanobis 状态和固定阈值
→ formal_dataset1 UDT 工件

秒级正常标定数据
→ dataset2 模型
→ dataset2 的 00 Mahalanobis 状态和固定阈值
→ formal_dataset2 UDT 工件
```

禁止将两个时间尺度的正常数据合并拟合一个 UDT 状态，也禁止交叉使用模型、得分状态、
固定阈值或 UDT 工件。

### 2.2 固定残差与确定性主异常得分

对窗口 `X_i∈R^(10×D)`，模型在确定性 `eval()` 模式下输出重构结果。固定残差向量为：

\[
R_i=\frac{1}{10}\sum_{t=1}^{10}|\hat X_{i,t}-X_{i,t}|\in\mathbb{R}^{D}.
\]

残差位于 checkpoint 对应的标准化空间。固定主异常得分为：

\[
s_i=\sqrt{(R_i-\mu)^T\Omega(R_i-\mu)},
\]

其中 `μ` 和 `Ω` 直接加载对应 00 正式工件，不允许在 06 中重新拟合。

后续真实检测时用于最终比较的仍然是这个确定性 `s_i`：

\[
\text{point\_pred}_i=\mathbb{1}(s_i>\delta_{d,i}).
\]

当前准备阶段只冻结产生 `δ_d` 所需的状态，不执行上述判定。

### 2.3 秒级标定数据无需连续时间流

`new_raw_阈值标定集.npz` 是从全部合法窗口起点中均匀抽取的 20000 个正常窗口，不是逐秒
连续序列。该文件不适合依赖历史滑窗更新的 04 ASPOT，但 06 UDT 是逐样本不确定性阈值，
论文也明确将“不建模数据和不确定性的时间属性”列为限制。因此：

- 06 不需要用过去样本更新阈值；
- 06 的阈值只依赖当前窗口的 MC Dropout 不确定性和冻结状态；
- 秒级 20000 个正常抽样窗口可用于 UDT 标定；
- 采样频率只影响未来报警持续时间和延迟的物理解释，不改变 UDT 公式。

---

## 3. UDT 数学合同

### 3.1 随机后验得分

对同一个输入窗口 `x`，保持模型权重不变，只启用 checkpoint 中已经存在的 LSTM dropout，
执行 `M` 次无梯度前向，得到：

\[
s^{(1)}(x),s^{(2)}(x),\ldots,s^{(M)}(x).
\]

每次随机得分仍使用相同的残差定义和冻结的 00 Mahalanobis 状态。06 不允许为随机残差重新
拟合中心、协方差或阈值。

推荐首版冻结：

```text
posterior_samples = 10
dropout_probability = checkpoint 中的 0.1
mc_seed = 20261105
score_state = 对应 dataset 的 00 正式状态
```

### 3.2 ECDF 异常概率

设对应数据集的纯正常确定性参考得分为：

\[
S_{ref}=\{s_1^{ref},s_2^{ref},\ldots,s_N^{ref}\}.
\]

第 `m` 次随机前向对应的异常概率定义为：

\[
p_m(x)=\frac{1}{N}\sum_{j=1}^{N}
\mathbb{1}\left(s_j^{ref}\leq s^{(m)}(x)\right).
\]

实现应先排序 `S_ref`，再使用：

```python
p = np.searchsorted(sorted_reference_scores, stochastic_score, side="right") / N
```

必须固定 `side="right"`，保证等于参考得分的样本计入 ECDF。正式状态应保存排序后参考得分
或保存其逐元素一致副本及 SHA-256。

本合同采用作者公开代码可执行的口径：随机候选得分与确定性正常参考得分 ECDF 比较。
若将来要按论文公式为每个后验样本分别生成一套参考分布，必须建立新的策略 ID，不能覆盖
本主方案。

### 3.3 Aleatoric 与 epistemic uncertainty

按照论文公式 (3)、(4)：

\[
u_a(x)=\frac{1}{M}\sum_{m=1}^{M}p_m(x)(1-p_m(x)),
\]

\[
u_e(x)=\frac{1}{M}\sum_{m=1}^{M}
\left(p_m(x)-\bar p(x)\right)^2.
\]

`u_e` 使用总体方差，即 `ddof=0`，与作者公开代码一致。必须满足：

```text
0 <= p_m <= 1
0 <= u_a <= 0.25
u_e >= 0
所有结果为有限数
```

### 3.4 两类不确定性的尺度对齐

只在纯正常标定窗口上计算：

\[
\kappa=\frac{\operatorname{mean}(u_a^{cal})}
{\operatorname{mean}(u_e^{cal})},
\qquad
u_e^{scaled}(x)=\kappa u_e(x).
\]

公开代码把训练不确定性和测试不确定性合并后再计算比例，存在测试泄漏。本项目必须改为：

```text
kappa_source = normal_calibration_only
test_uncertainty_used_for_kappa = false
```

若 `mean(u_e)` 小于冻结的数值容差，说明 MC Dropout 没有真正产生后验差异或该模型上的
epistemic uncertainty 不可辨识。正式准备必须失败，不得静默加一个 epsilon 后继续。

### 3.5 总不确定性的唯一 `beta` 语义

论文公式 (6) 写为：

\[
u(x)=\beta u_a(x)+(1-\beta)u_e^{scaled}(x).
\]

作者公开代码则把 `beta` 用作 epistemic 项的权重。为消除歧义，本项目冻结为论文语义：

```text
beta_semantics = weight_on_aleatoric_uncertainty
beta = 0.5
```

首版使用 `beta=0.5` 时，两种写法数值相同，但代码和工件仍必须记录语义。单元测试必须
验证 `beta=1` 只保留 `u_a`，`beta=0` 只保留尺度对齐后的 `u_e`。

### 3.6 正常验证统计量与动态阈值

在纯正常标定数据上得到总不确定性均值和总体标准差：

\[
\mu_v=\operatorname{mean}(u^{cal}),\qquad
\sigma_v=\operatorname{std}(u^{cal},ddof=0).
\]

对任一未来样本：

\[
z_u(x)=\frac{u(x)-(1+c)\mu_v}{\sigma_v},
\]

\[
\delta_d(x)=\delta_f-\alpha z_u(x).
\]

其中：

- `δ_f` 必须加载 00 对应数据集的固定 98% 阈值；
- `c` 控制正常不确定性中心的补偿；
- `alpha` 把标准化不确定性映射到 Mahalanobis 得分单位；
- `δ_d` 是逐样本阈值，但不是依赖历史的时间动态阈值。

必须检查 `sigma_v` 显著大于 0、全部动态阈值有限。主方案不静默裁剪负阈值，也不静默设置
上界。若正式正常标定审计出现非正阈值，应停止并重新审查预先声明的缩放规则；任何裁剪版
必须使用独立策略 ID。

---

## 4. MC Dropout 与现有联合任务 LSTM 的衔接

### 4.1 现有公共推理不能直接用于 UDT 随机前向

当前 `main.py` 中 `load_joint()` 会执行 `model.eval()`，`compute()` 在
`torch.no_grad()` 下做单次确定性前向。这是 00-05 和 06 主异常得分应继续使用的公共路径。

06 不能把公共 `compute()` 改成默认随机，否则会改变所有基线。应新增独立适配函数，例如：

```python
def mc_dropout_mahalanobis_scores(
    windows,
    model_bundle,
    score_state,
    posterior_samples,
    seed,
):
    """权重冻结，仅启用 LSTM 层间 dropout，返回 (M, N) 随机得分。"""
```

### 4.2 只激活现有 LSTM dropout

`LSTMAEClassifier` 没有 BatchNorm，dropout 位于 4 层 encoder/decoder LSTM 的层间连接。
推荐状态切换为：

```python
model.eval()
model.encoder.train()  # 只激活 encoder LSTM 内部 dropout
model.decoder.train()  # 只激活 decoder LSTM 内部 dropout

with torch.no_grad():
    # M 次前向；不得 backward，不得 optimizer.step
    ...

model.eval()           # 无论成功或异常都恢复
```

应通过 `try/finally` 恢复 `eval()`。不得调用整个训练流程，不得创建优化器，不得改变任何
parameter、buffer 或 checkpoint 文件。

作者公开实现的 MC 循环没有在相关片段中显式重新启用 dropout；直接照抄可能得到完全相同
的 M 次输出。因此必须设置以下门禁：

```text
posterior_score_variance_mean > tolerance
at_least_two_distinct_posterior_scores_per_audited_batch = true
model_parameter_hash_before == model_parameter_hash_after
model_mode_after_prepare == eval
```

若门禁失败，状态为 `CALIBRATION_BLOCKED_MC_DROPOUT_INACTIVE`。

### 4.3 随机种子与批处理可复现性

MC Dropout 结果会受随机数状态、设备和批大小影响。冻结工件至少记录：

- Python、NumPy、PyTorch 随机种子；
- CPU/CUDA 设备和 PyTorch 版本；
- 确定性算法设置；
- posterior sample 数；
- inference batch size；
- 每次后验前向的派生种子；
- 输入窗口的固定顺序；
- 是否允许跨设备逐位一致，或只要求数值容差一致。

推荐每个后验样本使用 `base_seed + m`，在处理 dataset1 与 dataset2 时加入独立 dataset
偏移，防止两个工件意外共享完全相同的随机流。

同一正式工件的准备过程必须固定 batch size。分批和一次性前向不一定产生同一组 dropout
mask，因此不能宣称两者逐位一致；应测试“同一冻结配置与同一批处理方案可重放一致”。

---

## 5. `alpha`、`beta`、`c` 的冻结规则

### 5.1 不能直接复制论文的 `alpha`

作者公开脚本对不同数据集使用的 `alpha` 跨越多个数量级，例如 SWaT 为 `0.001`、PSM 为
`0.05`、WADI 为 `110000`。论文也明确指出 `alpha` 需要按数据集调整。因此，本项目不能：

- 直接选择论文中表现最好的某个数据集的 `alpha`；
- 查看本项目测试指标后反向调整 `alpha`；
- 分别为分钟级和秒级手工试到测试 F1 最好；
- 把不同 `alpha` 的最佳测试结果拼成主结果。

### 5.2 推荐的无测试数据参数合同

首版建议冻结：

```text
posterior_samples = 10
beta = 0.5
beta_semantics = weight_on_aleatoric_uncertainty
c = 0.0
dropout_probability = checkpoint value 0.1
alpha_selection = normal_calibration_alarm_budget
target_normal_exceedance_rate = 0.02
formal_fallback = none
```

`alpha` 只能用纯正常标定数据按预先声明规则确定。推荐做法是：

1. 在任何测试文件可见前，冻结一个无量纲候选网格 `lambda_grid`；
2. 对每个候选令 `alpha=lambda×δ_f`，使缩放随主得分量纲变化；
3. 使用固定的正常标定交叉拟合或留出方案估计正常超阈值率；
4. 选择不超过 2% 正常报警预算的最大 `lambda`；
5. 保留既定的 reference / uncertainty-validation 分区，用选中的参数冻结 UDT 状态，不在选择后合并分区重拟合；
6. 将所有候选、选择规则和失败原因写入审计文件。

推荐初始候选网格：

```text
lambda_grid = [0.0, 0.0025, 0.005, 0.01, 0.02, 0.05, 0.1]
alpha = lambda * fixed_threshold
```

这是本项目的无标签迁移规则，不是论文原始超参数规则，必须在 README 和最终报告中披露。
`lambda=0` 只作为“退化为固定阈值”的审计候选；如果最终只能选择 0，06 不得声称已形成
有效动态阈值，应标记 `CALIBRATION_UNINFORMATIVE`。

如果后续能够提供与测试集完全独立、含异常标签的验证集，可以建立另一个
`06_udt_labeled_validation` 方案；不能用它覆盖本无标签主方案。

### 5.3 两个时间尺度采用同一选择规则

分钟级和秒级可以得到不同数值的 `alpha`，因为各自 `δ_f` 和正常不确定性分布不同，但：

- 使用同一个 `lambda_grid`；
- 使用同一个正常报警预算；
- 使用同一个选择准则；
- 使用同一个 `M、beta、c`；
- 不能因某一时间尺度未来表现差而单独改变规则。

---

## 6. 正常标定数据的分区建议

UDT 同时需要正常参考 ECDF 和正常不确定性统计。为减少同一窗口同时作为参考与验证造成的
乐观偏差，推荐在 06 内建立固定分区，但所有分区仍只来自纯正常标定数据。

### 6.1 分钟级 dataset1

`dataset1` 有 1960 个连续且带时间戳的正常窗口。推荐按时间顺序分区：

```text
前 70%：reference_normal
后 30%：uncertainty_validation_normal
```

不得随机打乱后再切分，以免高度重叠的相邻滑窗同时进入两边。应记录两段的窗口索引、
源行范围、时间范围和哈希。

`reference_normal` 用于冻结 ECDF 和估计 `kappa`；
`uncertainty_validation_normal` 用于冻结 `mu_v、sigma_v` 并执行预先声明的 `alpha` 选择规则。

### 6.2 秒级 dataset2

`dataset2` 的 20000 个窗口本身是均匀抽样，不是连续流。推荐按冻结的 `sample_id` 哈希分组，
而不是按加载顺序的偶然位置切分：

```text
hash(sample_id) mod 10 in [0,1,2] → uncertainty_validation_normal
其余                               → reference_normal
```

同一个源窗口只能进入一个分区。分区函数、哈希算法和最终索引必须写入工件。
两类分区的职责与 dataset1 相同，选择完成后不得合并重拟合。

### 6.3 与 00 固定阈值的关系

`δ_f` 仍直接复用 00 在全量正常标定数据上冻结的 98% 阈值，以保证 00 与 06 的固定基线完全
一致。06 的内部正常分区只用于 ECDF、不确定性统计与 `alpha` 规则，不重新定义 00 阈值。

若担心这种复用造成正常报警预算估计偏乐观，应通过固定分区 bootstrap 记录不确定性，不能
改用测试集评估后再调参。

---

## 7. 推荐程序结构与职责

```text
06阈值/
├── 06.pdf
├── 06阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_06_udt.py
├── prepare_06_udt.py
├── experiment_config.json
├── tests/
│   └── test_strategy_06_udt.py
└── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
```

当前阶段不创建或不运行 `detect_06_udt.py`。未来需要检测时再实现，并在用户明确授权后读取
测试数据。

### 7.1 `strategy_06_udt.py`

建议拆分为纯数学状态和模型随机推理适配器：

```python
class UDTThreshold:
    strategy_id = "06_udt_mc_dropout"

    def fit(self, normal_reference_scores, normal_ua, normal_ue):
        """只用纯正常标定数据冻结 kappa、mu_v、sigma_v 和缩放参数。"""

    def thresholds_from_uncertainty(self, ua, ue):
        """只产生动态阈值，不执行异常判定。"""

    def state_dict(self): ...

    @classmethod
    def from_state_dict(cls, state): ...
```

纯函数至少包括：

```python
ecdf_probabilities(reference_scores, posterior_scores)
complementary_uncertainty(probabilities)
uncertainty_scale_factor(normal_ua, normal_ue)
combine_uncertainty(ua, ue, kappa, beta)
udt_threshold(fixed_threshold, uncertainty, mu_v, sigma_v, alpha, c)
```

模型相关函数只负责：

```text
标准化输入
→ 仅激活 encoder/decoder LSTM dropout
→ M 次无梯度重构
→ 固定残差定义
→ 冻结 Mahalanobis 状态变换
→ 返回随机得分矩阵 (M, N)
→ 恢复 eval()
```

### 7.2 `prepare_06_udt.py`

完整准备流程应为：

```text
读取冻结配置
→ 校验 dataset 与全部路径映射
→ 校验模型、正常源和 00 工件 SHA-256
→ 校验 X 形状、窗口长度、特征维数、输入空间和 y 全为 0
→ 加载 00 固定阈值、score_state 和正常确定性得分
→ 按冻结规则建立 reference / uncertainty-validation 正常分区
→ 对正常窗口做 M 次 MC Dropout 随机前向
→ 用正常参考 ECDF 得到 p_m
→ 计算 u_a、u_e，并验证 dropout 确实生效
→ 只用正常数据拟合 kappa、mu_v、sigma_v
→ 按冻结的正常报警预算规则选择 alpha
→ 生成正常标定诊断，不产生异常预测文件
→ 保存、重新加载并执行状态重放检查
→ 状态写为 READY_FOR_TEST
→ 停止
```

命令行只允许：

```text
--dataset dataset1|dataset2
--config <冻结配置>
--normal-calibration <纯正常标定文件>
--upstream-score-artifact <00 正式工件目录>
--output-dir <06 正式工件目录>
```

禁止提供：

```text
--test
--test-labels
--detect
--evaluate
--point-adjust
--best-alpha-from-test
```

---

## 8. 冻结配置建议

```json
{
  "schema_version": 1,
  "strategy_id": "06_udt_mc_dropout",
  "strategy_name": "Uncertainty-informed dynamic threshold on common Mahalanobis scores",
  "reproduction_type": "threshold_module_migrated",
  "fixed_contract": {
    "model_seed": 10,
    "window_size": 10,
    "residual": "mean over time of abs(reconstruction - input) in standardized space",
    "score_method": "ledoit_wolf_mahalanobis",
    "fixed_threshold_source": "00_fixed98_formal_artifact",
    "main_score_mode": "deterministic_eval",
    "persistence": {"k": 1, "m": 1}
  },
  "strategy_contract": {
    "interface_type": "samplewise_uncertainty_dynamic_threshold",
    "posterior_samples": 10,
    "dropout_source": "checkpoint_lstm_interlayer_dropout",
    "dropout_probability": 0.1,
    "mc_base_seed": 20261105,
    "ecdf_reference": "normal_calibration_deterministic_scores",
    "ecdf_tie_policy": "right_inclusive",
    "epistemic_variance_ddof": 0,
    "scale_factor_source": "normal_calibration_only",
    "beta": 0.5,
    "beta_semantics": "weight_on_aleatoric_uncertainty",
    "c": 0.0,
    "alpha_parameterization": "alpha_equals_lambda_times_fixed_threshold",
    "lambda_grid": [0.0, 0.0025, 0.005, 0.01, 0.02, 0.05, 0.1],
    "alpha_selection": "largest_lambda_within_normal_alarm_budget",
    "target_normal_exceedance_rate": 0.02,
    "threshold_clip": null,
    "formal_fallback": null
  },
  "data_isolation": {
    "fit_source": "normal_calibration_only",
    "test_file": null,
    "test_labels": null,
    "test_data_allowed_during_prepare": false,
    "detection_allowed_during_prepare": false,
    "metrics_allowed_during_prepare": false
  }
}
```

`datasets.dataset1` 和 `datasets.dataset2` 还应分别冻结：

- checkpoint 路径和 SHA-256；
- 正常标定路径和 SHA-256；
- 00 `threshold_artifact.json`、`score_state.npz`、`calibration_scores.npy` 路径和哈希；
- 输入空间、窗口长度、特征维数；
- 正常分区规则和分区索引哈希；
- batch size、设备和派生随机种子；
- 输出目录。

---

## 9. 正式准备输出

每个数据集分别生成：

```text
artifacts/formal_datasetX/
├── threshold_artifact.json
├── udt_state.npz
├── sorted_reference_scores.npy
├── calibration_uncertainty.npz
├── alpha_selection_audit.csv
├── mc_dropout_audit.json
├── normal_calibration_audit.json
├── state_replay_check.json
└── calibration_udt_diagnostics.png
```

建议字段如下：

- `udt_state.npz`：`fixed_threshold、kappa、mu_v、sigma_v、alpha、beta、c、M`；
- `calibration_uncertainty.npz`：纯正常窗口的 `ua、ue、total_u、normalized_u、dynamic_threshold`；
- `alpha_selection_audit.csv`：每个 `lambda/alpha` 的正常标定审计和是否满足预算；
- `mc_dropout_audit.json`：后验得分方差、不同值计数、模型前后参数哈希和模式恢复结果；
- `normal_calibration_audit.json`：形状、标签、输入空间、分区和哈希；
- `state_replay_check.json`：保存/加载后正常阈值重放的一致性。

准备阶段不生成 `detections.csv`、测试曲线、测试 summary 或异常标签。诊断图只能包含纯正常
标定得分、不确定性和动态阈值，不标注任何故障区间。

`threshold_artifact.json` 至少记录：

```json
{
  "strategy_id": "06_udt_mc_dropout",
  "status": "READY_FOR_TEST",
  "formal_result_allowed": true,
  "dataset": "dataset1_or_dataset2",
  "main_score": "deterministic_ledoit_wolf_mahalanobis",
  "uncertainty_score": "mc_dropout_ledoit_wolf_mahalanobis",
  "test_data_used": false,
  "test_labels_used": false,
  "detection_executed": false,
  "metrics_computed": false
}
```

---

## 10. 失败与阻断规则

以下任一情况都不能写成 `READY_FOR_TEST`：

- 正常标定文件为空、含 NaN/Inf 或 `y` 中出现非 0；
- checkpoint、正常源或 00 工件哈希不匹配；
- dataset1 / dataset2 的模型、特征维数或工件发生交叉；
- 00 正常得分与正常窗口数不一致；
- 00 固定阈值不能由其工件复现；
- MC Dropout 的 M 次得分完全相同或平均后验方差低于容差；
- 模型参数在准备前后发生变化；
- `mean(u_e)` 太小导致尺度因子不可辨识；
- `kappa、mu_v、sigma_v` 非有限或 `sigma_v` 接近 0；
- 动态阈值出现 NaN/Inf；
- 所有非零 `lambda` 都不满足预先冻结的正常报警预算；
- 保存/加载后不能在容差内重放同一正常阈值；
- 配置、命令行或输出中出现非空测试路径；
- 任何参数来自测试指标、测试标签或既有实验结果。

失败时应使用明确状态，例如：

```text
CALIBRATION_BLOCKED_HASH_MISMATCH
CALIBRATION_BLOCKED_MC_DROPOUT_INACTIVE
CALIBRATION_BLOCKED_EPISTEMIC_DEGENERATE
CALIBRATION_UNSTABLE
CALIBRATION_UNINFORMATIVE
```

不得静默回退到 00 固定阈值并仍声称 06 已准备完成。

---

## 11. 不使用真实测试集的单元测试门禁

单元测试只使用手工数组、固定随机种子的合成窗口或纯正常标定数据，至少覆盖：

1. 空数组、错误维数、NaN、Inf 明确报错；
2. ECDF 的范围为 `[0,1]`，并验证 `side="right"` 的等值处理；
3. 人工概率矩阵能够复现 `u_a` 和 `u_e` 公式；
4. `u_e` 使用 `ddof=0`；
5. `beta=1` 只保留 aleatoric 项，`beta=0` 只保留 scaled epistemic 项；
6. `mean(u_e)` 近零时正式拟合失败，不静默加 epsilon；
7. `sigma_v` 近零时动态阈值失败；
8. 总不确定性越高时，在其他量不变的条件下动态阈值不增加；
9. `alpha=0` 时动态阈值严格退化为 00 固定阈值；
10. `c` 增大时阈值的整体平移方向与公式一致；
11. MC Dropout 前后模型参数逐元素一致；
12. MC Dropout 后模型恢复 `eval()`；
13. M 次随机前向具有非零后验差异；
14. 相同 seed、设备、批大小和输入产生可重放结果；
15. 保存/加载后 `kappa、mu_v、sigma_v、alpha、beta、c、M` 一致；
16. dataset1 工件不能加载到 dataset2，反之亦然；
17. 修改 dataset2 合成标定数据不影响 dataset1 状态；
18. 模型、正常源或 00 工件哈希变化时拒绝继续；
19. 准备脚本不接受测试路径、测试标签和评价参数；
20. 合成自检工件不能标记 `formal_result_allowed=true`；
21. 作者公开实现中的“校准 + 测试联合计算尺度因子”行为有防回归测试，确保本项目只使用正常标定数据；
22. 不存在基于真实标签的 point-adjust。

这些测试只验证公式、随机推理和工件契约，不构成真实异常检测。

---

## 12. 推荐实施顺序

### 步骤 1：冻结方法卡与偏离说明

- 固定论文公式 (2)-(8) 和 Algorithm 1；
- 固定主方案为 `06_udt_mc_dropout`；
- 标记为阈值模块迁移实现；
- 明确确定性主得分与随机不确定性得分的不同职责；
- 明确公开代码中的测试泄漏、point-adjust 和 `beta` 语义差异不会进入本方案。

完成状态：`FORMULA_VERIFIED`。

### 步骤 2：冻结两个数据集的输入合同

- 核对两个 checkpoint 和正常标定文件哈希；
- 核对 `y` 全为 0；
- 核对窗口长度、特征维数、标准化器和输入空间；
- 核对 00 得分状态、正常得分和固定阈值；
- 冻结 dataset1 时间分区和 dataset2 哈希分区规则；
- 核实联合任务模型训练数据不包含测试异常的证据；若证据不足，在工件中保留待审计标志。

完成状态：`INTERFACE_DEFINED`。

### 步骤 3：实现 UDT 数学层和 MC Dropout 适配层

- 新增 `strategy_06_udt.py`；
- 新增 `prepare_06_udt.py`；
- 新增冻结配置；
- 保持公共 `main.py` 的确定性默认行为不变；
- 不创建测试检测输出；
- 不实现真实标签评价和 point-adjust。

完成状态：`IMPLEMENTED`。

### 步骤 4：运行无真实测试数据的门禁测试

- 公式、边界和单调性测试；
- dropout 激活与参数冻结测试；
- 随机种子和状态重放测试；
- 双数据集隔离测试；
- 哈希和数据泄漏防回归测试。

完成状态：`UNIT_TESTED`。

### 步骤 5：只用纯正常数据分别生成两个工件

未来实现后的命令形式应为：

```powershell
python 阈值策略\06阈值\prepare_06_udt.py `
  --dataset dataset1 `
  --config 阈值策略\06阈值\experiment_config.json `
  --normal-calibration 正常数据\阈值标定集.npz `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset1 `
  --output-dir 阈值策略\06阈值\artifacts\formal_dataset1
```

```powershell
python 阈值策略\06阈值\prepare_06_udt.py `
  --dataset dataset2 `
  --config 阈值策略\06阈值\experiment_config.json `
  --normal-calibration 正常数据\new_raw_阈值标定集.npz `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset2 `
  --output-dir 阈值策略\06阈值\artifacts\formal_dataset2
```

两条命令都只能读取 checkpoint、纯正常标定数据和 00 正式得分工件。

完成状态：

```text
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
```

准备阶段达到该状态后停止；用户已在后续消息中另行授权异常检测，检测执行记录见第 14.2 节。

---

## 13. 分钟级与秒级异常检测边界（已按用户后续授权执行）

用户明确授权后，检测阶段按以下链路执行：

```text
读取对应时间尺度的测试窗口
→ 校验输入空间、维数、窗口、特征顺序和 checkpoint 哈希
→ 用 eval() 产生统一的确定性 Mahalanobis 主得分
→ 用冻结 seed 合同做 M 次 MC Dropout，产生当前窗口不确定性
→ 加载对应 06 工件产生逐窗口动态阈值
→ point_pred = deterministic_score > dynamic_threshold
→ 主实验固定 K=1, M=1
→ 分钟级和秒级分别保存、评价和报告
```

固定映射必须是：

```text
分钟级测试数据
→ dataset1 模型
→ dataset1 的 00 score_state
→ formal_dataset1 UDT 工件
→ 分钟级结果

秒级测试数据
→ dataset2 模型
→ dataset2 的 00 score_state
→ formal_dataset2 UDT 工件
→ 秒级结果
```

检测阶段禁止：

- 用测试窗口重新拟合 Mahalanobis 状态、ECDF、`kappa、mu_v、sigma_v`；
- 把测试不确定性用于重新计算尺度因子；
- 根据测试标签或测试 F1 改 `alpha、beta、c、M`；
- 用真实标签做 point-adjust；
- 将两个时间尺度拼接后拟合阈值或计算一个总指标；
- 只报告表现较好的一个时间尺度。

实际 `detections.csv` 包含：

```text
index
label
score
fixed_threshold
aleatoric_uncertainty
epistemic_uncertainty
total_uncertainty
normalized_uncertainty
dynamic_threshold
point_pred
alarm
```

同时必须额外报告每窗口前向次数、推理耗时、设备和峰值内存，因为 06 的计算成本高于其他
只消费现成得分的阈值策略。

---

## 14. 当前验收清单

- [x] 已确认 06 是 UDT 不确定性动态阈值方法；
- [x] 已核对论文公式 (2)-(8) 和 Algorithm 1；
- [x] 已确认两个 checkpoint 均含 4 层 LSTM 和 `dropout=0.1`；
- [x] 已确认现有公共推理默认是确定性 `eval()`；
- [x] 已确认分钟级正常标定集形状为 `(1960,10,8)` 且 `y=0`；
- [x] 已确认秒级正常标定集形状为 `(20000,10,15)` 且 `y=0`；
- [x] 已确认 00 的两个固定阈值和 Mahalanobis 状态可作为 06 上游输入；
- [x] 已识别论文、公开代码与本项目统一工作流之间的复现差异；
- [x] 已固定“确定性得分做判定、随机得分只估计不确定性”的公平接口；
- [x] 已设计只用正常标定数据的尺度对齐和参数冻结规则；
- [x] 已设计分钟级与秒级的独立工件及严格映射；
- [x] 准备阶段未读取或使用测试数组内容；
- [x] 准备阶段未执行异常检测或指标计算；
- [x] 已实现 `strategy_06_udt.py`；
- [x] 已实现 `prepare_06_udt.py`，且没有测试或检测入口；
- [x] 已创建并冻结 `experiment_config.json`；
- [x] 已运行 16 项合成与接口单元测试，全部通过；
- [x] 已生成 dataset1 / dataset2 正常标定工件；
- [x] 两套 MC Dropout 审计均确认 10 次后验得分存在差异；
- [x] 两套工件均确认 MC Dropout 前后模型参数哈希不变；
- [x] 两套工件保存后均能精确重放动态阈值；
- [x] 分钟级与秒级均已达到 `READY_FOR_TEST`；
- [x] 已在用户后续明确授权后完成分钟级与秒级异常检测；
- [x] 两个时间尺度均运行 5 个测试 seed，测试阶段没有重新拟合或测试后调参；
- [x] 已生成逐点结果、MC 后验审计、检测图、单 seed 指标和双数据集汇总报告。

### 14.1 当前正式准备结果

| 时间尺度 | 数据集 | 正常窗口 | reference / validation | `delta_f` | `kappa` | `lambda` | `alpha` | 正常验证超阈值率 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 分钟级 | `dataset1` | 1960 | 1372 / 588 | `5.1205146861` | `14.7632352557` | `0.1` | `0.5120514686` | `0.00170068` |
| 秒级 | `dataset2` | 20000 | 13929 / 6071 | `6.8380507074` | `5.4592944759` | `0.1` | `0.6838050707` | `0.01120079` |

两套工件都选择了预先冻结网格的最大候选 `lambda=0.1`。这只表示在纯正常验证分区上该
候选仍满足 2% 超阈值预算，不表示它已经通过测试集证明为最优。为防止测试后调参，当前
网格、选择规则和最终参数均已冻结。

当前状态：

```text
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
TESTED_BOTH_DATASETS
RESULT_FROZEN
```

正常标定工件仍保持 `READY_FOR_TEST` 且未被改写；检测结果作为独立只写结果存放在
`06实验结果/`。

### 14.2 用户授权后的检测执行记录

正式检测使用 10 次 MC Dropout、冻结的 ECDF/尺度因子/验证统计量和预先选择的
`alpha/beta/c`。确定性 Mahalanobis 得分负责最终判定，测试标签只在预测完成后用于计算指标。
主实验固定 `K=1, M=1`，没有 point-adjust。

| 时间尺度 | 测试 seed 数 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000 正常窗口 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 分钟级 | 5 | `0.9911 ± 0.0021` | `0.6976 ± 0.0000` | `0.8189 ± 0.0007` | `0.9665 ± 0.0006` | `0.9937 ± 0.0015` | `6.29 ± 1.48` |
| 秒级 | 5 | `0.9751 ± 0.0057` | `0.5807 ± 0.0007` | `0.7279 ± 0.0018` | `0.8980 ± 0.0029` | `0.9851 ± 0.0035` | `14.91 ± 3.49` |

完整报告：`06实验结果/evaluation_report.md`。逐 seed 结果目录保存 `detections.csv`、
`mc_posterior.npz`、`summary.json` 和 `udt_detection.png`。10 个运行均通过模型参数、
Mahalanobis 状态、UDT 状态和判定规则一致性复核。

---

## 15. 最终原则

06 与联合任务 LSTM 的融合不需要重新训练模型，正确准备链路是：

```text
固定联合任务 LSTM checkpoint
→ 固定确定性标准化残差与 Mahalanobis 主得分
→ 复用 00 固定 98% 阈值
→ 只为不确定性估计启用 checkpoint 已有 dropout
→ 只用分钟级纯正常数据拟合 dataset1 UDT 状态
→ 只用秒级纯正常数据拟合 dataset2 UDT 状态
→ 分别冻结两个工件
→ 准备阶段停止并等待授权
→ 用户授权后分别运行分钟级和秒级检测
→ 冻结双数据集结果
```

只要测试数据不参与 ECDF、两类不确定性尺度对齐、正常验证统计量、`alpha/beta/c/M`、
动态阈值状态或模型/得分参数的确定，就满足当前“异常检测前准备”和阈值策略公平对比的
要求。
