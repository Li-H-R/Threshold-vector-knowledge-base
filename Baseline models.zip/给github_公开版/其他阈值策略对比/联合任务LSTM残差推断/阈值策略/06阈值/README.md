# 06 UDT 阈值方案

## 当前状态

06 已完成异常检测前准备，并已在用户授权后完成双时间尺度正式检测：

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1
→ CALIBRATED_DATASET2
→ READY_FOR_TEST
→ TESTED_BOTH_DATASETS
→ RESULT_FROZEN
```

正式结果覆盖分钟级 `dataset1` 和秒级 `dataset2`，每个时间尺度各 5 个测试 seed。

## 方法定义

本方案把 06 论文的 Uncertainty-informed Dynamic Threshold（UDT）迁移到固定的联合任务
LSTM 后端：

1. 主异常得分继续使用 00 冻结的确定性收缩 Mahalanobis 得分；
2. 模型权重和结构保持不变；
3. 只在不确定性支路临时激活 checkpoint 已有的 LSTM dropout；
4. 通过 10 次 MC Dropout 后验得分计算 aleatoric 和 epistemic uncertainty；
5. 只用纯正常标定数据拟合 ECDF、尺度因子和正常不确定性统计；
6. 在预先冻结的候选网格中，用 2% 正常超阈值预算选择 `alpha`；
7. 正式检测使用 `deterministic_score > dynamic_threshold`，固定 `K=1, M=1`，不做 point-adjust。

详细公式、论文/公开代码差异和防泄漏规则见
[06阈值与联合任务LSTM融合准备方案.md](06阈值与联合任务LSTM融合准备方案.md)。

## 冻结结果

| 时间尺度 | 数据集 | 正常窗口 | reference / validation | 固定阈值 | `lambda` | `alpha` | 正常验证超阈值率 | 状态 |
|---|---|---:|---:|---:|---:|---:|---:|---|
| 分钟级 | `dataset1` | 1960 | 1372 / 588 | `5.1205146861` | `0.1` | `0.5120514686` | `0.00170068` | `READY_FOR_TEST` |
| 秒级 | `dataset2` | 20000 | 13929 / 6071 | `6.8380507074` | `0.1` | `0.6838050707` | `0.01120079` | `READY_FOR_TEST` |

两套结果都选择了冻结网格的最大候选 `lambda=0.1`。这表示当前正常报警预算没有要求使用更小
的候选值，不表示利用测试集证明了 `0.1` 是性能最优值。参数已经在读取测试集前冻结，后续
不得因为测试表现修改网格或参数。

## 文件结构

```text
06阈值/
├── 06.pdf
├── 06阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_06_udt.py
├── prepare_06_udt.py
├── detect_06_udt.py
├── evaluate_all_test_sets.py
├── experiment_config.json
├── tests/
│   └── test_strategy_06_udt.py
├── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
└── 06实验结果/
    ├── dataset1_minute/
    ├── dataset2_second/
    ├── evaluation_summary.json
    ├── per_seed_metrics.csv
    └── evaluation_report.md
```

每套正式工件包含：

```text
threshold_artifact.json
udt_state.npz
sorted_reference_scores.npy
calibration_uncertainty.npz
partition_indices.npz
alpha_selection_audit.csv
mc_dropout_audit.json
normal_calibration_audit.json
state_replay_check.json
calibration_udt_diagnostics.png
```

`calibration_uncertainty.npz` 只含正常标定得分、不确定性和标定阈值，不含 `point_pred`、
`alarm` 或测试标签。

## 重新运行正常标定

分钟级：

```powershell
python 阈值策略\06阈值\prepare_06_udt.py `
  --dataset dataset1 `
  --config 阈值策略\06阈值\experiment_config.json `
  --normal-calibration 正常数据\阈值标定集.npz `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset1 `
  --output-dir 阈值策略\06阈值\artifacts\formal_dataset1
```

秒级：

```powershell
python 阈值策略\06阈值\prepare_06_udt.py `
  --dataset dataset2 `
  --config 阈值策略\06阈值\experiment_config.json `
  --normal-calibration 正常数据\new_raw_阈值标定集.npz `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset2 `
  --output-dir 阈值策略\06阈值\artifacts\formal_dataset2
```

准备脚本没有 `--test`、`--test-labels`、`--detect`、`--evaluate` 或 `--point-adjust` 参数。

## 单元测试

```powershell
python -X utf8 -m unittest discover `
  -s 阈值策略\06阈值\tests `
  -p test_*.py `
  -v
```

当前 16 项测试覆盖公式、ECDF 等值规则、`beta` 语义、随机前向、模型权重不变、模式恢复、
状态重放、双数据集隔离，以及准备脚本不存在测试/检测入口的门禁。

## 正式检测结果

| 时间尺度 | Precision | Recall | F1 | PR-AUC | Specificity | MCC | 误报/1000 正常窗口 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 分钟级 | `0.9911 ± 0.0021` | `0.6976 ± 0.0000` | `0.8189 ± 0.0007` | `0.9665 ± 0.0006` | `0.9937 ± 0.0015` | `0.7235 ± 0.0019` | `6.29 ± 1.48` |
| 秒级 | `0.9751 ± 0.0057` | `0.5807 ± 0.0007` | `0.7279 ± 0.0018` | `0.8980 ± 0.0029` | `0.9851 ± 0.0035` | `0.6184 ± 0.0050` | `14.91 ± 3.49` |

以上为各时间尺度 5 个 seed 的均值 ± 样本标准差。完整报告见
[06实验结果/evaluation_report.md](06实验结果/evaluation_report.md)。

批量复现命令：

```powershell
python -X utf8 阈值策略\06阈值\evaluate_all_test_sets.py
```

默认拒绝覆盖非空结果目录；若要独立复跑，请显式指定新的 `--output-root`。

## 数据隔离与检测审计

- 两套正式工件均记录 `test_data_used=false`；
- 两套正式工件均记录 `test_labels_used=false`；
- 工件中的 `detection_executed=false` 和 `metrics_computed=false` 描述的是冻结时状态，冻结工件本身未被检测阶段改写；
- 检测阶段没有重新训练模型，没有重新拟合 Mahalanobis、ECDF、尺度因子或 UDT 参数；
- 测试标签在预测生成后读取，只用于指标和图中背景标注；
- 10 个运行均确认模型参数、Mahalanobis 状态和 UDT 状态在检测前后哈希一致；
- 逐点复核确认 `point_pred == (deterministic_score > dynamic_threshold)`；
- 测试文件没有真实时间戳或事件 ID，因此正式报告只解释点级指标。

