# -*- coding: utf-8 -*-
"""运行 06 UDT 阈值的分钟级/秒级各 5 个测试集并汇总评价。"""

from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
COMMON_DIR = PROJECT_ROOT / "阈值策略" / "00阈值"
for path in (PROJECT_ROOT, COMMON_DIR, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from artifact_utils import save_json  # noqa: E402
from detect_06_udt import run as run_detection  # noqa: E402


METRICS = (
    "precision",
    "recall",
    "specificity",
    "f1",
    "balanced_accuracy",
    "mcc",
    "roc_auc",
    "pr_auc",
    "false_positive_rate",
    "false_alarms_per_1000_normal_windows",
)


def seed_from_path(path: Path) -> int:
    match = re.search(r"seed(\d+)", path.stem)
    if not match:
        raise ValueError(f"无法从文件名读取 seed：{path.name}")
    return int(match.group(1))


def pooled_metrics(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    tp = sum(item["point_metrics"]["tp"] for item in summaries)
    fp = sum(item["point_metrics"]["fp"] for item in summaries)
    tn = sum(item["point_metrics"]["tn"] for item in summaries)
    fn = sum(item["point_metrics"]["fn"] for item in summaries)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    specificity = tn / max(tn + fp, 1)
    return {
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
        "precision": float(precision),
        "recall": float(recall),
        "specificity": float(specificity),
        "f1": float(2.0 * precision * recall / max(precision + recall, 1.0e-12)),
        "balanced_accuracy": float(0.5 * (recall + specificity)),
        "false_positive_rate": float(1.0 - specificity),
    }


def aggregate(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    metrics_mean_std: Dict[str, Any] = {}
    for metric in METRICS:
        values = np.asarray(
            [item["point_metrics"][metric] for item in summaries], dtype=np.float64
        )
        metrics_mean_std[metric] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            "min": float(np.min(values)),
            "max": float(np.max(values)),
        }

    type_names = sorted({
        type_name
        for item in summaries
        for type_name in (item.get("type_metrics") or {}).keys()
    })
    type_summary: Dict[str, Any] = {}
    for type_name in type_names:
        records = [
            item["type_metrics"][type_name]
            for item in summaries
            if type_name in (item.get("type_metrics") or {})
        ]
        if records and records[0]["positive_count"] == records[0]["count"]:
            values = np.asarray([record["point_recall"] for record in records])
            type_summary[type_name] = {
                "kind": "anomaly",
                "count_per_seed": int(records[0]["count"]),
                "recall_mean": float(np.mean(values)),
                "recall_std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            }
        elif records and records[0]["positive_count"] == 0:
            values = np.asarray(
                [record["point_false_positive_rate"] for record in records]
            )
            type_summary[type_name] = {
                "kind": "normal",
                "count_per_seed": int(records[0]["count"]),
                "false_positive_rate_mean": float(np.mean(values)),
                "false_positive_rate_std": (
                    float(np.std(values, ddof=1)) if values.size > 1 else 0.0
                ),
            }

    threshold_fields = ("minimum", "mean", "maximum", "std", "nonpositive_count")
    threshold_summary: Dict[str, Any] = {}
    for field in threshold_fields:
        values = np.asarray(
            [item["dynamic_threshold"][field] for item in summaries],
            dtype=np.float64,
        )
        threshold_summary[field] = {
            "mean_across_seeds": float(np.mean(values)),
            "std_across_seeds": (
                float(np.std(values, ddof=1)) if values.size > 1 else 0.0
            ),
            "min_across_seeds": float(np.min(values)),
            "max_across_seeds": float(np.max(values)),
        }
    return {
        "num_seeds": len(summaries),
        "metrics_mean_std": metrics_mean_std,
        "pooled_confusion_metrics": pooled_metrics(summaries),
        "type_metrics": type_summary,
        "dynamic_threshold": threshold_summary,
        "runtime_seconds_total": float(
            sum(item["runtime_seconds"]["total_inference"] for item in summaries)
        ),
    }


def audit_test_design(test_files: List[Path]) -> Dict[str, Any]:
    records = []
    for path in test_files:
        with np.load(path, allow_pickle=False) as archive:
            records.append({
                "x": archive["x"],
                "y": archive["y_true"].astype(np.int64),
                "types": archive["y_type"].astype(str),
            })
    base = records[0]
    anomaly_mask = base["y"] == 1
    normal_mask = ~anomaly_mask
    anomalies_identical = all(
        np.array_equal(base["x"][anomaly_mask], item["x"][item["y"] == 1])
        for item in records[1:]
    )
    normals_identical = all(
        np.array_equal(base["x"][normal_mask], item["x"][item["y"] == 0])
        for item in records[1:]
    )
    return {
        "num_test_files": len(records),
        "windows_per_file": int(base["y"].size),
        "normal_per_file": int(normal_mask.sum()),
        "anomaly_per_file": int(anomaly_mask.sum()),
        "label_transitions_per_file": int(np.count_nonzero(np.diff(base["y"]) != 0)),
        "anomaly_windows_identical_across_seeds": bool(anomalies_identical),
        "normal_windows_identical_across_seeds": bool(normals_identical),
        "timestamps_or_event_ids_available": False,
        "model_input_array": "x",
        "x_std_used_for_consistency_audit_only": True,
        "interpretation": (
            "五个 seed 共享相同异常窗口，仅正常窗口抽样不同；"
            "均值和标准差主要反映正常抽样导致的误报波动。"
        ),
    }


def write_seed_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fields = [
        "dataset", "time_scale", "seed", "fixed_threshold",
        "dynamic_threshold_min", "dynamic_threshold_mean",
        "dynamic_threshold_max", "dynamic_threshold_nonpositive_count",
        *METRICS, "tp", "fp", "tn", "fn", "runtime_seconds",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            summary = row["summary"]
            metrics = summary["point_metrics"]
            dynamic = summary["dynamic_threshold"]
            writer.writerow({
                "dataset": row["dataset"],
                "time_scale": row["time_scale"],
                "seed": row["seed"],
                "fixed_threshold": summary["udt"]["fixed_threshold"],
                "dynamic_threshold_min": dynamic["minimum"],
                "dynamic_threshold_mean": dynamic["mean"],
                "dynamic_threshold_max": dynamic["maximum"],
                "dynamic_threshold_nonpositive_count": dynamic["nonpositive_count"],
                **{key: metrics[key] for key in METRICS},
                **{key: metrics[key] for key in ("tp", "fp", "tn", "fn")},
                "runtime_seconds": summary["runtime_seconds"]["total_inference"],
            })


def fmt(value: Dict[str, float], digits: int = 4) -> str:
    return f"{value['mean']:.{digits}f} ± {value['std']:.{digits}f}"


def write_report(path: Path, result: Dict[str, Any]) -> None:
    lines = [
        "# 06 UDT 阈值：分钟级与秒级异常检测评价",
        "",
        "## Material Passport",
        "",
        "- `artifact_type`: experiment_result",
        "- `strategy_id`: `06_udt_mc_dropout`",
        "- `verification_status`: `ANALYZED`（完成单次冻结实验与完整性审计，未做独立复跑）",
        "- `scope`: 分钟级 dataset1 与秒级 dataset2，各 5 个正常抽样 seed",
        "",
        "## 评价口径",
        "",
        "- 使用纯正常标定阶段冻结的联合任务 LSTM、Mahalanobis 状态和 UDT 状态；测试阶段不重新训练、不重新拟合、不重新选择参数。",
        "- 确定性 Mahalanobis 得分负责判定；10 次 MC Dropout 只负责逐窗口不确定性和动态阈值。",
        "- 测试标签在预测完成后读取，只用于指标；不做 point-adjust，固定 `K=1, M=1`。",
        "- 每个时间尺度报告 5 个正常抽样 seed 的均值 ± 样本标准差。",
        "- 5 个 seed 的异常窗口完全相同、正常窗口不同，标准差主要反映正常抽样导致的误报波动。",
        "- 测试文件没有真实时间戳或事件 ID，因此只正式解释点级指标，不解释事件召回或检测延迟。",
        "",
        "## 总体结果",
        "",
        "| 时间尺度 | 固定基准阈值 | 动态阈值均值（跨 seed） | Precision | Recall | F1 | PR-AUC | Specificity | MCC | 误报/1000正常窗口 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        data = result[dataset]
        metrics = data["aggregate"]["metrics_mean_std"]
        threshold = data["aggregate"]["dynamic_threshold"]["mean"]
        lines.append(
            f"| {label} | {data['fixed_threshold']:.8f} | "
            f"{threshold['mean_across_seeds']:.4f} ± {threshold['std_across_seeds']:.4f} | "
            f"{fmt(metrics['precision'])} | {fmt(metrics['recall'])} | "
            f"{fmt(metrics['f1'])} | {fmt(metrics['pr_auc'])} | "
            f"{fmt(metrics['specificity'])} | {fmt(metrics['mcc'])} | "
            f"{fmt(metrics['false_alarms_per_1000_normal_windows'], 2)} |"
        )

    lines.extend(["", "## 单 seed 结果", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend([
            f"### {label}",
            "",
            "| Seed | 动态阈值 min / mean / max | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|",
        ])
        for run in result[dataset]["runs"]:
            metrics = run["point_metrics"]
            dynamic = run["dynamic_threshold"]
            lines.append(
                f"| {run['seed']} | {dynamic['minimum']:.3f} / "
                f"{dynamic['mean']:.3f} / {dynamic['maximum']:.3f} | "
                f"{metrics['precision']:.4f} | {metrics['recall']:.4f} | "
                f"{metrics['f1']:.4f} | {metrics['pr_auc']:.4f} | "
                f"{metrics['specificity']:.4f} | "
                f"{metrics['false_alarms_per_1000_normal_windows']:.2f} |"
            )
        lines.append("")

    lines.extend(["## 异常类型召回", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend([
            f"### {label}",
            "",
            "| y_type | 每个 seed 样本数 | Recall 均值 | Recall 标准差 |",
            "|---|---:|---:|---:|",
        ])
        for type_name, metrics in result[dataset]["aggregate"]["type_metrics"].items():
            if metrics["kind"] != "anomaly":
                continue
            lines.append(
                f"| {type_name} | {metrics['count_per_seed']} | "
                f"{metrics['recall_mean']:.4f} | {metrics['recall_std']:.4f} |"
            )
        lines.append("")

    lines.extend([
        "## 测试集设计与完整性审查",
        "",
        "| 时间尺度 | 每文件窗口 | 正常 | 异常 | 异常跨 seed 相同 | 正常跨 seed 相同 | 标签跳变数 |",
        "|---|---:|---:|---:|---|---|---:|",
    ])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        audit = result[dataset]["data_audit"]
        lines.append(
            f"| {label} | {audit['windows_per_file']} | {audit['normal_per_file']} | "
            f"{audit['anomaly_per_file']} | "
            f"{audit['anomaly_windows_identical_across_seeds']} | "
            f"{audit['normal_windows_identical_across_seeds']} | "
            f"{audit['label_transitions_per_file']} |"
        )

    lines.extend([
        "",
        "所有运行均验证 checkpoint、UDT 状态、Mahalanobis 状态及 06 工件文件 SHA-256；MC Dropout 前后模型参数哈希一致，推理后模型恢复 `eval`。",
        "",
        "模型输入统一使用测试文件原始量纲数组 `x`，由冻结 checkpoint 自带的标准化器转换。测试文件自带的 `x_std` 只做内部一致性审计，不作为模型输入。",
        "",
        "完整逐点得分、动态阈值、不确定性、标签、异常类型与判定见各 seed 目录中的 `detections.csv`、`mc_posterior.npz`、`summary.json` 和 `udt_detection.png`。",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="批量评价 06 UDT 阈值的双测试集")
    parser.add_argument("--test-root", type=Path, default=PROJECT_ROOT / "测试集数据")
    parser.add_argument("--output-root", type=Path, default=SCRIPT_DIR / "06实验结果")
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    configs = {
        "dataset1": {
            "time_scale": "minute",
            "input_dir": args.test_root / "dataset1",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset1" / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset1_minute",
        },
        "dataset2": {
            "time_scale": "second",
            "input_dir": args.test_root / "dataset2",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset2" / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset2_second",
        },
    }
    if args.output_root.exists() and any(args.output_root.iterdir()):
        raise FileExistsError(f"结果目录非空，拒绝覆盖：{args.output_root}")

    rows: List[Dict[str, Any]] = []
    result: Dict[str, Any] = {
        "strategy_id": "06_udt_mc_dropout",
        "status": "TESTED_BOTH_DATASETS",
        "completion_status": "RESULT_FROZEN",
        "verification_status": "ANALYZED",
        "evaluation_rule": "point-level, K=1, M=1, five normal-sampling seeds",
        "model_score_or_udt_refit_on_test": False,
        "test_data_used_for_threshold_selection": False,
        "test_labels_used_for_metrics_only": True,
        "point_adjust_used": False,
        "event_metrics_formally_used": False,
        "event_metrics_exclusion_reason": (
            "测试文件无真实时间戳或事件 ID，且标签按正常块/异常块排列。"
        ),
    }
    for dataset, config in configs.items():
        test_files = sorted(
            config["input_dir"].glob("test_seed*.npz"), key=seed_from_path
        )
        if len(test_files) != 5:
            raise ValueError(f"{dataset} 应有 5 个测试文件，实际 {len(test_files)}")
        summaries: List[Dict[str, Any]] = []
        runs: List[Dict[str, Any]] = []
        for test_file in test_files:
            seed = seed_from_path(test_file)
            print(f"开始 {dataset} seed={seed}：{test_file.name}", flush=True)
            namespace = SimpleNamespace(
                artifact=config["artifact"],
                test=test_file,
                labels=None,
                output_dir=config["output_dir"] / f"seed{seed}",
                k=1,
                m=1,
                array_key="x",
                label_key="y_true",
                type_key="y_type",
                input_space="raw",
            )
            summary = run_detection(namespace)
            summaries.append(summary)
            runs.append({"seed": seed, **summary})
            rows.append({
                "dataset": dataset,
                "time_scale": config["time_scale"],
                "seed": seed,
                "summary": summary,
            })
        result[dataset] = {
            "time_scale": config["time_scale"],
            "fixed_threshold": float(summaries[0]["udt"]["fixed_threshold"]),
            "posterior_samples": int(summaries[0]["udt"]["posterior_samples"]),
            "num_test_sets": len(summaries),
            "runs": runs,
            "aggregate": aggregate(summaries),
            "data_audit": audit_test_design(test_files),
        }

    args.output_root.mkdir(parents=True, exist_ok=True)
    save_json(args.output_root / "evaluation_summary.json", result)
    write_seed_csv(args.output_root / "per_seed_metrics.csv", rows)
    write_report(args.output_root / "evaluation_report.md", result)
    print(f"双测试集汇总：{args.output_root / 'evaluation_report.md'}")
    return result


def main() -> Dict[str, Any]:
    return run(build_parser().parse_args())


if __name__ == "__main__":
    main()
