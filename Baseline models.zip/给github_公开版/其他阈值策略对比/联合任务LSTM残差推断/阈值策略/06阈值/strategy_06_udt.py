# -*- coding: utf-8 -*-
"""06 阈值策略：基于 MC Dropout 不确定性的逐样本动态阈值（UDT）。"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch


SCHEMA_VERSION = 1
STRATEGY_ID = "06_udt_mc_dropout"
EPS = 1.0e-12


def validate_scores(
    values: np.ndarray,
    *,
    min_samples: int = 1,
    name: str = "scores",
) -> np.ndarray:
    scores = np.asarray(values, dtype=np.float64).reshape(-1)
    if scores.size < min_samples:
        raise ValueError(f"{name} 至少需要 {min_samples} 个值，实际 {scores.size}")
    if not np.all(np.isfinite(scores)):
        raise ValueError(f"{name} 中存在 NaN 或 Inf")
    if np.any(scores < 0.0):
        raise ValueError(f"{name} 不能包含负数")
    return np.ascontiguousarray(scores)


def validate_uncertainty_pair(
    aleatoric: np.ndarray,
    epistemic: np.ndarray,
    *,
    min_samples: int = 2,
) -> Tuple[np.ndarray, np.ndarray]:
    ua = np.asarray(aleatoric, dtype=np.float64).reshape(-1)
    ue = np.asarray(epistemic, dtype=np.float64).reshape(-1)
    if ua.size != ue.size:
        raise ValueError("aleatoric 与 epistemic uncertainty 长度不一致")
    if ua.size < min_samples:
        raise ValueError(f"不确定性样本至少需要 {min_samples} 个")
    if not np.all(np.isfinite(ua)) or not np.all(np.isfinite(ue)):
        raise ValueError("不确定性中存在 NaN 或 Inf")
    if np.any(ua < 0.0) or np.any(ua > 0.25 + 1.0e-12):
        raise ValueError("aleatoric uncertainty 必须位于 [0, 0.25]")
    if np.any(ue < 0.0):
        raise ValueError("epistemic uncertainty 不能为负")
    return np.ascontiguousarray(ua), np.ascontiguousarray(ue)


def ecdf_probabilities(
    reference_scores: np.ndarray,
    posterior_scores: np.ndarray,
) -> np.ndarray:
    """用右闭 ECDF 把 (M,N) 随机得分转换为异常概率。"""
    reference = validate_scores(
        reference_scores, min_samples=2, name="reference_scores"
    )
    posterior = np.asarray(posterior_scores, dtype=np.float64)
    if posterior.ndim != 2 or posterior.shape[0] < 2 or posterior.shape[1] < 1:
        raise ValueError("posterior_scores 应为至少两次后验前向组成的 (M,N) 数组")
    if not np.all(np.isfinite(posterior)) or np.any(posterior < 0.0):
        raise ValueError("posterior_scores 必须为有限非负数")
    sorted_reference = np.sort(reference)
    probabilities = np.searchsorted(
        sorted_reference,
        posterior.reshape(-1),
        side="right",
    ).reshape(posterior.shape) / float(sorted_reference.size)
    if (
        not np.all(np.isfinite(probabilities))
        or np.any(probabilities < 0.0)
        or np.any(probabilities > 1.0)
    ):
        raise RuntimeError("ECDF 产生无效异常概率")
    return probabilities.astype(np.float64, copy=False)


def complementary_uncertainty(probabilities: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """按论文公式计算 aleatoric 与 population epistemic uncertainty。"""
    probs = np.asarray(probabilities, dtype=np.float64)
    if probs.ndim != 2 or probs.shape[0] < 2 or probs.shape[1] < 1:
        raise ValueError("probabilities 应为 (M,N)，且 M 至少为 2")
    if (
        not np.all(np.isfinite(probs))
        or np.any(probs < 0.0)
        or np.any(probs > 1.0)
    ):
        raise ValueError("probabilities 必须位于 [0,1]")
    aleatoric = np.mean(probs * (1.0 - probs), axis=0)
    epistemic = np.var(probs, axis=0, ddof=0)
    validate_uncertainty_pair(aleatoric, epistemic, min_samples=1)
    return aleatoric.astype(np.float64), epistemic.astype(np.float64)


def uncertainty_scale_factor(
    normal_aleatoric: np.ndarray,
    normal_epistemic: np.ndarray,
    *,
    epistemic_tolerance: float = EPS,
) -> float:
    ua, ue = validate_uncertainty_pair(normal_aleatoric, normal_epistemic)
    if not np.isfinite(epistemic_tolerance) or epistemic_tolerance <= 0.0:
        raise ValueError("epistemic_tolerance 必须为有限正数")
    mean_ua = float(np.mean(ua))
    mean_ue = float(np.mean(ue))
    if mean_ue <= epistemic_tolerance:
        raise ValueError(
            "平均 epistemic uncertainty 接近 0，MC Dropout 未生效或不可辨识"
        )
    factor = mean_ua / mean_ue
    if not np.isfinite(factor) or factor <= 0.0:
        raise ValueError("不确定性尺度因子无效")
    return float(factor)


def combine_uncertainty(
    aleatoric: np.ndarray,
    epistemic: np.ndarray,
    *,
    scale_factor: float,
    beta: float,
) -> np.ndarray:
    """论文语义：beta 是 aleatoric uncertainty 的权重。"""
    ua, ue = validate_uncertainty_pair(aleatoric, epistemic, min_samples=1)
    if not np.isfinite(scale_factor) or scale_factor <= 0.0:
        raise ValueError("scale_factor 必须为有限正数")
    if not np.isfinite(beta) or not 0.0 <= beta <= 1.0:
        raise ValueError("beta 必须位于 [0,1]")
    total = float(beta) * ua + (1.0 - float(beta)) * float(scale_factor) * ue
    if not np.all(np.isfinite(total)) or np.any(total < 0.0):
        raise ValueError("总不确定性无效")
    return total.astype(np.float64, copy=False)


def udt_threshold(
    fixed_threshold: float,
    uncertainty: np.ndarray,
    *,
    validation_mean: float,
    validation_std: float,
    alpha: float,
    c: float,
) -> Tuple[np.ndarray, np.ndarray]:
    values = np.asarray(uncertainty, dtype=np.float64).reshape(-1)
    if values.size == 0 or not np.all(np.isfinite(values)) or np.any(values < 0.0):
        raise ValueError("uncertainty 必须为非空有限非负数组")
    scalars = (fixed_threshold, validation_mean, validation_std, alpha, c)
    if not all(np.isfinite(value) for value in scalars):
        raise ValueError("UDT 阈值参数必须为有限数")
    if fixed_threshold <= 0.0:
        raise ValueError("fixed_threshold 必须为正")
    if validation_std <= EPS:
        raise ValueError("validation_std 接近 0")
    if alpha < 0.0 or c < 0.0:
        raise ValueError("alpha 和 c 不能为负")
    normalized = (values - (1.0 + c) * validation_mean) / validation_std
    threshold = fixed_threshold - alpha * normalized
    if not np.all(np.isfinite(normalized)) or not np.all(np.isfinite(threshold)):
        raise ValueError("UDT 动态阈值产生 NaN 或 Inf")
    return threshold.astype(np.float64), normalized.astype(np.float64)


@dataclass(frozen=True)
class AlphaAuditRow:
    lambda_value: float
    alpha: float
    exceedance_count: int
    exceedance_rate: float
    threshold_min: float
    threshold_mean: float
    threshold_max: float
    within_budget: bool


def select_alpha_by_alarm_budget(
    validation_scores: np.ndarray,
    validation_uncertainty: np.ndarray,
    *,
    fixed_threshold: float,
    validation_mean: float,
    validation_std: float,
    c: float,
    lambda_grid: Iterable[float],
    target_exceedance_rate: float,
) -> Tuple[AlphaAuditRow, List[AlphaAuditRow]]:
    scores = validate_scores(
        validation_scores, min_samples=10, name="validation_scores"
    )
    uncertainty = np.asarray(validation_uncertainty, dtype=np.float64).reshape(-1)
    if uncertainty.size != scores.size:
        raise ValueError("validation_uncertainty 与 validation_scores 长度不一致")
    if not 0.0 <= target_exceedance_rate < 1.0:
        raise ValueError("target_exceedance_rate 必须位于 [0,1)")
    grid = sorted({float(value) for value in lambda_grid})
    if not grid or grid[0] < 0.0 or not np.all(np.isfinite(grid)):
        raise ValueError("lambda_grid 必须是非空有限非负网格")

    rows: List[AlphaAuditRow] = []
    for lambda_value in grid:
        alpha = float(lambda_value * fixed_threshold)
        thresholds, _ = udt_threshold(
            fixed_threshold,
            uncertainty,
            validation_mean=validation_mean,
            validation_std=validation_std,
            alpha=alpha,
            c=c,
        )
        count = int(np.sum(scores > thresholds))
        rate = float(count / scores.size)
        rows.append(AlphaAuditRow(
            lambda_value=lambda_value,
            alpha=alpha,
            exceedance_count=count,
            exceedance_rate=rate,
            threshold_min=float(np.min(thresholds)),
            threshold_mean=float(np.mean(thresholds)),
            threshold_max=float(np.max(thresholds)),
            within_budget=bool(
                rate <= target_exceedance_rate + np.finfo(np.float64).eps
                and np.min(thresholds) > 0.0
            ),
        ))
    eligible = [row for row in rows if row.within_budget]
    if not eligible:
        raise ValueError("没有 alpha 候选满足正常超限预算和正阈值门禁")
    return max(eligible, key=lambda row: row.lambda_value), rows


class UDTThreshold:
    """可冻结的 UDT 数学状态；不包含异常判定。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        *,
        dataset: str,
        fixed_threshold: float,
        alpha: float,
        beta: float = 0.5,
        c: float = 0.0,
        epistemic_tolerance: float = EPS,
    ) -> None:
        if dataset not in ("dataset1", "dataset2"):
            raise ValueError("dataset 必须是 dataset1 或 dataset2")
        if not np.isfinite(fixed_threshold) or fixed_threshold <= 0.0:
            raise ValueError("fixed_threshold 必须为有限正数")
        if not np.isfinite(alpha) or alpha < 0.0:
            raise ValueError("alpha 必须为有限非负数")
        if not np.isfinite(beta) or not 0.0 <= beta <= 1.0:
            raise ValueError("beta 必须位于 [0,1]")
        if not np.isfinite(c) or c < 0.0:
            raise ValueError("c 必须为有限非负数")
        if not np.isfinite(epistemic_tolerance) or epistemic_tolerance <= 0.0:
            raise ValueError("epistemic_tolerance 必须为有限正数")
        self.dataset = dataset
        self.fixed_threshold = float(fixed_threshold)
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.c = float(c)
        self.epistemic_tolerance = float(epistemic_tolerance)
        self.sorted_reference_scores_: Optional[np.ndarray] = None
        self.scale_factor_: Optional[float] = None
        self.validation_mean_: Optional[float] = None
        self.validation_std_: Optional[float] = None

    def fit(
        self,
        reference_scores: np.ndarray,
        scale_aleatoric: np.ndarray,
        scale_epistemic: np.ndarray,
        validation_aleatoric: np.ndarray,
        validation_epistemic: np.ndarray,
    ) -> "UDTThreshold":
        reference = validate_scores(
            reference_scores, min_samples=10, name="reference_scores"
        )
        scale_factor = uncertainty_scale_factor(
            scale_aleatoric,
            scale_epistemic,
            epistemic_tolerance=self.epistemic_tolerance,
        )
        validation_total = combine_uncertainty(
            validation_aleatoric,
            validation_epistemic,
            scale_factor=scale_factor,
            beta=self.beta,
        )
        validation_mean = float(np.mean(validation_total))
        validation_std = float(np.std(validation_total, ddof=0))
        if not np.isfinite(validation_mean) or validation_mean < 0.0:
            raise ValueError("正常验证总不确定性均值无效")
        if not np.isfinite(validation_std) or validation_std <= EPS:
            raise ValueError("正常验证总不确定性标准差接近 0")
        self.sorted_reference_scores_ = np.sort(reference)
        self.scale_factor_ = float(scale_factor)
        self.validation_mean_ = validation_mean
        self.validation_std_ = validation_std
        return self

    def _require_fit(self) -> None:
        if (
            self.sorted_reference_scores_ is None
            or self.scale_factor_ is None
            or self.validation_mean_ is None
            or self.validation_std_ is None
        ):
            raise RuntimeError("请先调用 fit()")

    def assert_dataset(self, dataset: str) -> None:
        if dataset != self.dataset:
            raise ValueError(f"UDT 工件属于 {self.dataset}，不能用于 {dataset}")

    def probabilities(self, posterior_scores: np.ndarray) -> np.ndarray:
        self._require_fit()
        assert self.sorted_reference_scores_ is not None
        return ecdf_probabilities(self.sorted_reference_scores_, posterior_scores)

    def thresholds_from_components(
        self,
        aleatoric: np.ndarray,
        epistemic: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        self._require_fit()
        assert self.scale_factor_ is not None
        assert self.validation_mean_ is not None
        assert self.validation_std_ is not None
        total = combine_uncertainty(
            aleatoric,
            epistemic,
            scale_factor=self.scale_factor_,
            beta=self.beta,
        )
        thresholds, normalized = udt_threshold(
            self.fixed_threshold,
            total,
            validation_mean=self.validation_mean_,
            validation_std=self.validation_std_,
            alpha=self.alpha,
            c=self.c,
        )
        return thresholds, total, normalized

    def state_dict(self) -> Dict[str, Any]:
        self._require_fit()
        assert self.sorted_reference_scores_ is not None
        assert self.scale_factor_ is not None
        assert self.validation_mean_ is not None
        assert self.validation_std_ is not None
        return {
            "schema_version": SCHEMA_VERSION,
            "strategy_id": STRATEGY_ID,
            "dataset": self.dataset,
            "fixed_threshold": self.fixed_threshold,
            "alpha": self.alpha,
            "beta": self.beta,
            "c": self.c,
            "epistemic_tolerance": self.epistemic_tolerance,
            "scale_factor": self.scale_factor_,
            "validation_mean": self.validation_mean_,
            "validation_std": self.validation_std_,
            "sorted_reference_scores": self.sorted_reference_scores_.copy(),
        }

    @classmethod
    def from_state_dict(cls, state: Mapping[str, Any]) -> "UDTThreshold":
        if int(np.asarray(state["schema_version"]).item()) != SCHEMA_VERSION:
            raise ValueError("不支持的 UDT schema_version")
        if str(np.asarray(state["strategy_id"]).item()) != STRATEGY_ID:
            raise ValueError("状态不是 06 UDT 工件")
        instance = cls(
            dataset=str(np.asarray(state["dataset"]).item()),
            fixed_threshold=float(np.asarray(state["fixed_threshold"]).item()),
            alpha=float(np.asarray(state["alpha"]).item()),
            beta=float(np.asarray(state["beta"]).item()),
            c=float(np.asarray(state["c"]).item()),
            epistemic_tolerance=float(
                np.asarray(state["epistemic_tolerance"]).item()
            ),
        )
        reference = validate_scores(
            np.asarray(state["sorted_reference_scores"], dtype=np.float64),
            min_samples=10,
            name="sorted_reference_scores",
        )
        if np.any(np.diff(reference) < 0.0):
            raise ValueError("冻结参考得分未排序")
        instance.sorted_reference_scores_ = reference.copy()
        instance.scale_factor_ = float(np.asarray(state["scale_factor"]).item())
        instance.validation_mean_ = float(
            np.asarray(state["validation_mean"]).item()
        )
        instance.validation_std_ = float(
            np.asarray(state["validation_std"]).item()
        )
        if instance.scale_factor_ <= 0.0 or instance.validation_std_ <= EPS:
            raise ValueError("冻结 UDT 状态包含无效尺度")
        return instance


def save_state_npz(path: Path, state: Mapping[str, Any]) -> None:
    payload = {key: np.asarray(value) for key, value in state.items()}
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **payload)


def load_state_npz(path: Path) -> Dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}


def model_parameter_sha256(model: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        digest.update(name.encode("utf-8"))
        array = tensor.detach().cpu().contiguous().numpy()
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _mahalanobis_from_residual(
    residual: np.ndarray,
    score_state: Mapping[str, np.ndarray],
) -> np.ndarray:
    values = np.asarray(residual, dtype=np.float64)
    if values.ndim != 2 or values.shape[0] == 0 or not np.all(np.isfinite(values)):
        raise ValueError("residual 应为非空有限 (N,D) 数组")
    location = np.asarray(score_state["location"], dtype=np.float64)
    precision = np.asarray(score_state["precision"], dtype=np.float64)
    if location.shape != (values.shape[1],) or precision.shape != (
        values.shape[1], values.shape[1]
    ):
        raise ValueError("Mahalanobis 状态维数与残差不一致")
    delta = values - location
    squared = np.einsum("ni,ij,nj->n", delta, precision, delta)
    scores = np.sqrt(np.maximum(squared, 0.0))
    return validate_scores(scores, min_samples=1, name="posterior_scores")


def mc_dropout_mahalanobis_scores(
    windows_standardized: np.ndarray,
    *,
    model: torch.nn.Module,
    score_state: Mapping[str, np.ndarray],
    posterior_samples: int,
    batch_size: int,
    base_seed: int,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """权重冻结，只激活 LSTM 层间 dropout，返回 (M,N) 随机得分。"""
    windows = np.asarray(windows_standardized, dtype=np.float32)
    if windows.ndim != 3 or windows.shape[0] == 0:
        raise ValueError("windows_standardized 应为非空 (N,T,D) 数组")
    if not np.all(np.isfinite(windows)):
        raise ValueError("windows_standardized 中存在 NaN 或 Inf")
    if posterior_samples < 2:
        raise ValueError("posterior_samples 至少为 2")
    if batch_size < 1:
        raise ValueError("batch_size 必须为正")
    if not hasattr(model, "encoder") or not hasattr(model, "decoder"):
        raise ValueError("模型必须包含 encoder 和 decoder")

    device = next(model.parameters()).device
    before_hash = model_parameter_sha256(model)
    scores = np.empty((posterior_samples, windows.shape[0]), dtype=np.float64)
    seeds = [int(base_seed + index) for index in range(posterior_samples)]
    old_benchmark = torch.backends.cudnn.benchmark
    old_deterministic = torch.backends.cudnn.deterministic
    try:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        model.eval()
        model.encoder.train()
        model.decoder.train()
        with torch.no_grad():
            for posterior_index, seed in enumerate(seeds):
                torch.manual_seed(seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(seed)
                chunks: List[np.ndarray] = []
                for start in range(0, windows.shape[0], batch_size):
                    end = min(start + batch_size, windows.shape[0])
                    batch = torch.from_numpy(windows[start:end]).to(device)
                    reconstruction, _, _ = model(batch)
                    residual = torch.mean(
                        torch.abs(reconstruction - batch), dim=1
                    ).detach().cpu().numpy()
                    chunks.append(_mahalanobis_from_residual(residual, score_state))
                scores[posterior_index] = np.concatenate(chunks)
    finally:
        model.eval()
        torch.backends.cudnn.benchmark = old_benchmark
        torch.backends.cudnn.deterministic = old_deterministic

    after_hash = model_parameter_sha256(model)
    if before_hash != after_hash:
        raise RuntimeError("MC Dropout 前后模型参数哈希发生变化")
    if model.training or model.encoder.training or model.decoder.training:
        raise RuntimeError("MC Dropout 后模型没有恢复 eval 模式")
    posterior_variance = np.var(scores, axis=0, ddof=0)
    posterior_range = np.ptp(scores, axis=0)
    audit = {
        "device": str(device),
        "posterior_samples": int(posterior_samples),
        "batch_size": int(batch_size),
        "base_seed": int(base_seed),
        "posterior_seeds": seeds,
        "parameter_sha256_before": before_hash,
        "parameter_sha256_after": after_hash,
        "parameters_unchanged": before_hash == after_hash,
        "model_eval_restored": True,
        "posterior_score_variance_mean": float(np.mean(posterior_variance)),
        "posterior_score_variance_min": float(np.min(posterior_variance)),
        "posterior_score_variance_max": float(np.max(posterior_variance)),
        "windows_with_nonzero_posterior_range": int(np.sum(posterior_range > EPS)),
        "window_count": int(windows.shape[0]),
    }
    return scores, audit

