# -*- coding: utf-8 -*-
"""只用纯正常标定数据准备 06 UDT 工件；不执行异常检测。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
BASELINE_DIR = SCRIPT_DIR.parent / "00阈值"
for candidate in (PROJECT_ROOT, SCRIPT_DIR, BASELINE_DIR):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from artifact_utils import load_score_state
from main import DATASETS, load_joint
from strategy_06_udt import (
    EPS,
    SCHEMA_VERSION,
    STRATEGY_ID,
    UDTThreshold,
    combine_uncertainty,
    complementary_uncertainty,
    ecdf_probabilities,
    load_state_npz,
    mc_dropout_mahalanobis_scores,
    save_state_npz,
    select_alpha_by_alarm_budget,
    uncertainty_scale_factor,
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    values = np.ascontiguousarray(array)
    digest = hashlib.sha256()
    digest.update(str(values.dtype).encode("ascii"))
    digest.update(np.asarray(values.shape, dtype=np.int64).tobytes())
    digest.update(values.tobytes())
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def resolve_project_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def require_hash(path: Path, expected: str, label: str) -> str:
    actual = sha256_file(path)
    if actual.lower() != str(expected).lower():
        raise ValueError(f"{label} SHA-256 不匹配：{actual} != {expected}")
    return actual


def validate_data_isolation(config: Dict[str, Any]) -> None:
    isolation = config.get("data_isolation", {})
    required_false = (
        "test_data_allowed_during_prepare",
        "detection_allowed_during_prepare",
        "metrics_allowed_during_prepare",
        "point_adjust_allowed",
        "test_uncertainty_used_for_scale_factor",
        "model_retraining_allowed",
    )
    for key in required_false:
        if isolation.get(key) is not False:
            raise ValueError(f"data_isolation.{key} 必须为 false")
    for key in ("test_file", "test_labels"):
        if isolation.get(key) is not None:
            raise ValueError(f"data_isolation.{key} 必须为 null")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True, choices=("dataset1", "dataset2"))
    parser.add_argument(
        "--config", type=Path, default=SCRIPT_DIR / "experiment_config.json"
    )
    parser.add_argument("--normal-calibration", type=Path)
    parser.add_argument("--upstream-score-artifact", type=Path)
    parser.add_argument("--output-dir", type=Path)
    return parser


def load_normal_calibration(
    path: Path,
    *,
    dataset: str,
    expected_count: int,
    input_dim: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    with np.load(path, allow_pickle=False) as archive:
        required = {"X", "y", "sample_id"}
        missing = sorted(required - set(archive.files))
        if missing:
            raise ValueError(f"正常标定文件缺少字段：{missing}")
        windows = np.asarray(archive["X"], dtype=np.float32)
        labels = np.asarray(archive["y"]).reshape(-1)
        sample_ids = np.asarray(archive["sample_id"]).astype(str).reshape(-1)
        available_keys = list(archive.files)
        scalar_metadata = {}
        for key in (
            "dataset", "input_space", "window_size", "feature_dimension",
            "checkpoint_sha256", "sampling_strategy", "normality_assumption",
        ):
            if key in archive.files:
                value = archive[key]
                scalar_metadata[key] = value.item() if value.ndim == 0 else value.tolist()

        dataset1_extra: Dict[str, Any] = {}
        if dataset == "dataset1":
            required_d1 = {
                "source_row_start", "source_row_end", "timestamp_start", "timestamp_end"
            }
            missing_d1 = sorted(required_d1 - set(archive.files))
            if missing_d1:
                raise ValueError(f"分钟级正常标定缺少字段：{missing_d1}")
            starts = np.asarray(archive["source_row_start"], dtype=np.int64)
            ends = np.asarray(archive["source_row_end"], dtype=np.int64)
            times = np.asarray(archive["timestamp_start"]).astype("datetime64[s]")
            if not np.all(np.diff(starts) == 1) or not np.all(np.diff(ends) == 1):
                raise ValueError("分钟级正常标定窗口不是步长 1 的连续序列")
            time_steps = np.diff(times).astype("timedelta64[s]").astype(np.int64)
            if not np.all(time_steps == 60):
                raise ValueError("分钟级正常标定时间戳未按 60 秒递增")
            dataset1_extra = {
                "chronological": True,
                "contiguous": True,
                "sampling_interval_seconds_observed": 60,
                "source_row_start": int(starts[0]),
                "source_row_end": int(ends[-1]),
                "timestamp_start": str(times[0]),
                "timestamp_last_window_start": str(times[-1]),
            }

    expected_shape = (expected_count, 10, input_dim)
    if windows.shape != expected_shape:
        raise ValueError(f"正常标定形状 {windows.shape} != {expected_shape}")
    if labels.size != expected_count or not np.all(labels == 0):
        raise ValueError("正常标定标签必须全部为 0")
    if sample_ids.size != expected_count or len(np.unique(sample_ids)) != expected_count:
        raise ValueError("sample_id 缺失或不唯一")
    if not np.all(np.isfinite(windows)):
        raise ValueError("正常标定窗口中存在 NaN 或 Inf")
    if "dataset" in scalar_metadata and scalar_metadata["dataset"] != dataset:
        raise ValueError("正常标定 dataset 元数据不匹配")
    if "input_space" in scalar_metadata and scalar_metadata["input_space"] != "standardized":
        raise ValueError("06 正常标定必须处于 standardized 空间")
    if "window_size" in scalar_metadata and int(scalar_metadata["window_size"]) != 10:
        raise ValueError("正常标定 window_size 元数据不匹配")
    if (
        "feature_dimension" in scalar_metadata
        and int(scalar_metadata["feature_dimension"]) != input_dim
    ):
        raise ValueError("正常标定 feature_dimension 元数据不匹配")
    audit = {
        "input_shape": list(windows.shape),
        "input_space": "standardized",
        "available_keys": available_keys,
        "label_counts": {"0": int(labels.size)},
        "sample_id_unique": True,
        "scalar_metadata": scalar_metadata,
    }
    audit.update(dataset1_extra)
    return windows, sample_ids, audit


def make_partition(
    *,
    dataset: str,
    sample_ids: np.ndarray,
    dataset_config: Dict[str, Any],
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    count = int(sample_ids.size)
    if dataset == "dataset1":
        fraction = float(dataset_config["reference_fraction"])
        cut = int(np.floor(count * fraction))
        reference = np.arange(0, cut, dtype=np.int64)
        validation = np.arange(cut, count, dtype=np.int64)
        details = {
            "method": "chronological_70_30",
            "reference_fraction_requested": fraction,
            "reference_index_start": 0,
            "reference_index_end_exclusive": cut,
            "validation_index_start": cut,
            "validation_index_end_exclusive": count,
        }
    else:
        validation_buckets = {
            int(value) for value in dataset_config["validation_hash_buckets"]
        }
        buckets = np.asarray([
            int.from_bytes(
                hashlib.sha256(str(sample_id).encode("utf-8")).digest()[:8],
                "big",
            ) % 10
            for sample_id in sample_ids
        ], dtype=np.int8)
        validation_mask = np.isin(buckets, sorted(validation_buckets))
        reference = np.flatnonzero(~validation_mask).astype(np.int64)
        validation = np.flatnonzero(validation_mask).astype(np.int64)
        details = {
            "method": "sha256_sample_id_mod10_validation_0_1_2",
            "hash_algorithm": "sha256_first_8_bytes_big_endian_mod_10",
            "validation_hash_buckets": sorted(validation_buckets),
            "bucket_counts": {
                str(bucket): int(np.sum(buckets == bucket)) for bucket in range(10)
            },
        }
    if reference.size < 10 or validation.size < 10:
        raise ValueError("正常标定 reference 或 validation 分区样本不足")
    if np.intersect1d(reference, validation).size:
        raise RuntimeError("正常标定分区发生交叉")
    if np.union1d(reference, validation).size != count:
        raise RuntimeError("正常标定分区没有覆盖全部窗口")
    details.update({
        "reference_count": int(reference.size),
        "validation_count": int(validation.size),
        "reference_indices_sha256": sha256_array(reference),
        "validation_indices_sha256": sha256_array(validation),
        "partitions_disjoint": True,
        "partitions_cover_all_windows": True,
    })
    return reference, validation, details


def save_alpha_audit(path: Path, rows: Sequence[Any], selected_lambda: float) -> None:
    fields = (
        "lambda", "alpha", "exceedance_count", "exceedance_rate",
        "threshold_min", "threshold_mean", "threshold_max",
        "within_budget", "selected",
    )
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "lambda": row.lambda_value,
                "alpha": row.alpha,
                "exceedance_count": row.exceedance_count,
                "exceedance_rate": row.exceedance_rate,
                "threshold_min": row.threshold_min,
                "threshold_mean": row.threshold_mean,
                "threshold_max": row.threshold_max,
                "within_budget": int(row.within_budget),
                "selected": int(row.lambda_value == selected_lambda),
            })


def save_diagnostic_plot(
    path: Path,
    *,
    dataset: str,
    deterministic_scores: np.ndarray,
    dynamic_thresholds: np.ndarray,
    aleatoric: np.ndarray,
    scaled_epistemic: np.ndarray,
    total_uncertainty: np.ndarray,
    validation_indices: np.ndarray,
) -> Optional[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"

    fig, axes = plt.subplots(3, 1, figsize=(12, 10))
    x = np.arange(deterministic_scores.size)
    axes[0].plot(x, deterministic_scores, color="#315f86", linewidth=0.65,
                 label="normal deterministic score")
    axes[0].plot(x, dynamic_thresholds, color="#c15f3c", linewidth=0.9,
                 label="UDT threshold (calibration audit)")
    validation_is_contiguous = bool(
        validation_indices.size > 1 and np.all(np.diff(validation_indices) == 1)
    )
    if validation_is_contiguous:
        axes[0].axvspan(
            int(validation_indices.min()), int(validation_indices.max()),
            color="#999999", alpha=0.08,
            label="uncertainty validation partition",
        )
    else:
        y_min = float(min(np.min(deterministic_scores), np.min(dynamic_thresholds)))
        axes[0].scatter(
            validation_indices,
            np.full(validation_indices.size, y_min),
            marker="|", s=8, linewidths=0.35, color="#777777", alpha=0.22,
            label="hash-scattered uncertainty validation windows",
        )
    axes[0].set_ylabel("Mahalanobis score")
    axes[0].legend(loc="upper right")
    axes[0].grid(alpha=0.2)

    axes[1].hist(aleatoric, bins=50, alpha=0.65, color="#477998",
                 label="aleatoric")
    axes[1].hist(scaled_epistemic, bins=50, alpha=0.55, color="#d49b54",
                 label="scaled epistemic")
    axes[1].set_xlabel("uncertainty")
    axes[1].set_ylabel("normal-window count")
    axes[1].legend()
    axes[1].grid(alpha=0.2)

    axes[2].hist(total_uncertainty, bins=50, color="#6a8f63", alpha=0.8)
    axes[2].set_xlabel("total uncertainty")
    axes[2].set_ylabel("normal-window count")
    axes[2].grid(alpha=0.2)
    fig.suptitle(f"06 UDT normal-calibration diagnostics ({dataset})")
    fig.tight_layout()
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)
    return None


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config_path = args.config.resolve()
    config = load_json(config_path)
    if config.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("不支持的配置 schema_version")
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("配置不是 06 UDT")
    validate_data_isolation(config)
    dataset_config = config["datasets"][args.dataset]
    strategy_config = config["strategy_contract"]

    normal_path = (
        args.normal_calibration.resolve()
        if args.normal_calibration is not None
        else resolve_project_path(dataset_config["normal_calibration"])
    )
    upstream_dir = (
        args.upstream_score_artifact.resolve()
        if args.upstream_score_artifact is not None
        else resolve_project_path(dataset_config["upstream_score_artifact"])
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else resolve_project_path(dataset_config["artifact_dir"])
    )
    model_path = resolve_project_path(dataset_config["model"])
    upstream_artifact_path = upstream_dir / "threshold_artifact.json"
    upstream_state_path = upstream_dir / "score_state.npz"
    upstream_scores_path = upstream_dir / "calibration_scores.npy"

    require_hash(model_path, dataset_config["model_sha256"], "checkpoint")
    require_hash(
        normal_path,
        dataset_config["normal_calibration_sha256"],
        "纯正常标定文件",
    )
    require_hash(
        upstream_artifact_path,
        dataset_config["upstream_artifact_sha256"],
        "00 threshold_artifact",
    )
    require_hash(
        upstream_state_path,
        dataset_config["upstream_score_state_sha256"],
        "00 score_state",
    )
    require_hash(
        upstream_scores_path,
        dataset_config["upstream_calibration_scores_sha256"],
        "00 calibration_scores",
    )

    upstream_artifact = load_json(upstream_artifact_path)
    if upstream_artifact.get("scheme_id") != "00_fixed98":
        raise ValueError("上游工件不是 00_fixed98")
    if upstream_artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("上游 00 工件未达到 READY_FOR_TEST")
    if upstream_artifact.get("dataset") != args.dataset:
        raise ValueError("上游 00 工件数据集不匹配")
    if upstream_artifact["model"]["checkpoint_sha256"].lower() != dataset_config[
        "model_sha256"
    ].lower():
        raise ValueError("上游 00 checkpoint 哈希不匹配")
    if upstream_artifact["calibration"]["source_sha256"].lower() != dataset_config[
        "normal_calibration_sha256"
    ].lower():
        raise ValueError("上游 00 正常源哈希不匹配")
    if upstream_artifact["calibration"]["input_space"] != "standardized":
        raise ValueError("上游 00 正常标定输入空间不是 standardized")
    if upstream_artifact["score"]["method"] != "mahalanobis":
        raise ValueError("06 只接受 00 冻结的 Mahalanobis 得分")
    if float(upstream_artifact["threshold"]["quantile"]) != 0.98:
        raise ValueError("上游 00 工件不是固定 98% 阈值")
    fixed_threshold = float(upstream_artifact["threshold"]["value"])

    expected_count = int(dataset_config["calibration_count"])
    input_dim = int(dataset_config["input_dim"])
    windows, sample_ids, normal_audit = load_normal_calibration(
        normal_path,
        dataset=args.dataset,
        expected_count=expected_count,
        input_dim=input_dim,
    )
    reference_indices, validation_indices, partition_audit = make_partition(
        dataset=args.dataset,
        sample_ids=sample_ids,
        dataset_config=dataset_config,
    )
    deterministic_scores = np.load(
        upstream_scores_path, allow_pickle=False
    ).astype(np.float64).reshape(-1)
    if deterministic_scores.size != expected_count:
        raise ValueError("00 正常得分数与正常窗口数不一致")
    if not np.all(np.isfinite(deterministic_scores)) or np.any(deterministic_scores < 0.0):
        raise ValueError("00 正常得分无效")
    recomputed_fixed = float(np.quantile(deterministic_scores, 0.98))
    if not np.isclose(recomputed_fixed, fixed_threshold, rtol=0.0, atol=1.0e-12):
        raise ValueError("00 固定阈值不能由其正常得分复现")

    print(
        f"{args.dataset}: 正常窗口 {expected_count}，reference {reference_indices.size}，"
        f"uncertainty-validation {validation_indices.size}",
        flush=True,
    )
    model, _, _, model_config = load_joint(args.dataset)
    if int(model_config["input_dim"]) != input_dim:
        raise ValueError("checkpoint input_dim 与配置不一致")
    if int(model_config["num_layers"]) < 2:
        raise ValueError("LSTM 少于两层，内部 dropout 不会生效")
    if not np.isclose(
        float(model_config["dropout"]),
        float(strategy_config["dropout_probability"]),
    ):
        raise ValueError("checkpoint dropout 与冻结配置不一致")
    score_state = load_score_state(upstream_state_path)
    print(
        f"{args.dataset}: 开始 {strategy_config['posterior_samples']} 次 MC Dropout 正常标定前向",
        flush=True,
    )
    posterior_scores, mc_audit = mc_dropout_mahalanobis_scores(
        windows,
        model=model,
        score_state=score_state,
        posterior_samples=int(strategy_config["posterior_samples"]),
        batch_size=int(dataset_config["inference_batch_size"]),
        base_seed=int(dataset_config["mc_base_seed"]),
    )
    variance_tolerance = float(strategy_config["posterior_variance_tolerance"])
    if mc_audit["posterior_score_variance_mean"] <= variance_tolerance:
        raise ValueError("MC Dropout 后验得分平均方差低于冻结门槛")
    if mc_audit["windows_with_nonzero_posterior_range"] != expected_count:
        raise ValueError("至少一个正常窗口的 MC Dropout 后验得分没有变化")
    mc_audit.update({
        "posterior_scores_shape": list(posterior_scores.shape),
        "posterior_scores_sha256": sha256_array(posterior_scores),
        "posterior_variance_tolerance": variance_tolerance,
        "checkpoint_dropout": float(model_config["dropout"]),
        "checkpoint_num_layers": int(model_config["num_layers"]),
    })

    reference_scores = deterministic_scores[reference_indices]
    probabilities = ecdf_probabilities(reference_scores, posterior_scores)
    aleatoric, epistemic = complementary_uncertainty(probabilities)
    scale_factor = uncertainty_scale_factor(
        aleatoric[reference_indices],
        epistemic[reference_indices],
        epistemic_tolerance=float(strategy_config["epistemic_tolerance"]),
    )
    total_uncertainty = combine_uncertainty(
        aleatoric,
        epistemic,
        scale_factor=scale_factor,
        beta=float(strategy_config["beta"]),
    )
    validation_mean = float(np.mean(total_uncertainty[validation_indices]))
    validation_std = float(np.std(total_uncertainty[validation_indices], ddof=0))
    if validation_std <= EPS:
        raise ValueError("正常不确定性验证分区标准差接近 0")
    selected, alpha_rows = select_alpha_by_alarm_budget(
        deterministic_scores[validation_indices],
        total_uncertainty[validation_indices],
        fixed_threshold=fixed_threshold,
        validation_mean=validation_mean,
        validation_std=validation_std,
        c=float(strategy_config["c"]),
        lambda_grid=strategy_config["lambda_grid"],
        target_exceedance_rate=float(
            strategy_config["target_normal_exceedance_rate"]
        ),
    )
    if selected.lambda_value <= 0.0:
        raise ValueError("只有 lambda=0 满足门禁，UDT 标定无信息")

    strategy = UDTThreshold(
        dataset=args.dataset,
        fixed_threshold=fixed_threshold,
        alpha=selected.alpha,
        beta=float(strategy_config["beta"]),
        c=float(strategy_config["c"]),
        epistemic_tolerance=float(strategy_config["epistemic_tolerance"]),
    ).fit(
        reference_scores,
        aleatoric[reference_indices],
        epistemic[reference_indices],
        aleatoric[validation_indices],
        epistemic[validation_indices],
    )
    dynamic_thresholds, total_replayed, normalized_uncertainty = (
        strategy.thresholds_from_components(aleatoric, epistemic)
    )
    if not np.array_equal(total_uncertainty, total_replayed):
        raise RuntimeError("UDT 类状态与直接计算的总不确定性不一致")
    if np.min(dynamic_thresholds) <= 0.0:
        raise ValueError("纯正常标定上出现非正动态阈值")

    output_dir.mkdir(parents=True, exist_ok=True)
    state_path = output_dir / "udt_state.npz"
    reference_path = output_dir / "sorted_reference_scores.npy"
    uncertainty_path = output_dir / "calibration_uncertainty.npz"
    partition_path = output_dir / "partition_indices.npz"
    alpha_path = output_dir / "alpha_selection_audit.csv"
    mc_path = output_dir / "mc_dropout_audit.json"
    normal_audit_path = output_dir / "normal_calibration_audit.json"
    replay_path = output_dir / "state_replay_check.json"
    plot_path = output_dir / "calibration_udt_diagnostics.png"
    artifact_path = output_dir / "threshold_artifact.json"

    save_state_npz(state_path, strategy.state_dict())
    np.save(reference_path, np.sort(reference_scores).astype(np.float64))
    partition_code = np.zeros(expected_count, dtype=np.int8)
    partition_code[validation_indices] = 1
    np.savez_compressed(
        uncertainty_path,
        deterministic_score=deterministic_scores.astype(np.float64),
        aleatoric_uncertainty=aleatoric.astype(np.float64),
        epistemic_uncertainty=epistemic.astype(np.float64),
        scaled_epistemic_uncertainty=(scale_factor * epistemic).astype(np.float64),
        total_uncertainty=total_uncertainty.astype(np.float64),
        normalized_uncertainty=normalized_uncertainty.astype(np.float64),
        dynamic_threshold=dynamic_thresholds.astype(np.float64),
        partition_code=partition_code,
    )
    np.savez_compressed(
        partition_path,
        reference_indices=reference_indices,
        uncertainty_validation_indices=validation_indices,
    )
    save_alpha_audit(alpha_path, alpha_rows, selected.lambda_value)

    restored = UDTThreshold.from_state_dict(load_state_npz(state_path))
    restored.assert_dataset(args.dataset)
    replay_thresholds, replay_total, replay_normalized = (
        restored.thresholds_from_components(aleatoric, epistemic)
    )
    replay = {
        "state_file": state_path.name,
        "exact_threshold_replay": bool(np.array_equal(
            dynamic_thresholds, replay_thresholds
        )),
        "exact_total_uncertainty_replay": bool(np.array_equal(
            total_uncertainty, replay_total
        )),
        "exact_normalized_uncertainty_replay": bool(np.array_equal(
            normalized_uncertainty, replay_normalized
        )),
        "max_abs_threshold_difference": float(np.max(np.abs(
            dynamic_thresholds - replay_thresholds
        ))),
    }
    if not all(replay[key] for key in (
        "exact_threshold_replay",
        "exact_total_uncertainty_replay",
        "exact_normalized_uncertainty_replay",
    )):
        raise RuntimeError("保存/加载后的 UDT 状态不能精确重放")
    save_json(replay_path, replay)
    save_json(mc_path, mc_audit)

    normal_audit.update({
        "dataset": args.dataset,
        "source_path": str(normal_path),
        "source_sha256": sha256_file(normal_path),
        "checkpoint_path": str(model_path),
        "checkpoint_sha256": sha256_file(model_path),
        "upstream_artifact_path": str(upstream_artifact_path),
        "upstream_artifact_sha256": sha256_file(upstream_artifact_path),
        "upstream_score_state_sha256": sha256_file(upstream_state_path),
        "upstream_calibration_scores_sha256": sha256_file(upstream_scores_path),
        "partition": partition_audit,
        "test_data_used": False,
        "test_labels_used": False,
        "detection_executed": False,
        "metrics_computed": False,
    })
    save_json(normal_audit_path, normal_audit)
    plot_warning = save_diagnostic_plot(
        plot_path,
        dataset=args.dataset,
        deterministic_scores=deterministic_scores,
        dynamic_thresholds=dynamic_thresholds,
        aleatoric=aleatoric,
        scaled_epistemic=scale_factor * epistemic,
        total_uncertainty=total_uncertainty,
        validation_indices=validation_indices,
    )

    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    state = strategy.state_dict()
    artifact = {
        "schema_version": SCHEMA_VERSION,
        "strategy_id": STRATEGY_ID,
        "strategy_name": config["strategy_name"],
        "reproduction_type": config["reproduction_type"],
        "status": "READY_FOR_TEST",
        "created_at_china": now_cn,
        "formal_result_allowed": True,
        "dataset": args.dataset,
        "time_scale": dataset_config["time_scale"],
        "model": {
            "checkpoint": str(model_path),
            "checkpoint_sha256": dataset_config["model_sha256"],
            "window_size": 10,
            "input_dim": input_dim,
            "num_layers": int(model_config["num_layers"]),
            "dropout": float(model_config["dropout"]),
            "weights_updated": False,
        },
        "normal_calibration": {
            "source_path": str(normal_path),
            "source_sha256": dataset_config["normal_calibration_sha256"],
            "input_shape": list(windows.shape),
            "input_space": "standardized",
            "label_counts": {"0": expected_count},
            "reference_count": int(reference_indices.size),
            "uncertainty_validation_count": int(validation_indices.size),
            "partition_method": partition_audit["method"],
        },
        "score": {
            "main_score": "deterministic_ledoit_wolf_mahalanobis",
            "uncertainty_score": "mc_dropout_ledoit_wolf_mahalanobis",
            "upstream_artifact": str(upstream_artifact_path),
            "upstream_score_state_sha256": dataset_config[
                "upstream_score_state_sha256"
            ],
            "upstream_calibration_scores_sha256": dataset_config[
                "upstream_calibration_scores_sha256"
            ],
        },
        "threshold": {
            "method": "uncertainty_informed_dynamic_threshold",
            "fixed_threshold_source": "00_fixed98_formal_artifact",
            "fixed_threshold": fixed_threshold,
            "posterior_samples": int(strategy_config["posterior_samples"]),
            "mc_base_seed": int(dataset_config["mc_base_seed"]),
            "ecdf_tie_policy": "right_inclusive",
            "scale_factor": float(state["scale_factor"]),
            "validation_mean": float(state["validation_mean"]),
            "validation_std": float(state["validation_std"]),
            "beta": float(state["beta"]),
            "beta_semantics": strategy_config["beta_semantics"],
            "c": float(state["c"]),
            "selected_lambda": selected.lambda_value,
            "selected_at_lambda_grid_max": bool(
                selected.lambda_value == max(strategy_config["lambda_grid"])
            ),
            "alpha": selected.alpha,
            "target_normal_exceedance_rate": float(
                strategy_config["target_normal_exceedance_rate"]
            ),
            "validation_exceedance_count": selected.exceedance_count,
            "validation_exceedance_rate": selected.exceedance_rate,
            "normal_dynamic_threshold_min": float(np.min(dynamic_thresholds)),
            "normal_dynamic_threshold_mean": float(np.mean(dynamic_thresholds)),
            "normal_dynamic_threshold_max": float(np.max(dynamic_thresholds)),
            "threshold_clip": None,
            "formal_fallback": None,
            "decision_rule_for_future_use": (
                "deterministic_score > dynamic_threshold"
            ),
            "persistence_for_main_experiment": {"k": 1, "m": 1},
        },
        "files": {
            "state": state_path.name,
            "sorted_reference_scores": reference_path.name,
            "calibration_uncertainty": uncertainty_path.name,
            "partition_indices": partition_path.name,
            "alpha_selection_audit": alpha_path.name,
            "mc_dropout_audit": mc_path.name,
            "normal_calibration_audit": normal_audit_path.name,
            "state_replay_check": replay_path.name,
            "diagnostic_plot": None if plot_warning else plot_path.name,
        },
        "file_sha256": {
            "state": sha256_file(state_path),
            "sorted_reference_scores": sha256_file(reference_path),
            "calibration_uncertainty": sha256_file(uncertainty_path),
            "partition_indices": sha256_file(partition_path),
            "alpha_selection_audit": sha256_file(alpha_path),
            "mc_dropout_audit": sha256_file(mc_path),
            "normal_calibration_audit": sha256_file(normal_audit_path),
            "state_replay_check": sha256_file(replay_path),
        },
        "test_data_used": False,
        "test_labels_used": False,
        "detection_executed": False,
        "metrics_computed": False,
        "point_adjust_used": False,
    }
    if plot_warning:
        artifact["plot_warning"] = plot_warning
    else:
        artifact["file_sha256"]["diagnostic_plot"] = sha256_file(plot_path)
    save_json(artifact_path, artifact)
    print(
        f"{args.dataset}: READY_FOR_TEST，lambda={selected.lambda_value:g}，"
        f"alpha={selected.alpha:.8g}，normal-validation exceedance="
        f"{selected.exceedance_rate:.6f}",
        flush=True,
    )
    print(f"阈值工件：{artifact_path}", flush=True)
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()

