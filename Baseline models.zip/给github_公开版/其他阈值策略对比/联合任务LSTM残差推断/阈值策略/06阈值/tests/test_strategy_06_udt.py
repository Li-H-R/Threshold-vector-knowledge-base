# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import torch


SCRIPT_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = SCRIPT_DIR.parents[1]
for candidate in (SCRIPT_DIR, PROJECT_ROOT):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from lstm_clf_model import LSTMAEClassifier
from prepare_06_udt import build_parser, make_partition, validate_data_isolation
from strategy_06_udt import (
    UDTThreshold,
    combine_uncertainty,
    complementary_uncertainty,
    ecdf_probabilities,
    load_state_npz,
    mc_dropout_mahalanobis_scores,
    model_parameter_sha256,
    save_state_npz,
    select_alpha_by_alarm_budget,
    uncertainty_scale_factor,
    udt_threshold,
)


class FormulaTests(unittest.TestCase):
    def test_ecdf_is_right_inclusive(self):
        reference = np.asarray([1.0, 2.0, 3.0, 4.0])
        posterior = np.asarray([[0.5, 2.0, 5.0], [1.0, 3.5, 4.0]])
        got = ecdf_probabilities(reference, posterior)
        expected = np.asarray([[0.0, 0.5, 1.0], [0.25, 0.75, 1.0]])
        np.testing.assert_array_equal(got, expected)

    def test_complementary_uncertainty_matches_formula(self):
        probabilities = np.asarray([
            [0.1, 0.2],
            [0.3, 0.6],
            [0.5, 1.0],
        ])
        ua, ue = complementary_uncertainty(probabilities)
        np.testing.assert_allclose(
            ua, np.mean(probabilities * (1.0 - probabilities), axis=0)
        )
        np.testing.assert_allclose(ue, np.var(probabilities, axis=0, ddof=0))

    def test_scale_factor_rejects_degenerate_epistemic(self):
        with self.assertRaises(ValueError):
            uncertainty_scale_factor(np.full(10, 0.1), np.zeros(10))

    def test_beta_semantics(self):
        ua = np.asarray([0.1, 0.2])
        ue = np.asarray([0.01, 0.02])
        np.testing.assert_array_equal(
            combine_uncertainty(ua, ue, scale_factor=5.0, beta=1.0), ua
        )
        np.testing.assert_array_equal(
            combine_uncertainty(ua, ue, scale_factor=5.0, beta=0.0), 5.0 * ue
        )

    def test_alpha_zero_reduces_to_fixed_threshold(self):
        thresholds, normalized = udt_threshold(
            5.0,
            np.asarray([0.1, 0.2, 0.3]),
            validation_mean=0.2,
            validation_std=0.1,
            alpha=0.0,
            c=0.0,
        )
        np.testing.assert_array_equal(thresholds, np.full(3, 5.0))
        self.assertTrue(np.all(np.isfinite(normalized)))

    def test_more_uncertainty_lowers_threshold(self):
        thresholds, _ = udt_threshold(
            5.0,
            np.asarray([0.1, 0.2, 0.3]),
            validation_mean=0.2,
            validation_std=0.1,
            alpha=0.5,
            c=0.0,
        )
        self.assertTrue(np.all(np.diff(thresholds) < 0.0))

    def test_c_increases_threshold(self):
        uncertainty = np.asarray([0.2, 0.3])
        low, _ = udt_threshold(
            5.0, uncertainty, validation_mean=0.2, validation_std=0.1,
            alpha=0.5, c=0.0,
        )
        high, _ = udt_threshold(
            5.0, uncertainty, validation_mean=0.2, validation_std=0.1,
            alpha=0.5, c=0.1,
        )
        self.assertTrue(np.all(high > low))

    def test_alpha_selection_uses_largest_eligible_lambda(self):
        scores = np.linspace(1.0, 4.0, 100)
        uncertainty = np.linspace(0.1, 0.3, 100)
        selected, rows = select_alpha_by_alarm_budget(
            scores,
            uncertainty,
            fixed_threshold=5.0,
            validation_mean=0.2,
            validation_std=0.1,
            c=0.0,
            lambda_grid=[0.0, 0.01, 0.1],
            target_exceedance_rate=0.02,
        )
        self.assertEqual(selected.lambda_value, 0.1)
        self.assertEqual(len(rows), 3)

    def test_invalid_values_are_rejected(self):
        with self.assertRaises(ValueError):
            ecdf_probabilities(np.asarray([1.0, np.nan]), np.ones((2, 2)))
        with self.assertRaises(ValueError):
            complementary_uncertainty(np.asarray([[0.1, 1.2], [0.2, 0.3]]))
        with self.assertRaises(ValueError):
            udt_threshold(
                5.0, np.asarray([0.1]), validation_mean=0.1,
                validation_std=0.0, alpha=0.1, c=0.0,
            )


class StateTests(unittest.TestCase):
    @staticmethod
    def fitted_strategy(dataset: str = "dataset1") -> UDTThreshold:
        reference = np.linspace(0.5, 5.0, 100)
        scale_ua = np.linspace(0.08, 0.15, 60)
        scale_ue = np.linspace(0.005, 0.02, 60)
        validation_ua = np.linspace(0.07, 0.17, 40)
        validation_ue = np.linspace(0.004, 0.03, 40)
        return UDTThreshold(
            dataset=dataset,
            fixed_threshold=5.0,
            alpha=0.1,
            beta=0.5,
            c=0.0,
        ).fit(reference, scale_ua, scale_ue, validation_ua, validation_ue)

    def test_save_load_replay_is_exact(self):
        strategy = self.fitted_strategy()
        ua = np.asarray([0.08, 0.1, 0.12])
        ue = np.asarray([0.005, 0.01, 0.02])
        expected = strategy.thresholds_from_components(ua, ue)
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "state.npz"
            save_state_npz(path, strategy.state_dict())
            restored = UDTThreshold.from_state_dict(load_state_npz(path))
        actual = restored.thresholds_from_components(ua, ue)
        for left, right in zip(expected, actual):
            np.testing.assert_array_equal(left, right)

    def test_cross_dataset_load_is_rejected(self):
        strategy = self.fitted_strategy("dataset1")
        with self.assertRaises(ValueError):
            strategy.assert_dataset("dataset2")


class MCDropoutTests(unittest.TestCase):
    def test_mc_dropout_varies_without_changing_parameters(self):
        torch.manual_seed(7)
        model = LSTMAEClassifier(
            input_dim=3,
            hidden_dim=8,
            latent_dim=4,
            num_layers=2,
            num_classes=2,
            dropout=0.5,
        ).cpu()
        rng = np.random.default_rng(7)
        windows = rng.normal(size=(12, 4, 3)).astype(np.float32)
        state = {
            "location": np.zeros(3, dtype=np.float64),
            "precision": np.eye(3, dtype=np.float64),
        }
        before = model_parameter_sha256(model)
        scores, audit = mc_dropout_mahalanobis_scores(
            windows,
            model=model,
            score_state=state,
            posterior_samples=4,
            batch_size=6,
            base_seed=123,
        )
        after = model_parameter_sha256(model)
        self.assertEqual(scores.shape, (4, 12))
        self.assertGreater(audit["posterior_score_variance_mean"], 0.0)
        self.assertEqual(audit["windows_with_nonzero_posterior_range"], 12)
        self.assertEqual(before, after)
        self.assertFalse(model.training)
        self.assertFalse(model.encoder.training)
        self.assertFalse(model.decoder.training)

    def test_mc_dropout_replays_with_same_seed_and_batch_size(self):
        torch.manual_seed(9)
        model = LSTMAEClassifier(
            input_dim=2,
            hidden_dim=6,
            latent_dim=3,
            num_layers=2,
            num_classes=2,
            dropout=0.4,
        ).cpu()
        windows = np.random.default_rng(9).normal(size=(8, 4, 2)).astype(np.float32)
        state = {
            "location": np.zeros(2, dtype=np.float64),
            "precision": np.eye(2, dtype=np.float64),
        }
        first, _ = mc_dropout_mahalanobis_scores(
            windows, model=model, score_state=state,
            posterior_samples=3, batch_size=4, base_seed=88,
        )
        second, _ = mc_dropout_mahalanobis_scores(
            windows, model=model, score_state=state,
            posterior_samples=3, batch_size=4, base_seed=88,
        )
        np.testing.assert_array_equal(first, second)


class IsolationTests(unittest.TestCase):
    def test_prepare_parser_has_no_test_or_detection_options(self):
        option_strings = {
            option
            for action in build_parser()._actions
            for option in action.option_strings
        }
        for forbidden in (
            "--test", "--test-labels", "--detect", "--evaluate", "--point-adjust"
        ):
            self.assertNotIn(forbidden, option_strings)

    def test_config_forbids_test_and_metrics(self):
        config_path = SCRIPT_DIR / "experiment_config.json"
        with config_path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)
        validate_data_isolation(config)
        self.assertIsNone(config["data_isolation"]["test_file"])
        self.assertIsNone(config["data_isolation"]["test_labels"])

    def test_partitions_are_disjoint_and_complete(self):
        ids1 = np.asarray([f"m-{i}" for i in range(100)])
        ref1, val1, _ = make_partition(
            dataset="dataset1",
            sample_ids=ids1,
            dataset_config={"reference_fraction": 0.7},
        )
        self.assertEqual(np.intersect1d(ref1, val1).size, 0)
        self.assertEqual(np.union1d(ref1, val1).size, 100)

        ids2 = np.asarray([f"s-{i}" for i in range(100)])
        ref2, val2, _ = make_partition(
            dataset="dataset2",
            sample_ids=ids2,
            dataset_config={"validation_hash_buckets": [0, 1, 2]},
        )
        self.assertEqual(np.intersect1d(ref2, val2).size, 0)
        self.assertEqual(np.union1d(ref2, val2).size, 100)


if __name__ == "__main__":
    unittest.main()

