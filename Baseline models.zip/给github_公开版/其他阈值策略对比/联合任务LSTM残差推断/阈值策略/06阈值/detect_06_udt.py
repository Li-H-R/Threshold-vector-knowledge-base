# -*- coding: utf-8 -*-
"""加载冻结的 06 UDT 工件，对一个测试文件执行异常检测。"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
COMMON_DIR = SCRIPT_DIR.parent / "00阈值"
for candidate in (PROJECT_ROOT, COMMON_DIR, SCRIPT_DIR):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from artifact_utils import (  # noqa: E402
    load_feature_array,
    load_optional_npz_array,
    load_score_state,
    save_json,
    sha256_file,
    transform_score,
)
from demo.anomaly_detection_demo import (  # noqa: E402
    align_labels,
    evaluate,
    event_ranges,
    load_labels,
)
from demo.threshold_strategies import causal_k_of_m  # noqa: E402
from main import DATASETS, compute, load_joint  # noqa: E402
from strategy_06_udt import (  # noqa: E402
    STRATEGY_ID,
    UDTThreshold,
    complementary_uncertainty,
    load_state_npz,
    mc_dropout_mahalanobis_scores,
    model_parameter_sha256,
)


_MODEL_CACHE: Dict[str, Tuple[Any, np.ndarray, np.ndarray, Dict[str, Any]]] = {}


def load_artifact(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        artifact = json.load(handle)
    required_flags = {
        "test_data_used": False,
        "test_labels_used": False,
        "detection_executed": False,
        "metrics_computed": False,
        "point_adjust_used": False,
    }
    if artifact.get("schema_version") != 1:
        raise ValueError("不支持的 06 工件 schema_version")
    if artifact.get("strategy_id") != STRATEGY_ID:
        raise ValueError("该工件不是 06 UDT")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("06 工件状态不是 READY_FOR_TEST")
    if artifact.get("formal_result_allowed") is not True:
        raise ValueError("06 工件不是正式标定工件")
    for key, expected in required_flags.items():
        if artifact.get(key) is not expected:
            raise ValueError(f"06 标定工件隔离标志异常：{key}")
    return artifact


def validate_artifact_files(
    artifact_path: Path, artifact: Dict[str, Any]
) -> Dict[str, str]:
    verified: Dict[str, str] = {}
    for key, filename in artifact["files"].items():
        candidate = artifact_path.parent / filename
        if not candidate.is_file():
            raise FileNotFoundError(f"找不到 06 工件文件：{candidate}")
        actual = sha256_file(candidate)
        expected = artifact["file_sha256"][key]
        if actual != expected:
            raise ValueError(f"06 工件文件 SHA-256 不一致：{key}")
        verified[key] = actual
    return verified


def load_frozen_strategy(
    artifact_path: Path, artifact: Dict[str, Any]
) -> UDTThreshold:
    state_path = artifact_path.parent / artifact["files"]["state"]
    strategy = UDTThreshold.from_state_dict(load_state_npz(state_path))
    strategy.assert_dataset(artifact["dataset"])
    checks = {
        "fixed_threshold": strategy.fixed_threshold,
        "alpha": strategy.alpha,
        "beta": strategy.beta,
        "c": strategy.c,
        "scale_factor": strategy.scale_factor_,
        "validation_mean": strategy.validation_mean_,
        "validation_std": strategy.validation_std_,
    }
    for key, actual in checks.items():
        expected = float(artifact["threshold"][key])
        if actual is None or not np.isclose(actual, expected, rtol=0.0, atol=1.0e-12):
            raise ValueError(f"UDT state 与工件中的 {key} 不一致")
    return strategy


def load_frozen_score_state(
    artifact: Dict[str, Any]
) -> Tuple[Dict[str, np.ndarray], Path, str]:
    upstream_artifact = Path(artifact["score"]["upstream_artifact"]).resolve()
    state_path = upstream_artifact.parent / "score_state.npz"
    if not state_path.is_file():
        raise FileNotFoundError(f"找不到公共 Mahalanobis 状态：{state_path}")
    actual = sha256_file(state_path)
    if actual != artifact["score"]["upstream_score_state_sha256"]:
        raise ValueError("公共 Mahalanobis 状态 SHA-256 与 06 工件不一致")
    return load_score_state(state_path), state_path, actual


def load_frozen_model(
    dataset: str, artifact: Dict[str, Any]
) -> Tuple[Any, np.ndarray, np.ndarray, Dict[str, Any]]:
    checkpoint_path = Path(DATASETS[dataset]["ckpt"]).resolve()
    if checkpoint_path != Path(artifact["model"]["checkpoint"]).resolve():
        raise ValueError("当前模型 checkpoint 路径与 06 工件不一致")
    if sha256_file(checkpoint_path) != artifact["model"]["checkpoint_sha256"]:
        raise ValueError("当前模型 checkpoint SHA-256 与 06 工件不一致")
    if dataset not in _MODEL_CACHE:
        _MODEL_CACHE[dataset] = load_joint(dataset)
    bundle = _MODEL_CACHE[dataset]
    model, _, _, cfg = bundle
    if int(cfg["input_dim"]) != int(artifact["model"]["input_dim"]):
        raise ValueError("checkpoint 输入维数与 06 工件不一致")
    if int(cfg.get("num_layers", 4)) != int(artifact["model"]["num_layers"]):
        raise ValueError("checkpoint LSTM 层数与 06 工件不一致")
    if not np.isclose(
        float(cfg.get("dropout", 0.1)),
        float(artifact["model"]["dropout"]),
        rtol=0.0,
        atol=1.0e-12,
    ):
        raise ValueError("checkpoint dropout 与 06 工件不一致")
    return bundle


def load_mc_contract(
    artifact_path: Path, artifact: Dict[str, Any], model: Any
) -> Dict[str, Any]:
    audit_path = artifact_path.parent / artifact["files"]["mc_dropout_audit"]
    with audit_path.open("r", encoding="utf-8") as handle:
        audit = json.load(handle)
    checks = {
        "posterior_samples": int(artifact["threshold"]["posterior_samples"]),
        "base_seed": int(artifact["threshold"]["mc_base_seed"]),
    }
    for key, expected in checks.items():
        if int(audit[key]) != expected:
            raise ValueError(f"MC Dropout 审计中的 {key} 与阈值工件不一致")
    current_parameter_hash = model_parameter_sha256(model)
    if current_parameter_hash != audit["parameter_sha256_after"]:
        raise ValueError("当前模型参数与正常标定阶段的模型参数不一致")
    return {
        "posterior_samples": checks["posterior_samples"],
        "base_seed": checks["base_seed"],
        "batch_size": int(audit["batch_size"]),
        "calibration_parameter_sha256": audit["parameter_sha256_after"],
    }


def validate_test_standardizer(
    test_path: Path,
    available_keys: Sequence[str],
    test_raw: np.ndarray,
    model_mean: np.ndarray,
    model_std: np.ndarray,
) -> Dict[str, Any]:
    audit: Dict[str, Any] = {
        "mean_std_present": False,
        "mean_matches_checkpoint": None,
        "std_matches_checkpoint": None,
        "mean_max_abs_difference_from_checkpoint": None,
        "std_max_abs_difference_from_checkpoint": None,
        "x_std_present": False,
        "x_std_matches_stored_standardizer": None,
        "max_abs_x_std_internal_difference": None,
        "deterministic_model_input_array": "x",
        "mc_model_input_source": "checkpoint_standardized_x",
        "stored_x_std_used_for_model": False,
    }
    stored_mean = None
    stored_std = None
    if "mean" in available_keys and "std" in available_keys:
        stored_mean = load_optional_npz_array(test_path, "mean").reshape(-1)
        stored_std = load_optional_npz_array(test_path, "std").reshape(-1)
        if stored_mean.shape != model_mean.shape or stored_std.shape != model_std.shape:
            raise ValueError("测试文件 mean/std 维数与 checkpoint 不一致")
        audit.update({
            "mean_std_present": True,
            "mean_matches_checkpoint": bool(
                np.allclose(stored_mean, model_mean, rtol=1.0e-6, atol=1.0e-6)
            ),
            "std_matches_checkpoint": bool(
                np.allclose(stored_std, model_std, rtol=1.0e-6, atol=1.0e-6)
            ),
            "mean_max_abs_difference_from_checkpoint": float(
                np.max(np.abs(stored_mean - model_mean))
            ),
            "std_max_abs_difference_from_checkpoint": float(
                np.max(np.abs(stored_std - model_std))
            ),
        })
    if "x_std" in available_keys:
        if stored_mean is None or stored_std is None:
            raise ValueError("测试文件包含 x_std，但缺少配套 mean/std")
        stored = load_optional_npz_array(test_path, "x_std").astype(np.float32)
        expected = (
            (test_raw - stored_mean[None, None, :])
            / (stored_std[None, None, :] + 1.0e-8)
        ).astype(np.float32)
        if stored.shape != expected.shape:
            raise ValueError("测试文件 x_std 与 x 形状不一致")
        max_diff = float(np.max(np.abs(stored - expected)))
        match = bool(np.allclose(stored, expected, rtol=1.0e-5, atol=1.0e-5))
        audit.update({
            "x_std_present": True,
            "x_std_matches_stored_standardizer": match,
            "max_abs_x_std_internal_difference": max_diff,
        })
        if not match:
            raise ValueError("测试文件 x_std 与其内置 mean/std 不一致")
    return audit


def type_level_metrics(
    labels: Optional[np.ndarray],
    anomaly_types: Optional[np.ndarray],
    point_pred: np.ndarray,
) -> Optional[Dict[str, Any]]:
    if labels is None or anomaly_types is None:
        return None
    output: Dict[str, Any] = {}
    for type_name in np.unique(anomaly_types):
        mask = anomaly_types == type_name
        count = int(mask.sum())
        positive_count = int(labels[mask].sum())
        item: Dict[str, Any] = {
            "count": count,
            "positive_count": positive_count,
            "point_predicted_positive": int(point_pred[mask].sum()),
        }
        if positive_count == count:
            item["point_recall"] = float(point_pred[mask].mean())
        elif positive_count == 0:
            item["point_false_positive_rate"] = float(point_pred[mask].mean())
        else:
            true_positive = int(np.sum(point_pred[mask] & (labels[mask] == 1)))
            false_positive = int(np.sum(point_pred[mask] & (labels[mask] == 0)))
            item["point_recall"] = float(true_positive / max(positive_count, 1))
            item["point_false_positive_rate"] = float(
                false_positive / max(count - positive_count, 1)
            )
        output[str(type_name)] = item
    return output


def save_detection_csv(
    path: Path,
    labels: Optional[np.ndarray],
    anomaly_types: Optional[np.ndarray],
    scores: np.ndarray,
    strategy: UDTThreshold,
    aleatoric: np.ndarray,
    epistemic: np.ndarray,
    total_uncertainty: np.ndarray,
    normalized_uncertainty: np.ndarray,
    thresholds: np.ndarray,
    point_pred: np.ndarray,
    alarm: np.ndarray,
) -> None:
    fields = [
        "index", "label", "anomaly_type", "deterministic_score",
        "fixed_threshold", "aleatoric_uncertainty", "epistemic_uncertainty",
        "scaled_epistemic_uncertainty", "total_uncertainty",
        "normalized_uncertainty", "dynamic_threshold", "decision_margin",
        "point_pred", "alarm",
    ]
    assert strategy.scale_factor_ is not None
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for index in range(scores.size):
            writer.writerow({
                "index": index,
                "label": "" if labels is None else int(labels[index]),
                "anomaly_type": (
                    "" if anomaly_types is None else str(anomaly_types[index])
                ),
                "deterministic_score": float(scores[index]),
                "fixed_threshold": float(strategy.fixed_threshold),
                "aleatoric_uncertainty": float(aleatoric[index]),
                "epistemic_uncertainty": float(epistemic[index]),
                "scaled_epistemic_uncertainty": float(
                    strategy.scale_factor_ * epistemic[index]
                ),
                "total_uncertainty": float(total_uncertainty[index]),
                "normalized_uncertainty": float(normalized_uncertainty[index]),
                "dynamic_threshold": float(thresholds[index]),
                "decision_margin": float(scores[index] - thresholds[index]),
                "point_pred": int(point_pred[index]),
                "alarm": int(alarm[index]),
            })


def save_plot(
    path: Path,
    scores: np.ndarray,
    thresholds: np.ndarray,
    point_pred: np.ndarray,
    aleatoric: np.ndarray,
    scaled_epistemic: np.ndarray,
    total_uncertainty: np.ndarray,
    labels: Optional[np.ndarray],
    dataset: str,
) -> Optional[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"

    x = np.arange(scores.size)
    figure, axes = plt.subplots(2, 1, figsize=(13, 8), sharex=True)
    axes[0].plot(x, scores, color="#2f6690", linewidth=0.9, label="deterministic score")
    axes[0].plot(x, thresholds, color="#cf4b3e", linewidth=1.1, label="UDT threshold")
    if np.any(point_pred):
        axes[0].scatter(
            x[point_pred], scores[point_pred], s=8, color="#5b2c6f", label="detected"
        )
    axes[1].plot(x, aleatoric, color="#2a9d8f", linewidth=0.8, label="aleatoric")
    axes[1].plot(
        x, scaled_epistemic, color="#e9c46a", linewidth=0.8,
        label="scaled epistemic",
    )
    axes[1].plot(
        x, total_uncertainty, color="#e76f51", linewidth=1.0,
        label="combined uncertainty",
    )
    if labels is not None:
        for start, end in event_ranges(labels):
            for axis in axes:
                axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.08)
    axes[0].set_ylabel("score")
    axes[0].set_title(f"06 uncertainty-informed dynamic threshold - {dataset}")
    axes[1].set_ylabel("uncertainty")
    axes[1].set_xlabel("stored test-window index")
    for axis in axes:
        axis.grid(alpha=0.2)
        axis.legend(loc="best")
    figure.tight_layout()
    figure.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(figure)
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="运行 06 UDT 动态阈值异常检测")
    parser.add_argument("--artifact", required=True, type=Path)
    parser.add_argument("--test", required=True, type=Path)
    parser.add_argument("--labels", type=Path)
    parser.add_argument("--array-key", default="x")
    parser.add_argument("--label-key", default="y_true")
    parser.add_argument("--type-key", default="y_type")
    parser.add_argument("--input-space", choices=("raw",), default="raw")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--k", type=int, default=1)
    parser.add_argument("--m", type=int, default=1)
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    if args.k != 1 or args.m != 1:
        raise ValueError("06 主实验固定 K=1, M=1；持续性规则应另做消融")
    output_dir = args.output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖：{output_dir}")

    artifact_path = args.artifact.resolve()
    artifact = load_artifact(artifact_path)
    verified_files = validate_artifact_files(artifact_path, artifact)
    state_path = artifact_path.parent / artifact["files"]["state"]
    initial_state_hash = sha256_file(state_path)
    strategy = load_frozen_strategy(artifact_path, artifact)
    score_state, score_state_path, initial_score_state_hash = (
        load_frozen_score_state(artifact)
    )

    dataset = artifact["dataset"]
    bundle = load_frozen_model(dataset, artifact)
    model, mean, std, cfg = bundle
    mc_contract = load_mc_contract(artifact_path, artifact, model)
    initial_model_hash = model_parameter_sha256(model)

    test_path = args.test.resolve()
    test, test_metadata = load_feature_array(test_path, args.array_key)
    if test.ndim != 3 or test.shape[1] != int(DATASETS[dataset]["window_size"]):
        raise ValueError("测试文件必须是已切好的 (N,10,D) 窗口")
    if test.shape[-1] != int(cfg["input_dim"]):
        raise ValueError("测试特征维与模型不一致")
    available_keys = test_metadata.get("available_keys") or []
    standardizer_audit = validate_test_standardizer(
        test_path, available_keys, test, mean, std
    )

    deterministic_start = time.perf_counter()
    residual_chunks = []
    batch_size = mc_contract["batch_size"]
    for start in range(0, test.shape[0], batch_size):
        end = min(start + batch_size, test.shape[0])
        residual = compute(
            test[start:end],
            dataset=dataset,
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual_chunks.append(residual.mean(axis=1))
    residual_mean = np.concatenate(residual_chunks, axis=0)
    scores = transform_score(residual_mean, "mahalanobis", score_state)
    deterministic_seconds = time.perf_counter() - deterministic_start

    checkpoint_standardized = (
        (test - mean[None, None, :]) / (std[None, None, :] + 1.0e-8)
    ).astype(np.float32)
    mc_start = time.perf_counter()
    posterior_scores, mc_audit = mc_dropout_mahalanobis_scores(
        checkpoint_standardized,
        model=model,
        score_state=score_state,
        posterior_samples=mc_contract["posterior_samples"],
        batch_size=batch_size,
        base_seed=mc_contract["base_seed"],
    )
    probabilities = strategy.probabilities(posterior_scores)
    aleatoric, epistemic = complementary_uncertainty(probabilities)
    thresholds, total_uncertainty, normalized_uncertainty = (
        strategy.thresholds_from_components(aleatoric, epistemic)
    )
    point_pred = scores > thresholds
    alarm = causal_k_of_m(point_pred, k=args.k, m=args.m)
    mc_seconds = time.perf_counter() - mc_start

    # 预测和阈值全部产生后才读取标签；标签不参与任何模型、得分或阈值计算。
    labels = None
    if args.labels is not None:
        labels = align_labels(load_labels(args.labels), test, scores.size)
    elif args.label_key in available_keys:
        labels = align_labels(
            load_optional_npz_array(test_path, args.label_key), test, scores.size
        )
    anomaly_types = None
    if args.type_key in available_keys:
        anomaly_types = (
            load_optional_npz_array(test_path, args.type_key).reshape(-1).astype(str)
        )
        if anomaly_types.size != scores.size:
            raise ValueError("异常类型长度与得分长度不一致")

    final_state_hash = sha256_file(state_path)
    final_score_state_hash = sha256_file(score_state_path)
    final_model_hash = model_parameter_sha256(model)
    if final_state_hash != initial_state_hash:
        raise RuntimeError("检测过程修改了冻结 udt_state.npz")
    if final_score_state_hash != initial_score_state_hash:
        raise RuntimeError("检测过程修改了冻结 Mahalanobis 状态")
    if final_model_hash != initial_model_hash:
        raise RuntimeError("检测过程修改了模型权重")

    output_dir.mkdir(parents=True, exist_ok=False)
    save_detection_csv(
        output_dir / "detections.csv",
        labels,
        anomaly_types,
        scores,
        strategy,
        aleatoric,
        epistemic,
        total_uncertainty,
        normalized_uncertainty,
        thresholds,
        point_pred,
        alarm,
    )
    np.savez_compressed(
        output_dir / "mc_posterior.npz",
        posterior_scores=posterior_scores,
        posterior_probabilities=probabilities,
        aleatoric_uncertainty=aleatoric,
        epistemic_uncertainty=epistemic,
        total_uncertainty=total_uncertainty,
        normalized_uncertainty=normalized_uncertainty,
        dynamic_threshold=thresholds,
    )

    decision_margin = scores - thresholds
    point_metrics = evaluate(labels, point_pred, decision_margin) if labels is not None else None
    alarm_metrics = evaluate(labels, alarm, decision_margin) if labels is not None else None
    type_metrics = type_level_metrics(labels, anomaly_types, point_pred)
    summary: Dict[str, Any] = {
        "strategy_id": STRATEGY_ID,
        "status": "TESTED",
        "artifact": str(artifact_path),
        "artifact_status_before_test": artifact["status"],
        "artifact_file_hashes_verified": verified_files,
        "dataset": dataset,
        "time_scale": artifact["time_scale"],
        "test_file": str(test_path),
        "test_sha256": sha256_file(test_path),
        "test_file_structure": test_metadata,
        "test_input_shape": list(test.shape),
        "test_standardizer_audit": standardizer_audit,
        "num_windows": int(scores.size),
        "num_normal_labels": None if labels is None else int(np.sum(labels == 0)),
        "num_anomaly_labels": None if labels is None else int(np.sum(labels == 1)),
        "model": {
            "checkpoint": artifact["model"]["checkpoint"],
            "checkpoint_sha256": artifact["model"]["checkpoint_sha256"],
            "parameter_sha256_before": initial_model_hash,
            "parameter_sha256_after": final_model_hash,
            "weights_updated": False,
            "retrained_on_test": False,
        },
        "score": {
            "method": "deterministic_ledoit_wolf_mahalanobis",
            "state": str(score_state_path),
            "state_sha256_before": initial_score_state_hash,
            "state_sha256_after": final_score_state_hash,
            "state_refit_on_test": False,
            "minimum": float(np.min(scores)),
            "mean": float(np.mean(scores)),
            "maximum": float(np.max(scores)),
        },
        "udt": {
            "state": str(state_path),
            "state_sha256_before": initial_state_hash,
            "state_sha256_after": final_state_hash,
            "state_refit_on_test": False,
            "fixed_threshold": float(strategy.fixed_threshold),
            "alpha": float(strategy.alpha),
            "beta": float(strategy.beta),
            "c": float(strategy.c),
            "scale_factor": float(strategy.scale_factor_),
            "validation_mean": float(strategy.validation_mean_),
            "validation_std": float(strategy.validation_std_),
            "posterior_samples": int(mc_contract["posterior_samples"]),
            "mc_base_seed": int(mc_contract["base_seed"]),
            "mc_batch_size": int(batch_size),
            "threshold_clip": None,
            "decision_rule": "deterministic_score > dynamic_threshold",
        },
        "dynamic_threshold": {
            "minimum": float(np.min(thresholds)),
            "mean": float(np.mean(thresholds)),
            "maximum": float(np.max(thresholds)),
            "std": float(np.std(thresholds, ddof=0)),
            "nonpositive_count": int(np.sum(thresholds <= 0.0)),
        },
        "uncertainty": {
            "aleatoric_mean": float(np.mean(aleatoric)),
            "epistemic_mean": float(np.mean(epistemic)),
            "total_mean": float(np.mean(total_uncertainty)),
            "total_std": float(np.std(total_uncertainty, ddof=0)),
        },
        "mc_dropout_audit": mc_audit,
        "runtime_seconds": {
            "deterministic_forward_and_score": float(deterministic_seconds),
            "mc_uncertainty_and_threshold": float(mc_seconds),
            "total_inference": float(deterministic_seconds + mc_seconds),
        },
        "persistence": {"k": args.k, "m": args.m},
        "point_adjust_used": False,
        "test_data_used_for_refit_or_threshold_selection": False,
        "test_labels_loaded_after_predictions": True,
        "test_labels_used_for_metrics_only": labels is not None,
        "num_point_detections": int(point_pred.sum()),
        "num_alarms": int(alarm.sum()),
        "type_metrics": type_metrics,
        "point_metrics": point_metrics,
        "alarm_metrics": alarm_metrics,
        "sequence_audit": {
            "stored_order_used_for_threshold_update": False,
            "true_chronological_metadata_available": False,
            "event_metrics_formally_used": False,
            "note": (
                "测试文件按正常块后接异常块存储，且没有真实时间戳或事件 ID；"
                "UDT 对每个窗口独立计算阈值，正式结果只解释点级指标。"
            ),
        },
        "formal_point_result_allowed": True,
        "formal_event_result_allowed": False,
    }
    plot_path = output_dir / "udt_detection.png"
    warning = save_plot(
        plot_path,
        scores,
        thresholds,
        point_pred,
        aleatoric,
        float(strategy.scale_factor_) * epistemic,
        total_uncertainty,
        labels,
        dataset,
    )
    if warning:
        summary["plot_warning"] = warning
    else:
        summary["plot"] = str(plot_path)
    summary["output_file_sha256"] = {
        "detections_csv": sha256_file(output_dir / "detections.csv"),
        "mc_posterior_npz": sha256_file(output_dir / "mc_posterior.npz"),
        **(
            {"plot": sha256_file(plot_path)}
            if plot_path.is_file()
            else {}
        ),
    }
    save_json(output_dir / "summary.json", summary)
    print(
        f"{dataset}: windows={scores.size}, detected={int(point_pred.sum())}, "
        f"threshold_mean={float(np.mean(thresholds)):.6f}, "
        f"seconds={deterministic_seconds + mc_seconds:.2f}"
    )
    print(f"结果：{output_dir / 'summary.json'}")
    return summary


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
