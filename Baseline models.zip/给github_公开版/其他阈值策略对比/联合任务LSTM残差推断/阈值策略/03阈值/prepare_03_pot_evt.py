# -*- coding: utf-8 -*-
"""只用纯正常标定得分准备 03 离线 POT/GPD 阈值工件。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from scipy.stats import genpareto


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from strategy_03_pot_evt import (  # noqa: E402
    POTEVTThreshold,
    SCHEMA_VERSION,
    STRATEGY_ID,
    validate_calibration_scores,
)


CONFIG_PATH = SCRIPT_DIR / "experiment_config.json"
FORBIDDEN_PATH_FRAGMENTS = ("测试集数据", "实验结果")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"{path} 的顶层必须是 JSON object")
    return value


def save_json(path: Path, value: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def resolve_project_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def assert_preparation_path(path: Path, label: str) -> None:
    resolved = path.resolve()
    for part in resolved.parts:
        if any(fragment in part for fragment in FORBIDDEN_PATH_FRAGMENTS):
            raise ValueError(f"准备阶段禁止 {label} 指向测试或实验结果目录：{resolved}")
    if resolved.name.lower() in {"detections.csv", "summary.json"}:
        raise ValueError(f"准备阶段禁止读取检测结果文件：{resolved}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="准备 03 阈值：正常 Mahalanobis 得分的离线 POT/GPD 阈值"
    )
    parser.add_argument("--dataset", required=True, choices=("dataset1", "dataset2"))
    parser.add_argument(
        "--config",
        type=Path,
        default=CONFIG_PATH,
        help="冻结实验配置，默认使用 03 目录下 experiment_config.json",
    )
    parser.add_argument(
        "--upstream-score-artifact",
        type=Path,
        help="00 正式公共得分工件目录；默认从冻结配置读取",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="正式输出目录；默认从冻结配置读取",
    )
    return parser


def validate_config(config: Dict[str, Any]) -> None:
    if config.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("experiment_config.json 的 schema_version 不正确")
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("experiment_config.json 的 strategy_id 不正确")

    isolation = config.get("data_isolation", {})
    if isolation.get("test_file") is not None:
        raise ValueError("准备配置中 test_file 必须为 null")
    if isolation.get("test_labels") is not None:
        raise ValueError("准备配置中 test_labels 必须为 null")
    for key in (
        "test_data_allowed_during_prepare",
        "detection_allowed_during_prepare",
        "metrics_allowed_during_prepare",
    ):
        if isolation.get(key) is not False:
            raise ValueError(f"准备配置必须显式设置 {key}=false")

    strategy = config["strategy_contract"]
    if strategy.get("interface_type") != "static_scalar_threshold":
        raise ValueError("03 正式配置必须使用 static_scalar_threshold 接口")
    if strategy.get("gpd_fit_method") != "maximum_likelihood":
        raise ValueError("03 正式配置只允许 GPD maximum_likelihood 拟合")
    if float(strategy.get("gpd_location")) != 0.0:
        raise ValueError("03 正式配置必须固定 GPD location=0")
    if strategy.get("formal_fallback") is not None:
        raise ValueError("03 正式配置禁止经验分位数回退")
    if not np.isclose(
        1.0 - float(strategy["alarm_quantile"]),
        float(strategy["target_tail_probability"]),
        rtol=0.0,
        atol=1.0e-15,
    ):
        raise ValueError("alarm_quantile 与 target_tail_probability 不互补")


def audit_normal_calibration(
    calibration_path: Path,
    dataset: str,
    contract: Dict[str, Any],
    upstream_artifact: Dict[str, Any],
) -> Tuple[Dict[str, Any], int]:
    expected_hash = str(contract["calibration_sha256"])
    actual_hash = sha256_file(calibration_path)
    if actual_hash != expected_hash:
        raise ValueError("正常标定文件 SHA-256 与冻结配置不一致")
    if actual_hash != upstream_artifact["calibration"]["source_sha256"]:
        raise ValueError("正常标定文件 SHA-256 与上游 00 工件不一致")

    with np.load(calibration_path, allow_pickle=False) as archive:
        if "X" not in archive.files or "y" not in archive.files:
            raise ValueError("正常标定 NPZ 必须同时包含 X 和 y")
        features = np.asarray(archive["X"])
        labels = np.asarray(archive["y"]).reshape(-1)
        if list(features.shape) != list(contract["calibration_shape"]):
            raise ValueError(f"正常标定 X 形状 {features.shape} 与冻结配置不一致")
        if labels.size != features.shape[0]:
            raise ValueError("正常标定 y 长度与窗口数不一致")
        if not np.all(labels == 0):
            raise ValueError("正常标定标签并非全部为 0，拒绝正式拟合")
        if not np.all(np.isfinite(features)):
            raise ValueError("正常标定特征中存在 NaN 或 Inf")

        unique, counts = np.unique(labels, return_counts=True)
        label_counts = {
            str(key.item() if isinstance(key, np.generic) else key): int(value)
            for key, value in zip(unique, counts)
        }
        present_metadata: Dict[str, Any] = {}
        for key in (
            "dataset",
            "input_space",
            "window_size",
            "feature_dimension",
            "checkpoint_name",
            "checkpoint_sha256",
        ):
            if key in archive.files:
                value = np.asarray(archive[key])
                present_metadata[key] = (
                    value.item() if value.ndim == 0 else value.tolist()
                )

    if dataset == "dataset2":
        expected_metadata = {
            "dataset": dataset,
            "input_space": contract["input_space"],
            "window_size": 10,
            "feature_dimension": int(contract["input_dim"]),
            "checkpoint_sha256": contract["model_sha256"],
        }
        for key, expected in expected_metadata.items():
            if present_metadata.get(key) != expected:
                raise ValueError(
                    f"秒级正常标定元数据 {key}={present_metadata.get(key)!r}，"
                    f"期望 {expected!r}"
                )

    metadata_gaps = [
        key
        for key in (
            "dataset",
            "input_space",
            "window_size",
            "feature_dimension",
            "checkpoint_sha256",
        )
        if key not in present_metadata
    ]
    audit = {
        "dataset": dataset,
        "source_path": str(calibration_path),
        "source_sha256": actual_hash,
        "input_shape": list(features.shape),
        "label_counts": label_counts,
        "all_labels_normal": True,
        "all_features_finite": True,
        "expected_input_space": contract["input_space"],
        "input_space_evidence": contract["input_space_evidence"],
        "present_source_metadata": present_metadata,
        "source_metadata_gaps": metadata_gaps,
        "source_file_modified": False,
        "test_data_used": False,
    }
    return audit, int(features.shape[0])


def audit_model(model_path: Path, contract: Dict[str, Any]) -> Dict[str, Any]:
    actual_hash = sha256_file(model_path)
    if actual_hash != contract["model_sha256"]:
        raise ValueError("模型 checkpoint SHA-256 与冻结配置不一致")
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    model_config = checkpoint.get("model_config", {})
    input_dim = int(model_config.get("input_dim", -1))
    if input_dim != int(contract["input_dim"]):
        raise ValueError("模型 input_dim 与数据集冻结配置不一致")
    standardizer = checkpoint.get("standardizer", {})
    if len(standardizer.get("mean", [])) != input_dim:
        raise ValueError("checkpoint standardizer.mean 维数不正确")
    if len(standardizer.get("std", [])) != input_dim:
        raise ValueError("checkpoint standardizer.std 维数不正确")
    return {
        "checkpoint": model_path.name,
        "checkpoint_path": str(model_path),
        "checkpoint_sha256": actual_hash,
        "model_config": model_config,
        "standardizer_dimension": input_dim,
    }


def audit_upstream_scores(
    upstream_dir: Path,
    dataset: str,
    contract: Dict[str, Any],
    num_windows: int,
) -> Tuple[np.ndarray, Dict[str, Any], Dict[str, Any]]:
    artifact_path = upstream_dir / "threshold_artifact.json"
    score_path = upstream_dir / "calibration_scores.npy"
    score_state_path = upstream_dir / "score_state.npz"
    for path in (artifact_path, score_path, score_state_path):
        if not path.is_file():
            raise FileNotFoundError(f"缺少上游公共得分工件：{path}")

    actual_state_hash = sha256_file(score_state_path)
    actual_scores_hash = sha256_file(score_path)
    if actual_state_hash != contract["upstream_score_state_sha256"]:
        raise ValueError("上游 score_state.npz SHA-256 与冻结配置不一致")
    if actual_scores_hash != contract["upstream_scores_sha256"]:
        raise ValueError("上游 calibration_scores.npy SHA-256 与冻结配置不一致")

    artifact = load_json(artifact_path)
    if artifact.get("scheme_id") != "00_fixed98":
        raise ValueError("上游工件不是 00_fixed98")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("上游 00 工件状态不是 READY_FOR_TEST")
    if artifact.get("formal_result_allowed") is not True:
        raise ValueError("上游 00 工件不是正式真实标定工件")
    if artifact.get("dataset") != dataset:
        raise ValueError("上游 00 工件的数据集标识不匹配")
    if artifact["model"]["checkpoint_sha256"] != contract["model_sha256"]:
        raise ValueError("上游 00 工件的模型哈希与冻结配置不一致")
    if artifact["calibration"]["source_sha256"] != contract["calibration_sha256"]:
        raise ValueError("上游 00 工件的正常标定哈希与冻结配置不一致")
    if artifact["score"]["method"] != "mahalanobis":
        raise ValueError("03 主实验只允许复用 Mahalanobis 公共得分")
    if artifact["residual"]["space"] != "standardized":
        raise ValueError("上游残差不在标准化空间")
    if artifact["calibration"]["num_windows"] != num_windows:
        raise ValueError("上游得分窗口数与正常标定窗口数不一致")

    scores = np.asarray(np.load(score_path, allow_pickle=False), dtype=np.float64).reshape(-1)
    if scores.size != num_windows:
        raise ValueError("上游 calibration_scores 长度不正确")
    validate_calibration_scores(scores)

    with np.load(score_state_path, allow_pickle=False) as state:
        required = {"location", "precision", "covariance", "shrinkage"}
        if not required.issubset(state.files):
            raise ValueError("上游 Mahalanobis score_state 字段不完整")
        input_dim = int(contract["input_dim"])
        if np.asarray(state["location"]).shape != (input_dim,):
            raise ValueError("上游 Mahalanobis location 维数不正确")
        if np.asarray(state["precision"]).shape != (input_dim, input_dim):
            raise ValueError("上游 Mahalanobis precision 维数不正确")
        if np.asarray(state["covariance"]).shape != (input_dim, input_dim):
            raise ValueError("上游 Mahalanobis covariance 维数不正确")

    audit = {
        "artifact_dir": str(upstream_dir),
        "artifact_file": str(artifact_path),
        "artifact_sha256": sha256_file(artifact_path),
        "score_state_file": str(score_state_path),
        "score_state_sha256": actual_state_hash,
        "calibration_scores_file": str(score_path),
        "calibration_scores_sha256": actual_scores_hash,
        "num_scores": int(scores.size),
        "score_method": "ledoit_wolf_mahalanobis",
        "upstream_empirical_threshold_not_used": True,
    }
    return scores, artifact, audit


def make_strategy(parameters: Dict[str, Any], *, initial_quantile: Optional[float] = None) -> POTEVTThreshold:
    return POTEVTThreshold(
        initial_quantile=(
            float(parameters["initial_quantile"])
            if initial_quantile is None
            else float(initial_quantile)
        ),
        alarm_quantile=float(parameters["alarm_quantile"]),
        tail_probability=float(parameters["target_tail_probability"]),
        min_exceedances=int(parameters["min_exceedances"]),
        min_samples=int(parameters["min_samples"]),
        min_unique_exceedances=int(parameters["min_unique_exceedances"]),
    )


def threshold_stability(
    scores: np.ndarray,
    parameters: Dict[str, Any],
    quantiles: Sequence[float],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for quantile in quantiles:
        strategy = make_strategy(parameters, initial_quantile=float(quantile)).fit(scores)
        state = strategy.state_dict()
        rows.append(
            {
                "initial_quantile": float(quantile),
                "initial_threshold": state["initial_threshold"],
                "num_exceedances": state["num_exceedances"],
                "exceedance_rate": state["exceedance_rate"],
                "gpd_shape": state["gpd_shape"],
                "gpd_scale": state["gpd_scale"],
                "threshold": state["threshold"],
            }
        )
    return rows


def bootstrap_thresholds(
    scores: np.ndarray,
    parameters: Dict[str, Any],
    replicates: int,
    seed: int,
) -> Tuple[np.ndarray, Dict[str, int]]:
    if replicates <= 0:
        raise ValueError("bootstrap_replicates 必须大于 0")
    rng = np.random.default_rng(seed)
    thresholds = np.full(replicates, np.nan, dtype=np.float64)
    errors: Counter[str] = Counter()
    for index in range(replicates):
        sampled = scores[rng.integers(0, scores.size, size=scores.size)]
        try:
            fitted = make_strategy(parameters).fit(sampled)
            thresholds[index] = float(fitted.threshold_)
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            errors[f"{type(exc).__name__}: {exc}"] += 1
        if (index + 1) % 100 == 0 or index + 1 == replicates:
            print(
                f"  bootstrap {index + 1}/{replicates}，"
                f"成功 {int(np.sum(np.isfinite(thresholds[:index + 1])))}",
                flush=True,
            )
    return thresholds, dict(errors)


def write_dict_rows(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"没有可写入 {path.name} 的记录")
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_bootstrap_csv(path: Path, thresholds: np.ndarray) -> None:
    rows = [
        {
            "replicate": index,
            "success": int(np.isfinite(value)),
            "threshold": "" if not np.isfinite(value) else f"{value:.17g}",
        }
        for index, value in enumerate(thresholds)
    ]
    write_dict_rows(path, rows)


def build_mean_excess(scores: np.ndarray) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for quantile in np.linspace(0.80, 0.98, 25):
        threshold = float(np.quantile(scores, quantile, method="linear"))
        exceedances = scores[scores > threshold] - threshold
        rows.append(
            {
                "quantile": float(quantile),
                "threshold": threshold,
                "num_exceedances": int(exceedances.size),
                "mean_excess": float(np.mean(exceedances)),
            }
        )
    return rows


def save_diagnostics(
    output_dir: Path,
    scores: np.ndarray,
    strategy: POTEVTThreshold,
    dataset: str,
    stability_rows: Sequence[Dict[str, Any]],
    bootstrap: np.ndarray,
) -> Dict[str, Any]:
    assert strategy.exceedances_ is not None
    assert strategy.initial_threshold_ is not None
    assert strategy.shape_ is not None
    assert strategy.scale_ is not None
    assert strategy.threshold_ is not None

    exceedances = strategy.exceedances_
    target_exceedance = float(strategy.threshold_ - strategy.initial_threshold_)
    x_max = max(float(np.max(exceedances) * 1.10), target_exceedance * 1.05)
    grid = np.linspace(0.0, x_max, 1200)
    pdf = genpareto.pdf(grid, c=strategy.shape_, loc=0.0, scale=strategy.scale_)
    cdf = genpareto.cdf(grid, c=strategy.shape_, loc=0.0, scale=strategy.scale_)
    curve = np.column_stack(
        (
            strategy.initial_threshold_ + grid,
            grid,
            pdf,
            cdf,
            1.0 - cdf,
        )
    )
    np.savetxt(
        output_dir / "tail_fit_curve.csv",
        curve,
        delimiter=",",
        header="score,exceedance,gpd_pdf,gpd_cdf,gpd_survival",
        comments="",
        fmt="%.12g",
    )

    write_dict_rows(output_dir / "threshold_stability.csv", stability_rows)
    mean_excess_rows = build_mean_excess(scores)
    write_dict_rows(output_dir / "mean_excess.csv", mean_excess_rows)
    save_bootstrap_csv(output_dir / "bootstrap_thresholds.csv", bootstrap)

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 2, figsize=(12.0, 5.0))
    axes[0].hist(
        exceedances,
        bins=40,
        density=True,
        color="#5f7f9f",
        alpha=0.55,
        label="normal tail exceedances",
    )
    axes[0].plot(grid, pdf, color="#173f5f", linewidth=2.0, label="fitted GPD")
    axes[0].axvline(
        target_exceedance,
        color="#d1495b",
        linewidth=2.0,
        label=f"target threshold = {strategy.threshold_:.6g}",
    )
    axes[0].set_xlim(0.0, x_max)
    axes[0].set_xlabel("exceedance above initial threshold")
    axes[0].set_ylabel("conditional density")
    axes[0].set_title(f"03 POT tail fit - {dataset}")
    axes[0].grid(alpha=0.2)
    axes[0].legend()

    empirical = np.sort(exceedances)
    empirical_survival = (empirical.size - np.arange(empirical.size)) / empirical.size
    fitted_survival = genpareto.sf(
        empirical, c=strategy.shape_, loc=0.0, scale=strategy.scale_
    )
    axes[1].plot(
        empirical,
        empirical_survival,
        color="#5f7f9f",
        linewidth=1.5,
        label="empirical tail",
    )
    axes[1].plot(
        empirical,
        fitted_survival,
        color="#173f5f",
        linewidth=2.0,
        label="fitted GPD",
    )
    axes[1].set_yscale("log")
    axes[1].set_xlabel("exceedance above initial threshold")
    axes[1].set_ylabel("conditional survival probability")
    axes[1].set_title("Tail survival audit")
    axes[1].grid(alpha=0.2)
    axes[1].legend()
    figure.tight_layout()
    figure.savefig(output_dir / "tail_fit_plot.png", dpi=180, bbox_inches="tight")
    plt.close(figure)

    probabilities = (np.arange(1, empirical.size + 1) - 0.5) / empirical.size
    theoretical = genpareto.ppf(
        probabilities, c=strategy.shape_, loc=0.0, scale=strategy.scale_
    )
    qq_limit = max(float(np.max(empirical)), float(np.max(theoretical)))
    figure, axis = plt.subplots(figsize=(6.0, 5.5))
    axis.scatter(theoretical, empirical, s=14, alpha=0.7, color="#35618a")
    axis.plot([0.0, qq_limit], [0.0, qq_limit], "--", color="#d1495b")
    axis.set_xlabel("theoretical GPD quantiles")
    axis.set_ylabel("empirical exceedance quantiles")
    axis.set_title(f"GPD QQ plot - {dataset}")
    axis.grid(alpha=0.2)
    figure.tight_layout()
    figure.savefig(output_dir / "gpd_qq_plot.png", dpi=180, bbox_inches="tight")
    plt.close(figure)

    fitted_probabilities = genpareto.cdf(
        empirical, c=strategy.shape_, loc=0.0, scale=strategy.scale_
    )
    figure, axis = plt.subplots(figsize=(6.0, 5.5))
    axis.scatter(
        fitted_probabilities, probabilities, s=14, alpha=0.7, color="#35618a"
    )
    axis.plot([0.0, 1.0], [0.0, 1.0], "--", color="#d1495b")
    axis.set_xlabel("fitted GPD probability")
    axis.set_ylabel("empirical probability")
    axis.set_title(f"GPD PP plot - {dataset}")
    axis.grid(alpha=0.2)
    figure.tight_layout()
    figure.savefig(output_dir / "gpd_pp_plot.png", dpi=180, bbox_inches="tight")
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(7.0, 5.0))
    axis.plot(
        [row["threshold"] for row in mean_excess_rows],
        [row["mean_excess"] for row in mean_excess_rows],
        marker="o",
        markersize=3,
        color="#35618a",
    )
    axis.axvline(
        strategy.initial_threshold_,
        color="#d1495b",
        linestyle="--",
        label=f"formal u (q={strategy.initial_quantile:.3f})",
    )
    axis.set_xlabel("candidate initial threshold")
    axis.set_ylabel("mean exceedance")
    axis.set_title(f"Mean-excess audit - {dataset}")
    axis.grid(alpha=0.2)
    axis.legend()
    figure.tight_layout()
    figure.savefig(output_dir / "mean_excess_plot.png", dpi=180, bbox_inches="tight")
    plt.close(figure)

    return {
        "tail_curve_file": "tail_fit_curve.csv",
        "tail_fit_plot_file": "tail_fit_plot.png",
        "qq_plot_file": "gpd_qq_plot.png",
        "pp_plot_file": "gpd_pp_plot.png",
        "mean_excess_file": "mean_excess.csv",
        "mean_excess_plot_file": "mean_excess_plot.png",
        "threshold_stability_file": "threshold_stability.csv",
        "bootstrap_thresholds_file": "bootstrap_thresholds.csv",
        "plots_use_normal_calibration_only": True,
    }


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config_path = args.config.resolve()
    assert_preparation_path(config_path, "配置")
    config = load_json(config_path)
    validate_config(config)
    parameters = config["strategy_contract"]
    diagnostics = config["diagnostics"]
    contract = config["datasets"][args.dataset]

    model_path = resolve_project_path(contract["model"])
    calibration_path = resolve_project_path(contract["calibration"])
    upstream_dir = (
        args.upstream_score_artifact.resolve()
        if args.upstream_score_artifact
        else resolve_project_path(contract["upstream_score_artifact"])
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir
        else resolve_project_path(contract["artifact_dir"])
    )
    for path, label in (
        (model_path, "读取模型"),
        (calibration_path, "读取正常标定集"),
        (upstream_dir, "读取公共得分工件"),
        (output_dir, "写入输出"),
    ):
        assert_preparation_path(path, label)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖正式工件：{output_dir}")

    model_audit = audit_model(model_path, contract)
    upstream_artifact = load_json(upstream_dir / "threshold_artifact.json")
    calibration_audit, num_windows = audit_normal_calibration(
        calibration_path, args.dataset, contract, upstream_artifact
    )
    scores, _, upstream_audit = audit_upstream_scores(
        upstream_dir, args.dataset, contract, num_windows
    )

    strategy = make_strategy(parameters).fit(scores)
    state = strategy.state_dict()
    stability_rows = threshold_stability(
        scores,
        parameters,
        diagnostics["stability_initial_quantiles"],
    )

    replicates = int(diagnostics["bootstrap_replicates"])
    bootstrap_seed = int(diagnostics["bootstrap_seed"])
    print(
        f"{args.dataset}: 正常得分 {scores.size} 个，正式 POT 阈值已拟合；"
        f"开始 {replicates} 次正常数据 bootstrap 稳定性审计……",
        flush=True,
    )
    bootstrap, bootstrap_errors = bootstrap_thresholds(
        scores, parameters, replicates, bootstrap_seed
    )
    valid_bootstrap = bootstrap[np.isfinite(bootstrap)]
    success_rate = float(valid_bootstrap.size / bootstrap.size)
    if success_rate < float(diagnostics["min_bootstrap_success_rate"]):
        raise RuntimeError(
            f"bootstrap 成功率 {success_rate:.3f} 未达到门槛 "
            f"{diagnostics['min_bootstrap_success_rate']}"
        )
    interval = diagnostics["bootstrap_interval"]
    bootstrap_summary = {
        "replicates": int(bootstrap.size),
        "seed": bootstrap_seed,
        "successes": int(valid_bootstrap.size),
        "failures": int(bootstrap.size - valid_bootstrap.size),
        "success_rate": success_rate,
        "failure_reasons": bootstrap_errors,
        "mean": float(np.mean(valid_bootstrap)),
        "std": (
            float(np.std(valid_bootstrap, ddof=1))
            if valid_bootstrap.size > 1
            else 0.0
        ),
        "median": float(np.median(valid_bootstrap)),
        "ci_lower_probability": float(interval[0]),
        "ci_upper_probability": float(interval[1]),
        "ci_lower": float(np.quantile(valid_bootstrap, float(interval[0]))),
        "ci_upper": float(np.quantile(valid_bootstrap, float(interval[1]))),
        "min": float(np.min(valid_bootstrap)),
        "max": float(np.max(valid_bootstrap)),
        "changes_formal_threshold": False,
    }

    output_dir.mkdir(parents=True, exist_ok=False)
    copied_scores_path = output_dir / "calibration_scores.npy"
    shutil.copy2(upstream_dir / "calibration_scores.npy", copied_scores_path)
    if sha256_file(copied_scores_path) != upstream_audit["calibration_scores_sha256"]:
        raise RuntimeError("复制后的正常标定得分哈希不一致")

    assert strategy.exceedances_ is not None
    np.save(output_dir / "tail_exceedances.npy", strategy.exceedances_)
    state_path = output_dir / "gpd_state.json"
    save_json(state_path, state)
    save_json(output_dir / "normal_calibration_audit.json", calibration_audit)
    diagnostic_files = save_diagnostics(
        output_dir,
        scores,
        strategy,
        args.dataset,
        stability_rows,
        bootstrap,
    )

    reloaded_state = load_json(state_path)
    reloaded_scores = np.load(copied_scores_path, allow_pickle=False)
    restored = POTEVTThreshold.from_state_dict(reloaded_state, reloaded_scores)
    if not np.isclose(
        restored.threshold_, strategy.threshold_, rtol=0.0, atol=1.0e-10
    ):
        raise RuntimeError("保存并重载后 POT 阈值不一致")

    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    threshold = float(strategy.threshold_)
    artifact = {
        "schema_version": SCHEMA_VERSION,
        "strategy_id": STRATEGY_ID,
        "strategy_name": "Offline POT/GPD threshold on Mahalanobis scores",
        "reproduction_type": "migrated",
        "source": config["source"],
        "status": "READY_FOR_TEST",
        "formal_result_allowed": True,
        "created_at_china": now_cn,
        "dataset": args.dataset,
        "time_scale": contract["time_scale"],
        "model": model_audit,
        "calibration": {
            **calibration_audit,
            "num_windows": num_windows,
            "audit_file": "normal_calibration_audit.json",
        },
        "residual": {
            "definition": "mean over time of abs(reconstruction - input)",
            "space": "standardized",
            "feature_dimension": int(contract["input_dim"]),
        },
        "score": {
            "method": "ledoit_wolf_mahalanobis",
            "upstream": upstream_audit,
            "copied_calibration_scores_file": copied_scores_path.name,
            "copied_calibration_scores_sha256": sha256_file(copied_scores_path),
        },
        "threshold": {
            "method": "pot_gpd",
            "initial_quantile": state["initial_quantile"],
            "quantile_method": state["quantile_method"],
            "initial_threshold": state["initial_threshold"],
            "num_exceedances": state["num_exceedances"],
            "num_unique_exceedances": state["num_unique_exceedances"],
            "exceedance_rate": state["exceedance_rate"],
            "gpd_fit_method": state["gpd_fit_method"],
            "gpd_shape": state["gpd_shape"],
            "gpd_scale": state["gpd_scale"],
            "gpd_location": state["gpd_location"],
            "gpd_log_likelihood": state["gpd_log_likelihood"],
            "finite_right_endpoint": state["finite_right_endpoint"],
            "alarm_quantile": state["alarm_quantile"],
            "target_tail_probability": state["target_tail_probability"],
            "value": threshold,
            "decision_rule_for_future_use": "score > threshold",
            "persistence_for_main_experiment": {"k": 1, "m": 1},
            "formal_fallback": None,
            "state_file": state_path.name,
        },
        "fit_diagnostics": {
            "threshold_stability": stability_rows,
            "bootstrap": bootstrap_summary,
            "files": diagnostic_files,
            "diagnostics_use_normal_calibration_only": True,
        },
        "reproducibility_check": {
            "state_reload_passed": True,
            "threshold_atol": 1.0e-10,
            "gpd_state_sha256": sha256_file(state_path),
            "tail_exceedances_sha256": sha256_file(
                output_dir / "tail_exceedances.npy"
            ),
        },
        "data_isolation": {
            "test_data_used": False,
            "test_labels_used": False,
            "detection_executed": False,
            "metrics_computed": False,
        },
        "notes": [
            "正式阈值只由纯正常标定 Mahalanobis 得分的高尾部拟合。",
            "未读取测试集；未生成异常判定；未计算检测指标。",
            "论文绝对阈值 0.06/0.0648 未迁移；初始阈值使用正常得分的固定 0.95 分位。",
            "论文高分位 1-1e-4 在公式中以无条件上尾概率 1e-4 实现。",
            "bootstrap 和候选初始分位只用于正常数据拟合稳定性审计，不改变正式阈值。",
            "正式拟合无经验分位数回退。",
        ],
    }
    artifact_path = output_dir / "threshold_artifact.json"
    save_json(artifact_path, artifact)

    print(f"03 POT/GPD 阈值：{threshold:.10f}")
    print(
        f"u={state['initial_threshold']:.10f}, xi={state['gpd_shape']:.10f}, "
        f"beta={state['gpd_scale']:.10f}, N_u={state['num_exceedances']}"
    )
    print(f"状态：{artifact['status']}")
    print("测试数据使用：否；异常检测执行：否；检测指标计算：否")
    print(f"正式工件：{artifact_path}")
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
