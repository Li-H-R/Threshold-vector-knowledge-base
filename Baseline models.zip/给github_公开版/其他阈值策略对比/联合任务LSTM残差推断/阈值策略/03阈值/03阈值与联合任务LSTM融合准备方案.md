# 03 阈值与联合任务 LSTM 融合：异常检测前准备方案

## 0. 本文件的范围与停止点

本方案的原始范围只设计 **异常检测之前** 的准备工作；在该准备阶段不读取测试集、不生成测试得分、不输出异常标签，也不计算 Precision、Recall、F1、PR-AUC 或事件检测指标。后续异常检测是在阈值冻结后、经用户另行明确授权才执行的。

当前允许使用的输入只有：

- 已训练完成的联合任务 LSTM checkpoint；
- 分钟级和秒级的两套纯正常阈值标定集；
- 由同一模型、同一残差定义和同一正常标定集产生的公共 Mahalanobis 标定得分；
- 固定随机种子生成、且不代表真实业务数据的合成单元测试数组。

当前明确禁止读取或消费：

```text
测试集数据/**
阈值策略/*阈值/*实验结果/**
任何 test、test_labels、detections.csv 或测试 summary.json
```

本阶段允许推进到：

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1 / CALIBRATED_DATASET2
→ READY_FOR_TEST
→ 停止
```

`READY_FOR_TEST` 只表示 03 的 POT 参数、GPD 状态和最终静态阈值已经用纯正常标定数据拟合并冻结，不表示已经执行异常检测。

本文件首次创建时只完成方法核对和实施设计。随后先在不读取测试集的条件下完成策略实现、合成单元测试和两套纯正常数据的 POT 标定；在用户再次明确授权后，已另行完成双测试集异常检测。正式准备结果见第 10 节，检测结果见 `03实验结果/evaluation_report.md`。

---

## 1. 参考依据与复现定位

### 1.1 统一实验约束

本方案遵循 `阈值策略/统一阈值实验工作流.md`：

- 所有阈值方案共用同一个训练完成的联合任务 LSTM；
- 共用标准化空间绝对重构残差、窗口时间均值和收缩 Mahalanobis 得分；
- 03 只替换阈值拟合方法，不重新训练或修改 LSTM；
- 分钟级和秒级分别使用各自的模型、正常标定集、公共得分状态和 03 阈值工件；
- 测试集不能参与初始阈值选择、GPD 拟合、尾部风险设置、拟合诊断或回退决策；
- 正式工件生成后冻结，后续不能因为测试结果不理想而重新拟合或改参数；
- 主阈值对比固定使用 `K=1, M=1`。持续性报警规则只能在后续授权后作为独立实验。

### 1.2 03 论文信息

| 项目 | 内容 |
|---|---|
| 标题 | *Anomaly detection of power battery pack using gated recurrent units based variational autoencoder* |
| 作者 | Changcheng Sun, Zhiwei He, Huipin Lin, Linhui Cai, Hui Cai, Mingyu Gao |
| 期刊 | Applied Soft Computing 132 (2023) 109903 |
| DOI | `10.1016/j.asoc.2022.109903` |
| 本地全文 | `阈值策略/03阈值/03.pdf` |
| 阈值相关位置 | 第 3.4、3.5 节，公式 (3)～(7) 和 Algorithm 2 |

论文阈值链路为：

```text
正常数据训练/交叉验证
→ 重构误差形成窗口得分 SW 或采样点得分 SP
→ 预选初始阈值 th_I
→ 对超过 th_I 的超限量拟合广义 Pareto 分布（GPD）
→ 根据目标高分位/尾部风险计算最终阈值 th_F
→ 后续在线阶段比较得分与 th_F
```

论文在自身电池数据上报告：预选 `th_I=0.06`，高分位写作 `1-10^-4`，最终得到 `th_F=0.0648`。这些数值只适用于论文的 GRU-VAE、MSE 得分和电池数据，不能复制到本项目。

### 1.3 复现类型

本项目应标记为 **迁移实现（migrated implementation）**，不能标记为严格复现，原因如下：

1. 论文前端是 GRU-VAE，本项目使用联合任务 LSTM-AE + 工况分类头；
2. 论文异常得分是多变量重构 MSE 的 `SW/SP`，本项目主实验固定使用收缩 Mahalanobis 得分；
3. 论文窗口长度为 20、重叠率为 50%，本项目已训练模型的窗口长度固定为 10，不能只为 03 改动；
4. 论文对象是 10 秒采样的电池数据，本项目需要分别迁移到分钟级和秒级风机数据；
5. 论文的绝对初始阈值 `0.06` 与最终阈值 `0.0648` 不具备跨模型、跨得分和跨数据集可迁移性；
6. 论文对符号 `q` 同时使用了“高分位数”和公式中的尾部风险含义，直接照抄容易把 `0.9999` 错当作尾部概率。

迁移时保留的核心是：

> 只用正常标定得分的高尾部超限量拟合 GPD，再根据预先冻结的目标尾部风险计算一个静态 POT 阈值。

---

## 2. 分钟级与秒级的固定对应关系

| 项目 | 分钟级 | 秒级 |
|---|---|---|
| 数据集标识 | `dataset1` | `dataset2` |
| 时间尺度 | 1 分钟级 | 秒级 |
| checkpoint | `models/dataset1_joint_seed10.pth` | `models/dataset2_joint_seed10.pth` |
| checkpoint SHA-256 | `adc97f5c48eb4b8e15dab7fa7ac09afe54cc01f88dab8986c5f7340daa96a4fa` | `ec92a82289f8e0e1f497570eedc9c008e19b86d70a24982d4a9d83fb19718d61` |
| 正常标定集 | `正常数据/阈值标定集.npz` | `正常数据/new_raw_阈值标定集.npz` |
| 标定集 SHA-256 | `99376a1f9cb781b0f51be4fe61f4cca64c880e27b5cf742cc942ccd8ac7cd42d` | `a95fd8ce46860252f2ea01bd33f26fc39f467be43316cd654cd3d0b6e62cfabc` |
| 标定形状 | `(1960, 10, 8)` | `(20000, 10, 15)` |
| 标签审计 | `y=0` 共 1960 个 | `y=0` 共 20000 个 |
| 窗口长度 | 10 | 10 |
| 特征维数 | 8 | 15 |
| 输入空间 | 按现有正式上游工件记录为 `standardized` | NPZ 元数据明确为 `standardized` |
| 公共得分工件 | `00阈值/artifacts/formal_dataset1` | `00阈值/artifacts/formal_dataset2` |
| `score_state.npz` SHA-256 | `7d2c04364625da818a1464f21427bfff74ab47618040373489ec65d3e589823e` | `33df46396284a767430343f29b2ebfdb4490973aa3957e7390522f0169617141` |
| `calibration_scores.npy` SHA-256 | `5633f2bb35314fca3fbe5a5d88e0305ef20e47b92ab2e996992308cdafda0729` | `1781429553f43f62363dbc1acfc95f7a55928f57a0687d3d5b9f8c18924da893` |
| 03 目标工件目录 | `03阈值/artifacts/formal_dataset1` | `03阈值/artifacts/formal_dataset2` |

固定映射为：

```text
分钟级正常标定集
→ dataset1 模型/标准化器
→ dataset1 公共 Mahalanobis 得分
→ dataset1 GPD/POT
→ 分钟级 03 阈值工件

秒级正常标定集
→ dataset2 模型/标准化器
→ dataset2 公共 Mahalanobis 得分
→ dataset2 GPD/POT
→ 秒级 03 阈值工件
```

以下操作全部禁止：

- 合并分钟级和秒级标定得分后拟合一个 GPD；
- 让分钟级和秒级共用 `u`、GPD 形状参数、尺度参数或最终阈值；
- 将分钟级工件用于秒级数据，或反向使用；
- 将论文的 `0.06`、`0.0648` 直接用于本项目；
- 根据未来测试表现为两个时间尺度选择不同的目标尾部风险；
- 为适配论文而改动模型窗口长度或重新训练模型。

### 2.1 分钟级标定数据的元数据门禁

`正常数据/阈值标定集.npz` 已确认包含 `(1960,10,8)` 的 `X` 和全 0 的 `y`，但文件内部没有显式保存：

- `dataset`；
- `input_space`；
- `window_size`；
- `feature_dimension`；
- `checkpoint_sha256`；
- `standardizer_mean/std`。

现有 00 正式工件已按 `standardized` 使用该文件，但在生成 03 正式工件前仍应：

1. 建立只读审计 sidecar，记录其来源、输入空间、特征顺序和 checkpoint；或
2. 生成带完整元数据的新标定 NPZ，同时保留原文件以及新旧文件 SHA-256；
3. 如果无法确认输入空间或特征顺序，则停止正式标定，不能依赖数值范围猜测。

不要原地覆盖现有正常标定文件。

---

## 3. 固定的融合数学链路

### 3.1 联合任务 LSTM 只负责产生残差

对第 `i` 个输入窗口：

\[
X_i\in\mathbb{R}^{10\times D},\qquad D=8\ \text{或}\ 15
\]

模型必须在 `eval()` 和 `torch.no_grad()` 下运行。公共残差向量固定为：

\[
R_i=\frac{1}{10}\sum_{t=1}^{10}
\left|\hat X_{i,t}-X_{i,t}\right|
\in\mathbb{R}^{D}
\]

要求：

- 输入与重构误差位于 checkpoint 对应的标准化空间；
- 使用绝对重构残差；
- 沿窗口时间维取均值；
- 不改变 LSTM 权重，不重新训练；
- 不使用 `latent` 或 `mode_w`，因为 03 只需要一列公共异常得分。

### 3.2 公共收缩 Mahalanobis 得分

只用对应数据集的正常标定残差拟合中心与收缩协方差：

\[
s_i=\sqrt{(R_i-\mu)^T\Omega(R_i-\mu)}
\]

其中 `μ` 是正常标定残差中心，`Ω` 是 Ledoit-Wolf 收缩协方差对应的精度矩阵。

03 不重新定义异常得分。为确保阈值方案之间的差异只来自阈值方法，推荐直接复用并严格校验 00 正式工件中的：

```text
00阈值/artifacts/formal_dataset1/score_state.npz
00阈值/artifacts/formal_dataset1/calibration_scores.npy

00阈值/artifacts/formal_dataset2/score_state.npz
00阈值/artifacts/formal_dataset2/calibration_scores.npy
```

复用时只读取公共得分状态和正常标定得分，不能把 00 的固定 98% 阈值作为 POT 的输入。

### 3.3 03 的 POT/GPD 尾部拟合

设某一数据集的正常标定得分为：

\[
s_1,s_2,\ldots,s_N
\]

先用预先冻结的初始分位数 `r_u` 得到初始阈值：

\[
u=Q_{r_u}(s)
\]

只保留严格超限量：

\[
y_j=s_j-u,\qquad s_j>u
\]

超限样本数记为 `N_u`，经验尾部占比为：

\[
p_u=\frac{N_u}{N}
\]

用位置参数固定为 0 的广义 Pareto 分布拟合 `y`：

\[
G_{\xi,\beta}(y)
=1-\left(1+\xi\frac{y}{\beta}\right)^{-1/\xi}
\]

其中 `ξ` 为形状参数，`β>0` 为尺度参数，并要求：

\[
1+\xi\frac{y}{\beta}>0
\]

实现上可以使用：

```python
shape, loc, scale = scipy.stats.genpareto.fit(exceedances, floc=0.0)
```

`loc` 必须固定为 0，不能让三参数拟合自由移动尾部起点。

### 3.4 从尾部风险计算最终静态阈值

定义 `α` 为最终允许的无条件上尾概率：

\[
P(S>\tau_{03})=\alpha
\]

POT 近似为：

\[
P(S>\tau_{03})
\approx p_u
\left(1+\xi\frac{\tau_{03}-u}{\beta}\right)^{-1/\xi}
\]

因此当 `ξ` 不接近 0 时：

\[
\tau_{03}
=u+\frac{\beta}{\xi}
\left[
\left(\frac{p_u}{\alpha}\right)^{\xi}-1
\right]
\]

当 `ξ→0` 时必须使用连续极限，避免数值不稳定：

\[
\tau_{03}=u+\beta\log\left(\frac{p_u}{\alpha}\right)
\]

必须满足：

```text
0 < α < p_u < 1
beta > 0
tau_03 >= u
tau_03 为有限数
若 xi < 0，则 tau_03 不得越过 GPD 的有限右端点 u - beta/xi
```

后续异常检测阶段的判定规则才是：

```text
point_pred = score > tau_03
```

当前准备阶段只冻结 `tau_03`，不执行这条比较。

### 3.5 消除论文 `q` 的符号歧义

论文正文把 `q` 描述为高分位，并在实验中写为 `1-10^-4`；但公式 (7) 的位置实际需要的是上尾风险概率。正式代码不得使用单个名为 `q` 的模糊参数，应拆成：

```text
alarm_quantile = 0.9999
target_tail_probability = 1.0 - alarm_quantile = 0.0001
```

代入 POT 公式的是 `target_tail_probability=1e-4`，不是 `0.9999`。

---

## 4. 参数冻结规则与拟合诊断

### 4.1 主配置建议

在不使用测试集调参的前提下，建议 03 正式首版固定：

```text
strategy_id = 03_pot_evt
initial_quantile = 0.95
alarm_quantile = 0.9999
target_tail_probability = 0.0001
gpd_fit = maximum_likelihood
gpd_location = 0.0 (fixed)
min_exceedances = 50
persistence = K=1, M=1
formal_fallback = none
```

选择逻辑：

- `target_tail_probability=1e-4` 与论文报告的 `1-10^-4` 高分位对齐；
- `initial_quantile=0.95` 是不依赖测试集的固定迁移规则，也与仓库现有 POT Demo 默认值一致；
- 分钟级约有 `1960×5%=98` 个候选超限样本，秒级约有 `20000×5%=1000` 个候选超限样本，均超过最低门槛 50；
- 两套数据使用相同的策略超参数，但各自拟合独立的 `u、ξ、β、τ`。

注意：分钟级 `N=1960` 时，`α=1e-4` 对应的期望经验超限数仅为 `0.196`，最终阈值属于明显的尾部外推，置信区间可能很宽。这不构成使用测试集调参的理由，而是必须在工件中披露的不确定性。

### 4.2 正式拟合失败时禁止静默回退

仓库 Demo 中的 POT 类在 GPD 失败时会回退到经验分位数。该行为适合演示，不适合 03 正式主实验，因为回退后方法已经不再是 POT。

正式准备阶段遇到以下任一情况应直接失败，不写入 `READY_FOR_TEST`：

- 正常标定得分为空、含 NaN/Inf 或出现负数；
- 得分近零方差或有效不同取值过少；
- 超限样本少于 `min_exceedances`；
- `target_tail_probability >= p_u`；
- MLE 失败或得到非有限参数；
- `scale <= 0`；
- 最终阈值非有限、低于 `u` 或越过有限右端点；
- 保存再加载后不能复现相同阈值；
- 模型、正常标定文件或公共得分工件哈希不匹配。

若需要经验分位数回退，只能创建独立的 `SELF_CHECK_ONLY_NOT_FOR_RESULTS` 工件，不能标记为 03 正式结果。

### 4.3 只用正常标定得分进行拟合诊断

正式阈值仍由 `initial_quantile=0.95` 的全量正常标定得分一次拟合得到。以下诊断只评估可信度，不根据未来测试性能挑选参数：

1. 记录 `N、u、N_u、p_u、ξ、β、τ`；
2. 生成超限量直方图与 GPD 密度曲线；
3. 生成 GPD QQ 图和 PP 图；
4. 生成 mean-excess 图；
5. 在 `0.90、0.925、0.95` 三个初始分位上生成参数稳定性表，但主阈值仍固定使用 `0.95`；
6. 使用固定随机种子的正常标定 bootstrap，记录 `τ` 的区间和失败比例；
7. 分钟级与秒级分别诊断，不能混合抽样。

推荐 bootstrap 配置：

```text
bootstrap_replicates = 1000
bootstrap_seed = 20261104
bootstrap_interval = [0.025, 0.975]
```

bootstrap 只作为审计信息，不用 bootstrap 均值、中位数或某次抽样阈值替换全量正常标定得分得到的正式阈值。

---

## 5. 推荐程序结构

在 `阈值策略/03阈值/` 下准备：

```text
03阈值/
├── 03.pdf
├── 03阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_03_pot_evt.py
├── prepare_03_pot_evt.py
├── experiment_config.json
├── tests/
│   └── test_strategy_03_pot_evt.py
└── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
```

当前阶段不需要创建或运行 `detect_03_pot_evt.py`。如果为了接口完整性提前创建，也只能保留未来加载/校验骨架，不能接受测试文件、计算测试得分或产生异常判定。

### 5.1 策略类职责

`strategy_03_pot_evt.py` 只处理一维正常标定得分，不加载模型、不读取原始数据：

```python
class POTEVTThreshold:
    strategy_id = "03_pot_evt"

    def fit(self, calibration_scores):
        """只用正常标定得分拟合 GPD 并计算静态阈值。"""
        ...

    def state_dict(self):
        """导出 u、xi、beta、p_u、alpha、threshold 和审计信息。"""
        ...

    @classmethod
    def from_state_dict(cls, state):
        """恢复冻结状态；恢复后阈值必须一致。"""
        ...
```

应将纯数学函数拆出并直接测试：

```python
def gpd_tail_threshold(u, shape, scale, exceedance_rate, tail_probability):
    ...
```

当 `abs(shape)` 小于约定数值容差时，必须走 `ξ→0` 的对数极限分支。

### 5.2 准备脚本职责

`prepare_03_pot_evt.py` 的完整流程：

```text
读取 dataset1 或 dataset2 的冻结配置
→ 校验模型文件及 SHA-256
→ 校验纯正常标定源、形状、输入空间、y 全为 0 及 SHA-256
→ 校验对应的 00 公共 score_state 和 calibration_scores
→ 确认公共得分长度、有限性、非负性和数据集映射
→ 计算固定 initial_quantile 对应的 u
→ 提取严格大于 u 的超限量
→ 检查超限样本门槛和不同取值数
→ 用 MLE 拟合 loc=0 的 GPD
→ 用 target_tail_probability 计算最终静态阈值
→ 只基于正常得分生成诊断图、稳定性表和 bootstrap 审计
→ 保存阈值工件和 GPD 状态
→ 重新加载并验证完全一致
→ 状态写为 READY_FOR_TEST
→ 停止，不读取测试集
```

推荐命令行只暴露：

```text
--dataset dataset1|dataset2
--config <冻结配置>
--upstream-score-artifact <00 正式工件目录>
--output-dir <03 对应正式目录>
```

正式主配置中的 `initial_quantile` 和 `target_tail_probability` 应从受版本控制的 `experiment_config.json` 读取，而不是允许在命令行临时覆盖。

准备脚本不得提供：

```text
--test
--test-labels
--test-input-space
--detect
--evaluate
```

### 5.3 冻结配置建议

`experiment_config.json` 至少包含：

```json
{
  "schema_version": 1,
  "strategy_id": "03_pot_evt",
  "strategy_name": "Offline POT/GPD threshold on Mahalanobis scores",
  "reproduction_type": "migrated",
  "fixed_contract": {
    "model_seed": 10,
    "window_size": 10,
    "residual": "mean over time of abs(reconstruction - input) in standardized space",
    "score_method": "ledoit_wolf_mahalanobis",
    "persistence": {"k": 1, "m": 1}
  },
  "strategy_contract": {
    "interface_type": "static_scalar_threshold",
    "required_inputs": ["normal_calibration_score"],
    "initial_quantile": 0.95,
    "alarm_quantile": 0.9999,
    "target_tail_probability": 0.0001,
    "gpd_fit_method": "maximum_likelihood",
    "gpd_location": 0.0,
    "min_exceedances": 50,
    "formal_fallback": null,
    "freeze_rule": "fit once on normal calibration scores and never refit during detection"
  },
  "data_isolation": {
    "test_file": null,
    "test_labels": null,
    "test_data_allowed_during_prepare": false,
    "detection_allowed_during_prepare": false
  }
}
```

分钟级与秒级的模型路径、正常标定路径、哈希、公共得分工件和输出目录应像 01 配置一样分别写在 `datasets.dataset1` 和 `datasets.dataset2` 中。

---

## 6. 正式准备阶段的输出

每套数据分别生成：

```text
artifacts/formal_datasetX/
├── threshold_artifact.json
├── gpd_state.json
├── calibration_scores.npy
├── tail_exceedances.npy
├── tail_fit_curve.csv
├── tail_fit_plot.png
├── gpd_qq_plot.png
├── gpd_pp_plot.png
├── mean_excess_plot.png
├── threshold_stability.csv
├── bootstrap_thresholds.csv
└── normal_calibration_audit.json
```

`calibration_scores.npy` 可以是公共得分的经过哈希校验的副本，也可以仅保存上游路径与哈希。若复制，必须验证与上游逐元素一致。

所有图和表只能包含正常标定得分或其超限量，不得包含测试得分、测试标签、故障区间或检测结果。

### 6.1 `threshold_artifact.json` 的最低字段

```json
{
  "schema_version": 1,
  "strategy_id": "03_pot_evt",
  "status": "READY_FOR_TEST",
  "formal_result_allowed": true,
  "dataset": "dataset1_or_dataset2",
  "model": {
    "checkpoint": null,
    "checkpoint_sha256": null,
    "window_size": 10,
    "input_dim": null
  },
  "calibration": {
    "source_path": null,
    "source_sha256": null,
    "label_counts": {"0": null},
    "num_windows": null,
    "input_space": "standardized"
  },
  "residual": {
    "definition": "mean over time of abs(reconstruction - input)",
    "space": "standardized"
  },
  "score": {
    "method": "ledoit_wolf_mahalanobis",
    "upstream_state_sha256": null,
    "upstream_scores_sha256": null
  },
  "threshold": {
    "method": "pot_gpd",
    "initial_quantile": 0.95,
    "initial_threshold": null,
    "num_exceedances": null,
    "exceedance_rate": null,
    "gpd_shape": null,
    "gpd_scale": null,
    "gpd_location": 0.0,
    "alarm_quantile": 0.9999,
    "target_tail_probability": 0.0001,
    "value": null,
    "decision_rule_for_future_use": "score > threshold",
    "persistence_for_main_experiment": {"k": 1, "m": 1},
    "formal_fallback": null
  },
  "fit_diagnostics": {
    "bootstrap_seed": 20261104,
    "bootstrap_replicates": 1000,
    "bootstrap_successes": null,
    "bootstrap_failures": null,
    "threshold_interval_95": [null, null]
  },
  "test_data_used": false,
  "detection_executed": false
}
```

---

## 7. 不使用真实测试集的单元测试门禁

单元测试只能使用手工数组或固定随机种子生成的合成分布，至少覆盖：

1. **输入检查**：空数组、NaN、Inf、负得分、常数得分和近零方差必须报错；
2. **参数检查**：`initial_quantile`、`alarm_quantile`、`target_tail_probability` 和 `min_exceedances` 越界必须报错；
3. **超限定义**：只使用 `score > u`，等于 `u` 的点不计入超限量；
4. **位置固定**：GPD 拟合结果的 `loc` 必须为 0；
5. **公式检查**：用人工给定的 `u、ξ、β、p_u、α` 验证闭式阈值；
6. **零形状极限**：`ξ=0` 以及非常接近 0 时，结果应与指数分布极限一致且连续；
7. **有限端点**：`ξ<0` 时阈值不得超过 `u-β/ξ`；
8. **风险单调性**：目标尾部概率越小，最终阈值不得降低；
9. **初始阈值单调性审计**：更高的 `initial_quantile` 应产生不多于原来的超限样本数；
10. **最低样本量**：超限样本不足 50 时正式拟合必须失败，不静默回退；
11. **保存/加载**：重载后 `u、ξ、β、p_u、α、τ` 一致；
12. **哈希门禁**：模型、正常标定文件、公共得分状态或得分文件发生变化时拒绝继续；
13. **双数据集隔离**：改变 dataset2 的合成标定数组不能影响 dataset1 工件，反之亦然；
14. **无测试数据**：准备脚本参数、配置和输出中不存在非空测试路径；
15. **确定性**：相同环境、输入、配置和 bootstrap seed 产生相同正式阈值与审计摘要；
16. **正式/自检隔离**：合成工件不能标记 `formal_result_allowed=true`。

测试通过只证明实现与工件契约正确，不构成真实异常检测。

---

## 8. 推荐实施顺序

### 步骤 1：冻结方法卡

- 固定论文来源和公式 (6)、(7)；
- 标记为 `migrated`；
- 明确公共得分仍为收缩 Mahalanobis；
- 明确 `alarm_quantile=0.9999` 与 `target_tail_probability=1e-4` 的换算；
- 固定 `initial_quantile=0.95`、`loc=0` 和无正式回退。

完成状态：`FORMULA_VERIFIED`。

### 步骤 2：完成两套输入审计

- 核对两个 checkpoint 的 SHA-256；
- 核对两个正常标定文件的 SHA-256；
- 核对 `y` 全为 0；
- 核对窗口长度和特征维数；
- 补强分钟级标定集的输入空间和特征顺序证据；
- 核对 00 公共 Mahalanobis 状态与得分文件哈希；
- 保证 dataset1 与 dataset2 映射严格隔离。

完成状态：`INTERFACE_DEFINED`。

### 步骤 3：只实现 POT 策略和准备脚本

- 新增 `strategy_03_pot_evt.py`；
- 新增 `prepare_03_pot_evt.py`；
- 新增冻结配置；
- 不接入测试数据；
- 不实现或不运行评价指标；
- 不创建实际检测结果目录。

完成状态：`IMPLEMENTED`。

### 步骤 4：运行无真实测试集的单元测试

- 公式与极限测试；
- 边界和失败测试；
- GPD 状态保存/加载测试；
- 双数据集隔离测试；
- 哈希与数据泄漏门禁测试。

完成状态：`UNIT_TESTED`。

### 步骤 5：分别生成两个正常标定工件

已执行以下正常标定命令：

```powershell
python 阈值策略\03阈值\prepare_03_pot_evt.py `
  --dataset dataset1 `
  --config 阈值策略\03阈值\experiment_config.json `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset1 `
  --output-dir 阈值策略\03阈值\artifacts\formal_dataset1
```

```powershell
python 阈值策略\03阈值\prepare_03_pot_evt.py `
  --dataset dataset2 `
  --config 阈值策略\03阈值\experiment_config.json `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset2 `
  --output-dir 阈值策略\03阈值\artifacts\formal_dataset2
```

这两条命令只读取正常标定数据和冻结的公共 Mahalanobis 得分，不包含测试、检测或评价参数。

完成状态：

```text
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
```

达到该状态后立即停止，等待用户另行授权异常检测。

---

## 9. 后续异常检测阶段的边界（当前不执行）

只有用户明确授权后，未来检测脚本才可以：

```text
读取对应时间尺度的测试数据
→ 校验输入空间、维数、特征顺序、时间戳和 checkpoint 哈希
→ 加载对应数据集冻结的 score_state
→ 计算测试 Mahalanobis 得分
→ 加载对应数据集冻结的 03 POT 工件
→ 使用 score > threshold 产生逐点判定
→ 主实验固定 K=1, M=1
→ 分钟级与秒级分别输出、分别评价
```

必须保持：

```text
分钟级测试集 → dataset1 模型 → dataset1 score_state → formal_dataset1 POT 工件
秒级测试集   → dataset2 模型 → dataset2 score_state → formal_dataset2 POT 工件
```

测试阶段禁止重新拟合 `μ、Ω、u、ξ、β、τ`，也禁止根据测试标签或检测表现改变 `initial_quantile` 与 `target_tail_probability`。

采样频率不改变静态 POT 公式，但会影响后续事件持续时间和报警延迟的物理解释。因此分钟级与秒级必须分别报告结果，不能把两个测试集的窗口拼接后计算一个总指标。

---

## 10. 当前正式准备结果与验收清单

两套工件均已达到 `READY_FOR_TEST`：

| 时间尺度 | 数据集 | 正常得分数 | 初始阈值 `u` | 超限数 | `ξ` | `β` | 03 POT 阈值 | 1000 次 bootstrap 95% 区间 |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| 分钟级 | `dataset1` | 1960 | `4.2025152243` | 98 | `-0.0141796319` | `0.9996258292` | **`10.1489481391`** | `[8.2992916278, 13.9502911100]` |
| 秒级 | `dataset2` | 20000 | `5.5406752794` | 1000 | `0.4955806604` | `1.1411840821` | **`53.3334514098`** | `[40.3397995487, 72.2816468510]` |

两套 bootstrap 均为 1000/1000 次成功。正式阈值始终来自全量正常标定得分，bootstrap 不改变正式值。

秒级标定得分最大值为 `32.1619371885`，而 `99.99%` POT 阈值为 `53.3334514098`。这是正形状参数 `ξ=0.4955806604` 所表示的重尾外推；其 bootstrap 区间也较宽。该现象已经作为拟合不确定性记录，当前没有利用测试集降低阈值或改动参数。

- [x] 已阅读 `统一阈值实验工作流` 并固定主实验口径；
- [x] 已核对 03 论文的 POT/GPD 阈值公式与 Algorithm 2；
- [x] 已确认 03 应标记为迁移实现；
- [x] 已识别论文 `q` 的分位数/尾部概率歧义并给出无歧义参数命名；
- [x] 已固定分钟级与秒级各自的模型、正常标定集和公共得分依赖；
- [x] 已核对两套正常标定数据形状以及 `y=0`；
- [x] 已记录模型、正常标定文件和公共得分工件 SHA-256；
- [x] 已识别分钟级正常标定文件的元数据缺口；
- [x] 异常检测前准备阶段未读取或使用测试集内容；
- [x] 异常检测前准备阶段未执行异常检测；
- [x] 已实现 `strategy_03_pot_evt.py`；
- [x] 已实现 `prepare_03_pot_evt.py`，且没有测试或检测入口；
- [x] 已创建并冻结 `experiment_config.json`；
- [x] 已运行 13 项合成单元测试，全部通过；
- [x] 已生成分钟级 GPD/POT 正式工件；
- [x] 已生成秒级 GPD/POT 正式工件；
- [x] 两套工件保存后重载均能复现阈值；
- [x] 两套正常数据 bootstrap 均完成 1000 次且无失败；
- [x] 已达到 `READY_FOR_TEST`；
- [x] 两套阈值在读取测试集前已冻结；
- [x] 后续仅在用户明确授权后读取测试集并执行异常检测；
- [x] 测试阶段未重新拟合 Mahalanobis、GPD 或阈值；
- [x] 已完成分钟级与秒级各 5 个测试文件的检测与统一评价；
- [x] 当前状态为 `TESTED_BOTH_DATASETS / RESULT_FROZEN`。

---

## 11. 最终原则

03 与联合任务 LSTM 的融合不需要重新训练模型。正确链路是：

```text
固定联合任务 LSTM
→ 固定标准化空间绝对重构残差
→ 固定窗口时间均值
→ 固定收缩 Mahalanobis 得分
→ 分钟级正常得分单独拟合 GPD/POT
→ 秒级正常得分单独拟合 GPD/POT
→ 分别冻结两个静态阈值工件
→ 停止，暂不执行异常检测
```

只要测试数据不参与模型、得分状态、初始尾阈值、GPD 参数、目标尾部风险、拟合诊断或最终阈值的确定，就满足当前“异常检测前准备”的数据隔离要求。
