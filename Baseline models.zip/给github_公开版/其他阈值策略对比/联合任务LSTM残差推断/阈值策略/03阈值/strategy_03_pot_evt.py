# -*- coding: utf-8 -*-
"""03 阈值策略：正常 Mahalanobis 得分的离线 POT/GPD 阈值。"""

from __future__ import annotations

import warnings
from typing import Any, Dict, Optional, Tuple

import numpy as np
from scipy.stats import genpareto


STRATEGY_ID = "03_pot_evt"
SCHEMA_VERSION = 1
DEFAULT_INITIAL_QUANTILE = 0.95
DEFAULT_ALARM_QUANTILE = 0.9999
DEFAULT_TAIL_PROBABILITY = 1.0e-4
DEFAULT_MIN_EXCEEDANCES = 50
DEFAULT_MIN_SAMPLES = 100
DEFAULT_MIN_UNIQUE_EXCEEDANCES = 10
SHAPE_ZERO_TOLERANCE = 1.0e-8
EPS = 1.0e-12


def validate_calibration_scores(
    values: np.ndarray, *, min_samples: int = DEFAULT_MIN_SAMPLES
) -> np.ndarray:
    """返回一维 float64 正常标定得分，并执行正式拟合门禁。"""
    scores = np.asarray(values, dtype=np.float64).reshape(-1)
    if scores.size < min_samples:
        raise ValueError(
            f"POT 正式拟合至少需要 {min_samples} 个正常得分，实际 {scores.size}"
        )
    if not np.all(np.isfinite(scores)):
        raise ValueError("正常标定得分中存在 NaN 或 Inf")
    if np.any(scores < 0.0):
        raise ValueError("Mahalanobis 得分理论上非负，输入中发现负值")
    if float(np.std(scores)) <= EPS:
        raise ValueError("正常标定得分方差接近 0，无法拟合 POT")
    if np.unique(scores).size < DEFAULT_MIN_UNIQUE_EXCEEDANCES:
        raise ValueError("正常标定得分的有效不同取值过少")
    return np.ascontiguousarray(scores)


def extract_exceedances(scores: np.ndarray, initial_threshold: float) -> np.ndarray:
    """提取严格大于初始阈值的超限量；等于阈值的点不计入。"""
    values = np.asarray(scores, dtype=np.float64).reshape(-1)
    return np.ascontiguousarray(values[values > initial_threshold] - initial_threshold)


def gpd_tail_threshold(
    initial_threshold: float,
    shape: float,
    scale: float,
    exceedance_rate: float,
    tail_probability: float,
    *,
    shape_zero_tolerance: float = SHAPE_ZERO_TOLERANCE,
) -> float:
    """由 GPD 尾部参数和无条件上尾概率计算最终 POT 阈值。"""
    values = (initial_threshold, shape, scale, exceedance_rate, tail_probability)
    if not all(np.isfinite(value) for value in values):
        raise ValueError("POT 阈值公式的输入必须全部为有限数")
    if initial_threshold < 0.0:
        raise ValueError("initial_threshold 不能为负")
    if scale <= 0.0:
        raise ValueError("GPD scale 必须大于 0")
    if not 0.0 < tail_probability < exceedance_rate < 1.0:
        raise ValueError("必须满足 0 < tail_probability < exceedance_rate < 1")
    if shape_zero_tolerance <= 0.0:
        raise ValueError("shape_zero_tolerance 必须大于 0")

    log_ratio = float(np.log(exceedance_rate / tail_probability))
    if abs(shape) <= shape_zero_tolerance:
        increment = scale * log_ratio
    else:
        increment = scale * float(np.expm1(shape * log_ratio)) / shape
    threshold = float(initial_threshold + increment)
    if not np.isfinite(threshold) or threshold < initial_threshold:
        raise ValueError("GPD 计算得到无效的最终阈值")

    if shape < 0.0:
        endpoint = float(initial_threshold - scale / shape)
        if not threshold < endpoint:
            raise ValueError("最终阈值越过 GPD 的有限右端点")
    return threshold


class POTEVTThreshold:
    """离线 POT/GPD 阈值器，只负责正常标定阶段的拟合与冻结。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        initial_quantile: float = DEFAULT_INITIAL_QUANTILE,
        alarm_quantile: float = DEFAULT_ALARM_QUANTILE,
        tail_probability: float = DEFAULT_TAIL_PROBABILITY,
        min_exceedances: int = DEFAULT_MIN_EXCEEDANCES,
        min_samples: int = DEFAULT_MIN_SAMPLES,
        min_unique_exceedances: int = DEFAULT_MIN_UNIQUE_EXCEEDANCES,
    ) -> None:
        if not 0.5 < initial_quantile < 1.0:
            raise ValueError("initial_quantile 必须位于 (0.5, 1)")
        if not 0.0 < alarm_quantile < 1.0:
            raise ValueError("alarm_quantile 必须位于 (0, 1)")
        if not 0.0 < tail_probability < 1.0:
            raise ValueError("tail_probability 必须位于 (0, 1)")
        if not np.isclose(
            1.0 - alarm_quantile,
            tail_probability,
            rtol=0.0,
            atol=1.0e-15,
        ):
            raise ValueError("tail_probability 必须等于 1 - alarm_quantile")
        if min_exceedances < 3:
            raise ValueError("min_exceedances 至少为 3")
        if min_samples < 10:
            raise ValueError("min_samples 至少为 10")
        if min_unique_exceedances < 3:
            raise ValueError("min_unique_exceedances 至少为 3")

        self.initial_quantile = float(initial_quantile)
        self.alarm_quantile = float(alarm_quantile)
        self.tail_probability = float(tail_probability)
        self.min_exceedances = int(min_exceedances)
        self.min_samples = int(min_samples)
        self.min_unique_exceedances = int(min_unique_exceedances)

        self.scores_: Optional[np.ndarray] = None
        self.exceedances_: Optional[np.ndarray] = None
        self.initial_threshold_: Optional[float] = None
        self.exceedance_rate_: Optional[float] = None
        self.shape_: Optional[float] = None
        self.scale_: Optional[float] = None
        self.threshold_: Optional[float] = None
        self.log_likelihood_: Optional[float] = None
        self.finite_right_endpoint_: Optional[float] = None

    def fit(self, calibration_scores: np.ndarray) -> "POTEVTThreshold":
        """只用纯正常标定得分拟合 loc=0 的 GPD 并冻结阈值。"""
        scores = validate_calibration_scores(
            calibration_scores, min_samples=self.min_samples
        )
        initial_threshold = float(
            np.quantile(scores, self.initial_quantile, method="linear")
        )
        exceedances = extract_exceedances(scores, initial_threshold)
        if exceedances.size < self.min_exceedances:
            raise ValueError(
                f"POT 超限样本至少需要 {self.min_exceedances} 个，"
                f"实际 {exceedances.size}"
            )
        if np.unique(exceedances).size < self.min_unique_exceedances:
            raise ValueError("POT 超限量的有效不同取值过少")
        if float(np.std(exceedances)) <= EPS:
            raise ValueError("POT 超限量方差接近 0，无法拟合 GPD")

        exceedance_rate = float(exceedances.size / scores.size)
        if self.tail_probability >= exceedance_rate:
            raise ValueError("目标尾部概率必须小于初始阈值的经验超限率")

        with warnings.catch_warnings():
            warnings.simplefilter("error", RuntimeWarning)
            try:
                shape, location, scale = genpareto.fit(exceedances, floc=0.0)
            except (ValueError, FloatingPointError, RuntimeWarning) as exc:
                raise RuntimeError(f"GPD 最大似然拟合失败：{exc}") from exc

        shape = float(shape)
        location = float(location)
        scale = float(scale)
        if not np.isclose(location, 0.0, rtol=0.0, atol=1.0e-15):
            raise RuntimeError("GPD location 未固定为 0")
        if not np.isfinite(shape) or not np.isfinite(scale) or scale <= 0.0:
            raise RuntimeError("GPD 拟合产生了无效参数")
        support = 1.0 + shape * exceedances / scale
        if np.any(support <= 0.0):
            raise RuntimeError("观测超限量落在拟合 GPD 的支持域之外")

        threshold = gpd_tail_threshold(
            initial_threshold,
            shape,
            scale,
            exceedance_rate,
            self.tail_probability,
        )
        log_pdf = genpareto.logpdf(exceedances, c=shape, loc=0.0, scale=scale)
        if not np.all(np.isfinite(log_pdf)):
            raise RuntimeError("GPD 对超限量给出了非有限对数似然")

        self.scores_ = scores.copy()
        self.exceedances_ = exceedances.copy()
        self.initial_threshold_ = initial_threshold
        self.exceedance_rate_ = exceedance_rate
        self.shape_ = shape
        self.scale_ = scale
        self.threshold_ = threshold
        self.log_likelihood_ = float(np.sum(log_pdf))
        self.finite_right_endpoint_ = (
            float(initial_threshold - scale / shape) if shape < 0.0 else None
        )
        return self

    def _require_fit(self) -> Tuple[float, float, float]:
        if (
            self.initial_threshold_ is None
            or self.shape_ is None
            or self.scale_ is None
            or self.threshold_ is None
        ):
            raise RuntimeError("请先调用 fit()")
        return self.initial_threshold_, self.shape_, self.scale_

    def conditional_cdf(self, exceedance: Any) -> Any:
        """返回给定超限量在已拟合 GPD 下的条件 CDF。"""
        _, shape, scale = self._require_fit()
        values = np.asarray(exceedance, dtype=np.float64)
        result = genpareto.cdf(values, c=shape, loc=0.0, scale=scale)
        return float(result.item()) if result.ndim == 0 else result

    def conditional_ppf(self, probability: Any) -> Any:
        """返回已拟合 GPD 的条件分位点。"""
        _, shape, scale = self._require_fit()
        values = np.asarray(probability, dtype=np.float64)
        result = genpareto.ppf(values, c=shape, loc=0.0, scale=scale)
        return float(result.item()) if result.ndim == 0 else result

    def state_dict(self) -> Dict[str, Any]:
        """返回可 JSON 序列化的冻结状态，不包含测试数据或判定结果。"""
        self._require_fit()
        assert self.scores_ is not None
        assert self.exceedances_ is not None
        assert self.initial_threshold_ is not None
        assert self.exceedance_rate_ is not None
        assert self.shape_ is not None
        assert self.scale_ is not None
        assert self.threshold_ is not None
        return {
            "schema_version": SCHEMA_VERSION,
            "strategy_id": STRATEGY_ID,
            "initial_quantile": self.initial_quantile,
            "quantile_method": "linear",
            "alarm_quantile": self.alarm_quantile,
            "target_tail_probability": self.tail_probability,
            "gpd_fit_method": "maximum_likelihood",
            "gpd_location": 0.0,
            "min_exceedances": self.min_exceedances,
            "min_samples": self.min_samples,
            "min_unique_exceedances": self.min_unique_exceedances,
            "num_calibration_scores": int(self.scores_.size),
            "score_min": float(np.min(self.scores_)),
            "score_max": float(np.max(self.scores_)),
            "score_mean": float(np.mean(self.scores_)),
            "score_std": float(np.std(self.scores_)),
            "initial_threshold": self.initial_threshold_,
            "num_exceedances": int(self.exceedances_.size),
            "num_unique_exceedances": int(np.unique(self.exceedances_).size),
            "exceedance_rate": self.exceedance_rate_,
            "gpd_shape": self.shape_,
            "gpd_scale": self.scale_,
            "gpd_log_likelihood": self.log_likelihood_,
            "finite_right_endpoint": self.finite_right_endpoint_,
            "threshold": self.threshold_,
            "formal_fallback": None,
        }

    @classmethod
    def from_state_dict(
        cls,
        state: Dict[str, Any],
        calibration_scores: np.ndarray,
        *,
        atol: float = 1.0e-10,
    ) -> "POTEVTThreshold":
        """从正常得分重建 POT/GPD，并验证冻结参数与阈值可复现。"""
        if state.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("不支持的 GPD state schema_version")
        if state.get("strategy_id") != STRATEGY_ID:
            raise ValueError("state 不是 03_pot_evt 工件")
        strategy = cls(
            initial_quantile=float(state["initial_quantile"]),
            alarm_quantile=float(state["alarm_quantile"]),
            tail_probability=float(state["target_tail_probability"]),
            min_exceedances=int(state["min_exceedances"]),
            min_samples=int(state["min_samples"]),
            min_unique_exceedances=int(state["min_unique_exceedances"]),
        ).fit(calibration_scores)
        checks = {
            "initial_threshold": strategy.initial_threshold_,
            "gpd_shape": strategy.shape_,
            "gpd_scale": strategy.scale_,
            "threshold": strategy.threshold_,
        }
        for key, actual in checks.items():
            expected = float(state[key])
            if actual is None or not np.isclose(actual, expected, rtol=0.0, atol=atol):
                raise ValueError(
                    f"重建 {key}={actual} 与冻结值 {expected} 不一致"
                )
        return strategy
