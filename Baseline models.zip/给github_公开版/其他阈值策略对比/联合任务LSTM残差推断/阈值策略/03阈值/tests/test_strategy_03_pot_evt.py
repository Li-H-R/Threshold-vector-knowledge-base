# -*- coding: utf-8 -*-

import json
import sys
import unittest
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from prepare_03_pot_evt import build_parser
from strategy_03_pot_evt import (
    POTEVTThreshold,
    extract_exceedances,
    gpd_tail_threshold,
)


class POTEVTThresholdTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(20261104)
        self.scores = rng.lognormal(mean=0.7, sigma=0.55, size=2400)

    def test_formula_matches_direct_expression(self):
        u, shape, scale, p_u, alpha = 3.0, 0.2, 1.4, 0.05, 1.0e-4
        expected = u + scale / shape * ((p_u / alpha) ** shape - 1.0)
        actual = gpd_tail_threshold(u, shape, scale, p_u, alpha)
        self.assertAlmostEqual(actual, expected, places=12)

    def test_zero_shape_limit_is_continuous(self):
        args = (2.0, 1.1, 0.05, 1.0e-4)
        expected = args[0] + args[1] * np.log(args[2] / args[3])
        at_zero = gpd_tail_threshold(args[0], 0.0, args[1], args[2], args[3])
        near_zero = gpd_tail_threshold(
            args[0], 1.0e-10, args[1], args[2], args[3]
        )
        self.assertAlmostEqual(at_zero, expected, places=12)
        self.assertAlmostEqual(near_zero, expected, places=10)

    def test_negative_shape_respects_finite_endpoint(self):
        u, shape, scale = 3.0, -0.2, 2.0
        threshold = gpd_tail_threshold(u, shape, scale, 0.1, 0.001)
        endpoint = u - scale / shape
        self.assertGreaterEqual(threshold, u)
        self.assertLess(threshold, endpoint)

    def test_smaller_tail_probability_gives_higher_threshold(self):
        common = (3.0, 0.15, 1.2, 0.05)
        moderate = gpd_tail_threshold(*common, 0.001)
        extreme = gpd_tail_threshold(*common, 0.0001)
        self.assertGreater(extreme, moderate)

    def test_exceedances_are_strictly_above_u(self):
        scores = np.array([1.0, 2.0, 2.0, 2.5, 4.0])
        actual = extract_exceedances(scores, 2.0)
        np.testing.assert_allclose(actual, np.array([0.5, 2.0]))

    def test_fit_returns_valid_static_threshold(self):
        strategy = POTEVTThreshold().fit(self.scores)
        self.assertTrue(np.isfinite(strategy.threshold_))
        self.assertGreaterEqual(strategy.threshold_, strategy.initial_threshold_)
        self.assertEqual(strategy.exceedances_.size, 120)
        self.assertEqual(strategy.state_dict()["formal_fallback"], None)

    def test_state_roundtrip_reproduces_parameters(self):
        fitted = POTEVTThreshold().fit(self.scores)
        restored = POTEVTThreshold.from_state_dict(
            fitted.state_dict(), self.scores
        )
        self.assertAlmostEqual(fitted.initial_threshold_, restored.initial_threshold_, 12)
        self.assertAlmostEqual(fitted.shape_, restored.shape_, 12)
        self.assertAlmostEqual(fitted.scale_, restored.scale_, 12)
        self.assertAlmostEqual(fitted.threshold_, restored.threshold_, 12)

    def test_fit_is_deterministic_and_datasets_are_independent(self):
        first = POTEVTThreshold().fit(self.scores)
        first_threshold = float(first.threshold_)
        repeated = POTEVTThreshold().fit(self.scores.copy())
        shifted = POTEVTThreshold().fit(self.scores * 3.0)
        self.assertAlmostEqual(first_threshold, repeated.threshold_, 12)
        self.assertGreater(shifted.threshold_, first_threshold)
        self.assertEqual(first.threshold_, first_threshold)

    def test_rejects_invalid_scores(self):
        invalid_cases = [
            np.ones(99),
            np.r_[np.ones(119), np.nan],
            np.r_[np.ones(119), np.inf],
            np.r_[np.ones(119), -0.1],
            np.ones(120),
        ]
        for values in invalid_cases:
            with self.subTest(case=repr(values[-3:])):
                with self.assertRaises(ValueError):
                    POTEVTThreshold().fit(values)

    def test_rejects_insufficient_tail_without_fallback(self):
        scores = np.linspace(0.0, 10.0, 200)
        strategy = POTEVTThreshold(
            initial_quantile=0.99,
            min_exceedances=10,
            min_unique_exceedances=3,
        )
        with self.assertRaises(ValueError):
            strategy.fit(scores)

    def test_rejects_invalid_parameters(self):
        invalid_kwargs = [
            {"initial_quantile": 0.5},
            {"alarm_quantile": 1.0},
            {"tail_probability": 0.01},
            {"min_exceedances": 2},
            {"min_samples": 9},
            {"min_unique_exceedances": 2},
        ]
        for kwargs in invalid_kwargs:
            with self.subTest(kwargs=kwargs):
                with self.assertRaises(ValueError):
                    POTEVTThreshold(**kwargs)

    def test_prepare_cli_has_no_detection_or_test_arguments(self):
        destinations = {action.dest for action in build_parser()._actions}
        forbidden = {
            "test",
            "test_labels",
            "labels",
            "detect",
            "evaluate",
            "test_input_space",
        }
        self.assertTrue(destinations.isdisjoint(forbidden))

    def test_config_explicitly_forbids_test_data_and_detection(self):
        with (SCRIPT_DIR / "experiment_config.json").open(
            "r", encoding="utf-8"
        ) as handle:
            config = json.load(handle)
        isolation = config["data_isolation"]
        self.assertIsNone(isolation["test_file"])
        self.assertIsNone(isolation["test_labels"])
        self.assertFalse(isolation["test_data_allowed_during_prepare"])
        self.assertFalse(isolation["detection_allowed_during_prepare"])
        self.assertFalse(isolation["metrics_allowed_during_prepare"])


if __name__ == "__main__":
    unittest.main()
