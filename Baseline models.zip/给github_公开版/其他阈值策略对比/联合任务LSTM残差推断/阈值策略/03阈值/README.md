# 03 阈值实验：离线 POT/GPD 标定与双测试集异常检测

## 当前结论

03 阈值已完成纯正常标定，并在用户后续明确授权后完成分钟级与秒级各 5 个测试文件的异常检测。测试阶段只加载冻结的 Mahalanobis 状态、GPD 参数和 POT 阈值，没有重新拟合或根据测试表现调参。

| 时间尺度 | 阈值 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 分钟级 | `10.14894814` | `0.9994 ± 0.0010` | `0.5872 ± 0.0000` | `0.7397 ± 0.0003` | `0.9621 ± 0.0006` | `0.9996 ± 0.0006` | `0.38 ± 0.56` |
| 秒级 | `53.33345141` | `1.0000 ± 0.0000` | `0.1021 ± 0.0000` | `0.1853 ± 0.0000` | `0.9075 ± 0.0030` | `1.0000 ± 0.0000` | `0.00 ± 0.00` |

分钟级在近零误报下检出约 58.72% 的异常窗口。秒级阈值是冻结的 99.99% 重尾外推值，因此实现了零误报，但只检出约 10.21% 的异常窗口；该结果未被用于回调阈值。

| 时间尺度 | 数据集 | 正常得分数 | 初始阈值 `u` | 超限数 | GPD `ξ` | GPD `β` | 99.99% POT 阈值 | 工件状态 |
|---|---|---:|---:|---:|---:|---:|---:|---|
| 分钟级 | `dataset1` | 1960 | `4.2025152243` | 98 | `-0.0141796319` | `0.9996258292` | **`10.1489481391`** | `READY_FOR_TEST` |
| 秒级 | `dataset2` | 20000 | `5.5406752794` | 1000 | `0.4955806604` | `1.1411840821` | **`53.3334514098`** | `READY_FOR_TEST` |

两套阈值分别位于：

```text
artifacts/formal_dataset1/threshold_artifact.json
artifacts/formal_dataset2/threshold_artifact.json
```

二者不能跨时间尺度使用。

## 方法口径

本实验是 Sun et al. (2023) POT 阈值方法向项目联合任务 LSTM 的迁移实现：

```text
固定联合任务 LSTM
→ 标准化空间绝对重构残差
→ 窗口时间维均值
→ Ledoit-Wolf 收缩 Mahalanobis 得分
→ 正常得分 95% 分位作为初始阈值 u
→ 对 score > u 的超限量拟合 loc=0 的 GPD
→ 按无条件上尾概率 1e-4 计算 99.99% 静态阈值
→ 冻结阈值工件
```

论文使用 GRU-VAE 的 MSE 得分，并报告绝对阈值 `0.06/0.0648`；这些数值没有迁移。本项目只迁移 POT/GPD 尾部建模逻辑。

为消除论文 `q` 的符号歧义，配置中明确区分：

```text
alarm_quantile = 0.9999
target_tail_probability = 0.0001
```

代入 POT 公式的是 `target_tail_probability`。

## 冻结参数

```text
initial_quantile = 0.95
alarm_quantile = 0.9999
target_tail_probability = 0.0001
gpd_fit_method = maximum_likelihood
gpd_location = 0.0
min_exceedances = 50
formal_fallback = none
persistence = K=1, M=1
```

正式拟合失败时直接停止，不静默回退到经验分位数。

## 正常数据稳定性审计

| 时间尺度 | 正式阈值 | bootstrap 成功 | bootstrap 均值 | bootstrap 中位数 | bootstrap 95% 区间 |
|---|---:|---:|---:|---:|---:|
| 分钟级 | `10.1489481391` | 1000/1000 | `10.2789294249` | `9.9890046525` | `[8.2992916278, 13.9502911100]` |
| 秒级 | `53.3334514098` | 1000/1000 | `54.1258402526` | `53.4521006374` | `[40.3397995487, 72.2816468510]` |

bootstrap 只使用对应数据集的正常标定得分，且不改变全量正常数据得到的正式阈值。

秒级 GPD 的形状参数为正值 `ξ=0.4955806604`，表示拟合尾部较重。秒级正常标定最大得分为 `32.1619371885`，正式阈值 `53.3334514098` 属于 99.99% 风险水平下的尾部外推；其较宽的 bootstrap 区间已经保留为不确定性证据。当前没有使用测试集调整该阈值。

## 生成文件

两个正式目录均包含：

| 文件 | 作用 |
|---|---|
| `threshold_artifact.json` | 阈值、GPD 参数、模型/数据哈希、上游依赖和数据隔离声明 |
| `gpd_state.json` | 可重建的 POT/GPD 冻结状态 |
| `calibration_scores.npy` | 从 00 公共工件逐字节复制的正常 Mahalanobis 得分 |
| `tail_exceedances.npy` | 严格大于初始阈值的正常超限量 |
| `tail_fit_curve.csv` | GPD PDF、CDF 和生存函数曲线 |
| `tail_fit_plot.png` | 正常尾部直方图、GPD 曲线、目标阈值和生存函数审计 |
| `gpd_qq_plot.png` | GPD QQ 诊断图 |
| `gpd_pp_plot.png` | GPD PP 诊断图 |
| `mean_excess.csv/png` | 只基于正常得分的 mean-excess 审计 |
| `threshold_stability.csv` | 初始分位 `0.90/0.925/0.95` 的参数稳定性表 |
| `bootstrap_thresholds.csv` | 固定种子的 1000 次正常数据 bootstrap 结果 |
| `normal_calibration_audit.json` | 正常标签、形状、元数据和来源审计 |

所有图表只包含正常标定得分或其超限量。

## 实现与验证

| 文件 | 作用 |
|---|---|
| `strategy_03_pot_evt.py` | POT/GPD 拟合、闭式阈值、`ξ→0` 极限和状态重建 |
| `prepare_03_pot_evt.py` | 输入/哈希门禁、正常标定、诊断和正式工件冻结 |
| `detect_03_pot_evt.py` | 加载冻结工件，对单个测试文件输出逐点得分、判定、图和指标 |
| `evaluate_all_test_sets.py` | 批量检测两个时间尺度各 5 个 seed 并生成统一汇总 |
| `experiment_config.json` | 双数据集固定映射、POT 参数和数据隔离配置 |
| `tests/test_strategy_03_pot_evt.py` | 仅使用合成数组的策略单元测试 |

已执行：

```powershell
python -m unittest discover -s 阈值策略\03阈值\tests -p "test_*.py" -v
```

结果：13 项测试全部通过，包括：

- POT 闭式公式与 `ξ→0` 连续极限；
- 负形状参数的有限右端点；
- 目标尾部概率的阈值单调性；
- 严格 `score > u` 的超限定义；
- 无经验分位数回退；
- 状态保存/重建与确定性；
- 分钟级和秒级互相隔离；
- 配置及 CLI 不提供测试、异常检测或评价入口。

## 已执行的正常标定命令

```powershell
python 阈值策略\03阈值\prepare_03_pot_evt.py --dataset dataset1
python 阈值策略\03阈值\prepare_03_pot_evt.py --dataset dataset2
```

准备脚本没有 `--test`、`--labels`、`--detect` 或 `--evaluate` 参数。

## 已执行的异常检测

```powershell
python 阈值策略\03阈值\evaluate_all_test_sets.py
```

结果位于 `03实验结果/`：

- `dataset1_minute/seed*/`：分钟级 5 个 seed 的逐点 CSV、摘要和检测曲线；
- `dataset2_second/seed*/`：秒级 5 个 seed 的逐点 CSV、摘要和检测曲线；
- `evaluation_summary.json`：机器可读的完整汇总；
- `per_seed_metrics.csv`：10 次检测的单 seed 指标；
- `evaluation_report.md`：双时间尺度评价报告。

主实验固定使用 `K=1, M=1`。测试文件没有真实时间戳或事件 ID，因此不正式解释事件召回和检测延迟。

测试文件内置的标准化器与冻结工件对应 seed10 checkpoint 存在版本差异：分钟级 `mean/std` 最大绝对差约为 `1.908/1.028`，秒级约为 `0.317/0.130`。检测使用原始量纲 `x`，并由当前 checkpoint 自带标准化器处理；测试文件的 `x_std` 只用于确认文件内部一致性，没有作为模型输入。

## 当前停止点

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1
→ CALIBRATED_DATASET2
→ READY_FOR_TEST
→ TESTED_BOTH_DATASETS
→ RESULT_FROZEN
```

已经生成 10 份逐点检测结果并完成汇总审计。两套标定工件仍保留原始 `READY_FOR_TEST` 状态，以表示其冻结的标定属性；检测完成状态记录在本 README 与 `03实验结果/evaluation_summary.json` 中。
