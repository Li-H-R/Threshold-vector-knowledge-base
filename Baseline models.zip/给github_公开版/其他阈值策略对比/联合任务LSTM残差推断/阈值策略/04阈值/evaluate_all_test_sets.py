# -*- coding: utf-8 -*-
"""运行 04 ASPOT 的分钟级/秒级各 5 个测试集并汇总点级评价。"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from detect_04_aspot import run as run_detection


METRICS = (
    "precision", "recall", "specificity", "f1", "balanced_accuracy",
    "mcc", "roc_auc", "pr_auc", "false_positive_rate",
    "false_alarms_per_1000_normal_windows",
)


def save_json(path: Path, value: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def seed_from_path(path: Path) -> int:
    match = re.search(r"seed(\d+)", path.stem)
    if not match:
        raise ValueError(f"无法从文件名读取 seed：{path.name}")
    return int(match.group(1))


def pooled_metrics(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    tp = sum(item["point_metrics"]["tp"] for item in summaries)
    fp = sum(item["point_metrics"]["fp"] for item in summaries)
    tn = sum(item["point_metrics"]["tn"] for item in summaries)
    fn = sum(item["point_metrics"]["fn"] for item in summaries)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    specificity = tn / max(tn + fp, 1)
    return {
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
        "precision": float(precision), "recall": float(recall),
        "specificity": float(specificity),
        "f1": float(2.0 * precision * recall / max(precision + recall, 1e-12)),
        "balanced_accuracy": float(0.5 * (recall + specificity)),
        "false_positive_rate": float(1.0 - specificity),
    }


def aggregate(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    metrics_mean_std: Dict[str, Any] = {}
    for metric in METRICS:
        values = np.asarray([item["point_metrics"][metric] for item in summaries])
        metrics_mean_std[metric] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            "min": float(np.min(values)),
            "max": float(np.max(values)),
        }
    type_names = sorted({
        name for item in summaries for name in (item.get("type_metrics") or {})
    })
    type_summary: Dict[str, Any] = {}
    for name in type_names:
        records = [item["type_metrics"][name] for item in summaries]
        if records and "point_recall" in records[0]:
            values = np.asarray([record["point_recall"] for record in records])
            type_summary[name] = {
                "kind": "anomaly",
                "count_per_seed": int(records[0]["count"]),
                "recall_mean": float(np.mean(values)),
                "recall_std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            }
        elif records and "point_false_positive_rate" in records[0]:
            values = np.asarray([record["point_false_positive_rate"] for record in records])
            type_summary[name] = {
                "kind": "normal",
                "count_per_seed": int(records[0]["count"]),
                "false_positive_rate_mean": float(np.mean(values)),
                "false_positive_rate_std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            }
    return {
        "num_seeds": len(summaries),
        "metrics_mean_std": metrics_mean_std,
        "pooled_confusion_metrics": pooled_metrics(summaries),
        "type_metrics": type_summary,
    }


def audit_test_design(test_files: List[Path]) -> Dict[str, Any]:
    records = []
    for path in test_files:
        with np.load(path, allow_pickle=False) as archive:
            records.append({
                "x": archive["x"],
                "y": archive["y_true"].astype(np.int64),
                "types": archive["y_type"].astype(str),
            })
    base = records[0]
    anomaly_mask = base["y"] == 1
    normal_mask = ~anomaly_mask
    return {
        "num_test_files": len(records),
        "windows_per_file": int(base["y"].size),
        "normal_per_file": int(normal_mask.sum()),
        "anomaly_per_file": int(anomaly_mask.sum()),
        "label_transitions_per_file": int(np.count_nonzero(np.diff(base["y"]) != 0)),
        "anomaly_windows_identical_across_seeds": bool(all(
            np.array_equal(base["x"][anomaly_mask], item["x"][item["y"] == 1])
            for item in records[1:]
        )),
        "normal_windows_identical_across_seeds": bool(all(
            np.array_equal(base["x"][normal_mask], item["x"][item["y"] == 0])
            for item in records[1:]
        )),
        "timestamps_or_event_ids_available": False,
        "stored_order": "randomly sampled normal block followed by fixed anomaly block",
        "dynamic_threshold_interpretation": (
            "ASPOT is causal in stored order, but updates are not a physically chronological stream."
        ),
    }


def write_seed_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fields = [
        "dataset", "time_scale", "seed",
        "initial_lower_threshold", "initial_upper_threshold",
        "final_lower_threshold", "final_upper_threshold",
        *METRICS, "tp", "fp", "tn", "fn",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            summary = row["summary"]
            metrics = summary["point_metrics"]
            writer.writerow({
                "dataset": row["dataset"],
                "time_scale": row["time_scale"],
                "seed": row["seed"],
                "initial_lower_threshold": summary["initial_bounds"]["lower_threshold"],
                "initial_upper_threshold": summary["initial_bounds"]["upper_threshold"],
                "final_lower_threshold": summary["runtime_final_bounds"]["lower_threshold"],
                "final_upper_threshold": summary["runtime_final_bounds"]["upper_threshold"],
                **{key: metrics[key] for key in METRICS},
                **{key: metrics[key] for key in ("tp", "fp", "tn", "fn")},
            })


def fmt(value: Dict[str, float], digits: int = 4) -> str:
    return f"{value['mean']:.{digits}f} ± {value['std']:.{digits}f}"


def write_report(path: Path, result: Dict[str, Any]) -> None:
    independent = result["update_mode"] == "frozen_independent"
    title = (
        "# 04 ASPOT 冻结边界独立窗口：分钟级与秒级异常检测评价"
        if independent
        else "# 04 双侧中心化 ASPOT：分钟级与秒级异常检测评价"
    )
    lines = [
        title,
        "",
        "## 评价口径",
        "",
        "- 使用纯正常阶段冻结的联合任务 LSTM、Mahalanobis 状态和 ASPOT 初始状态；测试阶段未重新拟合。",
        (
            "- 每个测试窗口独立使用冻结中心和双侧边界；测试阶段完全不更新 ASPOT 状态，窗口顺序不影响判定。"
            if independent
            else "- 每个测试文件都从对应数据集的同一冻结 ASPOT 状态副本开始，文件间不共享在线状态。"
        ),
        (
            "- 任一单独窗口越过下边界或上边界即判异常，不要求连续超限。该版本是冻结阈值迁移，不是论文完整在线自适应流程。"
            if independent
            else "- ASPOT 按文件存储顺序因果更新，异常点冻结，峰值点更新尾部与滑窗，普通正常点只更新滑窗。"
        ),
        "- 主结果固定 `K=1, M=1`，报告 5 个正常抽样 seed 的点级均值 ± 样本标准差。",
        "- 测试文件是随机正常块后接固定异常块，没有真实时间戳或事件 ID；不正式解释事件指标和检测延迟。",
        "",
        "## 总体点级结果",
        "",
        "| 时间尺度 | 初始中心化边界 | Precision | Recall | F1 | PR-AUC | Specificity | MCC | 误报/1000正常窗口 |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        data = result[dataset]
        metrics = data["aggregate"]["metrics_mean_std"]
        initial = data["initial_bounds"]
        lines.append(
            f"| {label} | [{initial['lower_threshold']:.6f}, {initial['upper_threshold']:.6f}] | "
            f"{fmt(metrics['precision'])} | {fmt(metrics['recall'])} | {fmt(metrics['f1'])} | "
            f"{fmt(metrics['pr_auc'])} | {fmt(metrics['specificity'])} | {fmt(metrics['mcc'])} | "
            f"{fmt(metrics['false_alarms_per_1000_normal_windows'], 2)} |"
        )
    lines.extend(["", "## 单 seed 结果", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend([
            f"### {label}", "",
            "| Seed | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 | 最终中心化边界 |",
            "|---:|---:|---:|---:|---:|---:|---:|---|",
        ])
        for run in result[dataset]["runs"]:
            metrics = run["point_metrics"]
            bounds = run["runtime_final_bounds"]
            lines.append(
                f"| {run['seed']} | {metrics['precision']:.4f} | {metrics['recall']:.4f} | "
                f"{metrics['f1']:.4f} | {metrics['pr_auc']:.4f} | {metrics['specificity']:.4f} | "
                f"{metrics['false_alarms_per_1000_normal_windows']:.2f} | "
                f"[{bounds['lower_threshold']:.4f}, {bounds['upper_threshold']:.4f}] |"
            )
        lines.append("")
    lines.extend(["## 异常类型召回", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend([
            f"### {label}", "",
            "| y_type | 每 seed 样本 | Recall 均值 | Recall 标准差 |",
            "|---|---:|---:|---:|",
        ])
        for name, metrics in result[dataset]["aggregate"]["type_metrics"].items():
            if metrics["kind"] == "anomaly":
                lines.append(
                    f"| {name} | {metrics['count_per_seed']} | "
                    f"{metrics['recall_mean']:.4f} | {metrics['recall_std']:.4f} |"
                )
        lines.append("")
    lines.extend([
        "## 测试设计限制",
        "",
        (
            "两个时间尺度的文件都只有一次标签跳变：正常窗口全部在前、异常窗口全部在后。"
            "五个 seed 共享相同异常窗口，只重新抽样正常窗口。独立窗口版本不使用测试顺序更新阈值，"
            "因此顺序不改变单窗判定；标准差主要反映正常抽样造成的误报波动。"
            if independent
            else
            "两个时间尺度的文件都只有一次标签跳变：正常窗口全部在前、异常窗口全部在后。"
            "五个 seed 共享相同异常窗口，只重新抽样正常窗口。因此标准差主要反映正常抽样与动态阈值预热顺序造成的误报波动。"
        ),
        "",
        "由于缺少真实时间戳/事件 ID，本报告只把逐点 Precision、Recall、F1、PR-AUC、Specificity、MCC 和误报率作为正式结果。",
        "",
        "测试文件内置 mean/std 与当前 seed10 checkpoint 略有差异：分钟级最大绝对差分别为 1.908203125 和 1.0277709961，"
        "秒级分别为 0.3166503906 和 0.1295166016。检测始终读取原始量纲数组 x，并使用冻结模型 checkpoint 自带的标准化器；"
        "测试文件的 x_std 只做内部一致性审计，不作为模型输入。",
        "",
        "完整逐点原始得分、中心、中心化得分、上下峰值、上下报警边界、更新类型和判定见各 seed 目录。",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test-root", type=Path, default=PROJECT_ROOT / "测试集数据")
    parser.add_argument("--output-root", type=Path, default=SCRIPT_DIR / "04实验结果")
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument(
        "--update-mode",
        choices=("causal_dynamic", "frozen_independent"),
        default="causal_dynamic",
    )
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    configs = {
        "dataset1": {
            "time_scale": "minute",
            "input_dir": args.test_root / "dataset1",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset1" / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset1_minute",
        },
        "dataset2": {
            "time_scale": "second",
            "input_dir": args.test_root / "dataset2",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset2" / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset2_second",
        },
    }
    if args.output_root.exists() and any(args.output_root.iterdir()):
        raise FileExistsError(f"结果目录非空，拒绝覆盖：{args.output_root}")
    rows: List[Dict[str, Any]] = []
    result: Dict[str, Any] = {
        "strategy_id": (
            "04_aspot_frozen_independent"
            if args.update_mode == "frozen_independent"
            else "04_aspot_two_sided"
        ),
        "source_strategy_id": "04_aspot_two_sided",
        "update_mode": args.update_mode,
        "status": "TESTED_BOTH_DATASETS",
        "completion_status": "RESULT_FROZEN",
        "evaluation_rule": "point-level, K=1, M=1, five normal-sampling seeds",
        "score_or_initial_aspot_refit_on_test": False,
        "online_causal_update_enabled": args.update_mode == "causal_dynamic",
        "test_state_updates_enabled": args.update_mode == "causal_dynamic",
        "single_window_is_sufficient_for_anomaly": True,
        "test_data_used_for_parameter_selection": False,
        "event_metrics_formally_used": False,
    }
    for dataset, config in configs.items():
        test_files = sorted(config["input_dir"].glob("test_seed*.npz"), key=seed_from_path)
        if len(test_files) != 5:
            raise ValueError(f"{dataset} 应有 5 个测试文件，实际 {len(test_files)}")
        summaries = []
        runs = []
        for test_file in test_files:
            seed = seed_from_path(test_file)
            namespace = SimpleNamespace(
                artifact=config["artifact"],
                test=test_file,
                labels=None,
                output_dir=config["output_dir"] / f"seed{seed}",
                k=1, m=1, batch_size=args.batch_size,
                array_key="x", label_key="y_true", type_key="y_type", input_space="raw",
                update_mode=args.update_mode,
            )
            summary = run_detection(namespace)
            summaries.append(summary)
            runs.append({"seed": seed, **summary})
            rows.append({
                "dataset": dataset,
                "time_scale": config["time_scale"],
                "seed": seed,
                "summary": summary,
            })
        result[dataset] = {
            "time_scale": config["time_scale"],
            "initial_bounds": summaries[0]["initial_bounds"],
            "num_test_sets": len(summaries),
            "runs": runs,
            "aggregate": aggregate(summaries),
            "data_audit": audit_test_design(test_files),
        }
    args.output_root.mkdir(parents=True, exist_ok=True)
    save_json(args.output_root / "evaluation_summary.json", result)
    write_seed_csv(args.output_root / "per_seed_metrics.csv", rows)
    write_report(args.output_root / "evaluation_report.md", result)
    print(f"双测试集汇总：{args.output_root / 'evaluation_report.md'}")
    return result


def main() -> Dict[str, Any]:
    return run(build_parser().parse_args())


if __name__ == "__main__":
    main()
