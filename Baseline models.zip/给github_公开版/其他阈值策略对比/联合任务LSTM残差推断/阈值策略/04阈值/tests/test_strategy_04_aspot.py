# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from strategy_04_aspot import (
    ASPOTThreshold,
    asp_threshold_increment,
    load_state_npz,
    mom_gpd_parameters,
    save_state_npz,
    two_sided_peak_exceedances,
)


def calibration(seed: int = 7, n: int = 800) -> np.ndarray:
    rng = np.random.default_rng(seed)
    base = 4.0 + 0.15 * np.sin(np.linspace(0.0, 12.0, n))
    return np.maximum(base + rng.normal(0.0, 0.35, n), 0.01)


class FormulaTests(unittest.TestCase):
    def test_two_sided_exceedances_are_positive(self):
        values = np.asarray([-3.0, -1.0, 0.0, 2.0, 5.0])
        got = two_sided_peak_exceedances(values, -2.0, 3.0)
        np.testing.assert_allclose(np.sort(got), [1.0, 2.0])

    def test_mom_matches_formula(self):
        values = np.asarray([0.2, 0.4, 0.7, 1.1, 1.8])
        gamma, sigma, mean, variance = mom_gpd_parameters(values)
        ratio = mean * mean / variance
        self.assertAlmostEqual(gamma, 0.5 * (1.0 - ratio))
        self.assertAlmostEqual(sigma, 0.5 * mean * (1.0 + ratio))

    def test_zero_shape_limit(self):
        direct = asp_threshold_increment(2.0, 0.0, 1000, 40, 1.0e-4)
        expected = 2.0 * np.log((40 / 1000) / 1.0e-4)
        self.assertAlmostEqual(direct, expected)
        near = asp_threshold_increment(2.0, 1.0e-12, 1000, 40, 1.0e-4)
        self.assertAlmostEqual(near, expected)


class StrategyTests(unittest.TestCase):
    def make_strategy(self) -> ASPOTThreshold:
        return ASPOTThreshold(
            history_size=300,
            minimum_peaks=10,
            risk_probability=1.0e-3,
        ).fit(calibration())

    def test_fit_bounds_and_counts(self):
        strategy = self.make_strategy()
        state = strategy.state_dict()
        self.assertLess(state["lower_threshold"], state["lower_peak"])
        self.assertLess(state["lower_peak"], state["upper_peak"])
        self.assertLess(state["upper_peak"], state["upper_threshold"])
        self.assertEqual(
            state["accepted_count"],
            state["initial_history_count"]
            + state["accepted_normal_count"]
            + state["accepted_peak_count"],
        )
        self.assertEqual(
            state["peak_count"],
            len(state["exceedances"]),
        )

    def test_extreme_freezes_state(self):
        strategy = self.make_strategy()
        before = strategy.state_dict()
        output = strategy.step(1.0e6)
        after = strategy.state_dict()
        self.assertTrue(output.point_pred)
        self.assertEqual(output.update_type, "frozen_extreme")
        for key in (
            "raw_history", "centered_history", "exceedances",
            "accepted_count", "peak_count", "lower_peak", "upper_peak",
            "lower_threshold", "upper_threshold",
        ):
            np.testing.assert_array_equal(before[key], after[key])

    def test_normal_updates_only_accepted_count(self):
        strategy = self.make_strategy()
        before = strategy.state_dict()
        center = float(np.mean(before["raw_history"]))
        output = strategy.step(center)
        after = strategy.state_dict()
        self.assertEqual(output.update_type, "accepted_normal")
        self.assertEqual(after["accepted_count"], before["accepted_count"] + 1)
        self.assertEqual(after["peak_count"], before["peak_count"])

    def test_peak_updates_tail(self):
        strategy = self.make_strategy()
        before = strategy.state_dict()
        center = float(np.mean(before["raw_history"]))
        centered = 0.5 * (before["upper_peak"] + before["upper_threshold"])
        output = strategy.step(center + centered)
        after = strategy.state_dict()
        self.assertEqual(output.update_type, "accepted_peak")
        self.assertEqual(after["accepted_count"], before["accepted_count"] + 1)
        self.assertEqual(after["peak_count"], before["peak_count"] + 1)

    def test_future_changes_do_not_change_prefix(self):
        base = self.make_strategy().state_dict()
        left = ASPOTThreshold.from_state_dict(base)
        right = ASPOTThreshold.from_state_dict(base)
        prefix = [4.0, 4.1, 3.9, 4.2]
        left_prefix = left.process(prefix)
        right_prefix = right.process(prefix)
        left.process([4.0, 4.0])
        right.process([1.0e6, 1.0e6])
        self.assertEqual(left_prefix, right_prefix)

    def test_save_load_next_step_is_exact(self):
        strategy = self.make_strategy()
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "state.npz"
            save_state_npz(path, strategy.state_dict())
            restored = ASPOTThreshold.from_state_dict(load_state_npz(path))
        probe = 4.05
        self.assertEqual(strategy.step(probe), restored.step(probe))
        a = strategy.state_dict()
        b = restored.state_dict()
        for key in a:
            np.testing.assert_array_equal(a[key], b[key])

    def test_invalid_scores_rejected(self):
        with self.assertRaises(ValueError):
            ASPOTThreshold(history_size=50, minimum_peaks=3).fit(
                np.r_[np.ones(60), np.nan]
            )


if __name__ == "__main__":
    unittest.main()
