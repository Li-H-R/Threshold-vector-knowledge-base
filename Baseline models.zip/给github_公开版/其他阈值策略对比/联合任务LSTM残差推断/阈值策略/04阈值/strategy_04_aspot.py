# -*- coding: utf-8 -*-
"""04 阈值策略：公共 Mahalanobis 得分上的双侧中心化 ASPOT。"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np


STRATEGY_ID = "04_aspot_two_sided"
SCHEMA_VERSION = 1
EPS = 1.0e-12


def validate_scores(values: np.ndarray, *, min_samples: int = 2) -> np.ndarray:
    scores = np.asarray(values, dtype=np.float64).reshape(-1)
    if scores.size < min_samples:
        raise ValueError(f"至少需要 {min_samples} 个得分，实际 {scores.size}")
    if not np.all(np.isfinite(scores)):
        raise ValueError("得分中存在 NaN 或 Inf")
    if np.any(scores < 0.0):
        raise ValueError("公共 Mahalanobis 得分不能为负")
    return np.ascontiguousarray(scores)


def two_sided_peak_exceedances(
    centered_scores: np.ndarray,
    lower_peak: float,
    upper_peak: float,
) -> np.ndarray:
    values = np.asarray(centered_scores, dtype=np.float64).reshape(-1)
    if not np.all(np.isfinite(values)):
        raise ValueError("中心化得分中存在 NaN 或 Inf")
    if not np.isfinite(lower_peak) or not np.isfinite(upper_peak):
        raise ValueError("峰值边界必须为有限数")
    if not lower_peak < upper_peak:
        raise ValueError("必须满足 lower_peak < upper_peak")
    upper = values[values > upper_peak] - upper_peak
    lower = lower_peak - values[values < lower_peak]
    result = np.concatenate((upper, lower)).astype(np.float64, copy=False)
    if result.size and (np.any(result <= 0.0) or not np.all(np.isfinite(result))):
        raise RuntimeError("双尾超限量必须是有限正数")
    return np.ascontiguousarray(result)


def mom_gpd_parameters(exceedances: np.ndarray) -> Tuple[float, float, float, float]:
    values = np.asarray(exceedances, dtype=np.float64).reshape(-1)
    if values.size < 2:
        raise ValueError("MOM 至少需要 2 个超限量")
    if not np.all(np.isfinite(values)) or np.any(values <= 0.0):
        raise ValueError("MOM 超限量必须为有限正数")
    mean = float(np.mean(values))
    variance = float(np.var(values, ddof=1))
    if mean <= EPS or variance <= EPS:
        raise ValueError("超限量均值或样本方差接近 0")
    ratio = mean * mean / variance
    sigma = 0.5 * mean * (1.0 + ratio)
    gamma = 0.5 * (1.0 - ratio)
    if not np.isfinite(sigma) or not np.isfinite(gamma) or sigma <= 0.0:
        raise ValueError("MOM 产生无效 GPD 参数")
    support = 1.0 + gamma * values / sigma
    if np.any(support <= 0.0):
        raise ValueError("观测超限量落在 MOM-GPD 支持域之外")
    return float(gamma), float(sigma), mean, variance


def asp_threshold_increment(
    sigma: float,
    gamma: float,
    accepted_count: int,
    peak_count: int,
    risk_probability: float,
    *,
    shape_zero_tolerance: float = 1.0e-8,
) -> float:
    if not np.isfinite(sigma) or sigma <= 0.0:
        raise ValueError("sigma 必须为有限正数")
    if not np.isfinite(gamma):
        raise ValueError("gamma 必须为有限数")
    if accepted_count < 1 or peak_count < 1 or peak_count >= accepted_count:
        raise ValueError("计数必须满足 0 < peak_count < accepted_count")
    if not 0.0 < risk_probability < 1.0:
        raise ValueError("risk_probability 必须位于 (0,1)")
    peak_rate = peak_count / accepted_count
    if risk_probability >= peak_rate:
        raise ValueError("risk_probability 必须小于经验峰值率")
    if shape_zero_tolerance <= 0.0:
        raise ValueError("shape_zero_tolerance 必须为正")

    log_ratio = float(np.log(peak_rate / risk_probability))
    if abs(gamma) <= shape_zero_tolerance:
        increment = sigma * log_ratio
    else:
        increment = sigma * float(np.expm1(gamma * log_ratio)) / gamma
    if not np.isfinite(increment) or increment <= 0.0:
        raise ValueError("ASPOT 得到无效报警边界增量")
    if gamma < 0.0:
        endpoint = -sigma / gamma
        if not increment < endpoint:
            raise ValueError("报警增量到达或越过 GPD 有限右端点")
    return float(increment)


@dataclass(frozen=True)
class ASPOTStepOutput:
    raw_score: float
    center: float
    centered_score: float
    lower_peak: float
    upper_peak: float
    lower_threshold: float
    upper_threshold: float
    point_pred: bool
    update_type: str


class ASPOTThreshold:
    """论文 ASPOT 阈值模块的可冻结、严格因果迁移实现。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        *,
        history_size: int,
        lower_peak_quantile: float = 0.02,
        upper_peak_quantile: float = 0.98,
        risk_probability: float = 1.0e-4,
        minimum_peaks: int = 30,
        shape_zero_tolerance: float = 1.0e-8,
        quantile_method: str = "linear",
    ) -> None:
        if history_size < 20:
            raise ValueError("history_size 至少为 20")
        if not 0.0 < lower_peak_quantile < upper_peak_quantile < 1.0:
            raise ValueError("峰值分位必须满足 0 < lower < upper < 1")
        if not 0.0 < risk_probability < 1.0:
            raise ValueError("risk_probability 必须位于 (0,1)")
        if minimum_peaks < 3:
            raise ValueError("minimum_peaks 至少为 3")
        if shape_zero_tolerance <= 0.0:
            raise ValueError("shape_zero_tolerance 必须为正")
        if quantile_method not in {"linear"}:
            raise ValueError("正式配置仅支持 linear 分位数")

        self.history_size = int(history_size)
        self.lower_peak_quantile = float(lower_peak_quantile)
        self.upper_peak_quantile = float(upper_peak_quantile)
        self.risk_probability = float(risk_probability)
        self.minimum_peaks = int(minimum_peaks)
        self.shape_zero_tolerance = float(shape_zero_tolerance)
        self.quantile_method = quantile_method

        self.raw_history_: Optional[deque] = None
        self.centered_history_: Optional[deque] = None
        self.exceedances_: Optional[List[float]] = None
        self.accepted_count_: Optional[int] = None
        self.peak_count_: Optional[int] = None
        self.lower_peak_: Optional[float] = None
        self.upper_peak_: Optional[float] = None
        self.gamma_: Optional[float] = None
        self.sigma_: Optional[float] = None
        self.exceedance_mean_: Optional[float] = None
        self.exceedance_variance_: Optional[float] = None
        self.increment_: Optional[float] = None
        self.lower_threshold_: Optional[float] = None
        self.upper_threshold_: Optional[float] = None
        self.update_counts_: Dict[str, int] = {
            "initial_history": 0,
            "accepted_normal": 0,
            "accepted_peak": 0,
            "frozen_extreme": 0,
        }
        self.trace_: List[ASPOTStepOutput] = []

    def _require_fit(self) -> None:
        required = (
            self.raw_history_, self.centered_history_, self.exceedances_,
            self.accepted_count_, self.peak_count_, self.lower_peak_,
            self.upper_peak_, self.gamma_, self.sigma_, self.increment_,
            self.lower_threshold_, self.upper_threshold_,
        )
        if any(value is None for value in required):
            raise RuntimeError("请先调用 fit()")

    def _refresh_mom_and_alarm_bounds(self) -> None:
        assert self.exceedances_ is not None
        assert self.accepted_count_ is not None
        assert self.peak_count_ is not None
        assert self.lower_peak_ is not None
        assert self.upper_peak_ is not None
        gamma, sigma, mean, variance = mom_gpd_parameters(
            np.asarray(self.exceedances_, dtype=np.float64)
        )
        increment = asp_threshold_increment(
            sigma,
            gamma,
            self.accepted_count_,
            self.peak_count_,
            self.risk_probability,
            shape_zero_tolerance=self.shape_zero_tolerance,
        )
        lower_threshold = self.lower_peak_ - increment
        upper_threshold = self.upper_peak_ + increment
        if not lower_threshold < self.lower_peak_ < self.upper_peak_ < upper_threshold:
            raise ValueError("ASPOT 上下边界顺序无效")
        self.gamma_ = gamma
        self.sigma_ = sigma
        self.exceedance_mean_ = mean
        self.exceedance_variance_ = variance
        self.increment_ = increment
        self.lower_threshold_ = float(lower_threshold)
        self.upper_threshold_ = float(upper_threshold)

    def fit(self, normal_calibration_scores: np.ndarray) -> "ASPOTThreshold":
        scores = validate_scores(
            normal_calibration_scores, min_samples=self.history_size + 1
        )
        initial_raw = scores[: self.history_size]
        initial_center = float(np.mean(initial_raw))
        initial_centered = initial_raw - initial_center
        if float(np.std(initial_centered)) <= EPS:
            raise ValueError("初始化中心化得分方差接近 0")

        lower_peak = float(np.quantile(
            initial_centered, self.lower_peak_quantile, method=self.quantile_method
        ))
        upper_peak = float(np.quantile(
            initial_centered, self.upper_peak_quantile, method=self.quantile_method
        ))
        exceedances = two_sided_peak_exceedances(
            initial_centered, lower_peak, upper_peak
        )
        if exceedances.size < self.minimum_peaks:
            raise ValueError(
                f"双尾峰值至少需要 {self.minimum_peaks} 个，实际 {exceedances.size}"
            )

        self.raw_history_ = deque(initial_raw.tolist(), maxlen=self.history_size)
        self.centered_history_ = deque(
            initial_centered.tolist(), maxlen=self.history_size
        )
        self.exceedances_ = exceedances.tolist()
        self.accepted_count_ = int(self.history_size)
        self.peak_count_ = int(exceedances.size)
        self.lower_peak_ = lower_peak
        self.upper_peak_ = upper_peak
        self.update_counts_ = {
            "initial_history": int(self.history_size),
            "accepted_normal": 0,
            "accepted_peak": 0,
            "frozen_extreme": 0,
        }
        self.trace_ = []
        self._refresh_mom_and_alarm_bounds()

        for score in scores[self.history_size :]:
            self.step(float(score), record_trace=True)
        return self

    def step(self, score: float, *, record_trace: bool = False) -> ASPOTStepOutput:
        self._require_fit()
        if not np.isfinite(score) or score < 0.0:
            raise ValueError("单步公共得分必须为有限非负数")
        assert self.raw_history_ is not None
        assert self.centered_history_ is not None
        assert self.exceedances_ is not None
        assert self.accepted_count_ is not None
        assert self.peak_count_ is not None
        assert self.lower_peak_ is not None
        assert self.upper_peak_ is not None
        assert self.lower_threshold_ is not None
        assert self.upper_threshold_ is not None

        center = float(np.mean(np.asarray(self.raw_history_, dtype=np.float64)))
        centered = float(score - center)
        used_lower_peak = self.lower_peak_
        used_upper_peak = self.upper_peak_
        used_lower_threshold = self.lower_threshold_
        used_upper_threshold = self.upper_threshold_

        if centered < used_lower_threshold or centered > used_upper_threshold:
            update_type = "frozen_extreme"
            point_pred = True
            self.update_counts_[update_type] += 1
        else:
            point_pred = False
            is_peak = centered < used_lower_peak or centered > used_upper_peak
            self.accepted_count_ += 1
            self.raw_history_.append(float(score))
            self.centered_history_.append(centered)
            if is_peak:
                update_type = "accepted_peak"
                exceedance = (
                    centered - used_upper_peak
                    if centered > used_upper_peak
                    else used_lower_peak - centered
                )
                if not np.isfinite(exceedance) or exceedance <= 0.0:
                    raise RuntimeError("单步峰值超限量无效")
                self.exceedances_.append(float(exceedance))
                self.peak_count_ += 1
                history = np.asarray(self.centered_history_, dtype=np.float64)
                self.lower_peak_ = float(np.quantile(
                    history, self.lower_peak_quantile, method=self.quantile_method
                ))
                self.upper_peak_ = float(np.quantile(
                    history, self.upper_peak_quantile, method=self.quantile_method
                ))
                self._refresh_mom_and_alarm_bounds()
            else:
                update_type = "accepted_normal"
            self.update_counts_[update_type] += 1

        output = ASPOTStepOutput(
            raw_score=float(score),
            center=center,
            centered_score=centered,
            lower_peak=used_lower_peak,
            upper_peak=used_upper_peak,
            lower_threshold=used_lower_threshold,
            upper_threshold=used_upper_threshold,
            point_pred=point_pred,
            update_type=update_type,
        )
        if record_trace:
            self.trace_.append(output)
        return output

    def process(self, scores: Iterable[float]) -> List[ASPOTStepOutput]:
        return [self.step(float(value)) for value in scores]

    def state_dict(self) -> Dict[str, Any]:
        self._require_fit()
        assert self.raw_history_ is not None
        assert self.centered_history_ is not None
        assert self.exceedances_ is not None
        return {
            "schema_version": SCHEMA_VERSION,
            "strategy_id": STRATEGY_ID,
            "history_size": self.history_size,
            "lower_peak_quantile": self.lower_peak_quantile,
            "upper_peak_quantile": self.upper_peak_quantile,
            "risk_probability": self.risk_probability,
            "minimum_peaks": self.minimum_peaks,
            "shape_zero_tolerance": self.shape_zero_tolerance,
            "quantile_method": self.quantile_method,
            "raw_history": np.asarray(self.raw_history_, dtype=np.float64),
            "centered_history": np.asarray(self.centered_history_, dtype=np.float64),
            "exceedances": np.asarray(self.exceedances_, dtype=np.float64),
            "accepted_count": int(self.accepted_count_),
            "peak_count": int(self.peak_count_),
            "lower_peak": float(self.lower_peak_),
            "upper_peak": float(self.upper_peak_),
            "gpd_shape": float(self.gamma_),
            "gpd_scale": float(self.sigma_),
            "exceedance_mean": float(self.exceedance_mean_),
            "exceedance_variance": float(self.exceedance_variance_),
            "threshold_increment": float(self.increment_),
            "lower_threshold": float(self.lower_threshold_),
            "upper_threshold": float(self.upper_threshold_),
            "initial_history_count": int(self.update_counts_["initial_history"]),
            "accepted_normal_count": int(self.update_counts_["accepted_normal"]),
            "accepted_peak_count": int(self.update_counts_["accepted_peak"]),
            "frozen_extreme_count": int(self.update_counts_["frozen_extreme"]),
        }

    @classmethod
    def from_state_dict(cls, state: Dict[str, Any]) -> "ASPOTThreshold":
        def scalar(name: str) -> Any:
            value = state[name]
            return value.item() if isinstance(value, np.ndarray) and value.ndim == 0 else value

        if int(scalar("schema_version")) != SCHEMA_VERSION:
            raise ValueError("不支持的 ASPOT schema_version")
        if str(scalar("strategy_id")) != STRATEGY_ID:
            raise ValueError("state 不是 04_aspot_two_sided 工件")
        obj = cls(
            history_size=int(scalar("history_size")),
            lower_peak_quantile=float(scalar("lower_peak_quantile")),
            upper_peak_quantile=float(scalar("upper_peak_quantile")),
            risk_probability=float(scalar("risk_probability")),
            minimum_peaks=int(scalar("minimum_peaks")),
            shape_zero_tolerance=float(scalar("shape_zero_tolerance")),
            quantile_method=str(scalar("quantile_method")),
        )
        raw = validate_scores(np.asarray(state["raw_history"]), min_samples=obj.history_size)
        if raw.size != obj.history_size:
            raise ValueError("冻结 raw_history 长度与 history_size 不一致")
        centered = np.asarray(state["centered_history"], dtype=np.float64).reshape(-1)
        exceedances = np.asarray(state["exceedances"], dtype=np.float64).reshape(-1)
        if centered.size != obj.history_size or not np.all(np.isfinite(centered)):
            raise ValueError("冻结 centered_history 无效")
        if exceedances.size < obj.minimum_peaks:
            raise ValueError("冻结 exceedances 少于 minimum_peaks")
        obj.raw_history_ = deque(raw.tolist(), maxlen=obj.history_size)
        obj.centered_history_ = deque(centered.tolist(), maxlen=obj.history_size)
        obj.exceedances_ = exceedances.tolist()
        obj.accepted_count_ = int(scalar("accepted_count"))
        obj.peak_count_ = int(scalar("peak_count"))
        obj.lower_peak_ = float(scalar("lower_peak"))
        obj.upper_peak_ = float(scalar("upper_peak"))
        obj.gamma_ = float(scalar("gpd_shape"))
        obj.sigma_ = float(scalar("gpd_scale"))
        obj.exceedance_mean_ = float(scalar("exceedance_mean"))
        obj.exceedance_variance_ = float(scalar("exceedance_variance"))
        obj.increment_ = float(scalar("threshold_increment"))
        obj.lower_threshold_ = float(scalar("lower_threshold"))
        obj.upper_threshold_ = float(scalar("upper_threshold"))
        obj.update_counts_ = {
            "initial_history": int(scalar("initial_history_count")),
            "accepted_normal": int(scalar("accepted_normal_count")),
            "accepted_peak": int(scalar("accepted_peak_count")),
            "frozen_extreme": int(scalar("frozen_extreme_count")),
        }
        obj.trace_ = []
        # 普通正常点只增加 accepted_count，不重算报警边界；因此当前计数可能
        # 晚于最近一次峰值更新。恢复时重建只依赖尾部池的 MOM 参数，并验证
        # 已冻结边界仍与已保存的峰值边界和增量严格一致。
        rebuilt_gamma, rebuilt_sigma, rebuilt_mean, rebuilt_variance = (
            mom_gpd_parameters(exceedances)
        )
        frozen_mom = (
            obj.gamma_, obj.sigma_,
            obj.exceedance_mean_, obj.exceedance_variance_,
        )
        rebuilt_mom = (
            rebuilt_gamma, rebuilt_sigma,
            rebuilt_mean, rebuilt_variance,
        )
        if not np.allclose(frozen_mom, rebuilt_mom, rtol=0.0, atol=1.0e-12):
            raise ValueError("冻结 ASPOT 的 MOM 参数与尾部池重建结果不一致")
        expected_lower = obj.lower_peak_ - obj.increment_
        expected_upper = obj.upper_peak_ + obj.increment_
        if not np.allclose(
            (obj.lower_threshold_, obj.upper_threshold_),
            (expected_lower, expected_upper),
            rtol=0.0,
            atol=1.0e-12,
        ):
            raise ValueError("冻结 ASPOT 报警边界与峰值边界/增量不一致")
        if obj.gamma_ < 0.0 and not obj.increment_ < -obj.sigma_ / obj.gamma_:
            raise ValueError("冻结 ASPOT 增量越过 GPD 有限右端点")
        return obj


def save_state_npz(path: Any, state: Dict[str, Any]) -> None:
    np.savez_compressed(path, **state)


def load_state_npz(path: Any) -> Dict[str, Any]:
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}
