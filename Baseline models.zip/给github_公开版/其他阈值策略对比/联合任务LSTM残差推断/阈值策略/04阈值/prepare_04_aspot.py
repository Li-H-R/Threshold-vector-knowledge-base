# -*- coding: utf-8 -*-
"""只用纯正常连续得分准备 04 双侧中心化 ASPOT 工件。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
BASELINE_DIR = SCRIPT_DIR.parent / "00阈值"
for candidate in (PROJECT_ROOT, SCRIPT_DIR, BASELINE_DIR):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from artifact_utils import load_score_state, transform_score
from main import DATASETS, compute, load_joint
from strategy_04_aspot import (
    ASPOTThreshold,
    load_state_npz,
    save_state_npz,
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def resolve_project_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def require_hash(path: Path, expected: str, label: str) -> str:
    actual = sha256_file(path)
    if actual.lower() != expected.lower():
        raise ValueError(f"{label} SHA-256 不匹配：{actual} != {expected}")
    return actual


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True, choices=("dataset1", "dataset2"))
    parser.add_argument(
        "--config", type=Path, default=SCRIPT_DIR / "experiment_config.json"
    )
    parser.add_argument("--normal-source", type=Path)
    parser.add_argument("--upstream-score-artifact", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--batch-size", type=int, default=2048)
    return parser


def audit_dataset1(source: Path, expected_count: int) -> Dict[str, Any]:
    with np.load(source, allow_pickle=False) as archive:
        required = {
            "X", "y", "source_row_start", "source_row_end",
            "timestamp_start", "timestamp_end",
        }
        missing = sorted(required - set(archive.files))
        if missing:
            raise ValueError(f"分钟级正常标定缺少字段：{missing}")
        x_shape = tuple(int(value) for value in archive["X"].shape)
        labels = np.asarray(archive["y"]).reshape(-1)
        starts = np.asarray(archive["source_row_start"], dtype=np.int64).reshape(-1)
        ends = np.asarray(archive["source_row_end"], dtype=np.int64).reshape(-1)
        timestamps = np.asarray(archive["timestamp_start"]).astype("datetime64[s]")
    if x_shape != (expected_count, 10, 8):
        raise ValueError(f"分钟级正常标定形状错误：{x_shape}")
    if labels.size != expected_count or not np.all(labels == 0):
        raise ValueError("分钟级正常标定标签必须全部为 0")
    if not np.all(np.diff(starts) == 1) or not np.all(np.diff(ends) == 1):
        raise ValueError("分钟级正常标定窗口不是步长 1 的连续序列")
    timestamp_steps = np.diff(timestamps).astype("timedelta64[s]").astype(np.int64)
    if not np.all(timestamp_steps == 60):
        raise ValueError("分钟级正常标定时间戳未按 60 秒连续递增")
    return {
        "input_shape": list(x_shape),
        "label_counts": {"0": int(labels.size)},
        "chronological": True,
        "contiguous": True,
        "sampling_interval_seconds_observed": 60,
        "source_row_start": int(starts[0]),
        "source_row_end_exclusive": int(ends[-1]),
        "timestamp_start": str(timestamps[0]),
        "timestamp_last_window_start": str(timestamps[-1]),
    }


def load_dataset1_scores(
    source: Path,
    upstream_dir: Path,
    expected_count: int,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    audit = audit_dataset1(source, expected_count)
    scores_path = upstream_dir / "calibration_scores.npy"
    scores = np.load(scores_path, allow_pickle=False).astype(np.float64).reshape(-1)
    if scores.size != expected_count:
        raise ValueError(
            f"上游分钟级正常得分数 {scores.size} != 配置 {expected_count}"
        )
    if not np.all(np.isfinite(scores)) or np.any(scores < 0.0):
        raise ValueError("上游分钟级正常得分无效")
    audit.update({
        "score_generation": "reuse ordered calibration_scores from frozen 00 artifact",
        "upstream_scores_path": str(scores_path),
        "upstream_scores_sha256": sha256_file(scores_path),
    })
    return scores, audit


def generate_dataset2_scores(
    source: Path,
    upstream_dir: Path,
    *,
    start_row: int,
    score_count: int,
    batch_size: int,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    if batch_size < 1:
        raise ValueError("batch_size 必须为正")
    raw = np.load(source, mmap_mode="r", allow_pickle=False)
    if raw.ndim != 2 or raw.shape[1] != 15:
        raise ValueError(f"秒级正常源应为 (T,15)，实际 {raw.shape}")
    window_size = 10
    end_score = start_row + score_count
    required_end_row = end_score + window_size - 1
    if start_row < 0 or required_end_row > raw.shape[0]:
        raise ValueError("秒级连续标定范围越界")

    state_path = upstream_dir / "score_state.npz"
    score_state = load_score_state(state_path)
    bundle = load_joint("dataset2")
    offsets = np.arange(window_size, dtype=np.int64)
    chunks = []
    for local_start in range(0, score_count, batch_size):
        local_end = min(local_start + batch_size, score_count)
        starts = start_row + np.arange(local_start, local_end, dtype=np.int64)
        windows = np.asarray(raw[starts[:, None] + offsets[None, :]], dtype=np.float32)
        if not np.all(np.isfinite(windows)):
            raise ValueError("秒级连续正常窗口中存在 NaN 或 Inf")
        full_residual = compute(
            windows,
            dataset="dataset2",
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual_mean = full_residual.mean(axis=1)
        chunks.append(transform_score(residual_mean, "mahalanobis", score_state))
        done = local_end
        if done == score_count or done % (batch_size * 10) == 0:
            print(f"dataset2 连续正常得分：{done}/{score_count}", flush=True)
    scores = np.concatenate(chunks).astype(np.float64, copy=False)
    if scores.size != score_count:
        raise RuntimeError("秒级分批得分长度错误")
    audit = {
        "source_shape": [int(raw.shape[0]), int(raw.shape[1])],
        "normality_assumption": "source_file_supplied_as_normal_data",
        "chronological": True,
        "contiguous": True,
        "sampling_interval_seconds": 1,
        "sampling_interval_is_assumption": True,
        "sampling_interval_evidence": (
            "project and user contract identifies dataset2 as second-level; "
            "source file has no timestamps"
        ),
        "continuous_start_row": int(start_row),
        "continuous_last_window_start": int(end_score - 1),
        "continuous_required_end_row_exclusive": int(required_end_row),
        "score_count": int(score_count),
        "batch_size": int(batch_size),
        "batch_overlap_context_rows": 9,
        "window_end_index_unique": True,
        "upstream_score_state_path": str(state_path),
        "upstream_score_state_sha256": sha256_file(state_path),
    }
    return scores, audit


def save_trace(path: Path, trace: Iterable[Any], start_index: int) -> None:
    fields = (
        "index", "raw_score", "center", "centered_score",
        "lower_peak", "upper_peak", "lower_threshold", "upper_threshold",
        "point_pred", "update_type",
    )
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for offset, item in enumerate(trace):
            writer.writerow({
                "index": start_index + offset,
                "raw_score": item.raw_score,
                "center": item.center,
                "centered_score": item.centered_score,
                "lower_peak": item.lower_peak,
                "upper_peak": item.upper_peak,
                "lower_threshold": item.lower_threshold,
                "upper_threshold": item.upper_threshold,
                "point_pred": int(item.point_pred),
                "update_type": item.update_type,
            })


def save_plot(path: Path, trace: Sequence[Any], dataset: str) -> Optional[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"
    if not trace:
        return "no_warmup_trace"
    x = np.arange(len(trace))
    centered = np.asarray([item.centered_score for item in trace])
    lower = np.asarray([item.lower_threshold for item in trace])
    upper = np.asarray([item.upper_threshold for item in trace])
    frozen = np.asarray([item.point_pred for item in trace], dtype=bool)
    fig, axis = plt.subplots(figsize=(12, 5.5))
    axis.plot(x, centered, color="#376996", linewidth=0.8, label="centered normal score")
    axis.plot(x, upper, color="#c65146", linewidth=1.2, label="upper ASPOT bound")
    axis.plot(x, lower, color="#c65146", linewidth=1.2, label="lower ASPOT bound")
    if np.any(frozen):
        axis.scatter(x[frozen], centered[frozen], s=12, color="#7d3c98", label="frozen extreme")
    axis.set_title(f"04 ASPOT normal-calibration warm-up ({dataset})")
    axis.set_xlabel("warm-up normal score index")
    axis.set_ylabel("centered Mahalanobis score")
    axis.grid(alpha=0.2)
    axis.legend(loc="best")
    fig.tight_layout()
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)
    return None


def compare_states(left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
    if set(left) != set(right):
        raise ValueError("重载状态字段集合不一致")
    max_abs = 0.0
    for key in left:
        a = np.asarray(left[key])
        b = np.asarray(right[key])
        if a.dtype.kind in "fiu" and b.dtype.kind in "fiu":
            if a.shape != b.shape:
                raise ValueError(f"重载状态字段 {key} 形状不一致")
            difference = float(np.max(np.abs(a.astype(float) - b.astype(float)))) if a.size else 0.0
            max_abs = max(max_abs, difference)
            if not np.array_equal(a, b):
                raise ValueError(f"重载状态字段 {key} 未逐元素一致")
        elif not np.array_equal(a, b):
            raise ValueError(f"重载状态字段 {key} 不一致")
    return {"all_fields_equal": True, "max_absolute_difference": max_abs}


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config_path = args.config.resolve()
    config = load_json(config_path)
    if config.get("schema_version") != 1:
        raise ValueError("不支持的 experiment_config schema_version")
    if config.get("strategy_id") != "04_aspot_two_sided":
        raise ValueError("配置 strategy_id 错误")
    isolation = config.get("data_isolation", {})
    if isolation.get("test_data_allowed_during_prepare") is not False:
        raise ValueError("准备配置必须禁止测试数据")
    if isolation.get("detection_allowed_during_prepare") is not False:
        raise ValueError("准备配置必须禁止异常检测")
    if isolation.get("test_file") is not None or isolation.get("test_labels") is not None:
        raise ValueError("准备配置不得包含测试文件或标签")

    dataset_cfg = config["datasets"][args.dataset]
    strategy_cfg = config["strategy_contract"]
    model_path = resolve_project_path(dataset_cfg["model"])
    source = (
        args.normal_source.resolve()
        if args.normal_source is not None
        else resolve_project_path(dataset_cfg["normal_source"])
    )
    upstream_dir = (
        args.upstream_score_artifact.resolve()
        if args.upstream_score_artifact is not None
        else resolve_project_path(dataset_cfg["upstream_score_artifact"])
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else resolve_project_path(dataset_cfg["artifact_dir"])
    )
    if "测试集数据" in str(source) or "实验结果" in str(source):
        raise ValueError("准备阶段拒绝测试集或实验结果路径")

    model_hash = require_hash(model_path, dataset_cfg["model_sha256"], "模型")
    source_hash = require_hash(source, dataset_cfg["normal_source_sha256"], "正常源")
    upstream_artifact_path = upstream_dir / "threshold_artifact.json"
    upstream_artifact = load_json(upstream_artifact_path)
    if upstream_artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("00 上游得分工件未达到 READY_FOR_TEST")
    if upstream_artifact.get("dataset") != args.dataset:
        raise ValueError("00 上游得分工件数据集映射错误")
    if upstream_artifact.get("score", {}).get("method") != "mahalanobis":
        raise ValueError("04 主实验只接受公共 Mahalanobis 得分")
    if upstream_artifact.get("model", {}).get("checkpoint_sha256", "").lower() != model_hash.lower():
        raise ValueError("00 上游模型哈希与 04 配置不一致")

    expected_count = int(dataset_cfg["calibration_score_count"])
    if args.dataset == "dataset1":
        scores, source_audit = load_dataset1_scores(source, upstream_dir, expected_count)
    else:
        scores, source_audit = generate_dataset2_scores(
            source,
            upstream_dir,
            start_row=int(dataset_cfg["continuous_start_row"]),
            score_count=expected_count,
            batch_size=args.batch_size,
        )

    history_size = int(dataset_cfg["history_size"])
    physical_seconds = history_size * int(dataset_cfg["sampling_interval_seconds"])
    configured_seconds = int(strategy_cfg["history_duration_hours"]) * 3600
    if physical_seconds != configured_seconds:
        raise ValueError("history_size 与统一物理历史时长不一致")

    print(f"拟合 {args.dataset} ASPOT：scores={scores.size}, history={history_size}")
    strategy = ASPOTThreshold(
        history_size=history_size,
        lower_peak_quantile=float(strategy_cfg["lower_peak_quantile"]),
        upper_peak_quantile=float(strategy_cfg["upper_peak_quantile"]),
        risk_probability=float(strategy_cfg["risk_probability"]),
        minimum_peaks=int(strategy_cfg["minimum_peaks"]),
        shape_zero_tolerance=float(strategy_cfg["shape_zero_tolerance"]),
        quantile_method=str(strategy_cfg["quantile_method"]),
    ).fit(scores)
    state = strategy.state_dict()

    output_dir.mkdir(parents=True, exist_ok=True)
    scores_path = output_dir / "calibration_scores.npy"
    state_path = output_dir / "asp_state.npz"
    trace_path = output_dir / "calibration_trace.csv"
    diagnostics_path = output_dir / "mom_diagnostics.json"
    audit_path = output_dir / "normal_calibration_audit.json"
    replay_path = output_dir / "state_replay_check.json"
    plot_path = output_dir / "calibration_threshold_trace.png"
    artifact_path = output_dir / "threshold_artifact.json"

    np.save(scores_path, scores.astype(np.float64))
    save_state_npz(state_path, state)
    save_trace(trace_path, strategy.trace_, history_size)
    restored = ASPOTThreshold.from_state_dict(load_state_npz(state_path))
    replay = compare_states(state, restored.state_dict())
    probe_score = float(np.mean(state["raw_history"]))
    probe_original = ASPOTThreshold.from_state_dict(state).step(probe_score)
    probe_restored = restored.step(probe_score)
    if probe_original != probe_restored:
        raise RuntimeError("重载后合成探针的下一步输出不一致")
    replay.update({
        "synthetic_probe_score": probe_score,
        "next_step_equal": True,
        "probe_is_test_data": False,
    })
    save_json(replay_path, replay)

    trace_counts = {
        key: int(state[key])
        for key in (
            "initial_history_count", "accepted_normal_count",
            "accepted_peak_count", "frozen_extreme_count",
        )
    }
    diagnostics = {
        "accepted_count": int(state["accepted_count"]),
        "peak_count": int(state["peak_count"]),
        "empirical_peak_rate": float(state["peak_count"] / state["accepted_count"]),
        "exceedance_mean": float(state["exceedance_mean"]),
        "exceedance_sample_variance": float(state["exceedance_variance"]),
        "gpd_shape": float(state["gpd_shape"]),
        "gpd_scale": float(state["gpd_scale"]),
        "threshold_increment": float(state["threshold_increment"]),
        "finite_right_endpoint": (
            float(-state["gpd_scale"] / state["gpd_shape"])
            if state["gpd_shape"] < 0.0 else None
        ),
        "lower_peak": float(state["lower_peak"]),
        "upper_peak": float(state["upper_peak"]),
        "lower_threshold": float(state["lower_threshold"]),
        "upper_threshold": float(state["upper_threshold"]),
        "update_counts": trace_counts,
        "formal_fallback": None,
    }
    save_json(diagnostics_path, diagnostics)

    audit = {
        "dataset": args.dataset,
        "time_scale": dataset_cfg["time_scale"],
        "normal_source": str(source),
        "normal_source_sha256": source_hash,
        "normal_only": True,
        "score_count": int(scores.size),
        "sampling_interval_seconds": int(dataset_cfg["sampling_interval_seconds"]),
        "sampling_interval_evidence": dataset_cfg["sampling_interval_evidence"],
        "sampling_interval_is_assumption": bool(dataset_cfg.get("sampling_interval_is_assumption", False)),
        "history_size": history_size,
        "history_duration_seconds": physical_seconds,
        "warmup_score_count": int(scores.size - history_size),
        "model": str(model_path),
        "model_sha256": model_hash,
        "upstream_artifact": str(upstream_artifact_path),
        "upstream_artifact_sha256": sha256_file(upstream_artifact_path),
        "upstream_score_state_sha256": sha256_file(upstream_dir / "score_state.npz"),
        "score_min": float(np.min(scores)),
        "score_max": float(np.max(scores)),
        "score_mean": float(np.mean(scores)),
        "score_std": float(np.std(scores)),
        "source_audit": source_audit,
        "test_data_used": False,
        "test_labels_used": False,
    }
    save_json(audit_path, audit)
    plot_warning = save_plot(plot_path, strategy.trace_, args.dataset)

    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    artifact = {
        "schema_version": 1,
        "strategy_id": "04_aspot_two_sided",
        "status": "READY_FOR_TEST",
        "formal_result_allowed": True,
        "created_at_china": now_cn,
        "dataset": args.dataset,
        "time_scale": dataset_cfg["time_scale"],
        "model": {
            "checkpoint": model_path.name,
            "checkpoint_sha256": model_hash,
            "window_size": int(DATASETS[args.dataset]["window_size"]),
            "input_dim": int(DATASETS[args.dataset]["input_dim"]),
        },
        "calibration": {
            "source_path": str(source),
            "source_sha256": source_hash,
            "score_count": int(scores.size),
            "sampling_interval_seconds": int(dataset_cfg["sampling_interval_seconds"]),
            "sampling_interval_evidence": dataset_cfg["sampling_interval_evidence"],
            "sampling_interval_is_assumption": bool(dataset_cfg.get("sampling_interval_is_assumption", False)),
            "chronological": True,
            "contiguous": True,
            "normal_only": True,
            "scores_file": scores_path.name,
            "scores_sha256": sha256_file(scores_path),
        },
        "score": {
            "method": "ledoit_wolf_mahalanobis",
            "upstream_artifact": str(upstream_artifact_path),
            "upstream_state_sha256": sha256_file(upstream_dir / "score_state.npz"),
            "residual_definition": "mean over time of abs(reconstruction - input)",
            "space": "standardized",
        },
        "threshold": {
            "method": "centered_two_sided_aspot",
            "state_file": state_path.name,
            "state_sha256": sha256_file(state_path),
            "history_size": history_size,
            "history_duration_seconds": physical_seconds,
            "lower_peak_quantile": float(state["lower_peak_quantile"]),
            "upper_peak_quantile": float(state["upper_peak_quantile"]),
            "risk_probability": float(state["risk_probability"]),
            "gpd_fit_method": "method_of_moments",
            "num_tail_exceedances": int(state["peak_count"]),
            "gpd_shape": float(state["gpd_shape"]),
            "gpd_scale": float(state["gpd_scale"]),
            "lower_peak": float(state["lower_peak"]),
            "upper_peak": float(state["upper_peak"]),
            "lower_threshold": float(state["lower_threshold"]),
            "upper_threshold": float(state["upper_threshold"]),
            "formal_fallback": None,
        },
        "future_decision_contract": {
            "rule": "centered_score < lower_threshold or centered_score > upper_threshold",
            "anomaly_update": "freeze_all",
            "peak_update": "tail_and_history",
            "normal_update": "history_only",
            "persistence_for_main_experiment": {"k": 1, "m": 1},
        },
        "files": {
            "calibration_trace": trace_path.name,
            "mom_diagnostics": diagnostics_path.name,
            "normal_calibration_audit": audit_path.name,
            "state_replay_check": replay_path.name,
            "calibration_threshold_trace": None if plot_warning else plot_path.name,
        },
        "paper_deviations": [
            "HCR front-end replaced by the frozen joint-task LSTM",
            "paper score replaced by the common frozen Mahalanobis score",
            "initial state uses a separate normal calibration stream, not the first test fraction",
            "raw-score history and centered-score threshold spaces are explicitly separated",
            "point-adjust is not used",
        ],
        "test_data_used": False,
        "test_labels_used": False,
        "detection_executed": False,
        "metrics_computed": False,
    }
    if plot_warning:
        artifact["plot_warning"] = plot_warning
    save_json(artifact_path, artifact)
    print(f"状态：READY_FOR_TEST；工件：{artifact_path}")
    print(
        f"最终边界：lower={state['lower_threshold']:.8f}, "
        f"upper={state['upper_threshold']:.8f}"
    )
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
