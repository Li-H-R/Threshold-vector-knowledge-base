# -*- coding: utf-8 -*-
"""加载冻结的 04 ASPOT 初始状态，对一个测试文件执行动态双侧检测。"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
COMMON_DIR = SCRIPT_DIR.parent / "00阈值"
for candidate in (PROJECT_ROOT, COMMON_DIR, SCRIPT_DIR):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from artifact_utils import (
    load_feature_array,
    load_optional_npz_array,
    load_score_state,
    save_json,
    sha256_file,
    transform_score,
)
from demo.anomaly_detection_demo import align_labels, evaluate, event_ranges, load_labels
from demo.threshold_strategies import causal_k_of_m
from main import DATASETS, compute, load_joint
from strategy_04_aspot import ASPOTThreshold, STRATEGY_ID, load_state_npz


def load_artifact(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        artifact = json.load(handle)
    if artifact.get("schema_version") != 1:
        raise ValueError("不支持的 04 工件 schema_version")
    if artifact.get("strategy_id") != STRATEGY_ID:
        raise ValueError("该工件不是 04_aspot_two_sided")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("04 工件状态不是 READY_FOR_TEST")
    if artifact.get("formal_result_allowed") is not True:
        raise ValueError("04 工件不是正式标定工件")
    if artifact.get("test_data_used") is not False:
        raise ValueError("04 标定工件在冻结前使用了测试数据")
    if artifact.get("detection_executed") is not False:
        raise ValueError("04 标定工件在冻结前已经执行检测")
    return artifact


def load_frozen_aspot(artifact_path: Path, artifact: Dict[str, Any]) -> ASPOTThreshold:
    state_path = artifact_path.parent / artifact["threshold"]["state_file"]
    if not state_path.is_file():
        raise FileNotFoundError(f"找不到 ASPOT 状态：{state_path}")
    if sha256_file(state_path) != artifact["threshold"]["state_sha256"]:
        raise ValueError("ASPOT 状态 SHA-256 与工件不一致")
    strategy = ASPOTThreshold.from_state_dict(load_state_npz(state_path))
    checks = {
        "lower_peak": strategy.lower_peak_,
        "upper_peak": strategy.upper_peak_,
        "lower_threshold": strategy.lower_threshold_,
        "upper_threshold": strategy.upper_threshold_,
        "gpd_shape": strategy.gamma_,
        "gpd_scale": strategy.sigma_,
    }
    for key, actual in checks.items():
        expected = float(artifact["threshold"][key])
        if actual is None or not np.isclose(actual, expected, rtol=0.0, atol=1.0e-10):
            raise ValueError(f"ASPOT state 与工件中的 {key} 不一致")
    return strategy


def load_frozen_score_state(artifact: Dict[str, Any]) -> Dict[str, np.ndarray]:
    upstream_artifact = Path(artifact["score"]["upstream_artifact"]).resolve()
    state_path = upstream_artifact.parent / "score_state.npz"
    if not state_path.is_file():
        raise FileNotFoundError(f"找不到公共 Mahalanobis 状态：{state_path}")
    if sha256_file(state_path) != artifact["score"]["upstream_state_sha256"]:
        raise ValueError("公共 Mahalanobis 状态 SHA-256 与工件不一致")
    return load_score_state(state_path)


def validate_test_standardizer(
    test_path: Path,
    available_keys: Sequence[str],
    test_raw: np.ndarray,
    model_mean: np.ndarray,
    model_std: np.ndarray,
) -> Dict[str, Any]:
    audit: Dict[str, Any] = {
        "mean_std_present": False,
        "mean_matches_checkpoint": None,
        "std_matches_checkpoint": None,
        "mean_max_abs_difference_from_checkpoint": None,
        "std_max_abs_difference_from_checkpoint": None,
        "x_std_present": False,
        "x_std_matches_stored_standardizer": None,
        "max_abs_x_std_internal_difference": None,
        "model_input_array": "x",
        "model_input_uses_checkpoint_standardizer": True,
        "stored_x_std_used_for_model": False,
    }
    stored_mean = None
    stored_std = None
    if "mean" in available_keys and "std" in available_keys:
        stored_mean = load_optional_npz_array(test_path, "mean").reshape(-1)
        stored_std = load_optional_npz_array(test_path, "std").reshape(-1)
        if stored_mean.shape != model_mean.shape or stored_std.shape != model_std.shape:
            raise ValueError("测试文件 mean/std 维数与 checkpoint 不一致")
        audit.update({
            "mean_std_present": True,
            "mean_matches_checkpoint": bool(np.allclose(stored_mean, model_mean, rtol=1e-6, atol=1e-6)),
            "std_matches_checkpoint": bool(np.allclose(stored_std, model_std, rtol=1e-6, atol=1e-6)),
            "mean_max_abs_difference_from_checkpoint": float(np.max(np.abs(stored_mean - model_mean))),
            "std_max_abs_difference_from_checkpoint": float(np.max(np.abs(stored_std - model_std))),
        })
    if "x_std" in available_keys:
        if stored_mean is None or stored_std is None:
            raise ValueError("测试文件包含 x_std，但缺少配套 mean/std")
        stored = load_optional_npz_array(test_path, "x_std").astype(np.float32)
        expected = (
            (test_raw - stored_mean[None, None, :])
            / (stored_std[None, None, :] + 1e-8)
        ).astype(np.float32)
        if stored.shape != expected.shape:
            raise ValueError("测试文件 x_std 与 x 形状不一致")
        max_diff = float(np.max(np.abs(stored - expected)))
        match = bool(np.allclose(stored, expected, rtol=1e-5, atol=1e-5))
        audit.update({
            "x_std_present": True,
            "x_std_matches_stored_standardizer": match,
            "max_abs_x_std_internal_difference": max_diff,
        })
        if not match:
            raise ValueError("测试文件 x_std 与内置 mean/std 不一致")
    return audit


def save_plot(
    path: Path,
    centered: np.ndarray,
    lower_threshold: np.ndarray,
    upper_threshold: np.ndarray,
    point_pred: np.ndarray,
    labels: Optional[np.ndarray],
    dataset: str,
) -> Optional[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"
    x = np.arange(centered.size)
    figure, axis = plt.subplots(figsize=(13, 5.5))
    axis.plot(x, centered, color="#2f6690", linewidth=0.9, label="centered Mahalanobis score")
    axis.plot(x, upper_threshold, color="#cf4b3e", linewidth=1.3, label="upper ASPOT bound")
    axis.plot(x, lower_threshold, color="#cf4b3e", linewidth=1.3, label="lower ASPOT bound")
    if np.any(point_pred):
        axis.scatter(x[point_pred], centered[point_pred], s=9, color="#5b2c6f", label="detected")
    if labels is not None:
        for start, end in event_ranges(labels):
            axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.10)
    axis.set_xlabel("stored test-window index")
    axis.set_ylabel("centered score")
    axis.set_title(f"04 two-sided ASPOT detection - {dataset}")
    axis.grid(alpha=0.2)
    axis.legend(loc="best")
    figure.tight_layout()
    figure.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(figure)
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="运行 04 双侧中心化 ASPOT 异常检测")
    parser.add_argument("--artifact", required=True, type=Path)
    parser.add_argument("--test", required=True, type=Path)
    parser.add_argument("--labels", type=Path)
    parser.add_argument("--array-key", default="x")
    parser.add_argument("--label-key", default="y_true")
    parser.add_argument("--type-key", default="y_type")
    parser.add_argument("--input-space", choices=("raw", "standardized"), default="raw")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--k", type=int, default=1)
    parser.add_argument("--m", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument(
        "--update-mode",
        choices=("causal_dynamic", "frozen_independent"),
        default="causal_dynamic",
        help=(
            "causal_dynamic=论文式因果在线更新；"
            "frozen_independent=每个窗口独立使用冻结中心和边界，不更新测试状态"
        ),
    )
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    if args.batch_size < 1:
        raise ValueError("--batch-size 必须大于 0")
    if args.k != 1 or args.m != 1:
        raise ValueError("04 主实验固定 K=1, M=1；持续性规则应另做消融")

    artifact_path = args.artifact.resolve()
    artifact = load_artifact(artifact_path)
    state_path = artifact_path.parent / artifact["threshold"]["state_file"]
    initial_state_hash = sha256_file(state_path)
    strategy = load_frozen_aspot(artifact_path, artifact)
    score_state = load_frozen_score_state(artifact)
    initial_counts = strategy.update_counts_.copy()

    dataset = artifact["dataset"]
    bundle = load_joint(dataset)
    _, mean, std, cfg = bundle
    checkpoint_path = Path(DATASETS[dataset]["ckpt"]).resolve()
    if sha256_file(checkpoint_path) != artifact["model"]["checkpoint_sha256"]:
        raise ValueError("当前模型 checkpoint 与 04 工件不一致")

    test_path = args.test.resolve()
    test, test_metadata = load_feature_array(test_path, args.array_key)
    if test.ndim != 3 or test.shape[1] != int(DATASETS[dataset]["window_size"]):
        raise ValueError("测试文件必须是已切好的 (N,10,D) 窗口")
    if test.shape[-1] != int(cfg["input_dim"]):
        raise ValueError("测试特征维与模型不一致")
    available_keys = test_metadata.get("available_keys") or []
    standardizer_audit = validate_test_standardizer(
        test_path, available_keys, test, mean, std
    )
    if args.input_space == "standardized":
        test_for_model = (test * std[None, None, :] + mean[None, None, :]).astype(np.float32)
    else:
        test_for_model = test

    residual_chunks = []
    for start in range(0, test_for_model.shape[0], args.batch_size):
        end = min(start + args.batch_size, test_for_model.shape[0])
        residual = compute(
            test_for_model[start:end],
            dataset=dataset,
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual_chunks.append(residual.mean(axis=1))
    residual_mean = np.concatenate(residual_chunks, axis=0)
    scores = transform_score(residual_mean, "mahalanobis", score_state)

    if args.update_mode == "causal_dynamic":
        outputs = strategy.process(scores)
        center = np.asarray([item.center for item in outputs], dtype=np.float64)
        centered = np.asarray([item.centered_score for item in outputs], dtype=np.float64)
        lower_peak = np.asarray([item.lower_peak for item in outputs], dtype=np.float64)
        upper_peak = np.asarray([item.upper_peak for item in outputs], dtype=np.float64)
        lower_threshold = np.asarray([item.lower_threshold for item in outputs], dtype=np.float64)
        upper_threshold = np.asarray([item.upper_threshold for item in outputs], dtype=np.float64)
        point_pred = np.asarray([item.point_pred for item in outputs], dtype=bool)
        update_type = np.asarray([item.update_type for item in outputs])
    else:
        frozen_state = strategy.state_dict()
        frozen_center = float(np.mean(frozen_state["raw_history"]))
        center = np.full(scores.size, frozen_center, dtype=np.float64)
        centered = scores - center
        lower_peak = np.full(scores.size, float(frozen_state["lower_peak"]), dtype=np.float64)
        upper_peak = np.full(scores.size, float(frozen_state["upper_peak"]), dtype=np.float64)
        lower_threshold = np.full(
            scores.size, float(frozen_state["lower_threshold"]), dtype=np.float64
        )
        upper_threshold = np.full(
            scores.size, float(frozen_state["upper_threshold"]), dtype=np.float64
        )
        point_pred = (centered < lower_threshold) | (centered > upper_threshold)
        update_type = np.full(scores.size, "frozen_independent")
    alarm = causal_k_of_m(point_pred, k=args.k, m=args.m)

    labels = None
    if args.labels is not None:
        labels = align_labels(load_labels(args.labels), test, scores.size)
    elif args.label_key in available_keys:
        labels = align_labels(load_optional_npz_array(test_path, args.label_key), test, scores.size)
    anomaly_types = None
    if args.type_key in available_keys:
        anomaly_types = load_optional_npz_array(test_path, args.type_key).reshape(-1).astype(str)
        if anomaly_types.size != scores.size:
            raise ValueError("异常类型长度与得分长度不一致")

    output_dir = args.output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖：{output_dir}")
    output_dir.mkdir(parents=True, exist_ok=False)
    with (output_dir / "detections.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "index", "label", "anomaly_type", "raw_score", "center",
            "centered_score", "lower_peak", "upper_peak", "lower_threshold",
            "upper_threshold", "point_pred", "alarm", "update_type",
        ])
        for index in range(scores.size):
            writer.writerow([
                index,
                "" if labels is None else int(labels[index]),
                "" if anomaly_types is None else anomaly_types[index],
                float(scores[index]), float(center[index]), float(centered[index]),
                float(lower_peak[index]), float(upper_peak[index]),
                float(lower_threshold[index]), float(upper_threshold[index]),
                int(point_pred[index]), int(alarm[index]), update_type[index],
            ])

    type_metrics = None
    if labels is not None and anomaly_types is not None:
        type_metrics = {}
        for type_name in np.unique(anomaly_types):
            mask = anomaly_types == type_name
            count = int(mask.sum())
            positive_count = int(labels[mask].sum())
            item: Dict[str, Any] = {
                "count": count,
                "positive_count": positive_count,
                "point_predicted_positive": int(point_pred[mask].sum()),
            }
            if positive_count == count:
                item["point_recall"] = float(point_pred[mask].mean())
            elif positive_count == 0:
                item["point_false_positive_rate"] = float(point_pred[mask].mean())
            type_metrics[str(type_name)] = item

    decision_margin = np.maximum(
        centered - upper_threshold,
        lower_threshold - centered,
    )
    runtime_counts = Counter(update_type.tolist())
    final_state = strategy.state_dict()
    final_state_hash = sha256_file(state_path)
    if final_state_hash != initial_state_hash:
        raise RuntimeError("检测过程修改了冻结 asp_state.npz")

    if args.update_mode == "causal_dynamic":
        sequence_note = (
            "测试文件按随机抽样正常块后接固定异常块排列，无真实时间戳或事件ID；"
            "ASPOT 按存储顺序因果运行，但动态更新不代表真实生产时间流。"
        )
        method_variant = STRATEGY_ID
    else:
        sequence_note = (
            "每个窗口独立使用正常标定阶段冻结的中心和双侧边界；"
            "测试顺序不参与阈值更新，不要求连续窗口。"
        )
        method_variant = "04_aspot_frozen_independent"
    summary: Dict[str, Any] = {
        "strategy_id": method_variant,
        "source_strategy_id": STRATEGY_ID,
        "update_mode": args.update_mode,
        "artifact": str(artifact_path),
        "artifact_status": artifact["status"],
        "frozen_state_sha256_before": initial_state_hash,
        "frozen_state_sha256_after": final_state_hash,
        "frozen_state_modified": False,
        "dataset": dataset,
        "time_scale": artifact["time_scale"],
        "test_file": str(test_path),
        "test_sha256": sha256_file(test_path),
        "test_file_structure": test_metadata,
        "test_input_space": args.input_space,
        "test_input_shape": list(test.shape),
        "test_standardizer_audit": standardizer_audit,
        "num_windows": int(scores.size),
        "score_method": "ledoit_wolf_mahalanobis",
        "score_state_refit_on_test": False,
        "aspot_initial_state_refit_on_test": False,
        "online_causal_update_enabled": args.update_mode == "causal_dynamic",
        "test_state_updates_enabled": args.update_mode == "causal_dynamic",
        "single_window_is_sufficient_for_anomaly": True,
        "initial_bounds": {
            "lower_peak": float(artifact["threshold"]["lower_peak"]),
            "upper_peak": float(artifact["threshold"]["upper_peak"]),
            "lower_threshold": float(artifact["threshold"]["lower_threshold"]),
            "upper_threshold": float(artifact["threshold"]["upper_threshold"]),
        },
        "runtime_final_bounds": {
            "lower_peak": float(final_state["lower_peak"]),
            "upper_peak": float(final_state["upper_peak"]),
            "lower_threshold": float(final_state["lower_threshold"]),
            "upper_threshold": float(final_state["upper_threshold"]),
        },
        "persistence": {"k": args.k, "m": args.m},
        "num_point_detections": int(point_pred.sum()),
        "num_alarms": int(alarm.sum()),
        "runtime_update_counts": {key: int(value) for key, value in runtime_counts.items()},
        "calibration_update_counts": {key: int(value) for key, value in initial_counts.items()},
        "type_metrics": type_metrics,
        "sequence_audit": {
            "stored_order_used": args.update_mode == "causal_dynamic",
            "true_chronological_metadata_available": False,
            "event_metrics_formally_used": False,
            "note": sequence_note,
        },
        "point_metrics": evaluate(labels, point_pred, decision_margin) if labels is not None else None,
        "alarm_metrics": evaluate(labels, alarm, decision_margin) if labels is not None else None,
        "formal_point_result_allowed": True,
        "formal_event_result_allowed": False,
    }
    plot_path = output_dir / "aspot_detection.png"
    warning = save_plot(
        plot_path, centered, lower_threshold, upper_threshold,
        point_pred, labels, dataset,
    )
    if warning:
        summary["plot_warning"] = warning
    else:
        summary["plot"] = str(plot_path)
    save_json(output_dir / "summary.json", summary)
    print(
        f"{dataset}: windows={scores.size}, detected={int(point_pred.sum())}, "
        f"updates={dict(runtime_counts)}"
    )
    print(f"结果：{output_dir / 'summary.json'}")
    return summary


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
