# 04 双侧中心化 ASPOT 阈值

04 已完成策略实现、合成单元测试、分钟级/秒级纯正常标定、状态冻结，以及用户后续授权的双测试集异常检测。检测阶段没有重新拟合模型、Mahalanobis 状态或 ASPOT 初始状态。

## 方法定位

本实现迁移 04 论文的 Adaptive Streaming Peak Over Thresholding：

```text
公共 Mahalanobis 得分
→ 已接纳历史均值中心化
→ 2% / 98% 双侧峰值边界
→ 双尾正超限量
→ GPD Method of Moments
→ 双侧动态报警边界
```

联合任务 LSTM、标准化绝对重构残差和公共 Mahalanobis 得分均保持不变。实现使用独立纯正常标定流初始化，不使用论文中的“测试流前 10%”。

## 冻结配置

| 参数 | 值 |
|---|---|
| 风险概率 | `1e-4` |
| 下峰值分位 | `0.02` |
| 上峰值分位 | `0.98` |
| GPD 参数估计 | Method of Moments |
| 共同历史时长 | 24 小时 |
| 分钟级历史窗 | 1440 点 |
| 秒级历史窗 | 86400 点 |
| 最低峰值数 | 30 |
| 主实验持续性 | `K=1, M=1` |
| 正式回退 | 无 |

秒级源文件没有时间戳；`1 秒`采样间隔来自项目与用户对 dataset2 的“秒级”合同，已在工件中显式标记为假设。

## 正式准备结果

| 数据集 | 连续正常得分 | 预热点数 | 峰值数 | shape | scale | 下边界 | 上边界 | 状态 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| dataset1（分钟级） | 1960 | 520 | 69 | 0.26725242 | 0.39409177 | -6.99297100 | 8.75999273 | `READY_FOR_TEST` |
| dataset2（秒级） | 117600 | 31200 | 3883 | 0.41158464 | 0.64719384 | -17.38399201 | 19.86230471 | `READY_FOR_TEST` |

正常预热期间两套数据的 `frozen_extreme_count` 均为 0，没有触发正式回退。状态保存/加载逐字段完全一致，最大绝对差为 0。

## 文件说明

| 文件 | 作用 |
|---|---|
| `strategy_04_aspot.py` | 双侧中心化 ASPOT、MOM 公式、状态保存/恢复 |
| `prepare_04_aspot.py` | 只读取纯正常数据并生成冻结工件 |
| `detect_04_aspot.py` | 从冻结状态副本开始，对单个测试文件因果检测 |
| `evaluate_all_test_sets.py` | 批量运行分钟级/秒级各 5 个 seed 并汇总 |
| `experiment_config.json` | 模型、数据、时间尺度和阈值参数合同 |
| `tests/test_strategy_04_aspot.py` | 公式、更新规则、因果性和序列化测试 |
| `artifacts/formal_dataset1` | 分钟级正式准备工件 |
| `artifacts/formal_dataset2` | 秒级正式准备工件 |

每套正式目录包含：

```text
threshold_artifact.json
asp_state.npz
calibration_scores.npy
calibration_trace.csv
mom_diagnostics.json
normal_calibration_audit.json
state_replay_check.json
calibration_threshold_trace.png
```

## 验证命令

```powershell
python -m py_compile 阈值策略\04阈值\strategy_04_aspot.py 阈值策略\04阈值\prepare_04_aspot.py
python -m unittest discover -s 阈值策略\04阈值\tests -v
```

预期为 10 项测试全部通过。

## 双测试集结果

### 论文式动态 ASPOT

主实验固定 `K=1, M=1`，每个时间尺度运行 5 个正常抽样 seed：

| 时间尺度 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |
|---|---:|---:|---:|---:|---:|---:|
| 分钟级 | 0.1955 ± 0.4370 | 0.0054 ± 0.0121 | 0.0105 ± 0.0235 | 0.4269 ± 0.0453 | 0.9996 ± 0.0006 | 0.38 ± 0.56 |
| 秒级 | 0.9929 ± 0.0059 | 0.1426 ± 0.0008 | 0.2494 ± 0.0013 | 0.6744 ± 0.0036 | 0.9990 ± 0.0008 | 1.02 ± 0.84 |

分钟级在 4/5 个 seed 中几乎没有报警；seed42 的 Recall 为 0.0270。曲线表明大量异常窗口先被当作可接纳峰值，使动态边界迅速扩张。秒级结果较稳定，但 Recall 仍只有约 0.1426。

测试文件是随机抽样正常块后接固定异常块，没有真实时间戳或事件 ID。ASPOT 按存储顺序严格因果运行，但在线更新不能解释为真实生产时间流；因此只把点级指标作为正式结果，不正式使用事件召回或检测延迟。

完整汇总见 `04实验结果/evaluation_report.md`，每个 seed 目录包含 `detections.csv`、`summary.json` 和 `aspot_detection.png`。

### 冻结边界独立窗口变体

根据后续实验要求，增加 `frozen_independent` 模式：

```text
每个测试窗口独立计算 Mahalanobis 得分
→ 减去正常标定阶段冻结的历史中心
→ 与冻结的 ASPOT 下/上报警边界比较
→ 任一边界越限即判异常
→ 不更新测试滑窗、峰值池、GPD 参数或报警边界
```

该模式不要求测试窗口连续，窗口顺序不影响判定，也不使用 K-of-M 持续超限规则；`K=1, M=1` 表示一个窗口越限即为异常。它保留论文阈值的正常标定结果，但不再包含论文的在线自适应更新，因此应标记为 `04_aspot_frozen_independent`，不能写成完整 ASPOT 严格复现。

| 时间尺度 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |
|---|---:|---:|---:|---:|---:|---:|
| 分钟级 | 0.9993 ± 0.0010 | 0.5747 ± 0.0000 | 0.7297 ± 0.0003 | 0.9615 ± 0.0004 | 0.9996 ± 0.0006 | 0.38 ± 0.56 |
| 秒级 | 0.9953 ± 0.0038 | 0.2167 ± 0.0000 | 0.3559 ± 0.0002 | 0.8030 ± 0.0029 | 0.9990 ± 0.0008 | 1.02 ± 0.84 |

相较动态版本：

- 分钟级 Recall 从 `0.0054` 提升到 `0.5747`，F1 从 `0.0105` 提升到 `0.7297`；
- 秒级 Recall 从 `0.1426` 提升到 `0.2167`，F1 从 `0.2494` 提升到 `0.3559`；
- 误报率不变，因为正常窗口在两种模式中基本没有推动到异常边界之外；
- 所有 seed 的测试状态更新数均为 0，最终上下边界与初始冻结边界完全相同。

完整汇总见 `04独立窗口实验结果/evaluation_report.md`。

运行命令：

```powershell
python 阈值策略\04阈值\evaluate_all_test_sets.py `
  --test-root 测试集数据 `
  --output-root 阈值策略\04阈值\04独立窗口实验结果 `
  --update-mode frozen_independent
```

## 当前状态

```text
TESTED_BOTH_DATASETS
RESULT_FROZEN
```

动态版本和独立窗口版本的 20 次检测均验证冻结 `asp_state.npz` 的运行前后 SHA-256 完全一致。独立窗口版本不修改内存状态；动态版本则为每个 seed 单独创建状态副本，文件间不共享在线状态。
