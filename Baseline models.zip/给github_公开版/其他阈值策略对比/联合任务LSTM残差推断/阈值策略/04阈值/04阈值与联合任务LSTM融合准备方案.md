# 04 阈值与联合任务 LSTM 融合：异常检测前准备方案

## 0. 范围与停止点

本方案只设计异常检测之前的准备工作。当前阶段不读取测试集、不生成测试得分、不输出异常标签，也不计算 Precision、Recall、F1、PR-AUC、误报率、检测延迟或事件级指标。

当前允许使用：

- 已训练完成的联合任务 LSTM checkpoint；
- 分钟级和秒级的纯正常阈值标定数据；
- 00 方案冻结的收缩 Mahalanobis 得分状态及正常标定得分；
- 04 论文全文；
- 固定随机种子生成的合成单元测试数组。

当前禁止读取或消费：

```text
测试集数据/**
阈值策略/*阈值/*实验结果/**
任何 test、test_labels、detections.csv 或测试 summary.json
```

本阶段最多推进到：

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1 / CALIBRATED_DATASET2
→ READY_FOR_TEST
→ 停止
```

`READY_FOR_TEST` 只表示 ASPOT 的初始滑窗、峰值边界、GPD-MOM 参数和初始动态报警边界已使用纯正常数据拟合并冻结，不表示已执行异常检测。

---

## 1. 参考依据与复现定位

### 1.1 统一实验约束

本方案遵循 `阈值策略/统一阈值实验工作流.md` 和 demo 的统一接口：

- 所有阈值方案共用同一个训练完成的联合任务 LSTM；
- 共用标准化空间绝对重构残差、窗口时间均值和收缩 Mahalanobis 主得分；
- 04 只替换阈值模块，不重新训练或修改 LSTM；
- 分钟级与秒级分别使用各自模型、正常标定源、公共得分状态和 04 工件；
- 测试集不能参与风险系数、滑窗长度、峰值分位、初始化方式或更新规则的选择；
- 正式配置在测试前冻结，后续不得因为测试结果不理想而改参数；
- 主阈值对比固定 `K=1, M=1`，不使用依赖真实异常区间的 point-adjust；
- 分钟级与秒级最终必须分别检测、分别评价、分别报告。

### 1.2 04 论文方法卡

| 项目 | 内容 |
|---|---|
| 标题 | *Hierarchical Context Representation and Self-Adaptive Thresholding for Multivariate Anomaly Detection* |
| 作者 | Chunming Lin, Bowen Du, Leilei Sun, Linchao Li |
| 期刊 | IEEE Transactions on Knowledge and Data Engineering, 36(7), 2024, 3139-3150 |
| DOI | `10.1109/TKDE.2024.3360640` |
| 本地全文 | `阈值策略/04阈值/04.pdf` |
| 阈值方法 | Adaptive Streaming Peak Over Thresholding，简称 ASPOT / AdaAD |
| 关键位置 | 第 III-G 节、公式 (12)-(14)、Algorithm 2 |
| 输入 | 一维异常得分流 |
| 初始峰值边界 | 上 98% 分位、下 2% 分位 |
| 尾部分布 | 双尾正超限量的广义 Pareto 分布（GPD） |
| 参数估计 | Method of Moments（MOM） |
| 输出 | 随历史正常/峰值数据更新的上下动态报警边界 |

论文阈值链路为：

```text
异常得分流
→ 滑窗均值中心化
→ 上 98% / 下 2% 峰值边界
→ 汇总双尾超限量
→ MOM 估计 GPD 参数
→ 风险系数 q 生成上下动态报警边界
→ 异常冻结，峰值更新 GPD，普通正常点只更新滑窗
```

### 1.3 复现类型

本项目应标记为 **阈值模块迁移实现**，不能标记为完整 HCR-AdaAD 严格复现：

1. 论文前端是 CNN、图网络和 Transformer 组成的 HCR，本项目固定使用联合任务 LSTM-AE；
2. 论文使用自身重构误差，本项目主实验固定使用收缩 Mahalanobis 得分；
3. 论文从流数据开头取约 10% 初始化，本项目为避免测试泄漏，改用独立纯正常标定序列；
4. 论文 Algorithm 2 对原始得分、中心化得分和滑窗符号存在歧义，本项目必须冻结一致解释；
5. 论文未给出可跨数据集直接复用的风险系数 `q` 和滑窗长度；
6. 论文评价使用 point-adjust，本项目主对比不使用这种标签依赖型后处理。

迁移保留的核心是：

> 对同一公共异常得分做因果滑窗中心化，以双侧峰值超限量拟合 GPD-MOM，并按“异常冻结、峰值更新、正常滑窗更新”的规则产生自适应上下阈值。

---

## 2. 固定模型、残差与数据映射

### 2.1 分钟级与秒级固定对应关系

| 项目 | 分钟级 | 秒级 |
|---|---|---|
| 数据集标识 | `dataset1` | `dataset2` |
| 时间尺度 | 1 分钟级 | 秒级 |
| checkpoint | `models/dataset1_joint_seed10.pth` | `models/dataset2_joint_seed10.pth` |
| checkpoint SHA-256 | `adc97f5c48eb4b8e15dab7fa7ac09afe54cc01f88dab8986c5f7340daa96a4fa` | `ec92a82289f8e0e1f497570eedc9c008e19b86d70a24982d4a9d83fb19718d61` |
| 特征维数 | 8 | 15 |
| 模型窗口长度 | 10 | 10 |
| 正常标定源 | `正常数据/阈值标定集.npz` | `正常数据/new_raw_data.npy` 的可审计连续窗口 |
| 现有普通标定集 | `(1960,10,8)`、连续、`y=0` | `(20000,10,15)`、均匀稀疏抽样、`y=0` |
| 普通标定集 SHA-256 | `99376a1f9cb781b0f51be4fe61f4cca64c880e27b5cf742cc942ccd8ac7cd42d` | `a95fd8ce46860252f2ea01bd33f26fc39f467be43316cd654cd3d0b6e62cfabc` |
| 秒级原始正常源 SHA-256 | 不适用 | `fb1e0d0c1dfcd61d94bced2f3fc5ea30fb78f1e1ab27579f0ad502ecd62c96ca` |
| 公共 Mahalanobis 状态 | `00阈值/artifacts/formal_dataset1/score_state.npz` | `00阈值/artifacts/formal_dataset2/score_state.npz` |
| 04 工件目录 | `04阈值/artifacts/formal_dataset1` | `04阈值/artifacts/formal_dataset2` |

固定映射：

```text
分钟级纯正常连续序列
→ dataset1 模型 / dataset1 公共 Mahalanobis 状态
→ dataset1 ASPOT 初始状态
→ formal_dataset1

秒级纯正常连续序列
→ dataset2 模型 / dataset2 公共 Mahalanobis 状态
→ dataset2 ASPOT 初始状态
→ formal_dataset2
```

禁止合并两种时间尺度的标定得分、交叉使用工件、为 04 更换残差或得分、重新训练模型，或根据未来测试表现为两个数据集分别调参。

### 2.2 固定残差与公共得分

对窗口 `X_i∈R^(10×D)`，联合任务 LSTM 在 `eval()` 和 `torch.no_grad()` 下产生：

\[
R_i=\frac{1}{10}\sum_{t=1}^{10}|\hat X_{i,t}-X_{i,t}|\in\mathbb{R}^{D}
\]

残差位于 checkpoint 对应的标准化空间。公共得分保持为：

\[
s_i=\sqrt{(R_i-\mu)^T\Omega(R_i-\mu)}
\]

其中 `μ` 和 `Ω` 由 00 正式工件冻结。04 不重新拟合 Mahalanobis 状态，也不使用 `latent` 或 `mode_w`。

---

## 3. 动态方法的数据连续性门禁

### 3.1 分钟级可以直接预热

`正常数据/阈值标定集.npz` 的 1960 个窗口按时间连续排列，`source_row_start` 从 3261 连续递增到 5220，时间从 `2024-01-03T06:21:00` 延续到 `2024-01-04T15:00:00`，窗口步长为 1，标签全为 0。因此可直接复用对应 00 `calibration_scores.npy` 的原始顺序。

### 3.2 秒级现有 20000 窗口不能冒充连续历史

`正常数据/new_raw_阈值标定集.npz` 的抽样方式是：

```text
uniform_over_all_valid_window_starts
```

它从 1,236,264 个合法窗口中均匀抽取 20,000 个，相邻起点通常相差约 61 或 62 个源行。该文件适合估计静态分布，但不等价于逐秒连续得分流。直接用于 ASPOT 会让滑窗均值、中心化差值和更新频率失去秒级含义。

秒级 04 正式准备必须从同一纯正常源 `正常数据/new_raw_data.npy` 构造连续得分序列。此过程只处理正常数据，不读取测试集。

建议保存：

```text
正常数据/new_raw_04连续标定索引.npz
阈值策略/04阈值/artifacts/formal_dataset2/calibration_scores.npy
```

索引工件至少记录源 SHA-256、连续片段起止行、采样间隔证据、窗口末端索引、缺口数、模型和公共得分状态哈希。连续得分应分批生成；相邻批次保留前 9 个源时刻作为上下文，再按窗口末端索引去重。

若无法证明秒级源的采样间隔、连续性或正常属性，`formal_dataset2` 只能标记 `CALIBRATION_BLOCKED`。

---

## 4. ASPOT 数学契约

### 4.1 中心化得分

维护长度为 `w` 的已接纳原始得分滑窗 `W_t`。处理时刻 `t` 前先计算：

\[
m_t=\operatorname{mean}(W_t),\qquad z_t=s_t-m_t
\]

当前点的均值和阈值只能来自此前状态，不能先放入 `s_t` 再判定。

### 4.2 双侧峰值与超限量

对纯正常初始化中心化得分集合 `Z`：

\[
u^+=Q_{0.98}(Z),\qquad u^-=Q_{0.02}(Z)
\]

双尾正超限量：

\[
Y=\{z-u^+\mid z>u^+\}\cup\{u^--z\mid z<u^-\}
\]

记 `N=|Z|`、`N_u=|Y|`、`p_u=N_u/N`。`Y` 中所有值必须严格大于 0。

### 4.3 GPD 的 MOM 参数

令 `μ_y=mean(Y)`，`S²=var(Y, ddof=1)`，则论文公式为：

\[
\hat\sigma=\frac{\mu_y}{2}\left(1+\frac{\mu_y^2}{S^2}\right),\qquad
\hat\gamma=\frac{1}{2}\left(1-\frac{\mu_y^2}{S^2}\right)
\]

必须检查 `Y` 有限且为正、`S²>0`、`σ>0`、参数有限、GPD 支持域有效，并达到 `minimum_peaks`。

### 4.4 风险概率与动态报警边界

论文未给出可直接跨数据集复用的 `q`。首版建议在测试前冻结：

```text
risk_probability = 1e-4
upper_peak_quantile = 0.98
lower_peak_quantile = 0.02
```

令 `a=qN/N_u`，必须满足 `0<a<1`。当 `|γ|` 不接近 0 时：

\[
\Delta=\frac{\hat\sigma}{\hat\gamma}(a^{-\hat\gamma}-1)
\]

当 `γ→0` 时使用连续极限：

\[
\Delta=\hat\sigma\log\left(\frac{N_u}{qN}\right)
\]

上下报警边界：

\[
\tau^+=u^++\Delta,\qquad \tau^-=u^--\Delta
\]

必须满足：

```text
tau_lower < lower_peak < upper_peak < tau_upper
tau_lower、tau_upper、Delta 均为有限数
若 gamma < 0，Delta 不得到达或越过有限右端点 -sigma/gamma
```

### 4.5 未来在线更新规则（当前不运行）

```text
若 z_t < tau_lower 或 z_t > tau_upper：
    point_pred = 1
    冻结原始滑窗、均值、尾部池、MOM 参数和全部阈值

否则若 z_t < lower_peak 或 z_t > upper_peak：
    point_pred = 0
    接纳为正常极值
    更新 N、N_u、尾部池、MOM 参数、报警边界和原始滑窗

否则：
    point_pred = 0
    接纳为普通正常点
    只更新 N、原始滑窗、均值和下一时刻峰值边界
```

阈值更新必须严格因果：改变未来得分，不得改变此前任一时刻的均值、阈值或判定。

### 4.6 论文符号歧义的冻结解释

论文 Algorithm 2 一方面计算中心化得分 `E'_i=E_i-M_i`，另一方面又对 `E_i` 或看似保存原始值的 `W*` 设置峰值边界，随后用中心化得分与这些边界比较。为避免原始量纲与中心化量纲混用，本项目冻结：

```text
W_raw：保存被接纳的原始公共得分，只用于移动均值
Z_history：保存对应中心化得分，用于 2%/98% 峰值边界
Y_tail：保存中心化得分相对其当时峰值边界的正超限量
所有判定都在 centered_score 空间完成
```

这是基于论文目标的合理迁移，必须在 README 和最终实验报告中披露。

---

## 5. 与现有单阈值接口的衔接

04 是双侧、中心化、动态阈值，不能无损压缩成现有的 `score > threshold`。应扩展输出：

```python
{
    "raw_score": ...,          # 公共 Mahalanobis 得分
    "center": ...,             # 判定前历史均值
    "centered_score": ...,
    "lower_peak": ...,
    "upper_peak": ...,
    "lower_threshold": ...,
    "upper_threshold": ...,
    "point_pred": ...,
    "update_type": ...         # frozen_anomaly / accepted_peak / accepted_normal
}
```

未来统一 CSV 可以保留 `score=raw_score`、`threshold=upper_threshold` 作为兼容列，但 04 的 `point_pred` 必须按双侧规则计算，评价程序不能重新用 `score > threshold` 覆盖它。绘图必须使用 `centered_score` 与上下边界。

如研究最终只允许单侧方法进入主表，应另建 `04_aspot_upper_only` 消融，不能覆盖完整的 `04_aspot_two_sided`，也不能在看到测试结果后再选择版本。

---

## 6. 参数冻结与时间尺度

论文固定部分：

```text
upper_peak_quantile = 0.98
lower_peak_quantile = 0.02
gpd_fit_method = method_of_moments
anomaly_update = freeze_all
peak_update = update_tail_and_window
normal_update = update_window_only
```

迁移时需在测试前冻结：

```text
risk_probability = 1e-4（建议首版）
history_duration 或 history_size
minimum_peaks = 30（建议首版）
shape_zero_tolerance = 1e-8
quantile_method = linear
秒级连续标定片段范围
formal_fallback = none
```

滑窗应按物理时长对齐，而不是两个数据集使用同一个窗口数。建议候选合同为 24 小时：

```text
dataset1 history_size = 1440
dataset2 history_size = 24 × 3600 / Δt_seconds
```

秒级 `Δt_seconds` 必须由时间戳或数据说明确认，不能只按文件名猜测。分钟级只有 1960 个正常得分；若 1440 点历史窗导致剩余预热段峰值不足，不得静默缩短窗口，应标记 `CALIBRATION_UNSTABLE`，再基于正常数据跨度和统一物理时长重新冻结配置。

参数选择只能依据论文、正常标定样本量、连续性、数值稳定性和物理时间可比性，不能依据测试指标或测试阈值曲线。

---

## 7. 推荐程序结构与职责

```text
04阈值/
├── 04.pdf
├── 04阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_04_aspot.py
├── prepare_04_aspot.py
├── experiment_config.json
├── tests/
│   └── test_strategy_04_aspot.py
└── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
```

当前阶段不创建或不运行 `detect_04_aspot.py`。

策略类建议：

```python
class ASPOTThreshold:
    strategy_id = "04_aspot_two_sided"

    def fit(self, normal_calibration_scores):
        """只用按时间排序的纯正常得分建立初始状态。"""

    def step(self, score):
        """未来单步因果判定；准备阶段不对真实测试数据调用。"""

    def state_dict(self): ...

    @classmethod
    def from_state_dict(cls, state): ...
```

应拆出可单测的 `mom_gpd_parameters()`、`asp_threshold_increment()` 和 `two_sided_peak_exceedances()`。

`prepare_04_aspot.py` 流程：

```text
读取冻结配置
→ 校验 checkpoint、正常源和公共 score_state 哈希
→ 校验正常属性、时间顺序、连续性、窗口长度和特征维数
→ dataset1 复用连续公共正常得分
→ dataset2 从纯正常源分批生成连续得分，并用冻结 score_state 转换
→ 按 history_size 初始化原始得分滑窗
→ 计算中心化历史、2%/98% 峰值和双尾超限量
→ MOM 估计 GPD 参数并生成上下报警边界
→ 用剩余纯正常得分因果预热
→ 保存、重新加载并执行状态重放检查
→ 状态写为 READY_FOR_TEST
→ 停止
```

命令行只允许 `--dataset`、`--config`、`--normal-source`、`--upstream-score-artifact` 和 `--output-dir`。禁止提供 `--test`、`--test-labels`、`--detect`、`--evaluate` 或 `--point-adjust`。

---

## 8. 冻结配置建议

```json
{
  "schema_version": 1,
  "strategy_id": "04_aspot_two_sided",
  "strategy_name": "Two-sided centered ASPOT on common Mahalanobis scores",
  "reproduction_type": "threshold_module_migrated",
  "fixed_contract": {
    "model_seed": 10,
    "window_size": 10,
    "residual": "mean over time of abs(reconstruction - input) in standardized space",
    "score_method": "ledoit_wolf_mahalanobis",
    "persistence": {"k": 1, "m": 1}
  },
  "strategy_contract": {
    "interface_type": "causal_dynamic_two_sided_threshold",
    "center_method": "mean_of_accepted_raw_score_history",
    "upper_peak_quantile": 0.98,
    "lower_peak_quantile": 0.02,
    "quantile_method": "linear",
    "gpd_fit_method": "method_of_moments",
    "risk_probability": 0.0001,
    "history_duration_hours": 24,
    "minimum_peaks": 30,
    "shape_zero_tolerance": 1e-8,
    "anomaly_update": "freeze_all",
    "peak_update": "tail_and_history",
    "normal_update": "history_only",
    "formal_fallback": null
  },
  "data_isolation": {
    "initialization_source": "normal_calibration_only",
    "paper_first_test_fraction_used": false,
    "test_file": null,
    "test_labels": null,
    "test_data_allowed_during_prepare": false,
    "detection_allowed_during_prepare": false
  }
}
```

`datasets.dataset1` 和 `datasets.dataset2` 还应分别冻结模型、正常源、公共得分工件、采样间隔、连续标定范围、输出目录及全部 SHA-256。

---

## 9. 正式准备输出与失败规则

每个数据集分别生成：

```text
artifacts/formal_datasetX/
├── threshold_artifact.json
├── asp_state.npz
├── calibration_scores.npy
├── calibration_trace.csv
├── mom_diagnostics.json
├── normal_calibration_audit.json
├── state_replay_check.json
└── calibration_threshold_trace.png
```

所有文件只能包含纯正常标定信息。`threshold_artifact.json` 至少记录：策略 ID、状态、数据集和时间尺度、模型/正常源/公共得分哈希、采样间隔、连续性、历史窗长度、风险概率、MOM 参数、上下峰值、上下报警边界、未来更新规则，并明确：

```json
{
  "test_data_used": false,
  "test_labels_used": false,
  "detection_executed": false,
  "metrics_computed": false
}
```

以下任一情况均应停止并标记 `CALIBRATION_BLOCKED` 或 `CALIBRATION_UNSTABLE`：

- 正常得分为空、含 NaN/Inf、逆序或存在未披露缺口；
- 滑窗长度不小于可用正常得分数；
- 中心化得分方差接近 0；
- 双尾峰值少于 `minimum_peaks`；
- MOM 参数无效或 `sigma<=0`；
- `risk_probability>=peak_rate`；
- 上下边界顺序错误或越过 GPD 支持域；
- 保存/加载、分批生成或状态重放不一致；
- 任一冻结输入哈希不匹配。

不得静默回退到固定分位数、03 静态 POT 或只保留上阈值。替代方法必须使用新策略 ID。

---

## 10. 不使用真实测试集的单元测试门禁

所有测试只使用人工数组或固定随机种子的合成得分流：

1. 空数组、NaN、Inf、错误维数明确报错；
2. 正式输入必须带可验证的单调时间索引；
3. 验证 MOM 公式、`gamma→0` 极限和有限端点；
4. 验证上下尾超限量均严格为正；
5. 验证 `tau_lower < u_lower < u_upper < tau_upper`；
6. 合成异常点不改变下一时刻任何状态；
7. 峰值点同时增加 `N` 与 `N_u`；
8. 普通正常点增加 `N`，但不增加 `N_u`；
9. 当前点阈值不包含当前点信息；
10. 修改未来得分不影响历史阈值和判定；
11. 逐点、分块和一次性合成流结果一致；
12. 保存/加载后下一步输出完全一致；
13. dataset1 和 dataset2 工件不能交叉加载；
14. 模型、正常源或公共工件哈希变化时拒绝正式输出；
15. 带时间缺口的秒级合成索引不能标记正式；
16. 准备脚本不存在测试文件或标签参数；
17. 合成工件只能标记 `SELF_CHECK_ONLY_NOT_FOR_RESULTS`；
18. 准备工件必须写入 `detection_executed=false`。

---

## 11. 正常标定稳定性审计

分钟级和秒级分别记录：

- 正常得分数、时间跨度、采样间隔和缺口数；
- 原始及中心化得分的均值、标准差和分位数；
- `history_size` 对应物理时长；
- 上下尾峰值数及占比；
- `gamma、sigma、Delta`；
- 预热前后上下峰值和报警边界；
- 三种更新类型数量；
- 阈值范围和最大单步变化；
- 保存/加载最大绝对差异；
- 分批生成与状态重放结果。

可按完整连续时间块做稳定性审计，但不能根据未来测试表现挑选某一块。若使用 bootstrap，应做时间块 bootstrap，而不是打乱单点，以保留局部相关性。

论文指出 ASPOT 更适合渐进正常分布漂移；突变并持续在新水平的序列可能产生较高误报。正式工件应披露：

```text
assumption = gradual normal distribution drift
known_risk = abrupt persistent level shift may be treated as collective anomaly
```

---

## 12. 推荐实施顺序

1. 冻结论文方法卡、双侧中心化解释和更新规则，状态到 `FORMULA_VERIFIED`；
2. 核对两套模型、正常源和公共得分哈希，确认秒级采样间隔与连续片段，状态到 `INTERFACE_DEFINED`；
3. 实现策略、准备脚本、冻结配置和测试，不创建检测结果目录，状态到 `IMPLEMENTED`；
4. 运行合成公式、因果性、保存/加载、分块等价和泄漏门禁测试，状态到 `UNIT_TESTED`；
5. 分别生成分钟级和秒级纯正常工件，通过全部门禁后到 `READY_FOR_TEST`；
6. 停止，等待用户另行授权异常检测。

未来准备命令骨架：

```powershell
python 阈值策略\04阈值\prepare_04_aspot.py `
  --dataset dataset1 `
  --config 阈值策略\04阈值\experiment_config.json `
  --normal-source 正常数据\阈值标定集.npz `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset1 `
  --output-dir 阈值策略\04阈值\artifacts\formal_dataset1
```

```powershell
python 阈值策略\04阈值\prepare_04_aspot.py `
  --dataset dataset2 `
  --config 阈值策略\04阈值\experiment_config.json `
  --normal-source 正常数据\new_raw_data.npy `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset2 `
  --output-dir 阈值策略\04阈值\artifacts\formal_dataset2
```

本文件创建阶段不运行以上命令。

---

## 13. 未来双测试集契约（当前不执行）

```text
分钟级测试数据
→ dataset1 模型
→ dataset1 公共得分状态
→ formal_dataset1 ASPOT 初始状态副本
→ 分钟级结果

秒级测试数据
→ dataset2 模型
→ dataset2 公共得分状态
→ formal_dataset2 ASPOT 初始状态副本
→ 秒级结果
```

检测时必须深拷贝冻结状态，运行时在线更新不能覆盖 `artifacts/formal_datasetX/asp_state.npz`。未来两套结果分别输出并分别计算指标，不能拼接。主结果保持 `K=1, M=1`。

---

## 14. 当前验收清单

- [x] 已阅读 04 全文并核对 ASPOT 公式与 Algorithm 2；
- [x] 已确认双侧 98%/2% 峰值边界和 GPD-MOM；
- [x] 已确认异常冻结、峰值更新尾部、普通正常点只更新滑窗；
- [x] 已确认只迁移阈值模块，不更换联合任务 LSTM；
- [x] 已固定公共残差和 Mahalanobis 得分；
- [x] 已固定分钟级与秒级模型/工件映射；
- [x] 已处理论文原始/中心化得分的符号歧义；
- [x] 已处理双侧动态阈值与单阈值接口的差异；
- [x] 已确认分钟级标定序列连续；
- [x] 已识别秒级现有 20000 窗口为稀疏抽样；
- [x] 已设计从同一纯正常源构造秒级连续得分的方案；
- [x] 已设计无测试集的单元测试、因果性与稳定性门禁；
- [x] 当前未读取测试样本或测试标签；
- [x] 当前未执行异常检测；
- [x] 已将秒级采样间隔冻结为 1 秒，并明确标记为项目/用户合同假设而非源文件时间戳证据；
- [x] 已冻结共同 24 小时历史窗：分钟级 1440 点、秒级 86400 点；
- [x] 已实现 04 策略、准备脚本和冻结配置；
- [x] 已通过 10 项合成单元测试；
- [x] 已从纯正常 `new_raw_data.npy` 生成 117600 个秒级连续得分；
- [x] 已拟合并重放验证两套正式 ASPOT 状态；
- [x] 两套正式工件均已达到 `READY_FOR_TEST`；
- [x] 用户后续授权后，已完成分钟级和秒级各 5 个 seed 的异常检测。

当前状态：

```text
FORMULA_VERIFIED
INTERFACE_DEFINED
IMPLEMENTED
UNIT_TESTED
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
TESTED_BOTH_DATASETS
RESULT_FROZEN
```

正式准备结果：

| 数据集 | 正常连续得分 | 历史窗 | 峰值数 | GPD shape | GPD scale | 下报警边界 | 上报警边界 | 状态 |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| dataset1（分钟级） | 1960 | 1440 | 69 | 0.26725242 | 0.39409177 | -6.99297100 | 8.75999273 | `READY_FOR_TEST` |
| dataset2（秒级） | 117600 | 86400 | 3883 | 0.41158464 | 0.64719384 | -17.38399201 | 19.86230471 | `READY_FOR_TEST` |

两套工件均记录 `test_data_used=false`、`detection_executed=false`、`metrics_computed=false`。
这些字段描述的是阈值工件冻结时的数据隔离状态；后续检测结果另存于 `04实验结果/`，未覆盖正式标定工件。

---

## 15. 最终原则

04 的正确融合不是重新训练 HCR-AdaAD，也不是把动态方法简化成另一个静态 POT，而是：

```text
固定联合任务 LSTM
→ 固定标准化绝对重构残差
→ 固定公共收缩 Mahalanobis 得分
→ 分钟级与秒级分别准备纯正常连续得分流
→ 滑窗因果中心化
→ 2%/98% 双尾峰值
→ MOM 估计 GPD 参数
→ 冻结上下 ASPOT 初始阈值及完整在线状态
→ 保存、重载、重放并审计两套工件
→ 停止，暂不异常检测
```

只要测试样本、测试标签和测试性能没有参与以上任何一步，并且秒级动态标定序列的连续性得到证明，就满足“只做异常检测前准备、只更换阈值策略、同时面向分钟级和秒级数据”的要求。
