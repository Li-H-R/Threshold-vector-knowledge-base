# -*- coding: utf-8 -*-

import sys
import unittest
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from prepare_02_conditional_kde import build_parser
from strategy_02_conditional_kde import ConditionalKDECriticalFunction


class ConditionalKDETests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(20261104)
        y0 = rng.uniform(0.0, 2.0, size=320)
        y1 = rng.normal(0.0, 0.8, size=320)
        r0 = 0.20 + 0.32 * y0 + np.abs(rng.normal(0.0, 0.08, size=320))
        r1 = 0.35 + 0.06 * y1 + np.abs(rng.normal(0.0, 0.10, size=320))
        self.y = np.column_stack((y0, y1))
        self.r = np.column_stack((r0, r1))

    def make_strategy(self):
        return ConditionalKDECriticalFunction(
            grid_size=48,
            minimum_samples=80,
            minimum_ess=0.0,
            backend="numpy",
        )

    def test_fit_produces_finite_positive_curves(self):
        strategy = self.make_strategy().fit(self.y, self.r)
        self.assertEqual(strategy.y_grid_.shape, (2, 48))
        self.assertEqual(strategy.q_grid_.shape, (2, 48))
        self.assertTrue(np.all(np.isfinite(strategy.q_grid_)))
        self.assertTrue(np.all(strategy.q_grid_ > 0.0))
        self.assertTrue(np.all(strategy.max_root_error_ < 1e-10))

    def test_threshold_tracks_condition_level(self):
        strategy = self.make_strategy().fit(self.y, self.r)
        low_high = strategy.thresholds(np.asarray([[0.1, 0.0], [1.9, 0.0]]))
        self.assertGreater(low_high[1, 0], low_high[0, 0])

    def test_outside_support_flattens_to_boundaries(self):
        strategy = self.make_strategy().fit(self.y, self.r)
        values = np.asarray([[-100.0, -100.0], [100.0, 100.0]])
        thresholds = strategy.thresholds(values)
        np.testing.assert_allclose(thresholds[0], strategy.q_grid_[:, 0])
        np.testing.assert_allclose(thresholds[1], strategy.q_grid_[:, -1])

    def test_state_roundtrip_is_exact(self):
        strategy = self.make_strategy().fit(self.y, self.r)
        restored = ConditionalKDECriticalFunction.from_state_dict(
            strategy.state_dict()
        )
        probe = self.y[::17]
        np.testing.assert_allclose(
            strategy.thresholds(probe), restored.thresholds(probe), rtol=0.0, atol=0.0
        )

    def test_fit_is_deterministic(self):
        first = self.make_strategy().fit(self.y, self.r)
        second = self.make_strategy().fit(self.y.copy(), self.r.copy())
        np.testing.assert_allclose(first.q_grid_, second.q_grid_, rtol=0.0, atol=0.0)

    def test_features_are_fit_independently(self):
        baseline = self.make_strategy().fit(self.y, self.r)
        changed_r = self.r.copy()
        changed_r[:, 1] *= 3.0
        changed = self.make_strategy().fit(self.y, changed_r)
        np.testing.assert_allclose(
            baseline.q_grid_[0], changed.q_grid_[0], rtol=0.0, atol=0.0
        )
        self.assertFalse(np.allclose(baseline.q_grid_[1], changed.q_grid_[1]))

    def test_invalid_inputs_are_rejected(self):
        cases = [
            (self.y[:50], self.r[:50]),
            (self.y, self.r[:, :1]),
            (self.y, np.where(np.indices(self.r.shape)[0] == 0, -1.0, self.r)),
            (np.where(np.indices(self.y.shape)[0] == 0, np.nan, self.y), self.r),
            (np.ones_like(self.y), self.r),
        ]
        for y, r in cases:
            with self.subTest(shape=(y.shape, r.shape)):
                with self.assertRaises(ValueError):
                    self.make_strategy().fit(y, r)

    def test_prepare_parser_has_no_detection_inputs(self):
        parser = build_parser()
        options = {
            option
            for action in parser._actions
            for option in action.option_strings
        }
        self.assertNotIn("--test", options)
        self.assertNotIn("--labels", options)
        self.assertNotIn("--metrics", options)
        self.assertNotIn("--k", options)
        self.assertNotIn("--m", options)


if __name__ == "__main__":
    unittest.main()
