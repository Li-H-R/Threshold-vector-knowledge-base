# -*- coding: utf-8 -*-
"""重新执行全部 02b 测试推理，并与冻结检测输出逐元素比较。"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict

import numpy as np


os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from main import load_joint  # noqa: E402
from detect_02b_support_aware_kde import (  # noqa: E402
    CONFIG_PATH,
    audit_and_load_threshold,
    configure_deterministic_inference,
    detect_unlabeled,
    infer_unlabeled_pairs,
    load_json,
    load_test_data,
    resolve_project_path,
    save_json,
)


def max_abs_difference(left: np.ndarray, right: np.ndarray) -> float:
    left = np.asarray(left)
    right = np.asarray(right)
    if left.shape != right.shape:
        return float("inf")
    return float(np.max(np.abs(left.astype(np.float64) - right.astype(np.float64))))


def verify_seed(
    dataset: str,
    seed: int,
    contract: Dict[str, Any],
    strategy: Any,
    bundle: Any,
    result_root: Path,
    batch_size: int,
) -> Dict[str, Any]:
    _, model_mean, model_std, _ = bundle
    test = load_test_data(
        dataset, seed, contract, model_mean, model_std
    )
    reconstruction_mean, residual_mean = infer_unlabeled_pairs(
        test["x"], dataset, bundle, batch_size
    )
    prediction = detect_unlabeled(
        reconstruction_mean, residual_mean, strategy
    )
    saved_path = result_root / dataset / f"seed_{seed}" / "detection_arrays.npz"
    with np.load(saved_path, allow_pickle=False) as archive:
        saved = {key: np.asarray(archive[key]) for key in archive.files}

    float32_fields = {
        "reconstruction_mean": prediction["reconstruction_mean"],
        "residual_mean": prediction["residual_mean"],
        "thresholds": prediction["thresholds"],
        "ratios": prediction["ratios"],
    }
    float32_exact = {
        key: bool(np.array_equal(saved[key], value.astype(np.float32)))
        for key, value in float32_fields.items()
    }
    float32_max_abs_difference = {
        key: max_abs_difference(saved[key], value.astype(np.float32))
        for key, value in float32_fields.items()
    }
    score_exact = bool(np.array_equal(saved["score"], prediction["scores"]))
    score_max_abs_difference = max_abs_difference(
        saved["score"], prediction["scores"]
    )
    discrete_exact = {
        "feature_flags": bool(
            np.array_equal(saved["feature_flags"], prediction["feature_flags"])
        ),
        "y_pred": bool(np.array_equal(saved["y_pred"], prediction["y_pred"])),
        "top_feature_index": bool(
            np.array_equal(
                saved["top_feature_index"], prediction["top_feature_index"]
            )
        ),
        "triggered_feature_count": bool(
            np.array_equal(
                saved["triggered_feature_count"],
                prediction["triggered_feature_count"],
            )
        ),
    }
    passed = bool(
        all(float32_exact.values())
        and score_exact
        and all(discrete_exact.values())
    )
    return {
        "dataset": dataset,
        "seed": seed,
        "passed": passed,
        "float32_fields_exact": float32_exact,
        "float32_max_abs_difference": float32_max_abs_difference,
        "score_exact": score_exact,
        "score_max_abs_difference": score_max_abs_difference,
        "discrete_fields_exact": discrete_exact,
        "prediction_mismatch_count": int(
            np.sum(saved["y_pred"] != prediction["y_pred"])
        ),
    }


def main() -> Dict[str, Any]:
    configure_deterministic_inference()
    config = load_json(CONFIG_PATH)
    result_root = resolve_project_path(config["output_root"])
    if not result_root.is_dir():
        raise FileNotFoundError("正式检测结果目录不存在")
    rows = []
    for dataset in ("dataset1", "dataset2"):
        contract = config["datasets"][dataset]
        strategy, _, _ = audit_and_load_threshold(dataset, contract)
        bundle = load_joint(dataset)
        for seed in [int(value) for value in config["seeds"]]:
            print(f"复算 {dataset} seed={seed}……", flush=True)
            rows.append(
                verify_seed(
                    dataset,
                    seed,
                    contract,
                    strategy,
                    bundle,
                    result_root,
                    int(config["batch_size"]),
                )
            )
    verified = bool(all(row["passed"] for row in rows))
    audit = {
        "schema_version": 1,
        "verification_status": "VERIFIED" if verified else "MISMATCH",
        "created_at_china": datetime.now(
            timezone(timedelta(hours=8))
        ).isoformat(),
        "method": "full deterministic re-inference of all ten test sets",
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
        "required_result": "exact equality after the original saved dtypes",
        "all_ten_runs_passed": verified,
        "runs": rows,
    }
    save_json(result_root / "reproducibility_audit.json", audit)
    print(f"复现性状态：{audit['verification_status']}", flush=True)
    if not verified:
        raise RuntimeError("检测复算与正式输出不一致")
    return audit


if __name__ == "__main__":
    main()
