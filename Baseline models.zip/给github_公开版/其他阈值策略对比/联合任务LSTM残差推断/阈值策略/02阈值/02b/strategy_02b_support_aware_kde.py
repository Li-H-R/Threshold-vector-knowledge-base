# -*- coding: utf-8 -*-
"""02b：在低局部支持度区域平滑回退到逐特征全局正常 KDE 阈值。"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
from scipy.optimize import brentq
from scipy.stats import gaussian_kde


SCHEMA_VERSION = 1
STRATEGY_ID = "02b_support_aware_conditional_kde"


def fit_global_positive_kde_quantile(
    residual: np.ndarray,
    confidence_level: float = 0.999,
) -> Dict[str, float]:
    values = np.asarray(residual, dtype=np.float64).reshape(-1)
    if values.size < 80:
        raise ValueError("全局回退 KDE 至少需要 80 个正常残差")
    if not np.all(np.isfinite(values)) or np.any(values < 0.0):
        raise ValueError("全局回退残差必须有限且非负")
    if float(np.std(values)) <= 1e-12:
        raise ValueError("全局回退残差方差过小")
    if not 0.5 < confidence_level < 1.0:
        raise ValueError("confidence_level 必须位于 (0.5,1)")

    kde = gaussian_kde(values, bw_method="scott")
    negative_mass = float(kde.integrate_box_1d(-np.inf, 0.0))
    positive_mass = 1.0 - negative_mass
    if positive_mass <= 1e-12:
        raise ValueError("全局 KDE 在非负支持域上的概率质量过小")
    target_raw_cdf = negative_mass + confidence_level * positive_mass

    def raw_cdf(x: float) -> float:
        return float(kde.integrate_box_1d(-np.inf, float(x)))

    upper = max(
        float(np.max(values) + 10.0 * np.std(values)),
        float(np.quantile(values, 0.999) * 1.5 + 1e-9),
        1.0,
    )
    expansions = 0
    while raw_cdf(upper) < target_raw_cdf and expansions < 20:
        upper *= 2.0
        expansions += 1
    if raw_cdf(upper) < target_raw_cdf:
        raise RuntimeError("全局回退 KDE 无法包围 0.999 分位点")
    threshold = float(
        brentq(
            lambda x: raw_cdf(x) - target_raw_cdf,
            0.0,
            upper,
            xtol=1e-12,
            rtol=1e-14,
            maxiter=200,
        )
    )
    positive_cdf = (raw_cdf(threshold) - negative_mass) / positive_mass
    return {
        "threshold": threshold,
        "confidence_level": float(confidence_level),
        "negative_mass": negative_mass,
        "positive_cdf_error": abs(positive_cdf - confidence_level),
        "scott_factor": float(kde.factor),
        "effective_bandwidth": float(np.sqrt(kde.covariance[0, 0])),
        "root_upper": upper,
        "root_upper_expansions": float(expansions),
    }


def smoothstep_support_weight(
    ess: np.ndarray,
    ess_low: float,
    ess_high: float,
) -> np.ndarray:
    if not 0.0 < ess_low < ess_high:
        raise ValueError("必须满足 0 < ess_low < ess_high")
    values = np.asarray(ess, dtype=np.float64)
    if not np.all(np.isfinite(values)) or np.any(values < 0.0):
        raise ValueError("ESS 必须有限且非负")
    u = np.clip((values - ess_low) / (ess_high - ess_low), 0.0, 1.0)
    return u * u * (3.0 - 2.0 * u)


class SupportAwareConditionalKDE:
    """条件阈值与逐特征全局阈值的支持度感知平滑融合。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        confidence_level: float = 0.999,
        ess_low: float = 50.0,
        ess_high: float = 100.0,
        maximum_median_relative_ci_width: float = 0.75,
    ) -> None:
        if not 0.5 < confidence_level < 1.0:
            raise ValueError("confidence_level 必须位于 (0.5,1)")
        if not 0.0 < ess_low < ess_high:
            raise ValueError("必须满足 0 < ess_low < ess_high")
        if maximum_median_relative_ci_width <= 0.0:
            raise ValueError("maximum_median_relative_ci_width 必须大于 0")
        self.confidence_level = float(confidence_level)
        self.ess_low = float(ess_low)
        self.ess_high = float(ess_high)
        self.maximum_median_relative_ci_width = float(
            maximum_median_relative_ci_width
        )

        self.y_grid_: Optional[np.ndarray] = None
        self.conditional_q_grid_: Optional[np.ndarray] = None
        self.ess_grid_: Optional[np.ndarray] = None
        self.support_weight_grid_: Optional[np.ndarray] = None
        self.stable_q_grid_: Optional[np.ndarray] = None
        self.global_threshold_: Optional[np.ndarray] = None
        self.global_negative_mass_: Optional[np.ndarray] = None
        self.global_root_error_: Optional[np.ndarray] = None
        self.global_scott_factor_: Optional[np.ndarray] = None
        self.global_effective_bandwidth_: Optional[np.ndarray] = None
        self.full_fallback_fraction_: Optional[np.ndarray] = None
        self.full_conditional_fraction_: Optional[np.ndarray] = None
        self.mean_support_weight_: Optional[np.ndarray] = None
        self.bootstrap_median_relative_ci_width_: Optional[np.ndarray] = None
        self.feature_pass_: Optional[np.ndarray] = None
        self.num_samples_: Optional[int] = None
        self.num_features_: Optional[int] = None
        self.grid_size_: Optional[int] = None

    @property
    def is_fitted(self) -> bool:
        return self.stable_q_grid_ is not None and self.y_grid_ is not None

    def fit(
        self,
        upstream_state: Dict[str, Any],
        reconstruction_mean: np.ndarray,
        residual_mean: np.ndarray,
    ) -> "SupportAwareConditionalKDE":
        y = np.asarray(reconstruction_mean, dtype=np.float64)
        r = np.asarray(residual_mean, dtype=np.float64)
        if y.ndim != 2 or r.shape != y.shape:
            raise ValueError("reconstruction_mean/residual_mean 必须为同形状 (N,D)")
        if not np.all(np.isfinite(y)) or not np.all(np.isfinite(r)):
            raise ValueError("正常标定配对含 NaN/Inf")
        if np.any(r < 0.0):
            raise ValueError("绝对残差不能为负")

        y_grid = np.asarray(upstream_state["y_grid"], dtype=np.float64)
        conditional_q = np.asarray(upstream_state["q_grid"], dtype=np.float64)
        ess_grid = np.asarray(upstream_state["ess_grid"], dtype=np.float64)
        if y_grid.shape != conditional_q.shape or y_grid.shape != ess_grid.shape:
            raise ValueError("上游 y/q/ESS 网格形状不一致")
        n_features, grid_size = y_grid.shape
        if y.shape[1] != n_features:
            raise ValueError("正常标定特征数与上游临界函数不一致")
        if not np.all(np.diff(y_grid, axis=1) > 0.0):
            raise ValueError("上游 y_grid 必须逐特征严格递增")

        support_weight = smoothstep_support_weight(
            ess_grid, self.ess_low, self.ess_high
        )
        global_threshold = np.empty(n_features, dtype=np.float64)
        global_negative_mass = np.empty(n_features, dtype=np.float64)
        global_root_error = np.empty(n_features, dtype=np.float64)
        global_scott_factor = np.empty(n_features, dtype=np.float64)
        global_effective_bandwidth = np.empty(n_features, dtype=np.float64)
        full_fallback_fraction = np.empty(n_features, dtype=np.float64)
        full_conditional_fraction = np.empty(n_features, dtype=np.float64)
        mean_support_weight = np.empty(n_features, dtype=np.float64)

        for feature_index in range(n_features):
            global_fit = fit_global_positive_kde_quantile(
                r[:, feature_index], self.confidence_level
            )
            global_threshold[feature_index] = global_fit["threshold"]
            global_negative_mass[feature_index] = global_fit["negative_mass"]
            global_root_error[feature_index] = global_fit["positive_cdf_error"]
            global_scott_factor[feature_index] = global_fit["scott_factor"]
            global_effective_bandwidth[feature_index] = global_fit[
                "effective_bandwidth"
            ]
            calibration_weights = np.interp(
                y[:, feature_index],
                y_grid[feature_index],
                support_weight[feature_index],
                left=support_weight[feature_index, 0],
                right=support_weight[feature_index, -1],
            )
            full_fallback_fraction[feature_index] = float(
                np.mean(calibration_weights <= 1e-12)
            )
            full_conditional_fraction[feature_index] = float(
                np.mean(calibration_weights >= 1.0 - 1e-12)
            )
            mean_support_weight[feature_index] = float(np.mean(calibration_weights))

        stable_q = (
            support_weight * conditional_q
            + (1.0 - support_weight) * global_threshold[:, None]
        )
        if not np.all(np.isfinite(stable_q)) or np.any(stable_q <= 0.0):
            raise ValueError("稳定化临界函数出现非有限值或非正值")
        base_pass = (
            np.isfinite(global_threshold)
            & (global_threshold > 0.0)
            & (global_root_error <= 1e-10)
        )

        self.y_grid_ = y_grid
        self.conditional_q_grid_ = conditional_q
        self.ess_grid_ = ess_grid
        self.support_weight_grid_ = support_weight
        self.stable_q_grid_ = stable_q
        self.global_threshold_ = global_threshold
        self.global_negative_mass_ = global_negative_mass
        self.global_root_error_ = global_root_error
        self.global_scott_factor_ = global_scott_factor
        self.global_effective_bandwidth_ = global_effective_bandwidth
        self.full_fallback_fraction_ = full_fallback_fraction
        self.full_conditional_fraction_ = full_conditional_fraction
        self.mean_support_weight_ = mean_support_weight
        self.bootstrap_median_relative_ci_width_ = np.full(
            n_features, np.nan, dtype=np.float64
        )
        self.feature_pass_ = base_pass
        self.num_samples_ = int(y.shape[0])
        self.num_features_ = int(n_features)
        self.grid_size_ = int(grid_size)
        return self

    def apply_bootstrap_gate(self, median_relative_ci_width: np.ndarray) -> None:
        if not self.is_fitted:
            raise RuntimeError("策略尚未拟合")
        values = np.asarray(median_relative_ci_width, dtype=np.float64).reshape(-1)
        if values.shape != (self.num_features_,):
            raise ValueError("bootstrap 相对 CI 宽度维数不正确")
        if not np.all(np.isfinite(values)) or np.any(values < 0.0):
            raise ValueError("bootstrap 相对 CI 宽度必须有限且非负")
        self.bootstrap_median_relative_ci_width_ = values
        assert self.feature_pass_ is not None
        self.feature_pass_ = self.feature_pass_ & (
            values <= self.maximum_median_relative_ci_width
        )

    def thresholds(self, reconstruction_mean: np.ndarray) -> np.ndarray:
        if not self.is_fitted:
            raise RuntimeError("策略尚未拟合")
        values = np.asarray(reconstruction_mean, dtype=np.float64)
        if values.ndim != 2 or values.shape[1] != self.num_features_:
            raise ValueError(
                f"reconstruction_mean 应为 (N,{self.num_features_})，实际 {values.shape}"
            )
        if not np.all(np.isfinite(values)):
            raise ValueError("reconstruction_mean 含 NaN/Inf")
        output = np.empty_like(values)
        assert self.y_grid_ is not None and self.stable_q_grid_ is not None
        for feature_index in range(int(self.num_features_)):
            output[:, feature_index] = np.interp(
                values[:, feature_index],
                self.y_grid_[feature_index],
                self.stable_q_grid_[feature_index],
                left=self.stable_q_grid_[feature_index, 0],
                right=self.stable_q_grid_[feature_index, -1],
            )
        return output

    def state_dict(self) -> Dict[str, Any]:
        if not self.is_fitted:
            raise RuntimeError("策略尚未拟合")
        return {
            "schema_version": np.asarray([SCHEMA_VERSION], dtype=np.int64),
            "strategy_id": np.asarray(STRATEGY_ID),
            "confidence_level": np.asarray([self.confidence_level], dtype=np.float64),
            "ess_low": np.asarray([self.ess_low], dtype=np.float64),
            "ess_high": np.asarray([self.ess_high], dtype=np.float64),
            "maximum_median_relative_ci_width": np.asarray(
                [self.maximum_median_relative_ci_width], dtype=np.float64
            ),
            "num_samples": np.asarray([self.num_samples_], dtype=np.int64),
            "num_features": np.asarray([self.num_features_], dtype=np.int64),
            "grid_size": np.asarray([self.grid_size_], dtype=np.int64),
            "y_grid": np.asarray(self.y_grid_, dtype=np.float64),
            "conditional_q_grid": np.asarray(
                self.conditional_q_grid_, dtype=np.float64
            ),
            "ess_grid": np.asarray(self.ess_grid_, dtype=np.float64),
            "support_weight_grid": np.asarray(
                self.support_weight_grid_, dtype=np.float64
            ),
            "stable_q_grid": np.asarray(self.stable_q_grid_, dtype=np.float64),
            "global_threshold": np.asarray(
                self.global_threshold_, dtype=np.float64
            ),
            "global_negative_mass": np.asarray(
                self.global_negative_mass_, dtype=np.float64
            ),
            "global_root_error": np.asarray(
                self.global_root_error_, dtype=np.float64
            ),
            "global_scott_factor": np.asarray(
                self.global_scott_factor_, dtype=np.float64
            ),
            "global_effective_bandwidth": np.asarray(
                self.global_effective_bandwidth_, dtype=np.float64
            ),
            "full_fallback_fraction": np.asarray(
                self.full_fallback_fraction_, dtype=np.float64
            ),
            "full_conditional_fraction": np.asarray(
                self.full_conditional_fraction_, dtype=np.float64
            ),
            "mean_support_weight": np.asarray(
                self.mean_support_weight_, dtype=np.float64
            ),
            "bootstrap_median_relative_ci_width": np.asarray(
                self.bootstrap_median_relative_ci_width_, dtype=np.float64
            ),
            "feature_pass": np.asarray(self.feature_pass_, dtype=np.bool_),
        }

    @classmethod
    def from_state_dict(cls, state: Dict[str, Any]) -> "SupportAwareConditionalKDE":
        def scalar(name: str) -> Any:
            return np.asarray(state[name]).reshape(-1)[0].item()

        if int(scalar("schema_version")) != SCHEMA_VERSION:
            raise ValueError("不支持的 02b state schema_version")
        if str(scalar("strategy_id")) != STRATEGY_ID:
            raise ValueError("state 不是 02b_support_aware_conditional_kde")
        instance = cls(
            confidence_level=float(scalar("confidence_level")),
            ess_low=float(scalar("ess_low")),
            ess_high=float(scalar("ess_high")),
            maximum_median_relative_ci_width=float(
                scalar("maximum_median_relative_ci_width")
            ),
        )
        instance.num_samples_ = int(scalar("num_samples"))
        instance.num_features_ = int(scalar("num_features"))
        instance.grid_size_ = int(scalar("grid_size"))
        array_names = [
            "y_grid",
            "conditional_q_grid",
            "ess_grid",
            "support_weight_grid",
            "stable_q_grid",
            "global_threshold",
            "global_negative_mass",
            "global_root_error",
            "global_scott_factor",
            "global_effective_bandwidth",
            "full_fallback_fraction",
            "full_conditional_fraction",
            "mean_support_weight",
            "bootstrap_median_relative_ci_width",
        ]
        for name in array_names:
            setattr(instance, f"{name}_", np.asarray(state[name], dtype=np.float64))
        instance.feature_pass_ = np.asarray(state["feature_pass"], dtype=bool)
        expected = (instance.num_features_, instance.grid_size_)
        if instance.y_grid_.shape != expected or instance.stable_q_grid_.shape != expected:
            raise ValueError("02b state 临界函数形状不正确")
        if not np.all(np.isfinite(instance.stable_q_grid_)) or np.any(
            instance.stable_q_grid_ <= 0.0
        ):
            raise ValueError("02b state 含无效稳定阈值")
        return instance
