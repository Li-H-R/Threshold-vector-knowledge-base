# -*- coding: utf-8 -*-
"""用冻结联合任务 LSTM 与冻结 02b 阈值执行分钟级/秒级异常检测。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence

import numpy as np

# CUDA >= 10.2 的严格 CuBLAS 复现性要求在首次 CUDA 调用前设置该变量。
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import torch
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from main import DATASETS, compute, load_joint  # noqa: E402
from strategy_02b_support_aware_kde import (  # noqa: E402
    STRATEGY_ID,
    SupportAwareConditionalKDE,
)


CONFIG_PATH = SCRIPT_DIR / "detection_config.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def to_builtin(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): to_builtin(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_builtin(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def save_json(path: Path, value: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(to_builtin(value), handle, ensure_ascii=False, indent=2)


def resolve_project_path(path_text: str) -> Path:
    path = Path(path_text)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def load_npz_dict(path: Path) -> Dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {key: np.asarray(archive[key]) for key in archive.files}


def configure_deterministic_inference() -> None:
    np.random.seed(0)
    torch.manual_seed(0)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(0)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except (AttributeError, TypeError):
        pass


def audit_and_load_threshold(
    dataset: str,
    contract: Dict[str, Any],
) -> tuple[SupportAwareConditionalKDE, Dict[str, Any], list[str]]:
    model_path = Path(DATASETS[dataset]["ckpt"]).resolve()
    if sha256_file(model_path) != contract["model_sha256"]:
        raise ValueError(f"{dataset}: 模型 SHA-256 与检测冻结配置不一致")

    artifact_dir = resolve_project_path(contract["threshold_artifact_dir"])
    artifact_path = artifact_dir / "threshold_artifact.json"
    state_path = artifact_dir / "stable_critical_functions.npz"
    if not artifact_path.is_file() or not state_path.is_file():
        raise FileNotFoundError(f"{dataset}: 缺少冻结 02b 阈值工件")
    artifact = load_json(artifact_path)
    if artifact.get("strategy_id") != STRATEGY_ID:
        raise ValueError(f"{dataset}: 阈值工件策略 ID 不正确")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError(f"{dataset}: 阈值工件未达到 READY_FOR_TEST")
    if artifact.get("dataset") != dataset:
        raise ValueError(f"{dataset}: 阈值工件数据集不匹配")
    actual_state_hash = sha256_file(state_path)
    if actual_state_hash != contract["stable_state_sha256"]:
        raise ValueError(f"{dataset}: stable state SHA-256 与检测配置不一致")
    if actual_state_hash != artifact["threshold"]["stable_critical_functions_sha256"]:
        raise ValueError(f"{dataset}: stable state SHA-256 与阈值审计不一致")
    state = load_npz_dict(state_path)
    strategy = SupportAwareConditionalKDE.from_state_dict(state)
    if not bool(np.all(strategy.feature_pass_)):
        raise ValueError(f"{dataset}: 存在未通过稳定性门的特征")
    feature_ids = list(artifact["normal_calibration"]["feature_ids"])
    if len(feature_ids) != int(contract["input_dim"]):
        raise ValueError(f"{dataset}: feature_ids 维数错误")
    return strategy, artifact, feature_ids


def load_test_data(
    dataset: str,
    seed: int,
    contract: Dict[str, Any],
    model_mean: np.ndarray,
    model_std: np.ndarray,
) -> Dict[str, Any]:
    test_path = resolve_project_path(contract["test_dir"]) / f"test_seed{seed}.npz"
    if not test_path.is_file():
        raise FileNotFoundError(f"{dataset} seed={seed}: 测试文件不存在")
    expected_hash = contract["test_sha256"][str(seed)]
    actual_hash = sha256_file(test_path)
    if actual_hash != expected_hash:
        raise ValueError(f"{dataset} seed={seed}: 测试文件 SHA-256 不匹配")

    required = {"x", "x_std", "y_true", "y_type", "mean", "std", "n_normal", "n_anomaly"}
    with np.load(test_path, allow_pickle=False) as archive:
        missing = sorted(required.difference(archive.files))
        if missing:
            raise ValueError(f"{dataset} seed={seed}: 测试 NPZ 缺少 {missing}")
        x = np.asarray(archive["x"], dtype=np.float32)
        provided_x_std = np.asarray(archive["x_std"], dtype=np.float32)
        y_true = np.asarray(archive["y_true"], dtype=np.int64).reshape(-1)
        y_type = np.asarray(archive["y_type"]).astype(str).reshape(-1)
        provided_mean = np.asarray(archive["mean"], dtype=np.float32).reshape(-1)
        provided_std = np.asarray(archive["std"], dtype=np.float32).reshape(-1)
        n_normal = int(np.asarray(archive["n_normal"]).reshape(-1)[0])
        n_anomaly = int(np.asarray(archive["n_anomaly"]).reshape(-1)[0])

    expected_shape_tail = (10, int(contract["input_dim"]))
    if x.ndim != 3 or tuple(x.shape[1:]) != expected_shape_tail:
        raise ValueError(f"{dataset} seed={seed}: x 形状错误 {x.shape}")
    if provided_x_std.shape != x.shape:
        raise ValueError(f"{dataset} seed={seed}: x_std 形状错误")
    if y_true.shape[0] != x.shape[0] or y_type.shape[0] != x.shape[0]:
        raise ValueError(f"{dataset} seed={seed}: 标签长度与窗口数不一致")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(provided_x_std)):
        raise ValueError(f"{dataset} seed={seed}: 测试特征含 NaN/Inf")
    if not set(np.unique(y_true)).issubset({0, 1}):
        raise ValueError(f"{dataset} seed={seed}: y_true 不是二元标签")
    if n_normal + n_anomaly != x.shape[0]:
        raise ValueError(f"{dataset} seed={seed}: 正常/异常计数不一致")
    if int(np.sum(y_true == 0)) != n_normal or int(np.sum(y_true == 1)) != n_anomaly:
        raise ValueError(f"{dataset} seed={seed}: 标签计数与元数据不一致")

    model_standardized = (
        (x - model_mean[None, None, :])
        / (model_std[None, None, :] + 1e-8)
    ).astype(np.float32)
    standardizer_audit = {
        "provided_mean_max_abs_difference_from_current_model": float(
            np.max(np.abs(provided_mean - model_mean))
        ),
        "provided_std_max_abs_difference_from_current_model": float(
            np.max(np.abs(provided_std - model_std))
        ),
        "provided_x_std_max_abs_difference_from_current_model_transform": float(
            np.max(np.abs(provided_x_std - model_standardized))
        ),
        "provided_x_std_used_for_inference": False,
        "raw_x_restandardized_by_current_model": True,
    }
    return {
        "path": test_path,
        "sha256": actual_hash,
        "x": x,
        "y_true": y_true,
        "y_type": y_type,
        "n_normal": n_normal,
        "n_anomaly": n_anomaly,
        "standardizer_audit": standardizer_audit,
    }


def infer_unlabeled_pairs(
    x_raw: np.ndarray,
    dataset: str,
    bundle: tuple[Any, np.ndarray, np.ndarray, Dict[str, Any]],
    batch_size: int,
) -> tuple[np.ndarray, np.ndarray]:
    reconstruction_chunks = []
    residual_chunks = []
    for start in range(0, x_raw.shape[0], batch_size):
        stop = min(start + batch_size, x_raw.shape[0])
        residual, reconstruction = compute(
            x_raw[start:stop],
            dataset=dataset,
            absolute=True,
            standardized=True,
            return_recon=True,
            model_bundle=bundle,
        )
        reconstruction_chunks.append(
            np.asarray(reconstruction.mean(axis=1), dtype=np.float64)
        )
        residual_chunks.append(
            np.asarray(residual.mean(axis=1), dtype=np.float64)
        )
    reconstruction_mean = np.concatenate(reconstruction_chunks, axis=0)
    residual_mean = np.concatenate(residual_chunks, axis=0)
    if reconstruction_mean.shape != residual_mean.shape:
        raise RuntimeError("模型重构均值与残差均值形状不一致")
    if not np.all(np.isfinite(reconstruction_mean)) or not np.all(
        np.isfinite(residual_mean)
    ):
        raise RuntimeError("模型测试输出含 NaN/Inf")
    if np.any(residual_mean < 0.0):
        raise RuntimeError("绝对残差出现负值")
    return reconstruction_mean, residual_mean


def detect_unlabeled(
    reconstruction_mean: np.ndarray,
    residual_mean: np.ndarray,
    strategy: SupportAwareConditionalKDE,
) -> Dict[str, np.ndarray]:
    thresholds = strategy.thresholds(reconstruction_mean)
    if not np.all(np.isfinite(thresholds)) or np.any(thresholds <= 0.0):
        raise RuntimeError("测试阈值含非有限值或非正值")
    ratios = residual_mean / thresholds
    feature_flags = residual_mean > thresholds
    scores = np.max(ratios, axis=1)
    y_pred = scores > 1.0
    top_feature_index = np.argmax(ratios, axis=1).astype(np.int64)
    if not np.array_equal(y_pred, np.any(feature_flags, axis=1)):
        raise RuntimeError("窗口规则与逐特征规则不一致")
    return {
        "reconstruction_mean": reconstruction_mean,
        "residual_mean": residual_mean,
        "thresholds": thresholds,
        "ratios": ratios,
        "feature_flags": feature_flags,
        "scores": scores,
        "y_pred": y_pred.astype(np.int64),
        "top_feature_index": top_feature_index,
        "triggered_feature_count": np.sum(feature_flags, axis=1).astype(np.int64),
    }


def compute_binary_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    scores: np.ndarray,
) -> Dict[str, Any]:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    specificity = float(tn / (tn + fp)) if tn + fp else float("nan")
    false_positive_rate = float(fp / (tn + fp)) if tn + fp else float("nan")
    return {
        "n": int(y_true.size),
        "n_normal": int(np.sum(y_true == 0)),
        "n_anomaly": int(np.sum(y_true == 1)),
        "predicted_anomaly_count": int(np.sum(y_pred == 1)),
        "predicted_anomaly_rate": float(np.mean(y_pred == 1)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "specificity": specificity,
        "false_positive_rate": false_positive_rate,
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "roc_auc": float(roc_auc_score(y_true, scores)),
        "average_precision": float(average_precision_score(y_true, scores)),
        "score_min": float(np.min(scores)),
        "score_median": float(np.median(scores)),
        "score_max": float(np.max(scores)),
    }


def type_detection_rows(
    y_true: np.ndarray,
    y_type: np.ndarray,
    y_pred: np.ndarray,
    scores: np.ndarray,
    seed: int,
) -> list[Dict[str, Any]]:
    rows = []
    for type_name in sorted(np.unique(y_type).tolist()):
        mask = y_type == type_name
        label_values = np.unique(y_true[mask])
        if label_values.size != 1:
            raise ValueError(f"类型 {type_name!r} 同时含正常/异常标签")
        label = int(label_values[0])
        detected_rate = float(np.mean(y_pred[mask] == 1))
        rows.append(
            {
                "seed": int(seed),
                "y_type": type_name,
                "label": label,
                "count": int(np.sum(mask)),
                "predicted_anomaly_count": int(np.sum(y_pred[mask] == 1)),
                "detection_rate": detected_rate,
                "score_median": float(np.median(scores[mask])),
                "score_p95": float(np.quantile(scores[mask], 0.95)),
            }
        )
    return rows


def feature_detection_rows(
    feature_ids: list[str],
    y_true: np.ndarray,
    feature_flags: np.ndarray,
    ratios: np.ndarray,
    top_feature_index: np.ndarray,
    seed: int,
) -> list[Dict[str, Any]]:
    rows = []
    for index, feature_id in enumerate(feature_ids):
        rows.append(
            {
                "seed": int(seed),
                "feature_index": index,
                "feature_id": feature_id,
                "trigger_rate_all": float(np.mean(feature_flags[:, index])),
                "trigger_rate_normal": float(
                    np.mean(feature_flags[y_true == 0, index])
                ),
                "trigger_rate_anomaly": float(
                    np.mean(feature_flags[y_true == 1, index])
                ),
                "top_score_feature_fraction": float(
                    np.mean(top_feature_index == index)
                ),
                "ratio_median_normal": float(
                    np.median(ratios[y_true == 0, index])
                ),
                "ratio_median_anomaly": float(
                    np.median(ratios[y_true == 1, index])
                ),
            }
        )
    return rows


def write_rows(path: Path, rows: Iterable[Dict[str, Any]]) -> None:
    rows = list(rows)
    if not rows:
        raise ValueError(f"拒绝写入空 CSV：{path}")
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_seed_outputs(
    output_dir: Path,
    feature_ids: list[str],
    test: Dict[str, Any],
    prediction: Dict[str, np.ndarray],
    metrics: Dict[str, Any],
    type_rows: list[Dict[str, Any]],
    feature_rows: list[Dict[str, Any]],
    audit: Dict[str, Any],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=False)
    np.savez_compressed(
        output_dir / "detection_arrays.npz",
        reconstruction_mean=prediction["reconstruction_mean"].astype(np.float32),
        residual_mean=prediction["residual_mean"].astype(np.float32),
        thresholds=prediction["thresholds"].astype(np.float32),
        ratios=prediction["ratios"].astype(np.float32),
        feature_flags=prediction["feature_flags"].astype(np.bool_),
        score=prediction["scores"].astype(np.float64),
        y_pred=prediction["y_pred"].astype(np.int64),
        y_true=test["y_true"].astype(np.int64),
        y_type=test["y_type"].astype(str),
        top_feature_index=prediction["top_feature_index"].astype(np.int64),
        triggered_feature_count=prediction["triggered_feature_count"].astype(
            np.int64
        ),
        feature_ids=np.asarray(feature_ids),
    )
    window_rows = []
    for index in range(test["y_true"].size):
        top_index = int(prediction["top_feature_index"][index])
        window_rows.append(
            {
                "window_index": index,
                "y_true": int(test["y_true"][index]),
                "y_type": str(test["y_type"][index]),
                "score": f"{prediction['scores'][index]:.12g}",
                "y_pred": int(prediction["y_pred"][index]),
                "triggered_feature_count": int(
                    prediction["triggered_feature_count"][index]
                ),
                "top_feature_index": top_index,
                "top_feature_id": feature_ids[top_index],
            }
        )
    write_rows(output_dir / "window_results.csv", window_rows)
    write_rows(output_dir / "type_detection_audit.csv", type_rows)
    write_rows(output_dir / "feature_trigger_audit.csv", feature_rows)
    seed_result = {
        "metrics": metrics,
        "test_audit": {
            "source_path": str(test["path"]),
            "source_sha256": test["sha256"],
            "provided_standardizer": test["standardizer_audit"],
        },
        "detection_audit": audit,
        "files": {
            "arrays": "detection_arrays.npz",
            "windows": "window_results.csv",
            "types": "type_detection_audit.csv",
            "features": "feature_trigger_audit.csv",
        },
    }
    save_json(output_dir / "metrics.json", seed_result)


def aggregate_metric_rows(
    dataset: str,
    time_scale: str,
    seed_metrics: list[Dict[str, Any]],
    metric_names: list[str],
) -> tuple[list[Dict[str, Any]], Dict[str, Any]]:
    seed_rows = []
    for item in seed_metrics:
        row = {"dataset": dataset, "time_scale": time_scale, "seed": item["seed"]}
        row.update({key: item[key] for key in metric_names})
        row.update(
            {
                "tn": item["tn"],
                "fp": item["fp"],
                "fn": item["fn"],
                "tp": item["tp"],
                "predicted_anomaly_rate": item["predicted_anomaly_rate"],
            }
        )
        seed_rows.append(row)
    summary: Dict[str, Any] = {}
    for metric in metric_names:
        values = np.asarray([row[metric] for row in seed_rows], dtype=np.float64)
        summary[metric] = {
            "mean": float(np.mean(values)),
            "sd": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "values_by_seed": {
                str(row["seed"]): float(row[metric]) for row in seed_rows
            },
        }
    return seed_rows, summary


def aggregate_type_rows(type_rows: list[Dict[str, Any]]) -> list[Dict[str, Any]]:
    grouped: Dict[str, list[Dict[str, Any]]] = defaultdict(list)
    for row in type_rows:
        grouped[str(row["y_type"])].append(row)
    output = []
    for type_name, rows in sorted(grouped.items()):
        rates = np.asarray([row["detection_rate"] for row in rows], dtype=float)
        score_medians = np.asarray([row["score_median"] for row in rows], dtype=float)
        output.append(
            {
                "y_type": type_name,
                "label": int(rows[0]["label"]),
                "count_per_seed": int(rows[0]["count"]),
                "seed_count": len(rows),
                "detection_rate_mean": float(np.mean(rates)),
                "detection_rate_sd": float(np.std(rates, ddof=1))
                if rates.size > 1
                else 0.0,
                "detection_rate_min": float(np.min(rates)),
                "detection_rate_max": float(np.max(rates)),
                "score_median_across_seeds": float(np.median(score_medians)),
            }
        )
    return output


def configure_plotting() -> None:
    import matplotlib as mpl

    mpl.use("Agg")
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": [
                "Arial Unicode MS",
                "Microsoft YaHei",
                "Arial",
                "Helvetica",
                "DejaVu Sans",
                "sans-serif",
            ],
            "font.size": 7,
            "axes.titlesize": 8,
            "axes.labelsize": 7,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "legend.fontsize": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
        }
    )


def save_figure_bundle(figure: Any, output_dir: Path, stem: str) -> Dict[str, Any]:
    png = output_dir / f"{stem}.png"
    svg = output_dir / f"{stem}.svg"
    pdf = output_dir / f"{stem}.pdf"
    tiff = output_dir / f"{stem}.tiff"
    figure.savefig(png, dpi=600, bbox_inches="tight", facecolor="white")
    figure.savefig(svg, bbox_inches="tight", facecolor="white")
    figure.savefig(pdf, bbox_inches="tight", facecolor="white")
    figure.savefig(
        tiff,
        dpi=600,
        bbox_inches="tight",
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    return {
        "png": png.name,
        "svg": svg.name,
        "pdf": pdf.name,
        "tiff": tiff.name,
        "png_dpi": 600,
        "tiff_dpi": 600,
    }


def save_dataset_figure(
    output_dir: Path,
    dataset: str,
    time_scale: str,
    seed_rows: list[Dict[str, Any]],
    type_summary: list[Dict[str, Any]],
    representative: Dict[str, Any],
) -> Dict[str, Any]:
    """四面板定量图：seed 稳定性、分数分布、混淆矩阵、类型召回。"""
    configure_plotting()
    import matplotlib.pyplot as plt

    height = 7.7 if dataset == "dataset1" else 6.2
    figure, axes = plt.subplots(2, 2, figsize=(7.2, height), squeeze=False)
    figure.subplots_adjust(
        left=0.105,
        right=0.985,
        bottom=0.075,
        top=0.91,
        hspace=0.42,
        wspace=0.62 if dataset == "dataset1" else 0.48,
    )
    signal = "#174A6E"
    accent = "#D97732"
    neutral = "#78838C"

    metric_keys = ["f1", "recall", "specificity", "roc_auc", "average_precision"]
    metric_labels = ["F1", "Recall", "Specificity", "ROC AUC", "Avg. precision"]
    values = np.asarray(
        [[row[key] for key in metric_keys] for row in seed_rows], dtype=float
    )
    axis = axes[0, 0]
    x_positions = np.arange(len(metric_keys))
    for row_index, row in enumerate(seed_rows):
        axis.plot(
            x_positions,
            values[row_index],
            color="#AAB3B9",
            linewidth=0.7,
            alpha=0.7,
            marker="o",
            markersize=2.6,
            label="Individual seed" if row_index == 0 else None,
        )
    means = np.mean(values, axis=0)
    sds = np.std(values, axis=0, ddof=1)
    axis.errorbar(
        x_positions,
        means,
        yerr=sds,
        color=signal,
        marker="o",
        markersize=4.0,
        linewidth=1.4,
        capsize=2.5,
        label="Mean ± seed SD",
        zorder=5,
    )
    axis.set_xticks(
        x_positions,
        metric_labels,
        rotation=20,
        ha="right",
        rotation_mode="anchor",
    )
    axis.set_ylim(0.0, 1.04)
    axis.set_ylabel("Metric value")
    axis.set_title("Performance across five normal-sampling seeds", loc="left")
    axis.grid(axis="y", alpha=0.18, linewidth=0.5)
    axis.legend(loc="lower left")

    axis = axes[0, 1]
    scores = np.asarray(representative["scores"], dtype=float)
    y_true = np.asarray(representative["y_true"], dtype=np.int64)
    guarded_scores = np.maximum(scores, 1e-8)
    if not np.all(guarded_scores > 0.0):
        raise RuntimeError("log10 分数保护失败")
    log_scores = np.log10(guarded_scores)
    low = float(np.quantile(log_scores, 0.001))
    high = float(np.quantile(log_scores, 0.999))
    bins = np.linspace(low, high, 48)
    axis.hist(
        log_scores[y_true == 0],
        bins=bins,
        density=True,
        histtype="stepfilled",
        alpha=0.42,
        color="#6BAED6",
        label="Normal",
    )
    axis.hist(
        log_scores[y_true == 1],
        bins=bins,
        density=True,
        histtype="step",
        linewidth=1.4,
        color=accent,
        label="Anomaly",
    )
    axis.axvline(0.0, color="#222222", linestyle="--", linewidth=1.0, label="Decision score = 1")
    axis.set_xlabel("log10(window anomaly score)")
    axis.set_ylabel("Density")
    axis.set_title("Score separation (representative seed 42)", loc="left")
    axis.legend(loc="upper right")
    axis.grid(axis="y", alpha=0.14, linewidth=0.5)

    axis = axes[1, 0]
    matrix = np.asarray(representative["confusion_matrix"], dtype=float)
    row_sum = matrix.sum(axis=1, keepdims=True)
    normalized = np.divide(
        matrix,
        row_sum,
        out=np.zeros_like(matrix),
        where=row_sum > 0.0,
    )
    image = axis.imshow(normalized, cmap="Blues", vmin=0.0, vmax=1.0, aspect="equal")
    for row in range(2):
        for column in range(2):
            text_color = "white" if normalized[row, column] >= 0.55 else "#173F5F"
            axis.text(
                column,
                row,
                f"{int(matrix[row, column])}\n({normalized[row, column]:.1%})",
                ha="center",
                va="center",
                color=text_color,
                fontsize=8,
            )
    axis.set_xticks([0, 1], ["Predicted normal", "Predicted anomaly"])
    axis.set_yticks([0, 1], ["True normal", "True anomaly"])
    axis.set_title("Confusion matrix: counts and row rates (seed 42)", loc="left")

    axis = axes[1, 1]
    anomaly_rows = [row for row in type_summary if int(row["label"]) == 1]
    anomaly_rows.sort(key=lambda row: float(row["detection_rate_mean"]))
    y_positions = np.arange(len(anomaly_rows))
    rates = np.asarray([row["detection_rate_mean"] for row in anomaly_rows])
    rate_sds = np.asarray([row["detection_rate_sd"] for row in anomaly_rows])
    def concise_type_label(value: str) -> str:
        label = str(value)
        label = label.replace("中风速(5-12m/s)", "中风速：")
        label = label.replace("低风速(0-5m/s)", "低风速：")
        label = label.replace("and", "/").replace("_", "")
        return label

    labels = [concise_type_label(str(row["y_type"])) for row in anomaly_rows]
    axis.barh(y_positions, rates, color=signal, alpha=0.88, height=0.72)
    if np.any(rate_sds > 0.0):
        axis.errorbar(
            rates,
            y_positions,
            xerr=rate_sds,
            fmt="none",
            ecolor=neutral,
            elinewidth=0.8,
            capsize=2,
        )
    axis.set_yticks(y_positions, labels)
    axis.tick_params(axis="y", labelsize=5.3 if dataset == "dataset1" else 6.5)
    axis.set_xlim(0.0, 1.02)
    axis.set_xlabel("Detection rate")
    axis.set_title("Detection rate by labeled anomaly type", loc="left")
    axis.grid(axis="x", alpha=0.18, linewidth=0.5)

    for label, axis in zip("abcd", axes.flat):
        axis.text(
            -0.12,
            1.06,
            label,
            transform=axis.transAxes,
            fontsize=9,
            fontweight="bold",
            va="top",
            ha="left",
        )
    figure.suptitle(
        f"Frozen 02b anomaly detection — {dataset} ({time_scale})",
        fontsize=10,
        y=0.985,
    )
    files = save_figure_bundle(figure, output_dir, "detection_summary")
    plt.close(figure)
    return {
        **files,
        "backend": "python_matplotlib",
        "archetype": "quantitative_grid",
        "core_conclusion": (
            "Frozen 02b thresholds yield deterministic test scores whose performance "
            "and anomaly-type heterogeneity are visible across five fixed seeds."
        ),
        "panel_a": "Five seed metrics; center is mean and spread is sample SD.",
        "panel_b": "Seed-42 score distributions; scores clipped only at 1e-8 for log display.",
        "panel_c": "Seed-42 counts and row-normalized confusion matrix.",
        "panel_d": "Per-labeled-anomaly detection rates; no hypothesis test.",
    }


def save_overall_figure(
    output_dir: Path,
    dataset_results: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    configure_plotting()
    import matplotlib.pyplot as plt

    metric_keys = ["f1", "recall", "specificity", "roc_auc", "average_precision"]
    labels = ["F1", "Recall", "Specificity", "ROC AUC", "Avg. precision"]
    colors = {"dataset1": "#174A6E", "dataset2": "#D97732"}
    figure, axis = plt.subplots(figsize=(7.2, 3.2))
    x_positions = np.arange(len(metric_keys))
    offsets = {"dataset1": -0.12, "dataset2": 0.12}
    for dataset in ("dataset1", "dataset2"):
        summary = dataset_results[dataset]["metrics_summary"]
        means = np.asarray([summary[key]["mean"] for key in metric_keys])
        sds = np.asarray([summary[key]["sd"] for key in metric_keys])
        axis.errorbar(
            x_positions + offsets[dataset],
            means,
            yerr=sds,
            fmt="o",
            markersize=5,
            capsize=3,
            linewidth=1.2,
            color=colors[dataset],
            label=f"{dataset} mean ± seed SD",
        )
    axis.set_xticks(x_positions, labels)
    axis.set_ylim(0.0, 1.04)
    axis.set_ylabel("Metric value")
    axis.set_title("Frozen 02b detection performance across time scales", loc="left")
    axis.grid(axis="y", alpha=0.18, linewidth=0.5)
    axis.legend(loc="lower left", ncol=2)
    files = save_figure_bundle(figure, output_dir, "overall_detection_comparison")
    plt.close(figure)
    return {
        **files,
        "backend": "python_matplotlib",
        "archetype": "quantitative_comparison",
        "uncertainty": "mean ± sample SD across five normal-sampling seeds",
        "test_sets_independent": False,
        "note": "Anomaly windows are shared across seeds; normal windows are resampled.",
    }


def run_dataset(
    dataset: str,
    config: Dict[str, Any],
    staging_dataset_dir: Path,
) -> Dict[str, Any]:
    contract = config["datasets"][dataset]
    strategy, threshold_artifact, feature_ids = audit_and_load_threshold(
        dataset, contract
    )
    bundle = load_joint(dataset)
    model, model_mean, model_std, model_config = bundle
    if model.training:
        raise RuntimeError(f"{dataset}: 模型未处于 eval 模式")
    if int(model_config["input_dim"]) != int(contract["input_dim"]):
        raise ValueError(f"{dataset}: 模型 input_dim 与检测配置不一致")
    batch_size = int(config["batch_size"])
    seeds = [int(value) for value in config["seeds"]]
    metric_names = list(config["metrics"])

    staging_dataset_dir.mkdir(parents=True, exist_ok=False)
    seed_metrics: list[Dict[str, Any]] = []
    all_type_rows: list[Dict[str, Any]] = []
    all_feature_rows: list[Dict[str, Any]] = []
    standardizer_audits: Dict[str, Any] = {}
    representative: Optional[Dict[str, Any]] = None
    seed_output_hashes: Dict[str, Any] = {}

    for seed in seeds:
        seed_start = time.perf_counter()
        print(f"{dataset} seed={seed}: 加载并审计测试数据……", flush=True)
        test = load_test_data(
            dataset, seed, contract, model_mean, model_std
        )
        print(
            f"{dataset} seed={seed}: 用冻结模型执行 {test['x'].shape[0]} 个窗口……",
            flush=True,
        )
        reconstruction_mean, residual_mean = infer_unlabeled_pairs(
            test["x"], dataset, bundle, batch_size
        )
        prediction = detect_unlabeled(
            reconstruction_mean, residual_mean, strategy
        )
        # 标签从这里开始只用于评价；上面的模型前向、阈值和预测均不依赖标签。
        metrics = compute_binary_metrics(
            test["y_true"], prediction["y_pred"], prediction["scores"]
        )
        metrics["seed"] = seed
        metrics["duration_seconds"] = float(time.perf_counter() - seed_start)
        type_rows = type_detection_rows(
            test["y_true"],
            test["y_type"],
            prediction["y_pred"],
            prediction["scores"],
            seed,
        )
        feature_rows = feature_detection_rows(
            feature_ids,
            test["y_true"],
            prediction["feature_flags"],
            prediction["ratios"],
            prediction["top_feature_index"],
            seed,
        )
        seed_dir = staging_dataset_dir / f"seed_{seed}"
        inference_device = str(next(model.parameters()).device)
        detection_audit = {
            "strategy_id": STRATEGY_ID,
            "threshold_state_sha256": contract["stable_state_sha256"],
            "model_sha256": contract["model_sha256"],
            "model_eval_mode": True,
            "inference_device": inference_device,
            "batch_size": batch_size,
            "labels_used_for_model_or_threshold": False,
            "labels_used_for_metrics_only": True,
            "decision_rule": config["decision_contract"],
            "threshold_parameters_modified_after_test_read": False,
        }
        save_seed_outputs(
            seed_dir,
            feature_ids,
            test,
            prediction,
            metrics,
            type_rows,
            feature_rows,
            detection_audit,
        )
        seed_metrics.append(metrics)
        all_type_rows.extend(type_rows)
        all_feature_rows.extend(feature_rows)
        standardizer_audits[str(seed)] = test["standardizer_audit"]
        seed_output_hashes[str(seed)] = {
            "arrays_sha256": sha256_file(seed_dir / "detection_arrays.npz"),
            "window_results_sha256": sha256_file(seed_dir / "window_results.csv"),
            "metrics_sha256": sha256_file(seed_dir / "metrics.json"),
        }
        if seed == 42:
            representative = {
                "scores": prediction["scores"].copy(),
                "y_true": test["y_true"].copy(),
                "confusion_matrix": np.asarray(
                    [
                        [metrics["tn"], metrics["fp"]],
                        [metrics["fn"], metrics["tp"]],
                    ],
                    dtype=int,
                ),
            }
        print(
            f"{dataset} seed={seed}: F1={metrics['f1']:.4f}, "
            f"Recall={metrics['recall']:.4f}, Specificity={metrics['specificity']:.4f}",
            flush=True,
        )

    if representative is None:
        raise RuntimeError("冻结 seeds 中缺少代表性 seed=42")
    seed_rows, metrics_summary = aggregate_metric_rows(
        dataset,
        contract["time_scale"],
        seed_metrics,
        metric_names,
    )
    type_summary = aggregate_type_rows(all_type_rows)
    write_rows(staging_dataset_dir / "seed_metrics.csv", seed_rows)
    write_rows(staging_dataset_dir / "type_detection_summary.csv", type_summary)
    write_rows(staging_dataset_dir / "feature_trigger_all_seeds.csv", all_feature_rows)
    figure_audit = save_dataset_figure(
        staging_dataset_dir,
        dataset,
        contract["time_scale"],
        seed_rows,
        type_summary,
        representative,
    )
    dataset_summary = {
        "dataset": dataset,
        "time_scale": contract["time_scale"],
        "model_sha256": contract["model_sha256"],
        "threshold_state_sha256": contract["stable_state_sha256"],
        "threshold_artifact_status": threshold_artifact["status"],
        "strategy_id": STRATEGY_ID,
        "seeds": seeds,
        "test_files_sha256": contract["test_sha256"],
        "metrics_summary": metrics_summary,
        "seed_metrics": seed_metrics,
        "test_standardizer_audit": {
            "provided_x_std_used": False,
            "current_model_restandardized_raw_x": True,
            "by_seed": standardizer_audits,
        },
        "output_hashes": seed_output_hashes,
        "figure": figure_audit,
        "decision_contract": config["decision_contract"],
        "test_tuning_performed": False,
    }
    save_json(staging_dataset_dir / "dataset_summary.json", dataset_summary)
    return dataset_summary


def build_report(
    output_dir: Path,
    dataset_results: Dict[str, Dict[str, Any]],
    command: str,
    duration_seconds: float,
    overall_figure: Dict[str, Any],
) -> None:
    now = datetime.now(timezone(timedelta(hours=8))).isoformat()
    lines = [
        "# 02b 联合任务 LSTM 异常检测实验报告",
        "",
        "## Material Passport",
        "",
        "- Origin Skill: experiment-agent",
        "- Origin Mode: run",
        f"- Origin Date: {now}",
        "- Verification Status: UNVERIFIED",
        "- Version Label: exp_result_v1",
        "",
        "## Experiment Result",
        "",
        "- **ID**: 02b_joint_lstm_frozen_threshold_detection",
        "- **Type**: analysis",
        "- **Status**: completed",
        f"- **Command**: `{command}`",
        f"- **Working Directory**: `{PROJECT_ROOT}`",
        f"- **Duration**: {duration_seconds:.3f} seconds",
        "- **Exit Code**: 0",
        "",
        "## 冻结检测口径",
        "",
        "- 输入使用测试 NPZ 的原始量纲 `x`，由当前冻结模型重新标准化。",
        "- 测试 NPZ 自带的 `x_std/mean/std` 与当前模型不完全一致，因此没有用于推理。",
        "- 逐特征规则：`residual_d > stable_threshold_d(reconstruction_d)`。",
        "- 窗口分数：`max_d(residual_d / stable_threshold_d)`；`score > 1` 判异常。",
        "- 标签只在全部预测完成后用于指标计算；没有测试集调参。",
        "- 测试窗口是平衡采样集合，不是连续时间流，因此没有应用 k/m 持续性后处理。",
        "",
        "## 五 seed 检测结果（mean ± sample SD）",
        "",
        "| 时间尺度 | 数据集 | F1 | Recall | Specificity | ROC AUC | Average precision |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for dataset in ("dataset1", "dataset2"):
        result = dataset_results[dataset]
        summary = result["metrics_summary"]
        values = []
        for metric in ("f1", "recall", "specificity", "roc_auc", "average_precision"):
            values.append(
                f"{summary[metric]['mean']:.4f} ± {summary[metric]['sd']:.4f}"
            )
        lines.append(
            f"| {result['time_scale']} | `{dataset}` | " + " | ".join(values) + " |"
        )
    lines.extend(
        [
            "",
            "## Output Files",
            "",
            "| File | Purpose |",
            "|---|---|",
            "| `dataset1/dataset_summary.json` | 分钟级五 seed 汇总与审计 |",
            "| `dataset2/dataset_summary.json` | 秒级五 seed 汇总与审计 |",
            "| `dataset*/seed_metrics.csv` | 每个 seed 的二元检测指标 |",
            "| `dataset*/type_detection_summary.csv` | 逐异常类型检测率 |",
            "| `dataset*/seed_*/window_results.csv` | 每窗口分数、预测与最高贡献特征 |",
            "| `dataset*/seed_*/detection_arrays.npz` | 完整重构、残差、阈值、比值及特征触发数组 |",
            f"| `{overall_figure['pdf']}` | 两个时间尺度的总体指标比较图 |",
            "",
            "## Anomalies Detected",
            "",
            "- Execution anomalies: None.",
            "- Data-contract note: test-file standardizers differ from the current frozen model; raw `x` was restandardized by the current model and the provided `x_std` was not used.",
            "",
            "## Interpretation Boundary",
            "",
            "五个 seed 共享完全相同的异常窗口，只重新采样正常窗口，因此 seed SD 主要反映正常样本抽样变化，不能解释为五个完全独立测试集的不确定性。",
        ]
    )
    (output_dir / "detection_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="使用冻结联合任务 LSTM 与冻结 02b 阈值执行异常检测"
    )
    parser.add_argument(
        "--dataset",
        default="all",
        choices=["all", "dataset1", "dataset2"],
        help="默认 all：同时检测分钟级与秒级测试集",
    )
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    start = time.perf_counter()
    configure_deterministic_inference()
    config = load_json(CONFIG_PATH)
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("detection_config.json 的 strategy_id 不正确")
    if bool(config["decision_contract"].get("test_tuning_allowed", True)):
        raise ValueError("检测配置不得允许测试集调参")
    output_root = resolve_project_path(config["output_root"])
    staging_root = output_root.with_name(output_root.name + "_staging")
    if output_root.exists():
        raise FileExistsError(f"检测结果目录已存在，拒绝覆盖：{output_root}")
    if staging_root.exists():
        raise FileExistsError(f"检测 staging 目录已存在，拒绝覆盖：{staging_root}")
    staging_root.mkdir(parents=True, exist_ok=False)

    datasets = ["dataset1", "dataset2"] if args.dataset == "all" else [args.dataset]
    results: Dict[str, Dict[str, Any]] = {}
    for dataset in datasets:
        results[dataset] = run_dataset(
            dataset, config, staging_root / dataset
        )
    if set(results) == {"dataset1", "dataset2"}:
        overall_figure = save_overall_figure(staging_root, results)
    else:
        only = datasets[0]
        overall_figure = {
            "pdf": results[only]["figure"]["pdf"],
            "note": "single-dataset run",
        }
    duration = float(time.perf_counter() - start)
    command = f"python {Path(__file__).name} --dataset {args.dataset}"
    experiment_manifest = {
        "schema_version": 1,
        "experiment_id": config["experiment_id"],
        "status": "COMPLETED",
        "created_at_china": datetime.now(timezone(timedelta(hours=8))).isoformat(),
        "command": command,
        "duration_seconds": duration,
        "datasets": results,
        "overall_figure": overall_figure,
        "labels_used_for_thresholding": False,
        "test_tuning_performed": False,
        "decision_contract": config["decision_contract"],
    }
    save_json(staging_root / "experiment_manifest.json", experiment_manifest)
    if set(results) == {"dataset1", "dataset2"}:
        overall_rows = []
        for dataset in ("dataset1", "dataset2"):
            for metric, summary in results[dataset]["metrics_summary"].items():
                overall_rows.append(
                    {
                        "dataset": dataset,
                        "time_scale": results[dataset]["time_scale"],
                        "metric": metric,
                        "mean": summary["mean"],
                        "sd": summary["sd"],
                        "min": summary["min"],
                        "max": summary["max"],
                    }
                )
        write_rows(staging_root / "overall_metrics.csv", overall_rows)
    build_report(staging_root, results, command, duration, overall_figure)
    staging_root.replace(output_root)
    print(f"检测完成：{output_root}", flush=True)
    return experiment_manifest


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
