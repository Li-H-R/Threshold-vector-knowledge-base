# -*- coding: utf-8 -*-

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from detect_02b_support_aware_kde import (  # noqa: E402
    aggregate_metric_rows,
    build_parser,
    compute_binary_metrics,
    detect_unlabeled,
)


class ConstantThresholdStrategy:
    def __init__(self, thresholds):
        self.fixed = np.asarray(thresholds, dtype=np.float64)

    def thresholds(self, reconstruction_mean):
        return np.broadcast_to(
            self.fixed[None, :], np.asarray(reconstruction_mean).shape
        ).copy()


class DetectionContractTests(unittest.TestCase):
    def test_window_score_and_strict_decision_rule(self):
        reconstruction = np.zeros((4, 2), dtype=np.float64)
        residual = np.asarray(
            [
                [0.5, 0.9],
                [1.0, 0.2],
                [1.1, 0.2],
                [0.2, 2.1],
            ],
            dtype=np.float64,
        )
        result = detect_unlabeled(
            reconstruction,
            residual,
            ConstantThresholdStrategy([1.0, 2.0]),
        )
        np.testing.assert_allclose(result["scores"], [0.5, 1.0, 1.1, 1.05])
        np.testing.assert_array_equal(result["y_pred"], [0, 0, 1, 1])
        np.testing.assert_array_equal(
            result["y_pred"], np.any(result["feature_flags"], axis=1)
        )

    def test_binary_metrics_match_known_confusion_matrix(self):
        y_true = np.asarray([0, 0, 0, 1, 1, 1])
        y_pred = np.asarray([0, 1, 0, 1, 0, 1])
        scores = np.asarray([0.1, 0.8, 0.2, 0.9, 0.4, 0.7])
        metrics = compute_binary_metrics(y_true, y_pred, scores)
        self.assertEqual(
            (metrics["tn"], metrics["fp"], metrics["fn"], metrics["tp"]),
            (2, 1, 1, 2),
        )
        self.assertAlmostEqual(metrics["recall"], 2 / 3)
        self.assertAlmostEqual(metrics["specificity"], 2 / 3)
        self.assertAlmostEqual(metrics["precision"], 2 / 3)
        self.assertAlmostEqual(metrics["f1"], 2 / 3)

    def test_seed_summary_uses_sample_sd(self):
        rows = [
            {"seed": 1, "f1": 0.5, "tn": 1, "fp": 1, "fn": 1, "tp": 1, "predicted_anomaly_rate": 0.5},
            {"seed": 2, "f1": 1.0, "tn": 2, "fp": 0, "fn": 0, "tp": 2, "predicted_anomaly_rate": 0.5},
        ]
        _, summary = aggregate_metric_rows(
            "dataset1", "minute", rows, ["f1"]
        )
        self.assertAlmostEqual(summary["f1"]["mean"], 0.75)
        self.assertAlmostEqual(summary["f1"]["sd"], np.std([0.5, 1.0], ddof=1))

    def test_cli_has_no_threshold_or_tuning_arguments(self):
        parser = build_parser()
        options = " ".join(
            option
            for action in parser._actions
            for option in action.option_strings
        ).lower()
        for forbidden in (
            "threshold",
            "tail",
            "ess",
            "confidence",
            "persistence",
            "label",
            "metric",
            "output",
        ):
            self.assertNotIn(forbidden, options)
        args = parser.parse_args(["--dataset", "all"])
        self.assertEqual(args.dataset, "all")

    def test_detection_config_freezes_all_ten_test_files(self):
        path = SCRIPT_DIR / "detection_config.json"
        with path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)
        self.assertEqual(config["seeds"], [42, 123, 2024, 7, 999])
        self.assertFalse(config["decision_contract"]["test_tuning_allowed"])
        self.assertFalse(config["decision_contract"]["labels_used_for_thresholding"])
        for dataset in ("dataset1", "dataset2"):
            self.assertEqual(len(config["datasets"][dataset]["test_sha256"]), 5)
            self.assertEqual(len(config["datasets"][dataset]["model_sha256"]), 64)
            self.assertEqual(
                len(config["datasets"][dataset]["stable_state_sha256"]), 64
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
