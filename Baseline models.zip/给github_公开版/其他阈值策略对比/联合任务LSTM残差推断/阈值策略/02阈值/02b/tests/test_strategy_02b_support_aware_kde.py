# -*- coding: utf-8 -*-

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from prepare_02b_support_aware_kde import build_parser  # noqa: E402
from strategy_02b_support_aware_kde import (  # noqa: E402
    STRATEGY_ID,
    SupportAwareConditionalKDE,
    fit_global_positive_kde_quantile,
    smoothstep_support_weight,
)


def synthetic_inputs(seed: int = 7):
    rng = np.random.default_rng(seed)
    n_samples = 240
    n_features = 2
    grid_size = 7
    reconstruction = rng.normal(size=(n_samples, n_features))
    residual = np.abs(
        np.column_stack(
            [
                rng.normal(0.20, 0.045, n_samples),
                rng.normal(0.35, 0.065, n_samples),
            ]
        )
    )
    y_grid = np.vstack(
        [
            np.linspace(-2.5, 2.5, grid_size),
            np.linspace(-2.5, 2.5, grid_size),
        ]
    )
    q_grid = np.vstack(
        [
            np.linspace(0.25, 0.50, grid_size),
            np.linspace(0.40, 0.75, grid_size),
        ]
    )
    ess_grid = np.vstack(
        [
            [5.0, 49.0, 50.0, 75.0, 100.0, 101.0, 140.0],
            [20.0, 45.0, 60.0, 80.0, 95.0, 120.0, 160.0],
        ]
    )
    upstream = {
        "y_grid": y_grid,
        "q_grid": q_grid,
        "ess_grid": ess_grid,
    }
    return upstream, reconstruction, residual


class TestSupportAwareConditionalKDE(unittest.TestCase):
    def test_global_positive_kde_quantile_is_finite_and_accurate(self):
        rng = np.random.default_rng(11)
        residual = np.abs(rng.normal(0.2, 0.06, size=500))
        result = fit_global_positive_kde_quantile(residual, 0.999)
        self.assertGreater(result["threshold"], 0.0)
        self.assertTrue(np.isfinite(result["threshold"]))
        self.assertLessEqual(result["positive_cdf_error"], 1e-10)
        self.assertGreaterEqual(result["negative_mass"], 0.0)
        self.assertLess(result["negative_mass"], 1.0)

    def test_smoothstep_support_weight_has_exact_boundaries(self):
        ess = np.asarray([0.0, 49.0, 50.0, 75.0, 100.0, 150.0])
        weights = smoothstep_support_weight(ess, 50.0, 100.0)
        np.testing.assert_allclose(weights[:3], 0.0, atol=0.0, rtol=0.0)
        self.assertAlmostEqual(weights[3], 0.5)
        np.testing.assert_allclose(weights[4:], 1.0, atol=0.0, rtol=0.0)
        self.assertTrue(np.all(np.diff(weights) >= 0.0))

    def test_stable_curve_uses_global_and_conditional_limits_at_boundaries(self):
        upstream, reconstruction, residual = synthetic_inputs()
        strategy = SupportAwareConditionalKDE().fit(
            upstream, reconstruction, residual
        )
        self.assertIsNotNone(strategy.stable_q_grid_)
        self.assertIsNotNone(strategy.global_threshold_)
        self.assertIsNotNone(strategy.conditional_q_grid_)
        self.assertIsNotNone(strategy.support_weight_grid_)
        for feature_index in range(2):
            low = strategy.support_weight_grid_[feature_index] == 0.0
            high = strategy.support_weight_grid_[feature_index] == 1.0
            np.testing.assert_allclose(
                strategy.stable_q_grid_[feature_index, low],
                strategy.global_threshold_[feature_index],
                atol=1e-14,
                rtol=0.0,
            )
            np.testing.assert_allclose(
                strategy.stable_q_grid_[feature_index, high],
                strategy.conditional_q_grid_[feature_index, high],
                atol=1e-14,
                rtol=0.0,
            )

    def test_state_roundtrip_preserves_thresholds_exactly(self):
        upstream, reconstruction, residual = synthetic_inputs()
        strategy = SupportAwareConditionalKDE().fit(
            upstream, reconstruction, residual
        )
        strategy.apply_bootstrap_gate(np.asarray([0.12, 0.25]))
        restored = SupportAwareConditionalKDE.from_state_dict(strategy.state_dict())
        probe = reconstruction[:41]
        np.testing.assert_array_equal(
            strategy.thresholds(probe), restored.thresholds(probe)
        )
        self.assertEqual(restored.strategy_id, STRATEGY_ID)
        np.testing.assert_array_equal(restored.feature_pass_, [True, True])

    def test_bootstrap_gate_rejects_feature_above_frozen_width(self):
        upstream, reconstruction, residual = synthetic_inputs()
        strategy = SupportAwareConditionalKDE(
            maximum_median_relative_ci_width=0.75
        ).fit(upstream, reconstruction, residual)
        strategy.apply_bootstrap_gate(np.asarray([0.74, 0.76]))
        np.testing.assert_array_equal(strategy.feature_pass_, [True, False])

    def test_smoothstep_rejects_invalid_ess(self):
        for bad_ess in (
            np.asarray([-1.0, 2.0]),
            np.asarray([1.0, np.nan]),
        ):
            with self.subTest(bad_ess=bad_ess):
                with self.assertRaises(ValueError):
                    smoothstep_support_weight(bad_ess, 50.0, 100.0)

    def test_prepare_cli_exposes_no_test_detection_or_metric_arguments(self):
        parser = build_parser()
        option_strings = {
            option
            for action in parser._actions
            for option in action.option_strings
        }
        lowered = " ".join(sorted(option_strings)).lower()
        for forbidden in (
            "test",
            "label",
            "detect",
            "metric",
            "persistence",
            "threshold",
            "calibration",
            "output",
        ):
            self.assertNotIn(forbidden, lowered)
        args = parser.parse_args(["--dataset", "dataset1"])
        self.assertEqual(args.dataset, "dataset1")

    def test_frozen_config_forbids_test_and_detection_inputs(self):
        config_path = SCRIPT_DIR / "experiment_config_02b.json"
        with config_path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)
        self.assertEqual(config["strategy_id"], STRATEGY_ID)
        isolation = config["data_isolation"]
        self.assertIsNone(isolation["test_file"])
        self.assertIsNone(isolation["test_labels"])
        self.assertFalse(isolation["test_data_allowed_during_prepare"])
        self.assertFalse(isolation["detection_allowed_during_prepare"])
        self.assertFalse(isolation["metrics_allowed_during_prepare"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
