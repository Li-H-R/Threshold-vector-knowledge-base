# -*- coding: utf-8 -*-
"""只用冻结的正常标定工件准备 02b 支持度感知稳定临界函数。

本脚本没有测试集、异常标签、异常检测或评价指标入口。它只读取 02 的
纯正常 calibration pairs / critical functions / bootstrap audit，并生成新的
02b 工件；原 02 工件保持不变。
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[2]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from strategy_02b_support_aware_kde import (  # noqa: E402
    SCHEMA_VERSION,
    STRATEGY_ID,
    SupportAwareConditionalKDE,
    fit_global_positive_kde_quantile,
)


CONFIG_PATH = SCRIPT_DIR / "experiment_config_02b.json"
EXPECTED_UPSTREAM_STRATEGY_ID = "02_conditional_kde"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: Path, value: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def resolve_project_path(path_text: str) -> Path:
    path = Path(path_text)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def npz_scalar(state: Dict[str, np.ndarray], key: str) -> Any:
    value = np.asarray(state[key]).reshape(-1)[0]
    return value.item() if isinstance(value, np.generic) else value


def load_npz_dict(path: Path) -> Dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as archive:
        return {key: np.asarray(archive[key]) for key in archive.files}


def require_no_detection_inputs(config: Dict[str, Any]) -> None:
    isolation = config.get("data_isolation", {})
    if isolation.get("test_file") is not None:
        raise ValueError("02b 准备配置不得包含测试文件")
    if isolation.get("test_labels") is not None:
        raise ValueError("02b 准备配置不得包含测试标签")
    forbidden_true = [
        "test_data_allowed_during_prepare",
        "detection_allowed_during_prepare",
        "metrics_allowed_during_prepare",
    ]
    if any(bool(isolation.get(key, False)) for key in forbidden_true):
        raise ValueError("02b 准备配置违反测试/检测隔离合同")


def load_and_audit_upstream(
    dataset: str,
    dataset_contract: Dict[str, Any],
    strategy_contract: Dict[str, Any],
) -> Dict[str, Any]:
    upstream_dir = resolve_project_path(dataset_contract["upstream_artifact_dir"])
    required = {
        "artifact": upstream_dir / "threshold_artifact.json",
        "audit": upstream_dir / "normal_calibration_audit.json",
        "critical": upstream_dir / "critical_functions.npz",
        "pairs": upstream_dir / "calibration_pairs.npz",
        "bootstrap": upstream_dir / "bootstrap_audit.npz",
    }
    for name, path in required.items():
        if not path.is_file():
            raise FileNotFoundError(f"缺少上游正常标定工件 {name}: {path}")

    artifact = load_json(required["artifact"])
    audit = load_json(required["audit"])
    if artifact.get("strategy_id") != EXPECTED_UPSTREAM_STRATEGY_ID:
        raise ValueError("上游工件不是冻结的 02 条件 KDE 策略")
    if artifact.get("dataset") != dataset or audit.get("dataset") != dataset:
        raise ValueError("上游工件数据集与请求不一致")
    if artifact.get("time_scale") != dataset_contract["time_scale"]:
        raise ValueError("上游时间尺度与 02b 配置不一致")
    if artifact["model"]["checkpoint_sha256"] != dataset_contract["model_sha256"]:
        raise ValueError("上游模型 SHA-256 与 02b 冻结配置不一致")
    if artifact["calibration"]["source_sha256"] != dataset_contract["calibration_sha256"]:
        raise ValueError("上游正常标定 SHA-256 与 02b 冻结配置不一致")
    if sha256_file(required["critical"]) != artifact["threshold"][
        "critical_functions_sha256"
    ]:
        raise ValueError("上游 critical_functions.npz 完整性校验失败")
    if sha256_file(required["pairs"]) != artifact["pair_definition"]["pairs_sha256"]:
        raise ValueError("上游 calibration_pairs.npz 完整性校验失败")

    for source in (artifact, audit):
        isolation = source.get("data_isolation", {})
        forbidden = (
            "test_data_used",
            "test_labels_used",
            "detection_executed",
            "metrics_computed",
        )
        if any(bool(isolation.get(key, False)) for key in forbidden):
            raise ValueError("上游工件包含测试/检测活动，拒绝用于 02b 准备")

    critical = load_npz_dict(required["critical"])
    if str(npz_scalar(critical, "strategy_id")) != EXPECTED_UPSTREAM_STRATEGY_ID:
        raise ValueError("上游 NPZ strategy_id 不正确")
    if int(npz_scalar(critical, "grid_size")) != int(strategy_contract["grid_size"]):
        raise ValueError("上游临界函数网格数与 02b 冻结配置不一致")
    if not np.isclose(
        float(npz_scalar(critical, "tail_probability")),
        float(strategy_contract["conditional_tail_probability"]),
        rtol=0.0,
        atol=1e-15,
    ):
        raise ValueError("上游条件尾概率不是冻结的 0.001")

    pairs = load_npz_dict(required["pairs"])
    reconstruction = np.asarray(pairs["reconstruction_mean"], dtype=np.float64)
    residual = np.asarray(pairs["residual_mean"], dtype=np.float64)
    feature_ids = [str(value) for value in np.asarray(pairs["feature_ids"]).tolist()]
    expected_features = int(dataset_contract["input_dim"])
    if reconstruction.ndim != 2 or residual.shape != reconstruction.shape:
        raise ValueError("上游正常 reconstruction/residual 配对形状错误")
    if reconstruction.shape[1] != expected_features:
        raise ValueError("上游正常配对特征维数与冻结配置不一致")
    if len(feature_ids) != expected_features or len(set(feature_ids)) != expected_features:
        raise ValueError("上游 feature_ids 缺失、重复或维数错误")
    if not np.all(np.isfinite(reconstruction)) or not np.all(np.isfinite(residual)):
        raise ValueError("上游正常配对含 NaN/Inf")
    if np.any(residual < 0.0):
        raise ValueError("上游绝对残差含负值")
    artifact_feature_ids = artifact["calibration"]["feature_order"]["feature_ids"]
    if feature_ids != artifact_feature_ids:
        raise ValueError("上游配对 feature_ids 与审计合同不一致")

    bootstrap = load_npz_dict(required["bootstrap"])
    expected_replicates = int(strategy_contract["bootstrap_replicates"])
    expected_anchors = int(strategy_contract["bootstrap_anchor_count"])
    expected_boot_shape = (expected_replicates, expected_features, expected_anchors)
    if np.asarray(bootstrap["curves"]).shape != expected_boot_shape:
        raise ValueError(
            f"上游 bootstrap 曲线应为 {expected_boot_shape}，"
            f"实际 {np.asarray(bootstrap['curves']).shape}"
        )
    if np.asarray(bootstrap["anchor_y"]).shape != (
        expected_features,
        expected_anchors,
    ):
        raise ValueError("上游 bootstrap anchor_y 形状错误")
    if not np.all(np.isfinite(bootstrap["curves"])):
        raise ValueError("上游 bootstrap 曲线含 NaN/Inf")

    return {
        "upstream_dir": upstream_dir,
        "paths": required,
        "artifact": artifact,
        "audit": audit,
        "critical": critical,
        "reconstruction": reconstruction,
        "residual": residual,
        "feature_ids": feature_ids,
        "bootstrap": bootstrap,
    }


def build_stable_bootstrap(
    residual: np.ndarray,
    upstream_state: Dict[str, np.ndarray],
    upstream_bootstrap: Dict[str, np.ndarray],
    strategy: SupportAwareConditionalKDE,
    replicates: int,
    seed: int,
) -> Dict[str, np.ndarray]:
    """复用相同 bootstrap 索引，将条件曲线与全局正常回退曲线融合。"""
    anchor_y = np.asarray(upstream_bootstrap["anchor_y"], dtype=np.float64)
    conditional_curves = np.asarray(upstream_bootstrap["curves"], dtype=np.float64)
    n_samples, n_features = residual.shape
    if conditional_curves.shape[0] != replicates:
        raise ValueError("上游 bootstrap 重复次数与冻结配置不一致")

    assert strategy.y_grid_ is not None
    assert strategy.support_weight_grid_ is not None
    support_weight_anchor = np.empty_like(anchor_y)
    for feature_index in range(n_features):
        grid = strategy.y_grid_[feature_index]
        if not np.all(np.diff(grid) > 0.0):
            raise ValueError("稳定化插值要求 y_grid 严格递增")
        support_weight_anchor[feature_index] = np.interp(
            anchor_y[feature_index],
            grid,
            strategy.support_weight_grid_[feature_index],
            left=strategy.support_weight_grid_[feature_index, 0],
            right=strategy.support_weight_grid_[feature_index, -1],
        )

    global_curves = np.empty((replicates, n_features), dtype=np.float64)
    global_root_errors = np.empty_like(global_curves)
    rng = np.random.Generator(np.random.PCG64(seed))
    for replicate in range(replicates):
        indices = rng.integers(0, n_samples, size=n_samples)
        for feature_index in range(n_features):
            fit = fit_global_positive_kde_quantile(
                residual[indices, feature_index], strategy.confidence_level
            )
            global_curves[replicate, feature_index] = fit["threshold"]
            global_root_errors[replicate, feature_index] = fit[
                "positive_cdf_error"
            ]
        if (replicate + 1) % 10 == 0 or replicate + 1 == replicates:
            print(f"  正常 bootstrap 全局回退：{replicate + 1}/{replicates}", flush=True)

    stable_curves = (
        support_weight_anchor[None, :, :] * conditional_curves
        + (1.0 - support_weight_anchor[None, :, :])
        * global_curves[:, :, None]
    )
    if not np.all(np.isfinite(stable_curves)) or np.any(stable_curves <= 0.0):
        raise RuntimeError("稳定化 bootstrap 曲线出现非有限值或非正值")
    median = np.median(stable_curves, axis=0)
    ci_2_5 = np.quantile(stable_curves, 0.025, axis=0)
    ci_97_5 = np.quantile(stable_curves, 0.975, axis=0)
    relative_ci_width = (ci_97_5 - ci_2_5) / np.maximum(np.abs(median), 1e-12)
    median_relative_ci_width = np.median(relative_ci_width, axis=1)
    return {
        "anchor_probabilities": np.asarray(
            upstream_bootstrap["anchor_probabilities"], dtype=np.float64
        ),
        "anchor_y": anchor_y,
        "support_weight_anchor": support_weight_anchor,
        "conditional_curves": conditional_curves,
        "global_threshold_curves": global_curves,
        "global_root_errors": global_root_errors,
        "stable_curves": stable_curves,
        "median": median,
        "ci_2_5": ci_2_5,
        "ci_97_5": ci_97_5,
        "relative_ci_width": relative_ci_width,
        "median_relative_ci_width": median_relative_ci_width,
    }


def save_feature_audit_csv(
    path: Path,
    feature_ids: list[str],
    strategy: SupportAwareConditionalKDE,
    bootstrap: Dict[str, np.ndarray],
) -> None:
    assert strategy.feature_pass_ is not None
    assert strategy.global_threshold_ is not None
    assert strategy.global_negative_mass_ is not None
    assert strategy.global_root_error_ is not None
    assert strategy.global_scott_factor_ is not None
    assert strategy.global_effective_bandwidth_ is not None
    assert strategy.full_fallback_fraction_ is not None
    assert strategy.full_conditional_fraction_ is not None
    assert strategy.mean_support_weight_ is not None
    assert strategy.stable_q_grid_ is not None
    assert strategy.conditional_q_grid_ is not None
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        fieldnames = [
            "feature_index",
            "feature_id",
            "num_normal_windows",
            "global_threshold_0_999",
            "global_negative_kde_mass",
            "global_root_cdf_error",
            "global_scott_factor",
            "global_effective_bandwidth",
            "full_fallback_fraction",
            "full_conditional_fraction",
            "mean_support_weight",
            "original_conditional_min",
            "original_conditional_max",
            "stable_threshold_min",
            "stable_threshold_max",
            "bootstrap_median_relative_ci_width",
            "feature_pass",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for index, feature_id in enumerate(feature_ids):
            writer.writerow(
                {
                    "feature_index": index,
                    "feature_id": feature_id,
                    "num_normal_windows": strategy.num_samples_,
                    "global_threshold_0_999": f"{strategy.global_threshold_[index]:.12g}",
                    "global_negative_kde_mass": f"{strategy.global_negative_mass_[index]:.12g}",
                    "global_root_cdf_error": f"{strategy.global_root_error_[index]:.12g}",
                    "global_scott_factor": f"{strategy.global_scott_factor_[index]:.12g}",
                    "global_effective_bandwidth": f"{strategy.global_effective_bandwidth_[index]:.12g}",
                    "full_fallback_fraction": f"{strategy.full_fallback_fraction_[index]:.12g}",
                    "full_conditional_fraction": f"{strategy.full_conditional_fraction_[index]:.12g}",
                    "mean_support_weight": f"{strategy.mean_support_weight_[index]:.12g}",
                    "original_conditional_min": f"{np.min(strategy.conditional_q_grid_[index]):.12g}",
                    "original_conditional_max": f"{np.max(strategy.conditional_q_grid_[index]):.12g}",
                    "stable_threshold_min": f"{np.min(strategy.stable_q_grid_[index]):.12g}",
                    "stable_threshold_max": f"{np.max(strategy.stable_q_grid_[index]):.12g}",
                    "bootstrap_median_relative_ci_width": f"{bootstrap['median_relative_ci_width'][index]:.12g}",
                    "feature_pass": bool(strategy.feature_pass_[index]),
                }
            )


def save_calibration_figure(
    output_dir: Path,
    dataset: str,
    feature_ids: list[str],
    reconstruction: np.ndarray,
    residual: np.ndarray,
    strategy: SupportAwareConditionalKDE,
    bootstrap: Dict[str, np.ndarray],
) -> Dict[str, Any]:
    """定量网格：全部正常点、原条件曲线、回退线、02b 曲线与 95% CI。"""
    import matplotlib as mpl

    mpl.use("Agg")
    import matplotlib.pyplot as plt

    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 7,
            "axes.titlesize": 7,
            "axes.labelsize": 7,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "legend.fontsize": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
        }
    )
    assert strategy.y_grid_ is not None
    assert strategy.conditional_q_grid_ is not None
    assert strategy.stable_q_grid_ is not None
    assert strategy.global_threshold_ is not None
    n_features = len(feature_ids)
    n_columns = 2 if n_features <= 8 else 3
    n_rows = int(math.ceil(n_features / n_columns))
    figure, axes = plt.subplots(
        n_rows,
        n_columns,
        figsize=(7.2, 2.05 * n_rows + 0.75),
        squeeze=False,
    )
    figure.subplots_adjust(
        left=0.085,
        right=0.99,
        bottom=0.055,
        top=0.865,
        hspace=0.55,
        wspace=0.25,
    )
    for feature_index, axis in enumerate(axes.flat):
        if feature_index >= n_features:
            axis.axis("off")
            continue
        axis.hexbin(
            reconstruction[:, feature_index],
            residual[:, feature_index],
            gridsize=42,
            mincnt=1,
            bins="log",
            cmap="Blues",
            linewidths=0.0,
            rasterized=True,
        )
        axis.fill_between(
            bootstrap["anchor_y"][feature_index],
            bootstrap["ci_2_5"][feature_index],
            bootstrap["ci_97_5"][feature_index],
            color="#9ECAE1",
            alpha=0.48,
            linewidth=0,
            label="02b bootstrap 95% interval" if feature_index == 0 else None,
        )
        axis.plot(
            strategy.y_grid_[feature_index],
            strategy.conditional_q_grid_[feature_index],
            color="#E07A32",
            linewidth=0.95,
            linestyle=(0, (3, 2)),
            alpha=0.9,
            label="Original conditional limit" if feature_index == 0 else None,
        )
        axis.axhline(
            strategy.global_threshold_[feature_index],
            color="#6C757D",
            linewidth=0.9,
            linestyle=(0, (1.5, 1.5)),
            label="Global normal limit" if feature_index == 0 else None,
        )
        axis.plot(
            strategy.y_grid_[feature_index],
            strategy.stable_q_grid_[feature_index],
            color="#173F5F",
            linewidth=1.55,
            label="02b stable limit" if feature_index == 0 else None,
        )
        axis.set_title(f"{feature_index}: {feature_ids[feature_index]}", loc="left")
        axis.set_xlabel("Mean reconstruction (standardized)")
        axis.set_ylabel("Mean absolute residual")
        axis.grid(alpha=0.16, linewidth=0.5)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    if handles:
        figure.legend(
            handles,
            labels,
            loc="upper center",
            ncol=4,
            bbox_to_anchor=(0.5, 0.935),
            columnspacing=1.2,
            handlelength=2.6,
        )
    figure.suptitle(
        f"Support-aware normal-calibration limits — {dataset}",
        fontsize=9,
        y=0.985,
    )
    png_path = output_dir / "support_aware_calibration.png"
    svg_path = output_dir / "support_aware_calibration.svg"
    pdf_path = output_dir / "support_aware_calibration.pdf"
    tiff_path = output_dir / "support_aware_calibration.tiff"
    figure.savefig(png_path, dpi=600, bbox_inches="tight", facecolor="white")
    figure.savefig(svg_path, bbox_inches="tight", facecolor="white")
    figure.savefig(pdf_path, bbox_inches="tight", facecolor="white")
    figure.savefig(
        tiff_path,
        dpi=600,
        bbox_inches="tight",
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(figure)
    return {
        "png_file": png_path.name,
        "svg_file": svg_path.name,
        "pdf_file": pdf_path.name,
        "tiff_file": tiff_path.name,
        "backend": "python_matplotlib",
        "archetype": "quantitative_grid",
        "core_conclusion": (
            "Support-aware fallback suppresses sparse-region conditional excursions "
            "while preserving conditional adaptation in well-supported regions."
        ),
        "normal_windows": int(reconstruction.shape[0]),
        "all_normal_calibration_observations_used": True,
        "bootstrap_interval": "pointwise percentile 95% interval across 100 normal resamples",
        "test_data_plotted": False,
        "png_dpi": 600,
        "tiff_dpi": 600,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "准备 02b：只读取冻结的纯正常 02 标定工件，生成支持度感知稳定临界函数"
        )
    )
    parser.add_argument("--dataset", required=True, choices=["dataset1", "dataset2"])
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config = load_json(CONFIG_PATH)
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("experiment_config_02b.json 的 strategy_id 不正确")
    if config.get("upstream_strategy_id") != EXPECTED_UPSTREAM_STRATEGY_ID:
        raise ValueError("02b 配置的 upstream_strategy_id 不正确")
    require_no_detection_inputs(config)
    strategy_contract = config["strategy_contract"]
    dataset_contract = config["datasets"][args.dataset]
    if float(strategy_contract["conditional_tail_probability"]) != float(
        strategy_contract["global_fallback_tail_probability"]
    ):
        raise ValueError("条件阈值和全局回退阈值必须使用相同尾概率")

    output_dir = resolve_project_path(dataset_contract["artifact_dir"])
    forbidden_parts = {"测试集数据", "02实验结果", "results"}
    if any(part in forbidden_parts for part in output_dir.parts):
        raise ValueError("准备阶段禁止把工件写入测试或检测结果目录")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖正式 02b 工件：{output_dir}")

    upstream = load_and_audit_upstream(
        args.dataset, dataset_contract, strategy_contract
    )
    reconstruction = upstream["reconstruction"]
    residual = upstream["residual"]
    confidence_level = 1.0 - float(
        strategy_contract["global_fallback_tail_probability"]
    )
    print(f"{args.dataset}: 拟合纯正常全局回退并融合冻结的条件曲线……", flush=True)
    strategy = SupportAwareConditionalKDE(
        confidence_level=confidence_level,
        ess_low=float(strategy_contract["ess_low"]),
        ess_high=float(strategy_contract["ess_high"]),
        maximum_median_relative_ci_width=float(
            strategy_contract["maximum_median_relative_bootstrap_ci_width"]
        ),
    ).fit(upstream["critical"], reconstruction, residual)

    replicates = int(strategy_contract["bootstrap_replicates"])
    seed = int(strategy_contract["bootstrap_seed"])
    print(
        f"{args.dataset}: 开始 {replicates} 次纯正常 bootstrap 稳定性审计……",
        flush=True,
    )
    bootstrap = build_stable_bootstrap(
        residual,
        upstream["critical"],
        upstream["bootstrap"],
        strategy,
        replicates,
        seed,
    )
    strategy.apply_bootstrap_gate(bootstrap["median_relative_ci_width"])

    output_dir.mkdir(parents=True, exist_ok=False)
    state_path = output_dir / "stable_critical_functions.npz"
    np.savez_compressed(state_path, **strategy.state_dict())
    global_path = output_dir / "global_fallback_state.npz"
    np.savez_compressed(
        global_path,
        confidence_level=np.asarray([strategy.confidence_level]),
        global_threshold=np.asarray(strategy.global_threshold_),
        global_negative_mass=np.asarray(strategy.global_negative_mass_),
        global_root_error=np.asarray(strategy.global_root_error_),
        global_scott_factor=np.asarray(strategy.global_scott_factor_),
        global_effective_bandwidth=np.asarray(strategy.global_effective_bandwidth_),
    )
    bootstrap_path = output_dir / "bootstrap_stability.npz"
    np.savez_compressed(bootstrap_path, **bootstrap)
    feature_audit_path = output_dir / "feature_stability_audit.csv"
    save_feature_audit_csv(
        feature_audit_path, upstream["feature_ids"], strategy, bootstrap
    )

    normal_audit = {
        "dataset": args.dataset,
        "time_scale": dataset_contract["time_scale"],
        "source_upstream_artifact_dir": str(upstream["upstream_dir"]),
        "source_upstream_artifact_sha256": sha256_file(
            upstream["paths"]["artifact"]
        ),
        "source_critical_functions_sha256": sha256_file(
            upstream["paths"]["critical"]
        ),
        "source_calibration_pairs_sha256": sha256_file(
            upstream["paths"]["pairs"]
        ),
        "source_bootstrap_audit_sha256": sha256_file(
            upstream["paths"]["bootstrap"]
        ),
        "model_sha256": dataset_contract["model_sha256"],
        "normal_calibration_sha256": dataset_contract["calibration_sha256"],
        "num_normal_windows": int(reconstruction.shape[0]),
        "input_dim": int(reconstruction.shape[1]),
        "feature_ids": upstream["feature_ids"],
        "normal_only_evidence": {
            "upstream_all_labels_normal": bool(
                upstream["artifact"]["calibration"]["all_labels_normal"]
            ),
            "upstream_test_data_used": False,
            "upstream_test_labels_used": False,
        },
        "data_isolation": {
            "test_data_used": False,
            "test_labels_used": False,
            "detection_executed": False,
            "metrics_computed": False,
        },
    }
    save_json(output_dir / "normal_calibration_audit.json", normal_audit)
    figure_audit = save_calibration_figure(
        output_dir,
        args.dataset,
        upstream["feature_ids"],
        reconstruction,
        residual,
        strategy,
        bootstrap,
    )

    restored_state = load_npz_dict(state_path)
    restored = SupportAwareConditionalKDE.from_state_dict(restored_state)
    probe_rows = np.linspace(
        0,
        reconstruction.shape[0] - 1,
        min(257, reconstruction.shape[0]),
        dtype=int,
    )
    before = strategy.thresholds(reconstruction[probe_rows])
    after = restored.thresholds(reconstruction[probe_rows])
    reload_max_abs_error = float(np.max(np.abs(before - after)))
    if reload_max_abs_error > 1e-12:
        raise RuntimeError("02b 临界函数保存/重载后结果不一致")

    feature_pass = np.asarray(strategy.feature_pass_, dtype=bool)
    ready = bool(np.all(feature_pass))
    status = "READY_FOR_TEST" if ready else "CALIBRATION_UNSTABLE"
    now_china = datetime.now(timezone(timedelta(hours=8))).isoformat()
    artifact = {
        "schema_version": SCHEMA_VERSION,
        "strategy_id": STRATEGY_ID,
        "strategy_name": config["strategy_name"],
        "reproduction_type": config["reproduction_type"],
        "status": status,
        "formal_result_allowed": ready,
        "created_at_china": now_china,
        "dataset": args.dataset,
        "time_scale": dataset_contract["time_scale"],
        "model": upstream["artifact"]["model"],
        "normal_calibration": {
            "source_sha256": dataset_contract["calibration_sha256"],
            "num_windows": int(reconstruction.shape[0]),
            "pairs_shape": list(reconstruction.shape),
            "feature_ids": upstream["feature_ids"],
            "audit_file": "normal_calibration_audit.json",
        },
        "upstream_02": {
            "strategy_id": EXPECTED_UPSTREAM_STRATEGY_ID,
            "status": upstream["artifact"]["status"],
            "artifact_dir": str(upstream["upstream_dir"]),
            "artifact_sha256": sha256_file(upstream["paths"]["artifact"]),
            "critical_functions_sha256": sha256_file(
                upstream["paths"]["critical"]
            ),
            "calibration_pairs_sha256": sha256_file(upstream["paths"]["pairs"]),
            "bootstrap_audit_sha256": sha256_file(
                upstream["paths"]["bootstrap"]
            ),
            "overwritten": False,
        },
        "threshold": {
            "method": "support_aware_conditional_kde_with_global_normal_fallback",
            "conditional_tail_probability": float(
                strategy_contract["conditional_tail_probability"]
            ),
            "global_fallback_tail_probability": float(
                strategy_contract["global_fallback_tail_probability"]
            ),
            "conditional_quantile": confidence_level,
            "global_fallback_quantile": confidence_level,
            "positive_support_renormalized": True,
            "ess_low": strategy.ess_low,
            "ess_high": strategy.ess_high,
            "blend": "smoothstep u^2(3-2u)",
            "weight_formula": "u=clip((ESS-50)/(100-50),0,1)",
            "stable_formula": "tau_stable=w*tau_conditional+(1-w)*tau_global",
            "grid_size": int(strategy.grid_size_),
            "interpolation": "linear with frozen boundary values",
            "num_critical_functions": int(strategy.num_features_),
            "stable_critical_functions_file": state_path.name,
            "stable_critical_functions_sha256": sha256_file(state_path),
            "global_fallback_state_file": global_path.name,
            "global_fallback_state_sha256": sha256_file(global_path),
            "global_threshold_by_feature": np.asarray(
                strategy.global_threshold_, dtype=float
            ).tolist(),
        },
        "stability_gate": {
            "maximum_median_relative_bootstrap_ci_width": strategy.maximum_median_relative_ci_width,
            "global_root_cdf_error_maximum": 1e-10,
            "finite_positive_stable_curves_required": True,
            "state_reload_atol": 1e-12,
            "all_features_passed": ready,
            "failed_feature_indices": np.flatnonzero(~feature_pass)
            .astype(int)
            .tolist(),
            "median_relative_bootstrap_ci_width_by_feature": np.asarray(
                strategy.bootstrap_median_relative_ci_width_, dtype=float
            ).tolist(),
            "global_root_cdf_error_by_feature": np.asarray(
                strategy.global_root_error_, dtype=float
            ).tolist(),
            "full_fallback_fraction_by_feature": np.asarray(
                strategy.full_fallback_fraction_, dtype=float
            ).tolist(),
            "full_conditional_fraction_by_feature": np.asarray(
                strategy.full_conditional_fraction_, dtype=float
            ).tolist(),
            "mean_support_weight_by_feature": np.asarray(
                strategy.mean_support_weight_, dtype=float
            ).tolist(),
            "feature_audit_file": feature_audit_path.name,
        },
        "bootstrap_stability_audit": {
            "replicates": replicates,
            "seed": seed,
            "anchor_count": int(strategy_contract["bootstrap_anchor_count"]),
            "anchor_region": "normal reconstruction quantiles 0.01 through 0.99",
            "conditional_curves": "reused from the matching frozen upstream normal bootstrap",
            "global_fallback": "refit on the identical normal bootstrap indices",
            "support_weights": "frozen from full normal calibration ESS and interpolated to anchors",
            "file": bootstrap_path.name,
            "sha256": sha256_file(bootstrap_path),
        },
        "reproducibility_check": {
            "state_reload_passed": True,
            "threshold_probe_rows": int(probe_rows.size),
            "reload_max_abs_error": reload_max_abs_error,
            "atol": 1e-12,
        },
        "calibration_visualization": figure_audit,
        "future_decision_contract": {
            "feature_rule": strategy_contract["future_feature_rule"],
            "window_score": strategy_contract["future_window_score"],
            "window_rule": strategy_contract["future_window_rule"],
            "frozen_before_test": True,
            "detection_executed_now": False,
        },
        "data_isolation": {
            "test_data_used": False,
            "test_labels_used": False,
            "detection_executed": False,
            "metrics_computed": False,
        },
        "notes": [
            "The original unstable 02 artifacts are retained unchanged for auditability.",
            "All new parameters use only frozen pure-normal calibration artifacts.",
            "No feature is deleted; sparse local support triggers a smooth global-normal fallback.",
            "This script exposes no test-file, test-label, detection, persistence, or metric argument.",
            "No anomaly-detection claim is made by this preparation artifact.",
        ],
    }
    artifact_path = output_dir / "threshold_artifact.json"
    save_json(artifact_path, artifact)
    print(f"{args.dataset}: 状态={status}", flush=True)
    print(
        "bootstrap 中位相对 CI 宽度最大值="
        f"{float(np.max(strategy.bootstrap_median_relative_ci_width_)):.6g}",
        flush=True,
    )
    print(
        "测试数据使用：否；异常检测执行：否；检测指标计算：否",
        flush=True,
    )
    print(f"正式工件：{artifact_path}", flush=True)
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
