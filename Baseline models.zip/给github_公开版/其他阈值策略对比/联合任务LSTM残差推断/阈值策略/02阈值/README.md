# 02 / 02b 阈值实验：条件 Gaussian KDE 与支持度感知稳定化

## 当前结论

02 原始迁移和 02b 支持度感知稳定化均已完成实现、无测试集单元测试、分钟级正常标定和秒级
正常标定。阈值拟合严格只使用对应的纯正常标定工件；在后续获得明确授权后，已使用冻结的 02b
工件对测试集执行分钟级与秒级异常检测。测试标签只在预测完成后用于评估，没有参与阈值拟合或调参。

原 02 两套工件没有通过预先冻结的局部有效样本数门禁：

| 时间尺度 | 数据集 | 正常窗口 | 临界函数数 | 通过特征 | 失败特征 | 最小中央 ESS | 状态 |
|---|---|---:|---:|---:|---|---:|---|
| 分钟级 | `dataset1` | 1960 | 8 | 1 | `0,1,2,4,5,6,7` | `2.0787` | `CALIBRATION_UNSTABLE` |
| 秒级 | `dataset2` | 20000 | 15 | 10 | `3,4,5,6,10` | `8.3577` | `CALIBRATION_UNSTABLE` |

原 02 冻结门禁为中央 98% 条件变量区域内 `ESS >= 50`。失败原因是部分重构输出区域只有很少的局部
正常样本，而不是 KDE 求根失败：所有特征的条件 CDF 求根误差约为 `1e-12` 或更小，保存后
重载阈值的最大绝对误差为 `0`。

为保留条件阈值并解决稀疏区不稳定，新增独立策略
`02b_support_aware_conditional_kde`：`ESS <= 50` 时使用同一特征的全局纯正常 KDE 99.9%
阈值，`ESS >= 100` 时保留原条件阈值，中间使用 smoothstep 平滑融合。它不删除特征，也没有
根据测试结果调参。

| 时间尺度 | 数据集 | 正常窗口 | 特征数 | 最大中位相对 95% CI 宽度 | 失败特征 | 02b 状态 |
|---|---|---:|---:|---:|---|---|
| 分钟级 | `dataset1` | 1960 | 8 | `0.566933` | 无 | `READY_FOR_TEST` |
| 秒级 | `dataset2` | 20000 | 15 | `0.364246` | 无 | `READY_FOR_TEST` |

冻结上限为 `0.75`；两套全局 KDE 最大 CDF 求根误差分别为 `1.22e-15` 和 `3.22e-15`，
状态重载误差均为 `0`。这两套 `READY_FOR_TEST` 工件随后被原样用于检测，未按测试表现回改
`ess_low/ess_high`、尾概率、特征顺序或全局回退阈值。

冻结检测已经完成，完整报告见
`02b/detection_results/detection_report.md`。分钟级 `dataset1` 的五 seed 平均 F1 为 `0.8056`、
召回率为 `0.6794`、特异度为 `0.9927`；秒级 `dataset2` 的五 seed 平均 F1 为 `0.6959`、
召回率为 `0.5411`、特异度为 `0.9860`。

实现依据与完整复现边界见
`02阈值与联合任务LSTM融合准备方案.md`。

## 方法口径

```text
固定联合任务 LSTM（eval + no_grad）
→ 同一次前向取得 reconstruction 和 absolute residual
→ 分别沿 10 步窗口取时间均值
→ 每个特征拟合 (reconstruction_mean, residual_mean) 二维 Gaussian KDE
→ Scott 带宽
→ 在残差非负支持域上归一化条件 CDF
→ 条件残差分布的 99.9% 临界函数
→ 线性插值，支持域外固定为边界值
→ 冻结工件
→ 在独立检测步骤中读取测试原始 x
→ 由当前冻结模型重新标准化
→ score = max_d(residual_d / threshold_d)
→ score > 1 判为异常
```

这是论文阈值模块向现有单个联合任务 LSTM 的迁移实现，不是论文五个 DAE 集成模型的端到端
严格复现。

## 固定双数据集映射

| 时间尺度 | 数据集 | 模型 | 正常标定集 | 特征数 | 正式工件目录 |
|---|---|---|---|---:|---|
| 分钟级 | `dataset1` | `dataset1_joint_seed10.pth` | `正常数据/阈值标定集.npz` | 8 | `artifacts/formal_dataset1` |
| 秒级 | `dataset2` | `dataset2_joint_seed10.pth` | `正常数据/new_raw_阈值标定集.npz` | 15 | `artifacts/formal_dataset2` |

两套数据分别拟合，不能合并或交叉使用工件。

## 实现文件

| 文件 | 作用 |
|---|---|
| `strategy_02_conditional_kde.py` | 联合 KDE、条件高斯混合 CDF、99.9% 求根、插值及状态恢复 |
| `prepare_02_conditional_kde.py` | 正常数据审计、模型前向、稳定性门禁、工件与正常标定图生成 |
| `experiment_config.json` | 双数据集哈希、公式参数、稳定性门禁与数据隔离配置 |
| `feature_order_contract.json` | 不改源 NPZ 的逐特征列顺序冻结 sidecar |
| `tests/test_strategy_02_conditional_kde.py` | 只使用合成正常数组的单元测试 |
| `02b/strategy_02b_support_aware_kde.py` | 02b 全局正常回退、smoothstep 融合和状态恢复 |
| `02b/prepare_02b_support_aware_kde.py` | 02b 上游审计、正常 bootstrap、稳定工件和审计图生成 |
| `02b/experiment_config_02b.json` | 02b 冻结参数、数据哈希和数据隔离合同 |
| `02b/tests/test_strategy_02b_support_aware_kde.py` | 02b 的 8 项无测试集单元测试 |
| `02b/detection_config.json` | 10 个测试文件哈希、模型/阈值哈希和冻结判定合同 |
| `02b/detect_02b_support_aware_kde.py` | 分钟级与秒级冻结检测、逐窗口结果、指标与图形导出 |
| `02b/verify_02b_detection.py` | 对 10 组测试重新前向并逐元素核对保存结果 |
| `02b/tests/test_detect_02b_support_aware_kde.py` | 检测口径、配置冻结和无调参 CLI 的 5 项测试 |

准备脚本故意不提供 `--test`、`--labels`、`--metrics`、`--k` 或 `--m` 参数。

## 正式准备命令

```powershell
python 阈值策略\02阈值\prepare_02_conditional_kde.py --dataset dataset1
```

```powershell
python 阈值策略\02阈值\prepare_02_conditional_kde.py --dataset dataset2
```

默认正式参数：

```text
tail_probability = 0.001
conditional_quantile = 0.999
grid_size = 512
support_extension_fraction = 0.2
minimum_samples = 1000
minimum_ess_in_central_98_percent = 50
bootstrap_replicates = 100
bootstrap_seed = 2026
```

## 标定工件状态

只有所有特征均通过样本量、中央区域 ESS、带宽条件数、CDF 求根和保存/重载门禁时，工件才
能标记为 `READY_FOR_TEST`。失败时状态为 `CALIBRATION_UNSTABLE`，不得进入真实测试，也不
静默回退到经验分位数。

本 README 只记录正常标定与稳定性审计结果，不包含任何异常检测结果。

## 已执行验证

```powershell
python -m unittest discover -s 阈值策略\02阈值\tests -p "test_*.py" -v
python -m unittest discover -s 阈值策略\02阈值\02b\tests -p "test_*.py" -v
```

结果：当前 `02b/tests` 共 13 项全部通过，包括输入门禁、全局 KDE 求根、支持度平滑边界、
状态重载、冻结判定规则、五 seed 汇总和检测 CLI 无阈值调参入口检查。原 02 的历史测试也已保留。

正式正常标定已执行：

```powershell
python 阈值策略\02阈值\prepare_02_conditional_kde.py --dataset dataset1
python 阈值策略\02阈值\prepare_02_conditional_kde.py --dataset dataset2
```

每套数据均执行 100 次纯正常 bootstrap。bootstrap 只用于稳定性审计，没有替换全量正常标定
数据得到的临界函数。

## 正常标定审计工件

两套目录均保留完整失败审计，而不是删除或伪装成可用阈值：

```text
artifacts/formal_dataset1/
artifacts/formal_dataset2/
```

每个目录包含：

- `threshold_artifact.json`：状态、模型/数据哈希、失败特征和数据隔离声明；
- `critical_functions.npz`：冻结临界函数，仅供审计，当前禁止用于测试；
- `kde_state.npz`：带宽协方差、ESS 和求根误差；
- `calibration_pairs.npz`：纯正常重构均值/残差均值配对；
- `bootstrap_audit.npz`：100 次正常 bootstrap 曲线；
- `feature_fit_audit.csv`：逐特征稳定性结果；
- `normal_calibration_audit.json`：正常标签、标准化器和特征顺序证据；
- `calibration_critical_functions.{png,svg,pdf,tiff}`：仅含正常数据的审计图。

图形源代码检查为 20 项通过、0 警告、0 失败；两个 PDF 的最小实际文字字号均为 7 pt。

## 02b 稳定工件与命令

```powershell
python 阈值策略\02阈值\02b\prepare_02b_support_aware_kde.py --dataset dataset1
python 阈值策略\02阈值\02b\prepare_02b_support_aware_kde.py --dataset dataset2
```

输出目录：

```text
02b/artifacts/stable_dataset1/
02b/artifacts/stable_dataset2/
```

每套目录包含冻结曲线、全局回退状态、100 次纯正常 bootstrap、逐特征 CSV、数据隔离审计 JSON
和 PNG/SVG/PDF/TIFF 审计图。图形源代码严格预检为 20 项通过、0 警告、0 失败；两个 02b PDF
的最小实际文字字号均为 6.5 pt。完整公式、实测结果和限制见
`02b/02b支持度感知稳定化方案.md`。

## 冻结检测结果

正式命令：

```powershell
python 阈值策略\02阈值\02b\detect_02b_support_aware_kde.py --dataset all
python 阈值策略\02阈值\02b\verify_02b_detection.py
```

检测只读取测试文件的原始 `x`，没有使用与当前模型不一致的测试文件 `x_std/mean/std`；原始
数据由当前冻结联合任务 LSTM 重新标准化。窗口判定为严格的 `score > 1`，且未对平衡采样的
测试窗口添加不适用的 k/m 时序持续性后处理。

10 组测试的完整复算结果为 `VERIFIED`：重构均值、残差、阈值、残差/阈值比值、窗口分数、
逐特征触发和最终预测在保存精度下完全一致，预测不一致窗口数为 `0`。

## 当前状态

```text
02_ORIGINAL_AUDITED (UNSTABLE, RETAINED)
→ 02b_IMPLEMENTED
→ 02b_UNIT_TESTED
→ 02b_DATASET1 (READY_FOR_TEST)
→ 02b_DATASET2 (READY_FOR_TEST)
→ FROZEN_TEST_DETECTION_COMPLETED
→ FULL_RECOMPUTATION_VERIFIED
```

检测结果位于 `02b/detection_results/`。逐窗口 CSV/NPZ、逐 seed 指标、逐异常类型检测率、
可编辑矢量图、复现审计和实验清单均已保留。结果显示两套检测均具有很高的精确率与特异度，
但召回率为中等水平，尤其秒级数据仍有较多漏检；后续改进应作为新的、独立的开发/验证实验，
不能回写本次冻结结果。
