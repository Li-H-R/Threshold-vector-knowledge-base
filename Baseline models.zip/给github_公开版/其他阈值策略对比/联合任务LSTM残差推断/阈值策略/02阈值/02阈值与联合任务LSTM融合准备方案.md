# 02 阈值与联合任务 LSTM 融合：异常检测前准备方案

## 0. 本文件的范围

本方案只说明并约束 **02 阈值方法与现有联合任务 LSTM 的融合准备工作**。当前阶段：

- 不读取分钟级或秒级测试样本；
- 不读取测试标签；
- 不生成测试得分、异常标签或报警序列；
- 不计算 Precision、Recall、F1、PR-AUC 等检测指标；
- 不根据测试结果选择参数；
- 不重新训练联合任务 LSTM。

本阶段允许使用的内容只有：

- `02阈值/02.pdf`；
- 两个已经训练完成的联合任务 LSTM checkpoint；
- 两套纯正常阈值标定集；
- 正常标定集经过对应 LSTM 后得到的重构输出与绝对重构残差；
- 固定随机种子产生的合成数组，用于公式和程序单元测试。

计划中的停止点为：

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1 / CALIBRATED_DATASET2
→ READY_FOR_TEST
→ 停止
```

`READY_FOR_TEST` 只表示两套正常标定工件已经冻结，并不表示已经执行异常检测。

本文所述策略代码、单元测试和两套正常标定审计现已完成。两套标定均因局部有效样本数不足
被标记为 `CALIBRATION_UNSTABLE`，尚未达到 `READY_FOR_TEST`，且未执行异常检测。

---

## 1. 参考依据与论文方法确认

### 1.1 统一实验约束

本方案参考 `阈值策略/统一阈值实验工作流.md`，固定以下原则：

- 分钟级与秒级使用各自的模型、正常标定集和正式工件；
- 模型使用 `eval()` 和 `torch.no_grad()`，不重新训练；
- 残差位于 checkpoint 对应的标准化空间；
- 残差定义保持为窗口内逐特征绝对重构残差的时间均值；
- 测试集不参与 KDE、条件分位数、支持域、网格或任何稳定性参数的确定；
- 分钟级和秒级不得共用联合 KDE 或临界函数；
- 正式标定后冻结配置、模型哈希、数据哈希和策略工件。

### 1.2 02 论文信息

| 项目 | 内容 |
|---|---|
| 标题 | *A new auto-encoder-based dynamic threshold to reduce false alarm rate for anomaly detection of steam turbines* |
| 作者 | Jin Uk Ko, Kyumin Na, Joon-Seok Oh, Jaedong Kim, Byeng D. Youn |
| 期刊 | Expert Systems with Applications 189 (2022) 116094 |
| DOI | `10.1016/j.eswa.2021.116094` |
| 本地全文 | `阈值策略/02阈值/02.pdf` |
| 阈值核心位置 | 第 3.1 节，图 5，公式 (5)～(7) |

论文的阈值链路不是普通的固定标量阈值，也不是随时间滚动更新的阈值。其核心是：

```text
正常数据的模型重构输出 y
+ 与 y 对应的绝对残差 r
→ 对每个变量拟合二维联合 Gaussian KDE：f(y, r)
→ 在给定 y 的条件下求残差上侧置信限 q(y)
→ 对离散临界点线性插值，形成临界函数 g(y)
→ 新样本的模型输出不同，使用的残差阈值也不同
```

因此，论文所谓 dynamic threshold 的“动态”主要是 **阈值随当前模型重构输出/运行水平变化**，
不是使用测试历史不断重新拟合参数。02 的正式准备仍然可以完全在纯正常标定集上完成。

### 1.3 论文原始数学定义

对某个变量，论文把模型输出记为 `y`，相应的绝对残差记为 `r`。先使用 Gaussian kernel 和
Scott 带宽拟合二维联合密度：

\[
f(y,r).
\]

对规则网格上的某个输出值 \(y_k\)，条件残差密度为：

\[
h(r;y=y_k)=
\frac{f(y_k,r)}{\int_{-\infty}^{+\infty} f(y_k,r)\,dr}.
\]

论文用尾部概率 \(p\) 定义临界点 \(q_k\)：

\[
\int_{-\infty}^{q_k} h(r;y=y_k)\,dr=1-p.
\]

论文实验将 `p` 设为 `1e-3`，因此对应条件分位数为：

```text
tail_probability = 0.001
conditional_quantile = 0.999
```

所有 \((y_k,q_k)\) 线性插值后形成临界函数 \(g(y)\)。论文还把插值支持域外的两端阈值
固定为边界值，避免在稀疏区域不稳定外推。

### 1.4 复现定位

本项目只能标记为 **阈值模块迁移实现（threshold-module migrated implementation）**，不能
标记为论文端到端严格复现，原因包括：

1. 论文使用 5 个 DAE 的集成平均输出，本项目使用一个联合任务 LSTM-AE；
2. 论文输入是单时刻多变量数据，本项目输入是长度为 10 的序列窗口；
3. 论文模型训练时加入不同白噪声并执行去噪任务，本项目 checkpoint 的训练目标不同；
4. 论文使用训练集与验证集的正常输出/残差建阈值，本项目使用独立纯正常阈值标定集；
5. 论文原始信号采用 min-max 缩放，本项目模型固定使用 checkpoint 标准化器；
6. 本项目不替换模型，只迁移公式 (5)～(7) 的条件 KDE 临界函数；
7. 秒级风机数据属于跨设备、跨变量数和跨采样频率迁移。

项目可准确声称的是：

> 使用现有联合任务 LSTM 的正常重构输出和正常绝对残差，迁移 Ko 等人提出的联合 KDE
> 条件临界函数，建立逐特征、随模型输出变化的动态阈值。

---

## 2. 两套数据的固定对应关系

| 项目 | 分钟级 | 秒级 |
|---|---|---|
| 数据集标识 | `dataset1` | `dataset2` |
| 时间尺度 | 1 分钟级 | 秒级 |
| checkpoint | `models/dataset1_joint_seed10.pth` | `models/dataset2_joint_seed10.pth` |
| checkpoint SHA-256 | `adc97f5c48eb4b8e15dab7fa7ac09afe54cc01f88dab8986c5f7340daa96a4fa` | `ec92a82289f8e0e1f497570eedc9c008e19b86d70a24982d4a9d83fb19718d61` |
| 正常标定集 | `正常数据/阈值标定集.npz` | `正常数据/new_raw_阈值标定集.npz` |
| 标定集 SHA-256 | `99376a1f9cb781b0f51be4fe61f4cca64c880e27b5cf742cc942ccd8ac7cd42d` | `a95fd8ce46860252f2ea01bd33f26fc39f467be43316cd654cd3d0b6e62cfabc` |
| 标定形状 | `(1960, 10, 8)` | `(20000, 10, 15)` |
| 正常标签审计 | `y=0` 共 1960 个 | `y=0` 共 20000 个 |
| 窗口长度 | 10 | 10 |
| 特征维数 | 8 | 15 |
| 模型输入空间 | `standardized` | `standardized` |
| 需要拟合的临界函数数 | 8 | 15 |
| 目标工件目录 | `02阈值/artifacts/formal_dataset1` | `02阈值/artifacts/formal_dataset2` |

固定映射：

```text
分钟级正常标定集
→ dataset1 模型
→ 8 组 (reconstruction_mean, residual_mean)
→ 8 条条件临界函数
→ formal_dataset1

秒级正常标定集
→ dataset2 模型
→ 15 组 (reconstruction_mean, residual_mean)
→ 15 条条件临界函数
→ formal_dataset2
```

禁止：

- 合并两套正常数据后拟合一个 KDE；
- 用分钟级的临界函数处理秒级变量；
- 用秒级的临界函数处理分钟级变量；
- 把不同特征的数据堆叠成一条公共临界函数；
- 使用测试数据扩展 KDE 支持域或重算边界；
- 根据未来检测结果修改 `p=0.001`、网格数、带宽或回退规则。

### 2.1 分钟级标定数据的元数据门禁

分钟级 `正常数据/阈值标定集.npz` 虽然含 `X/y/sample_id/timestamp` 等字段，但没有把以下
信息完整写进文件内部：

- `dataset`；
- `input_space`；
- `window_size`；
- `feature_dimension`；
- `checkpoint_sha256`；
- `standardizer_mean/std`；
- 明确的特征名称与顺序。

02 是逐特征拟合方法，特征顺序错误会使整个工件失效。正式准备前必须建立只读 sidecar 或
生成带完整元数据的新标定文件；不要原地覆盖现有 NPZ。至少要证明：

```text
dataset1
input_space = standardized
window_size = 10
feature_dimension = 8
feature_order 与 dataset1 checkpoint 训练输入一致
```

如果只能确认维数而不能确认特征顺序，02 分钟级工件不得标记为 `READY_FOR_TEST`。

### 2.2 秒级标定数据的说明

秒级 NPZ 已记录数据集、输入空间、窗口长度、维数、标准化器和 checkpoint 哈希。它采用对
全部合法窗口起点的均匀抽样。02 的离线联合 KDE 不依赖时间顺序，因此该抽样方式可以用于
标定；但其样本相关性和覆盖范围仍应写入工件审计。

---

## 3. 与联合任务 LSTM 的融合数学链路

### 3.1 一次前向同时取得重构与残差

现有 `main.compute()` 已支持：

```python
residual, reconstruction = compute(
    x,
    dataset="dataset1_or_dataset2",
    absolute=True,
    standardized=True,
    return_recon=True,
)
```

其中：

```text
reconstruction.shape = (N, 10, D)
residual.shape       = (N, 10, D)
residual             = abs(reconstruction - standardized_input)
D                     = 8 或 15
```

不得分别执行两次模型前向来生成 `y` 和 `r`。两者必须来自同一次确定性前向，保证逐元素对应。

模型要求：

```text
model.eval()
torch.no_grad()
dropout 不重新开启
checkpoint 不改变
```

论文使用模型集成，但本阶段不训练额外模型、不使用 MC dropout。否则实验变化将不再只属于
阈值模块。

### 3.2 已标准化 NPZ 的输入处理

`main.compute()` 的公开入口按原始量纲输入并在内部应用 checkpoint 标准化器。两套正式 NPZ
目前保存的是标准化窗口，因此准备脚本必须沿用 00 的已验证规则：

```text
读取 standardized X
→ 使用 checkpoint mean/std 精确反变换为 raw 量纲
→ 交给 main.compute()
→ main.compute() 使用同一 mean/std 恢复模型标准化输入
```

这样可以避免对已经标准化的数组再次标准化。准备脚本必须对反变换/再标准化的最大绝对误差
设置门禁并记录结果。

### 3.3 从序列窗口迁移到逐窗口阈值输入

论文在单时刻上对每个变量建立 `(y, r)`。本项目窗口长度为 10。为保持统一工作流中已经冻结
的残差定义，正式首版采用窗口时间均值：

\[
\bar y_{i,d}=\frac{1}{10}\sum_{t=1}^{10}\hat x_{i,t,d},
\]

\[
\bar r_{i,d}=\frac{1}{10}\sum_{t=1}^{10}
\left|\hat x_{i,t,d}-x_{i,t,d}\right|.
\]

于是：

```text
reconstruction_mean.shape = (N, D)
residual_mean.shape       = (N, D)
```

这一步是论文向序列窗口模型迁移时的明确改动。不要同时把 `(N,10,D)` 展平为 `(N*10,D)`，
否则会：

- 改变统一工作流的残差口径；
- 把重叠窗口内同一时刻重复计入；
- 人为放大有效样本数；
- 使分钟级与秒级的样本相关性更难解释。

### 3.4 每个特征独立拟合联合 KDE

对特征 `d`，仅使用对应数据集的纯正常标定对：

\[
Z_d=\{(\bar y_{i,d},\bar r_{i,d})\}_{i=1}^{N}.
\]

拟合二维 Gaussian KDE：

\[
\hat f_d(y,r)=\frac{1}{N}\sum_{i=1}^{N}
\mathcal N\left(
\begin{bmatrix}y\\r\end{bmatrix};
\begin{bmatrix}\bar y_{i,d}\\\bar r_{i,d}\end{bmatrix},
H_d
\right).
\]

首版正式配置固定：

```text
kernel = gaussian
bandwidth_rule = scott
kde_dimension = 2
tail_probability = 0.001
conditional_quantile = 0.999
grid_size = 512
interpolation = linear
outside_support = flatten_to_boundary
```

二维 Scott factor 为：

\[
N^{-1/(2+4)}=N^{-1/6}.
\]

不得把论文其他数据集上的带宽数值复制到本项目。每个数据集、每个特征都由自己的正常标定对
确定协方差带宽矩阵。

### 3.5 标准化输出下的支持域修正

论文对 min-max 数据使用：

```text
y_lower = 0.8 * min(y)
y_upper = 1.2 * max(y)
```

当前模型输出位于标准化空间，可能包含负数。对负的最小值直接乘 `0.8` 会把下界向数据内部
移动，失去论文设置边界的本意。因此本迁移版本使用与数值符号无关的区间扩展：

\[
\Delta_d=y_{d,\max}-y_{d,\min},
\]

\[
y_{d,\mathrm{lower}}=y_{d,\min}-0.2\Delta_d,
\qquad
y_{d,\mathrm{upper}}=y_{d,\max}+0.2\Delta_d.
\]

这一差异必须写入 README 和工件，不能描述为论文原公式。若 `Δ` 接近 0，应拒绝拟合该特征，
而不是静默构造任意区间。

### 3.6 条件 99.9% 临界函数

对每个网格值 \(y_{d,k}\)，计算：

\[
h_d(r\mid y_{d,k})=
\frac{\hat f_d(y_{d,k},r)}
{\int \hat f_d(y_{d,k},u)\,du}.
\]

再求：

\[
q_{d,k}=F^{-1}_{R_d\mid Y_d=y_{d,k}}(0.999).
\]

绝对残差理论支持域为 \([0,+\infty)\)，而 Gaussian KDE 会向负半轴泄漏概率质量。首次正式
数值门禁发现，标准化输出的稀疏扩展区可能因此产生非正临界值。正式实现采用正半轴条件 CDF：

\[
F_{+,d}(q\mid y)=
\frac{F_d(q\mid y)-F_d(0\mid y)}{1-F_d(0\mid y)},\qquad q\ge 0,
\]

并求 \(F_{+,d}(q\mid y)=0.999\)。工件逐特征记录 `max_negative_kde_mass`。这是一项针对
非负绝对残差的数值边界修正，已作为论文偏离项公开记录，不改变正常数据或模型输出。

实现时可以利用 Gaussian KDE 的条件高斯混合形式精确计算条件 CDF，再用确定性求根得到
`q[d,k]`。这样与二维联合 KDE 的数学定义一致，同时避免在极端尾部使用粗糙的残差积分网格。

把网格点线性插值后得到逐特征临界函数：

\[
g_d(y)=\operatorname{LinearInterp}
\left(\{(y_{d,k},q_{d,k})\}_{k=1}^{512}\right).
\]

支持域外按论文思想固定为边界值：

\[
g_d(y)=
\begin{cases}
g_d(y_{d,\mathrm{lower}}), & y\le y_{d,\mathrm{lower}},\\
g_d(y), & y_{d,\mathrm{lower}}<y<y_{d,\mathrm{upper}},\\
g_d(y_{d,\mathrm{upper}}), & y\ge y_{d,\mathrm{upper}}.
\end{cases}
\]

### 3.7 未来检测接口的定义（当前不执行）

将来用户单独授权异常检测后，对一个新窗口只加载冻结工件并计算：

\[
\tau_{i,d}=g_d(\bar y_{i,d}),
\]

\[
e_{i,d}=\frac{\bar r_{i,d}}{\tau_{i,d}+\epsilon}.
\]

逐特征超限规则：

\[
a_{i,d}=\mathbb 1[\bar r_{i,d}>\tau_{i,d}].
\]

为了与统一工作流的一窗口一行输出对接，预先定义：

\[
\mathrm{score}_{02,i}=\max_d e_{i,d},
\qquad
\mathrm{point\_pred}_{02,i}=\mathbb 1[\mathrm{score}_{02,i}>1].
\]

同时保留：

```text
feature_thresholds: (N, D)
feature_exceedance_ratios: (N, D)
feature_predictions: (N, D)
window_score: (N,)
window_prediction: (N,)
```

当前阶段只冻结这一接口定义，不创建上述测试输出。

### 3.8 维数差异与窗口级误报风险

`dataset1` 有 8 个特征，`dataset2` 有 15 个特征。若每个特征都用 `p=0.001` 且窗口规则为
“任一特征超限”，在特征独立的理想近似下窗口误报概率约为：

\[
1-(1-0.001)^D.
\]

因此 8 维和 15 维的窗口级名义误报率本来就不同。主迁移版本仍保留论文的逐特征
`p=0.001`，不在测试集上做多重比较修正。未来报告必须：

- 同时报告逐特征与窗口级结果；
- 不把两个时间尺度的误报数直接拼接；
- 将 Šidák/Bonferroni 修正作为单独消融，而不是事后修补主结果。

---

## 4. 与“统一 Mahalanobis 得分”主实验的关系

02 论文方法与 00/01 存在一个不能隐藏的结构差异：

| 方案 | 阈值输入 | 阈值输出 |
|---|---|---|
| 00 | 单一 Mahalanobis score | 单一固定标量 |
| 01 | 单一 Mahalanobis score | KDE 99.7% 固定标量 |
| 02 原论文迁移 | 每个特征的 reconstruction + residual | 每个特征随 reconstruction 变化的阈值 |

因此，02 的论文忠实迁移不能被描述成“只在同一 Mahalanobis score 上换了一条阈值线”。

推荐分成两个层次：

### 4.1 02-A：论文阈值模块迁移（本方案主线）

```text
输入：reconstruction_mean + residual_mean
输出：逐特征 g_d(y) 和 max exceedance ratio
用途：评价 EDAE-DT 条件临界函数与现有 LSTM 的完整融合效果
比较类别：完整检测规则对比
```

02-A 应与 00/01 使用相同模型、数据划分和残差，但不应伪装成“同一标量得分纯阈值消融”。

### 4.2 02-B：统一标量得分的受控适配（可选，不在首版实现）

如果研究必须把 02 放入“同一 Mahalanobis score”主表，可预先定义一个额外适配：

```text
正常 reconstruction_mean
→ 只在正常标定集拟合 PCA
→ 第一主成分 c 作为一维运行水平

(c, mahalanobis_score)
→ 二维联合 KDE
→ 条件阈值 tau(c)
```

该版本保持 `score=Mahalanobis`，但 PCA 条件变量不是论文原方法，只能标记为
`02-inspired scalar adaptation`。它应使用独立策略 ID 和独立工件，不能覆盖 02-A。

首版建议先实现 02-A；除非最终比较协议明确要求，否则不要同时增加 02-B，避免扩大实验范围。

---

## 5. 推荐程序结构

```text
02阈值/
├── 02.pdf
├── 02阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_02_conditional_kde.py
├── prepare_02_conditional_kde.py
├── experiment_config.json
├── tests/
│   └── test_strategy_02_conditional_kde.py
└── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
```

当前阶段不创建或不运行 `detect_02_conditional_kde.py`。未来若为了接口完整性创建检测脚本，
在用户授权前也不得传入真实测试文件。

### 5.1 策略类职责

`strategy_02_conditional_kde.py` 只处理已经对齐的正常 `(y_mean, residual_mean)`，不加载
LSTM、不读取原始数据：

```python
class ConditionalKDECriticalFunction:
    strategy_id = "02_conditional_kde"

    def fit(self, reconstruction_mean, residual_mean):
        """按特征拟合二维 KDE 和条件 0.999 临界函数。"""
        ...

    def thresholds(self, reconstruction_mean):
        """仅使用冻结临界函数产生 (N,D) 阈值矩阵。"""
        ...

    def state_dict(self):
        """返回网格、临界值、边界、带宽和审计信息。"""
        ...

    @classmethod
    def from_state_dict(cls, state):
        """恢复冻结临界函数；不得重新拟合。"""
        ...
```

正式检测只需要冻结的 `y_grid` 和 `q_grid` 做插值，不需要读取正常标定集重新训练 KDE。

### 5.2 准备脚本职责

`prepare_02_conditional_kde.py` 的流程：

```text
读取 dataset1 或 dataset2 冻结配置
→ 校验 checkpoint SHA-256
→ 校验正常标定文件 SHA-256
→ 校验标签全部为 0
→ 校验输入空间、窗口长度、特征维数和特征顺序
→ standardized 数据按同一标准化器反变换后送入 main.compute
→ 单次批量前向同时取得 reconstruction 和 residual
→ 分别沿时间维取均值
→ 对 D 个特征分别拟合联合 Gaussian KDE
→ 求条件 0.999 临界函数
→ 运行稳定性与数值审计
→ 保存并重新加载工件
→ 检查重载前后阈值矩阵完全一致
→ 状态写为 READY_FOR_TEST
→ 停止
```

建议参数：

```text
--dataset dataset1|dataset2
--calibration <纯正常标定 NPZ>
--input-space standardized
--tail-probability 0.001
--bandwidth-rule scott
--grid-size 512
--output-dir <02 对应正式目录>
```

准备脚本不提供：

```text
--test
--test-labels
--metrics
--k
--m
```

这样可从命令行接口层面阻止准备阶段意外开始异常检测。

### 5.3 配置文件建议

`experiment_config.json` 至少冻结：

```json
{
  "strategy_id": "02_conditional_kde",
  "reproduction_type": "threshold_module_migrated",
  "kernel": "gaussian",
  "bandwidth_rule": "scott",
  "kde_dimension": 2,
  "tail_probability": 0.001,
  "conditional_quantile": 0.999,
  "residual_support": [0.0, "positive_infinity"],
  "positive_support_renormalized": true,
  "grid_size": 512,
  "interpolation": "linear",
  "support_extension_fraction": 0.2,
  "outside_support": "flatten_to_boundary",
  "window_reconstruction_definition": "mean over time of reconstruction in standardized space",
  "window_residual_definition": "mean over time of abs(reconstruction-input) in standardized space",
  "future_window_score": "max_d(residual_d / threshold_d)",
  "future_window_decision": "window_score > 1",
  "persistence": {"k": 1, "m": 1},
  "test_file": null,
  "test_labels": null
}
```

---

## 6. 正式准备阶段的输出

每套数据分别生成：

```text
artifacts/formal_datasetX/
├── threshold_artifact.json
├── critical_functions.npz
├── kde_state.npz
├── calibration_pairs.npz
├── feature_fit_audit.csv
├── normal_calibration_audit.json
└── calibration_critical_functions.png
```

文件职责：

| 文件 | 作用 |
|---|---|
| `threshold_artifact.json` | 总契约、哈希、方法偏离、状态和数据隔离声明 |
| `critical_functions.npz` | 冻结的 `y_grid[D,G]`、`q_grid[D,G]`、上下边界和插值参数 |
| `kde_state.npz` | 每个特征的标定对、Scott factor、带宽协方差及数值状态 |
| `calibration_pairs.npz` | 正常 `reconstruction_mean` 与 `residual_mean`，便于审计 |
| `feature_fit_audit.csv` | 每个特征样本数、方差、相关性、条件数、ESS、bootstrap 摘要 |
| `normal_calibration_audit.json` | 正常标签、数据/模型/标准化器和特征顺序证据 |
| `calibration_critical_functions.png` | 只显示正常标定散点与临界函数，不含测试数据 |

### 6.1 `threshold_artifact.json` 最低字段

```json
{
  "schema_version": 1,
  "strategy_id": "02_conditional_kde",
  "status": "READY_FOR_TEST",
  "formal_result_allowed": true,
  "dataset": "dataset1_or_dataset2",
  "time_scale": "minute_or_second",
  "model": {
    "checkpoint": null,
    "checkpoint_sha256": null,
    "window_size": 10,
    "input_dim": null,
    "eval_mode": true,
    "single_forward_for_recon_and_residual": true
  },
  "calibration": {
    "source_path": null,
    "source_sha256": null,
    "num_windows": null,
    "label_counts": {"0": null},
    "input_space": "standardized",
    "feature_order_evidence": null
  },
  "pair_definition": {
    "condition": "mean over time of reconstruction",
    "residual": "mean over time of abs(reconstruction-input)",
    "space": "standardized"
  },
  "threshold": {
    "method": "featurewise_conditional_gaussian_kde",
    "kernel": "gaussian",
    "bandwidth_rule": "scott",
    "tail_probability": 0.001,
    "conditional_quantile": 0.999,
    "residual_support": [0.0, "positive_infinity"],
    "positive_support_renormalized": true,
    "grid_size": 512,
    "interpolation": "linear",
    "outside_support": "flatten_to_boundary",
    "critical_functions_file": "critical_functions.npz"
  },
  "future_decision_contract": {
    "feature_rule": "residual_d > g_d(reconstruction_d)",
    "window_score": "max_d(residual_d / g_d(reconstruction_d))",
    "window_rule": "window_score > 1",
    "persistence_for_main_experiment": {"k": 1, "m": 1}
  },
  "paper_deviations": [],
  "test_data_used": false,
  "test_labels_used": false,
  "detection_executed": false,
  "metrics_computed": false
}
```

### 6.2 只基于正常标定数据的图

`calibration_critical_functions.png` 可以按特征分页或多面板显示：

- 横轴：正常标定 `reconstruction_mean`；
- 纵轴：正常标定 `residual_mean`；
- 正常标定散点或二维密度；
- 条件 99.9% 临界函数；
- 特征索引、样本数、Scott factor 和支持域。

禁止叠加测试点、故障区间、测试标签、报警区域或检测指标。

---

## 7. 不使用真实测试集的单元测试门禁

所有单元测试只使用人工构造数组或固定随机种子的合成正常对：

1. **形状检查**：`y` 与 `r` 必须是相同的非空 `(N,D)`；
2. **数值检查**：NaN、Inf、负残差必须报错；
3. **方差检查**：条件变量或残差近零方差时拒绝拟合；
4. **KDE 检查**：带宽协方差必须有限且可逆，病态矩阵不静默通过；
5. **条件 CDF 检查**：每个 `q[d,k]` 对应的条件 CDF 接近 `0.999`；
6. **插值检查**：网格内部线性插值结果与预期一致；
7. **边界检查**：低于下界和高于上界时分别固定为边界阈值；
8. **逐特征独立性检查**：改变特征 `d2` 的标定对不影响 `d1` 的临界函数；
9. **双数据集隔离检查**：dataset1 和 dataset2 工件不能交叉加载；
10. **保存/加载检查**：重载后临界函数和给定 `y` 的阈值逐元素一致；
11. **确定性检查**：同一输入和配置重复拟合得到相同工件；
12. **哈希门禁**：模型或正常标定文件哈希变化时拒绝写入正式目录；
13. **正常标签门禁**：标定标签存在非零值时拒绝拟合；
14. **输入空间门禁**：standardized 数据不得被二次标准化；
15. **无测试参数检查**：准备脚本不存在真实测试文件或测试标签参数；
16. **状态检查**：合成数据工件只能标记 `SELF_CHECK_ONLY_NOT_FOR_RESULTS`；
17. **窗口得分接口检查**：只在合成数组上验证 `max residual/threshold` 的形状与公式；
18. **正式输出检查**：工件必须明确写入 `detection_executed=false`。

---

## 8. 条件尾部的稳定性审计

### 8.1 样本量风险

02 使用的是 **局部条件 99.9% 分位数**，比 01 的一维 99.7% KDE 更难稳定估计：

- 分钟级 `N=1960`，全局尾部概率 `0.001` 名义上只对应约 1.96 个样本；
- 秒级 `N=20000`，全局尾部概率 `0.001` 名义上约对应 20 个样本；
- 条件 KDE 在某个 `y` 附近的有效样本数会进一步减少。

因此，论文参数可以保留，但不能因为公式成功返回有限值就认为标定稳定。

### 8.2 必须记录的审计量

每个特征至少记录：

- `var(y)`、`var(r)` 和相关系数；
- 带宽协方差矩阵及条件数；
- 各网格点归一化条件权重的有效样本数：

\[
ESS(y_k)=\frac{1}{\sum_i w_i(y_k)^2};
\]

- 中央 98% 条件变量区域内的最小、P5 和中位 ESS；
- 条件临界函数的最小值、最大值和非有限值数量；
- 固定随机种子 bootstrap 临界函数区间；
- 重载前后最大绝对差异。

### 8.3 推荐稳定性门禁

在运行正式拟合前，把以下门禁值写入配置并冻结：

```text
minimum_samples = 1000
minimum_ess_in_central_region = 50
maximum_bandwidth_condition_number = 1e12
bootstrap_replicates = 100
bootstrap_seed = 2026
```

bootstrap 只用于诊断，不允许根据测试表现挑选某次重采样结果，也不改变全量正常标定数据得到的
正式临界函数。

若分钟级数据未通过稳定性门禁，应将状态保持为 `CALIBRATION_UNSTABLE`，并停止进入真实测试。
不得静默回退到经验分位数；若以后需要回退策略，应建立新的策略 ID 和独立实验。

---

## 9. 推荐实施顺序

### 步骤 1：冻结方法卡

- 确认论文公式 (5)～(7)；
- 固定 Gaussian kernel、Scott 带宽和 `p=0.001`；
- 明确 02 是条件阈值，不是时间滚动阈值；
- 明确只迁移阈值模块，不复现五 DAE 集成；
- 固定窗口级 `(reconstruction_mean, residual_mean)` 定义；
- 固定标准化空间的符号无关支持域扩展。

完成状态：`FORMULA_VERIFIED`。

### 步骤 2：完成两套输入审计

- 核对模型与正常标定 SHA-256；
- 核对 `y` 全为 0；
- 核对窗口长度和特征维数；
- 核对标准化器；
- 补充分钟级数据的特征顺序证据；
- 确认准备脚本不暴露测试入口。

完成状态：`INTERFACE_DEFINED`。

### 步骤 3：实现策略与准备脚本

- 新增 `strategy_02_conditional_kde.py`；
- 新增 `prepare_02_conditional_kde.py`；
- 新增冻结配置和单元测试；
- 不创建测试结果目录；
- 不读取 `测试集数据/` 下的数组或标签。

完成状态：`IMPLEMENTED`。

### 步骤 4：运行合成单元测试

- 公式与求根测试；
- 插值与边界固定测试；
- 状态保存/加载测试；
- 双数据集隔离测试；
- 输入空间、哈希和数据泄漏门禁测试。

完成状态：`UNIT_TESTED`。

### 步骤 5：分别生成两套正常标定工件

未来可执行的分钟级准备命令：

```powershell
python 阈值策略\02阈值\prepare_02_conditional_kde.py `
  --dataset dataset1 `
  --calibration 正常数据\阈值标定集.npz `
  --input-space standardized `
  --tail-probability 0.001 `
  --bandwidth-rule scott `
  --grid-size 512 `
  --output-dir 阈值策略\02阈值\artifacts\formal_dataset1
```

未来可执行的秒级准备命令：

```powershell
python 阈值策略\02阈值\prepare_02_conditional_kde.py `
  --dataset dataset2 `
  --calibration 正常数据\new_raw_阈值标定集.npz `
  --input-space standardized `
  --tail-probability 0.001 `
  --bandwidth-rule scott `
  --grid-size 512 `
  --output-dir 阈值策略\02阈值\artifacts\formal_dataset2
```

以上两个命令已在 2026-11-04 执行，且只读取对应的纯正常标定集。

只有两套工件都通过门禁后，状态才能成为：

```text
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
```

实际结果为：

```text
dataset1: CALIBRATION_UNSTABLE
  最小中央 ESS = 2.0787
  失败特征 = 0,1,2,4,5,6,7

dataset2: CALIBRATION_UNSTABLE
  最小中央 ESS = 8.3577
  失败特征 = 3,4,5,6,10
```

因此当前停止，不能进入异常检测。

---

## 10. 当前阶段验收清单

- [x] 已阅读 02 全文并核对阈值核心公式；
- [x] 已确认 02 为 `reconstruction-residual` 联合 KDE 条件临界函数；
- [x] 已确认论文使用 Gaussian kernel 与 Scott 带宽；
- [x] 已确认论文实验尾部概率为 `p=1e-3`；
- [x] 已确认本项目只能标记为阈值模块迁移实现；
- [x] 已固定分钟级与秒级模型、正常标定集和目标工件的一一映射；
- [x] 已固定窗口级 `reconstruction_mean` 与 `residual_mean` 接口；
- [x] 已识别 02 与统一 Mahalanobis 标量主实验的结构差异；
- [x] 已识别分钟级标定元数据和特征顺序证据缺口；
- [x] 已建立只读特征列顺序 sidecar，保留源列编号且未虚构传感器语义名称；
- [x] 已设计不使用测试集的单元测试与稳定性门禁；
- [x] 当前未加载测试样本数组或测试标签；
- [x] 当前未执行异常检测；
- [x] 已实现 02 策略源代码；
- [x] 已运行 02 单元测试（8 项全部通过）；
- [x] 已拟合并审计分钟级临界函数；
- [x] 已拟合并审计秒级临界函数；
- [ ] 尚未生成 `READY_FOR_TEST` 工件；
- [ ] 尚未执行分钟级或秒级异常检测。

当前状态：

```text
FORMULA_VERIFIED
INTERFACE_DEFINED
IMPLEMENTED
UNIT_TESTED
CALIBRATED_DATASET1（CALIBRATION_UNSTABLE）
CALIBRATED_DATASET2（CALIBRATION_UNSTABLE）
STOPPED_BEFORE_DETECTION
```

---

## 11. 最终原则

02 与联合任务 LSTM 的正确融合不是重新训练一个 EDAE，也不是把 02 错写成普通固定阈值，
而是：

```text
固定联合任务 LSTM
→ 对纯正常标定窗口进行一次确定性前向
→ 同时取得标准化空间 reconstruction 与 absolute residual
→ 分别沿窗口时间维取均值
→ 分钟级按 8 个特征拟合 8 条条件 99.9% 临界函数
→ 秒级按 15 个特征拟合 15 条条件 99.9% 临界函数
→ 保存、重载并审计两套冻结工件
→ 停止，暂不异常检测
```

只要测试样本、测试标签和测试性能没有参与以上任何一步，就满足当前“异常检测前准备”与
数据隔离要求。
