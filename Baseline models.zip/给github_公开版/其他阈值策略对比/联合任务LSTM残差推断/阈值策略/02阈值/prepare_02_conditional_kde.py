# -*- coding: utf-8 -*-
"""只用纯正常标定窗口准备 02 条件 Gaussian KDE 临界函数工件。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np
import torch


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from main import DATASETS, compute, load_joint  # noqa: E402
from strategy_02_conditional_kde import (  # noqa: E402
    ConditionalKDECriticalFunction,
    SCHEMA_VERSION,
    STRATEGY_ID,
    fit_feature_curve,
)


CONFIG_PATH = SCRIPT_DIR / "experiment_config.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def save_json(path: Path, value: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def resolve_project_path(path_text: str) -> Path:
    path = Path(path_text)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def scalar_from_npz(archive: Any, key: str) -> Any:
    value = np.asarray(archive[key]).reshape(-1)[0]
    return value.item() if isinstance(value, np.generic) else value


def load_and_audit_calibration(
    path: Path,
    dataset: str,
    contract: Dict[str, Any],
    checkpoint_hash: str,
    checkpoint_mean: np.ndarray,
    checkpoint_std: np.ndarray,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    actual_hash = sha256_file(path)
    if actual_hash != contract["calibration_sha256"]:
        raise ValueError("正常标定文件 SHA-256 与冻结配置不一致")
    if path.suffix.lower() != ".npz":
        raise ValueError("02 正式准备只接受带正常标签审计的 NPZ")

    with np.load(path, allow_pickle=False) as archive:
        if "X" not in archive.files or "y" not in archive.files:
            raise ValueError("正常标定 NPZ 必须包含 X 和 y")
        features = np.asarray(archive["X"], dtype=np.float32)
        labels = np.asarray(archive["y"]).reshape(-1)
        available_keys = list(archive.files)
        metadata_audit: Dict[str, Any] = {}
        expectations = {
            "dataset": dataset,
            "input_space": contract["input_space"],
            "window_size": 10,
            "feature_dimension": int(contract["input_dim"]),
            "checkpoint_sha256": checkpoint_hash,
        }
        for key, expected in expectations.items():
            if key in archive.files:
                actual = scalar_from_npz(archive, key)
                match = actual == expected
                metadata_audit[key] = {
                    "file": actual,
                    "expected": expected,
                    "match": bool(match),
                }
                if not match:
                    raise ValueError(
                        f"正常标定元数据 {key}={actual!r} 与冻结设置 {expected!r} 不一致"
                    )
        if "standardizer_mean" in archive.files:
            match = bool(
                np.allclose(
                    np.asarray(archive["standardizer_mean"]),
                    checkpoint_mean,
                    rtol=1e-6,
                    atol=1e-6,
                )
            )
            metadata_audit["standardizer_mean_match"] = match
            if not match:
                raise ValueError("标定文件 standardizer_mean 与 checkpoint 不一致")
        if "standardizer_std" in archive.files:
            match = bool(
                np.allclose(
                    np.asarray(archive["standardizer_std"]),
                    checkpoint_std,
                    rtol=1e-6,
                    atol=1e-6,
                )
            )
            metadata_audit["standardizer_std_match"] = match
            if not match:
                raise ValueError("标定文件 standardizer_std 与 checkpoint 不一致")

    expected_shape = tuple(int(value) for value in contract["calibration_shape"])
    if features.shape != expected_shape:
        raise ValueError(f"正常标定形状应为 {expected_shape}，实际为 {features.shape}")
    if labels.size != features.shape[0]:
        raise ValueError("正常标签长度与标定窗口数不一致")
    unique, counts = np.unique(labels, return_counts=True)
    label_counts = {str(key): int(value) for key, value in zip(unique, counts)}
    if not np.all(labels == 0):
        raise ValueError("正常标定集含非零标签，拒绝拟合")
    if not np.all(np.isfinite(features)):
        raise ValueError("正常标定特征含 NaN/Inf")

    audit = {
        "source_path": str(path),
        "source_sha256": actual_hash,
        "input_shape": list(features.shape),
        "available_keys": available_keys,
        "label_counts": label_counts,
        "all_labels_normal": True,
        "all_features_finite": True,
        "input_space": contract["input_space"],
        "input_space_evidence": contract["input_space_evidence"],
        "metadata_audit": metadata_audit,
        "test_data_used": False,
        "test_labels_used": False,
    }
    return features, audit


def audit_feature_order(
    dataset: str, contract: Dict[str, Any]
) -> Tuple[Dict[str, Any], list[str]]:
    sidecar_path = resolve_project_path(contract["feature_order_sidecar"])
    sidecar = load_json(sidecar_path)
    entry = sidecar[contract["feature_order_sidecar_key"]]
    feature_ids = list(entry["feature_ids"])
    if len(feature_ids) != int(contract["input_dim"]):
        raise ValueError("特征顺序 sidecar 的 feature_ids 维数不正确")
    if len(set(feature_ids)) != len(feature_ids):
        raise ValueError("特征顺序 sidecar 中存在重复 feature_id")
    return {
        "sidecar_path": str(sidecar_path),
        "sidecar_sha256": sha256_file(sidecar_path),
        "dataset_key": dataset,
        "feature_ids": feature_ids,
        "order_rule": entry["order_rule"],
        "evidence": entry["evidence"],
        "semantic_feature_names_available": bool(
            entry["semantic_feature_names_available"]
        ),
        "semantic_name_policy": entry["semantic_name_policy"],
    }, feature_ids


def infer_normal_pairs(
    features_standardized: np.ndarray,
    dataset: str,
    bundle: Tuple[Any, np.ndarray, np.ndarray, Dict[str, Any]],
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    _, mean, std, _ = bundle
    scale = std + 1e-8
    raw = features_standardized * scale[None, None, :] + mean[None, None, :]
    roundtrip = (raw - mean[None, None, :]) / scale[None, None, :]
    roundtrip_max_abs_error = float(
        np.max(np.abs(roundtrip.astype(np.float64) - features_standardized))
    )
    if roundtrip_max_abs_error > 2e-6:
        raise RuntimeError("standardized → raw → standardized 往返误差超过门限")

    reconstruction_chunks = []
    residual_chunks = []
    for start in range(0, raw.shape[0], batch_size):
        stop = min(start + batch_size, raw.shape[0])
        residual, reconstruction = compute(
            raw[start:stop],
            dataset=dataset,
            absolute=True,
            standardized=True,
            return_recon=True,
            model_bundle=bundle,
        )
        reconstruction_chunks.append(
            np.asarray(reconstruction.mean(axis=1), dtype=np.float64)
        )
        residual_chunks.append(np.asarray(residual.mean(axis=1), dtype=np.float64))
    reconstruction_mean = np.concatenate(reconstruction_chunks, axis=0)
    residual_mean = np.concatenate(residual_chunks, axis=0)
    if reconstruction_mean.shape != residual_mean.shape:
        raise RuntimeError("重构均值与残差均值形状不一致")
    if not np.all(np.isfinite(reconstruction_mean)) or not np.all(
        np.isfinite(residual_mean)
    ):
        raise RuntimeError("模型正常标定输出含 NaN/Inf")
    if np.any(residual_mean < 0.0):
        raise RuntimeError("绝对残差出现负值")
    audit = {
        "model_forward_mode": "eval + torch.no_grad",
        "single_forward_for_reconstruction_and_residual": True,
        "input_space_to_model": "standardized",
        "output_space": "standardized",
        "roundtrip_max_abs_error": roundtrip_max_abs_error,
        "roundtrip_atol": 2e-6,
        "batch_size": int(batch_size),
        "reconstruction_mean_shape": list(reconstruction_mean.shape),
        "residual_mean_shape": list(residual_mean.shape),
    }
    return reconstruction_mean, residual_mean, audit


def bootstrap_curves(
    reconstruction_mean: np.ndarray,
    residual_mean: np.ndarray,
    tail_probability: float,
    replicates: int,
    seed: int,
    anchor_count: int,
    backend: str,
) -> Dict[str, np.ndarray]:
    if replicates < 0:
        raise ValueError("bootstrap_replicates 不能为负")
    n_samples, n_features = reconstruction_mean.shape
    probabilities = np.linspace(0.01, 0.99, anchor_count)
    anchors = np.quantile(reconstruction_mean, probabilities, axis=0).T
    curves = np.empty((replicates, n_features, anchor_count), dtype=np.float64)
    rng = np.random.Generator(np.random.PCG64(seed))
    for replicate in range(replicates):
        indices = rng.integers(0, n_samples, size=n_samples)
        for feature_index in range(n_features):
            result = fit_feature_curve(
                reconstruction_mean[indices, feature_index],
                residual_mean[indices, feature_index],
                anchors[feature_index],
                tail_probability=tail_probability,
                positive_support_renormalized=True,
                backend=backend,
                bisection_iterations=40,
            )
            curves[replicate, feature_index] = result["q_grid"]
    return {
        "anchor_probabilities": probabilities,
        "anchor_y": anchors,
        "curves": curves,
        "median": np.median(curves, axis=0),
        "ci_2_5": np.quantile(curves, 0.025, axis=0),
        "ci_97_5": np.quantile(curves, 0.975, axis=0),
    }


def save_feature_audit_csv(
    path: Path,
    feature_ids: list[str],
    strategy: ConditionalKDECriticalFunction,
    bootstrap: Dict[str, np.ndarray],
) -> None:
    assert strategy.q_grid_ is not None
    assert strategy.scott_factor_ is not None
    assert strategy.condition_number_ is not None
    assert strategy.central_min_ess_ is not None
    assert strategy.central_p05_ess_ is not None
    assert strategy.central_median_ess_ is not None
    assert strategy.max_root_error_ is not None
    assert strategy.max_negative_mass_ is not None
    assert strategy.feature_pass_ is not None
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        fieldnames = [
            "feature_index",
            "feature_id",
            "num_samples",
            "scott_factor",
            "bandwidth_condition_number",
            "central_min_ess",
            "central_p05_ess",
            "central_median_ess",
            "critical_min",
            "critical_max",
            "max_root_cdf_error",
            "max_negative_kde_mass",
            "bootstrap_median_ci_width",
            "feature_pass",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        ci_width = bootstrap["ci_97_5"] - bootstrap["ci_2_5"]
        for feature_index, feature_id in enumerate(feature_ids):
            writer.writerow(
                {
                    "feature_index": feature_index,
                    "feature_id": feature_id,
                    "num_samples": strategy.num_samples_,
                    "scott_factor": f"{strategy.scott_factor_[feature_index]:.12g}",
                    "bandwidth_condition_number": f"{strategy.condition_number_[feature_index]:.12g}",
                    "central_min_ess": f"{strategy.central_min_ess_[feature_index]:.12g}",
                    "central_p05_ess": f"{strategy.central_p05_ess_[feature_index]:.12g}",
                    "central_median_ess": f"{strategy.central_median_ess_[feature_index]:.12g}",
                    "critical_min": f"{np.min(strategy.q_grid_[feature_index]):.12g}",
                    "critical_max": f"{np.max(strategy.q_grid_[feature_index]):.12g}",
                    "max_root_cdf_error": f"{strategy.max_root_error_[feature_index]:.12g}",
                    "max_negative_kde_mass": f"{strategy.max_negative_mass_[feature_index]:.12g}",
                    "bootstrap_median_ci_width": f"{np.median(ci_width[feature_index]):.12g}",
                    "feature_pass": bool(strategy.feature_pass_[feature_index]),
                }
            )


def save_calibration_figure(
    output_dir: Path,
    dataset: str,
    feature_ids: list[str],
    reconstruction_mean: np.ndarray,
    residual_mean: np.ndarray,
    strategy: ConditionalKDECriticalFunction,
    bootstrap: Dict[str, np.ndarray],
) -> Dict[str, Any]:
    """科研图合同：定量网格；主证据为正常联合分布及条件临界曲线。"""
    import matplotlib as mpl

    mpl.use("Agg")
    import matplotlib.pyplot as plt

    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
        }
    )
    assert strategy.y_grid_ is not None and strategy.q_grid_ is not None
    n_features = len(feature_ids)
    n_columns = 2 if n_features <= 8 else 3
    n_rows = int(math.ceil(n_features / n_columns))
    figure, axes = plt.subplots(
        n_rows,
        n_columns,
        figsize=(7.2, 2.0 * n_rows + 0.6),
        squeeze=False,
    )
    figure.subplots_adjust(
        left=0.09,
        right=0.985,
        bottom=0.055,
        top=0.875,
        hspace=0.52,
        wspace=0.22,
    )
    density_color = "#4C78A8"
    threshold_color = "#C23B22"
    interval_color = "#E7A79A"
    for feature_index, axis in enumerate(axes.flat):
        if feature_index >= n_features:
            axis.axis("off")
            continue
        axis.hexbin(
            reconstruction_mean[:, feature_index],
            residual_mean[:, feature_index],
            gridsize=42,
            mincnt=1,
            bins="log",
            cmap="Blues",
            linewidths=0.0,
            rasterized=True,
        )
        axis.fill_between(
            bootstrap["anchor_y"][feature_index],
            bootstrap["ci_2_5"][feature_index],
            bootstrap["ci_97_5"][feature_index],
            color=interval_color,
            alpha=0.38,
            linewidth=0,
            label="Bootstrap 95% interval" if feature_index == 0 else None,
        )
        axis.plot(
            strategy.y_grid_[feature_index],
            strategy.q_grid_[feature_index],
            color=threshold_color,
            linewidth=1.35,
            label="Conditional 99.9% limit" if feature_index == 0 else None,
        )
        axis.set_title(f"{feature_index}: {feature_ids[feature_index]}", loc="left", fontsize=7)
        axis.set_xlabel("Mean reconstruction (standardized)")
        axis.set_ylabel("Mean absolute residual")
        axis.grid(alpha=0.16, linewidth=0.5)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    if handles:
        figure.legend(
            handles,
            labels,
            loc="upper center",
            ncol=2,
            bbox_to_anchor=(0.5, 0.945),
        )
    figure.suptitle(
        f"Normal-calibration conditional critical functions — {dataset}",
        fontsize=9,
        y=0.985,
    )
    png_path = output_dir / "calibration_critical_functions.png"
    svg_path = output_dir / "calibration_critical_functions.svg"
    pdf_path = output_dir / "calibration_critical_functions.pdf"
    tiff_path = output_dir / "calibration_critical_functions.tiff"
    figure.savefig(png_path, dpi=600, bbox_inches="tight", facecolor="white")
    figure.savefig(svg_path, bbox_inches="tight", facecolor="white")
    figure.savefig(pdf_path, bbox_inches="tight", facecolor="white")
    figure.savefig(
        tiff_path,
        dpi=600,
        bbox_inches="tight",
        facecolor="white",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(figure)
    return {
        "png_file": png_path.name,
        "svg_file": svg_path.name,
        "pdf_file": pdf_path.name,
        "tiff_file": tiff_path.name,
        "backend": "python_matplotlib",
        "archetype": "quantitative_grid",
        "core_conclusion": "The normal residual limit varies with the model reconstruction level and is feature-specific.",
        "all_normal_calibration_observations_used": True,
        "test_data_plotted": False,
        "png_dpi": 600,
        "tiff_dpi": 600,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="准备 02：只用纯正常标定窗口拟合逐特征条件 Gaussian KDE 临界函数"
    )
    parser.add_argument("--dataset", required=True, choices=list(DATASETS))
    parser.add_argument("--calibration", type=Path)
    parser.add_argument("--input-space", choices=["standardized"], default="standardized")
    parser.add_argument("--tail-probability", type=float)
    parser.add_argument("--bandwidth-rule", choices=["scott"], default="scott")
    parser.add_argument("--grid-size", type=int)
    parser.add_argument("--bootstrap-replicates", type=int)
    parser.add_argument("--bootstrap-seed", type=int)
    parser.add_argument("--backend", choices=["auto", "numpy", "cuda"], default="auto")
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument(
        "--refresh-figure-only",
        action="store_true",
        help="只从现有正常标定工件刷新科研图导出，不重新拟合",
    )
    return parser


def refresh_existing_figure_exports(
    output_dir: Path,
    dataset: str,
    feature_ids: list[str],
) -> Dict[str, Any]:
    required = [
        output_dir / "threshold_artifact.json",
        output_dir / "critical_functions.npz",
        output_dir / "calibration_pairs.npz",
        output_dir / "bootstrap_audit.npz",
    ]
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(f"刷新图形缺少现有正常标定工件：{path}")
    with np.load(output_dir / "critical_functions.npz", allow_pickle=False) as saved:
        strategy = ConditionalKDECriticalFunction.from_state_dict(
            {key: saved[key] for key in saved.files}
        )
    with np.load(output_dir / "calibration_pairs.npz", allow_pickle=False) as pairs:
        reconstruction_mean = np.asarray(pairs["reconstruction_mean"], dtype=np.float64)
        residual_mean = np.asarray(pairs["residual_mean"], dtype=np.float64)
    with np.load(output_dir / "bootstrap_audit.npz", allow_pickle=False) as saved:
        bootstrap = {key: np.asarray(saved[key]) for key in saved.files}
    figure_audit = save_calibration_figure(
        output_dir,
        dataset,
        feature_ids,
        reconstruction_mean,
        residual_mean,
        strategy,
        bootstrap,
    )
    artifact_path = output_dir / "threshold_artifact.json"
    artifact = load_json(artifact_path)
    if artifact.get("strategy_id") != STRATEGY_ID or artifact.get("dataset") != dataset:
        raise ValueError("现有工件与请求的数据集/策略不一致")
    artifact["calibration_visualization"] = figure_audit
    save_json(artifact_path, artifact)
    print(f"{dataset}: 已从冻结正常标定工件刷新图形导出；未重新拟合")
    return artifact


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config = load_json(CONFIG_PATH)
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("experiment_config.json 的 strategy_id 不正确")
    strategy_contract = config["strategy_contract"]
    dataset_contract = config["datasets"][args.dataset]

    tail_probability = (
        float(args.tail_probability)
        if args.tail_probability is not None
        else float(strategy_contract["tail_probability"])
    )
    grid_size = (
        int(args.grid_size)
        if args.grid_size is not None
        else int(strategy_contract["grid_size"])
    )
    bootstrap_replicates = (
        int(args.bootstrap_replicates)
        if args.bootstrap_replicates is not None
        else int(strategy_contract["bootstrap_replicates"])
    )
    bootstrap_seed = (
        int(args.bootstrap_seed)
        if args.bootstrap_seed is not None
        else int(strategy_contract["bootstrap_seed"])
    )
    if not np.isclose(
        tail_probability,
        float(strategy_contract["tail_probability"]),
        rtol=0.0,
        atol=1e-15,
    ):
        raise ValueError("正式主实验 tail_probability 必须固定为 0.001")
    if grid_size != int(strategy_contract["grid_size"]):
        raise ValueError("正式主实验 grid_size 必须固定为 512")
    if bootstrap_replicates < 1:
        raise ValueError("正式准备必须执行至少一次 bootstrap")
    if args.batch_size < 1:
        raise ValueError("batch_size 必须为正整数")

    model_path = resolve_project_path(dataset_contract["model"])
    calibration_path = (
        args.calibration.resolve()
        if args.calibration is not None
        else resolve_project_path(dataset_contract["calibration"])
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else resolve_project_path(dataset_contract["artifact_dir"])
    )
    forbidden_parts = {"测试集数据", "02实验结果", "results"}
    if any(part in forbidden_parts for part in output_dir.parts):
        raise ValueError("准备阶段禁止把工件写入测试或检测结果目录")
    if args.refresh_figure_only:
        _, feature_ids = audit_feature_order(args.dataset, dataset_contract)
        return refresh_existing_figure_exports(output_dir, args.dataset, feature_ids)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖正式工件：{output_dir}")

    checkpoint_hash = sha256_file(model_path)
    if checkpoint_hash != dataset_contract["model_sha256"]:
        raise ValueError("模型 checkpoint SHA-256 与冻结配置不一致")
    bundle = load_joint(args.dataset)
    model, mean, std, model_config = bundle
    if model.training:
        raise RuntimeError("联合任务 LSTM 未处于 eval 模式")
    if int(model_config["input_dim"]) != int(dataset_contract["input_dim"]):
        raise ValueError("checkpoint input_dim 与冻结配置不一致")

    calibration, calibration_audit = load_and_audit_calibration(
        calibration_path,
        args.dataset,
        dataset_contract,
        checkpoint_hash,
        mean,
        std,
    )
    feature_order_audit, feature_ids = audit_feature_order(
        args.dataset, dataset_contract
    )

    print(f"{args.dataset}: 提取纯正常 reconstruction/residual 配对……")
    reconstruction_mean, residual_mean, inference_audit = infer_normal_pairs(
        calibration,
        args.dataset,
        bundle,
        args.batch_size,
    )
    strategy = ConditionalKDECriticalFunction(
        tail_probability=tail_probability,
        grid_size=grid_size,
        support_extension=float(strategy_contract["support_extension_fraction"]),
        minimum_samples=int(strategy_contract["minimum_samples"]),
        minimum_ess=float(
            strategy_contract["minimum_ess_in_central_98_percent"]
        ),
        maximum_condition_number=float(
            strategy_contract["maximum_bandwidth_condition_number"]
        ),
        positive_support_renormalized=bool(
            strategy_contract["positive_support_renormalized"]
        ),
        backend=args.backend,
    ).fit(reconstruction_mean, residual_mean)

    print(
        f"{args.dataset}: 开始 {bootstrap_replicates} 次纯正常 bootstrap 稳定性审计……"
    )
    bootstrap = bootstrap_curves(
        reconstruction_mean,
        residual_mean,
        tail_probability,
        bootstrap_replicates,
        bootstrap_seed,
        int(strategy_contract["bootstrap_anchor_count"]),
        strategy.resolved_backend_ or args.backend,
    )

    output_dir.mkdir(parents=True, exist_ok=False)
    state = strategy.state_dict()
    np.savez_compressed(output_dir / "critical_functions.npz", **state)
    np.savez_compressed(
        output_dir / "kde_state.npz",
        data_covariance=state["data_covariance"],
        bandwidth_covariance=state["bandwidth_covariance"],
        scott_factor=state["scott_factor"],
        condition_number=state["condition_number"],
        ess_grid=state["ess_grid"],
        max_root_error=state["max_root_error"],
        max_negative_mass=state["max_negative_mass"],
    )
    np.savez_compressed(
        output_dir / "calibration_pairs.npz",
        reconstruction_mean=reconstruction_mean,
        residual_mean=residual_mean,
        feature_ids=np.asarray(feature_ids),
    )
    np.savez_compressed(
        output_dir / "bootstrap_audit.npz",
        anchor_probabilities=bootstrap["anchor_probabilities"],
        anchor_y=bootstrap["anchor_y"],
        curves=bootstrap["curves"],
        median=bootstrap["median"],
        ci_2_5=bootstrap["ci_2_5"],
        ci_97_5=bootstrap["ci_97_5"],
    )
    save_feature_audit_csv(
        output_dir / "feature_fit_audit.csv", feature_ids, strategy, bootstrap
    )
    normal_audit = {
        "dataset": args.dataset,
        "time_scale": dataset_contract["time_scale"],
        "calibration": calibration_audit,
        "feature_order": feature_order_audit,
        "inference": inference_audit,
        "data_isolation": {
            "test_data_used": False,
            "test_labels_used": False,
            "detection_executed": False,
            "metrics_computed": False,
        },
    }
    save_json(output_dir / "normal_calibration_audit.json", normal_audit)
    figure_audit = save_calibration_figure(
        output_dir,
        args.dataset,
        feature_ids,
        reconstruction_mean,
        residual_mean,
        strategy,
        bootstrap,
    )

    with np.load(output_dir / "critical_functions.npz", allow_pickle=False) as saved:
        restored = ConditionalKDECriticalFunction.from_state_dict(
            {key: saved[key] for key in saved.files}
        )
    probe_rows = np.linspace(
        0, reconstruction_mean.shape[0] - 1, min(257, reconstruction_mean.shape[0]), dtype=int
    )
    before = strategy.thresholds(reconstruction_mean[probe_rows])
    after = restored.thresholds(reconstruction_mean[probe_rows])
    reload_max_abs_error = float(np.max(np.abs(before - after)))
    if reload_max_abs_error > 1e-12:
        raise RuntimeError("临界函数保存/重载后结果不一致")

    feature_pass = np.asarray(strategy.feature_pass_, dtype=bool)
    ready = bool(np.all(feature_pass))
    status = "READY_FOR_TEST" if ready else "CALIBRATION_UNSTABLE"
    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    artifact = {
        "schema_version": SCHEMA_VERSION,
        "strategy_id": STRATEGY_ID,
        "strategy_name": config["strategy_name"],
        "reproduction_type": config["reproduction_type"],
        "status": status,
        "formal_result_allowed": ready,
        "created_at_china": now_cn,
        "dataset": args.dataset,
        "time_scale": dataset_contract["time_scale"],
        "model": {
            "checkpoint": model_path.name,
            "checkpoint_path": str(model_path),
            "checkpoint_sha256": checkpoint_hash,
            "model_config": model_config,
            "window_size": 10,
            "input_dim": int(dataset_contract["input_dim"]),
            "eval_mode": True,
            "single_forward_for_reconstruction_and_residual": True,
        },
        "calibration": {
            **calibration_audit,
            "num_windows": int(reconstruction_mean.shape[0]),
            "audit_file": "normal_calibration_audit.json",
            "feature_order": feature_order_audit,
        },
        "pair_definition": {
            "condition": "mean over time of reconstruction",
            "residual": "mean over time of abs(reconstruction-input)",
            "space": "standardized",
            "shape": list(reconstruction_mean.shape),
            "pairs_file": "calibration_pairs.npz",
            "pairs_sha256": sha256_file(output_dir / "calibration_pairs.npz"),
        },
        "threshold": {
            "method": "featurewise_conditional_gaussian_kde",
            "kernel": "gaussian",
            "bandwidth_rule": "scott",
            "kde_dimension": 2,
            "tail_probability": tail_probability,
            "conditional_quantile": 1.0 - tail_probability,
            "residual_support": [0.0, "positive_infinity"],
            "positive_support_renormalized": strategy.positive_support_renormalized,
            "grid_size": grid_size,
            "interpolation": "linear",
            "support_extension_fraction": strategy.support_extension,
            "outside_support": "flatten_to_boundary",
            "num_critical_functions": int(strategy.num_features_),
            "critical_functions_file": "critical_functions.npz",
            "critical_functions_sha256": sha256_file(
                output_dir / "critical_functions.npz"
            ),
            "kde_state_file": "kde_state.npz",
            "calculation_backend": strategy.resolved_backend_,
        },
        "stability_gate": {
            "minimum_samples": strategy.minimum_samples,
            "minimum_ess_in_central_98_percent": strategy.minimum_ess,
            "maximum_bandwidth_condition_number": strategy.maximum_condition_number,
            "all_features_passed": ready,
            "failed_feature_indices": np.flatnonzero(~feature_pass).astype(int).tolist(),
            "central_min_ess_by_feature": np.asarray(
                strategy.central_min_ess_, dtype=float
            ).tolist(),
            "bandwidth_condition_number_by_feature": np.asarray(
                strategy.condition_number_, dtype=float
            ).tolist(),
            "max_root_cdf_error_by_feature": np.asarray(
                strategy.max_root_error_, dtype=float
            ).tolist(),
            "max_negative_kde_mass_by_feature": np.asarray(
                strategy.max_negative_mass_, dtype=float
            ).tolist(),
            "feature_audit_file": "feature_fit_audit.csv",
        },
        "bootstrap_stability_audit": {
            "replicates": bootstrap_replicates,
            "seed": bootstrap_seed,
            "anchor_count": int(strategy_contract["bootstrap_anchor_count"]),
            "anchor_region": "normal reconstruction quantiles 0.01 through 0.99",
            "changes_formal_critical_function": False,
            "file": "bootstrap_audit.npz",
        },
        "future_decision_contract": {
            "feature_rule": strategy_contract["future_feature_rule"],
            "window_score": strategy_contract["future_window_score"],
            "window_rule": strategy_contract["future_window_rule"],
            "persistence_for_main_experiment": {"k": 1, "m": 1},
        },
        "paper_deviations": [
            "The paper uses an ensemble of five denoising autoencoders; this experiment keeps one frozen joint-task LSTM.",
            "Sequence outputs and residuals are averaged over each 10-step window.",
            "The paper's 0.8*min/1.2*max boundary rule is replaced by sign-safe 20% range extension in standardized space.",
            "Because absolute residuals are non-negative, each conditional KDE CDF is renormalized on [0,+infinity) before taking the 0.999 quantile.",
            "Only the conditional threshold module is migrated; no end-to-end EDAE claim is made.",
        ],
        "reproducibility_check": {
            "state_reload_passed": True,
            "threshold_probe_rows": int(probe_rows.size),
            "reload_max_abs_error": reload_max_abs_error,
            "atol": 1e-12,
        },
        "calibration_visualization": figure_audit,
        "data_isolation": {
            "test_data_used": False,
            "test_labels_used": False,
            "detection_executed": False,
            "metrics_computed": False,
        },
        "notes": [
            "All fitted distributions and critical functions use only the corresponding pure-normal calibration NPZ.",
            "Bootstrap audits stability only and does not replace the full-calibration critical functions.",
            "No test file or detection entry point exists in this preparation script.",
            "Semantic sensor names were not invented; stable source-column IDs are retained.",
        ],
    }
    save_json(output_dir / "threshold_artifact.json", artifact)
    print(f"{args.dataset}: 状态={status}")
    print(f"全部特征最小中央 ESS={float(np.min(strategy.central_min_ess_)):.3f}")
    print("测试数据使用：否；异常检测执行：否；检测指标计算：否")
    print(f"正式工件：{output_dir / 'threshold_artifact.json'}")
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
