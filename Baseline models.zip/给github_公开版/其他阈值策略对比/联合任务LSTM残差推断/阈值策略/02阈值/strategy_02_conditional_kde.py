# -*- coding: utf-8 -*-
"""02：基于重构输出-残差联合 Gaussian KDE 的逐特征条件临界函数。"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import numpy as np
from scipy.special import ndtr


SCHEMA_VERSION = 1
STRATEGY_ID = "02_conditional_kde"
DEFAULT_TAIL_PROBABILITY = 1e-3
DEFAULT_GRID_SIZE = 512
DEFAULT_SUPPORT_EXTENSION = 0.2


def _as_pair_arrays(
    reconstruction_mean: np.ndarray,
    residual_mean: np.ndarray,
    minimum_samples: int,
) -> Tuple[np.ndarray, np.ndarray]:
    y = np.asarray(reconstruction_mean, dtype=np.float64)
    r = np.asarray(residual_mean, dtype=np.float64)
    if y.ndim != 2 or r.ndim != 2 or y.shape != r.shape:
        raise ValueError("reconstruction_mean 与 residual_mean 必须是同形状 (N,D) 数组")
    if y.shape[0] < minimum_samples:
        raise ValueError(f"标定样本数至少为 {minimum_samples}，实际为 {y.shape[0]}")
    if y.shape[1] < 1:
        raise ValueError("特征维数必须大于 0")
    if not np.all(np.isfinite(y)) or not np.all(np.isfinite(r)):
        raise ValueError("重构输出或残差中存在 NaN/Inf")
    if np.any(r < 0.0):
        raise ValueError("02 条件阈值要求非负绝对残差")
    return y, r


def _resolve_backend(backend: str) -> str:
    if backend not in {"auto", "numpy", "cuda"}:
        raise ValueError("backend 只能是 auto、numpy 或 cuda")
    if backend == "numpy":
        return "numpy"
    try:
        import torch

        cuda_available = bool(torch.cuda.is_available())
    except ImportError:
        cuda_available = False
    if backend == "cuda" and not cuda_available:
        raise RuntimeError("请求了 CUDA 条件分位数计算，但当前环境没有可用 CUDA")
    return "cuda" if cuda_available else "numpy"


def _conditional_quantiles_numpy(
    y: np.ndarray,
    r: np.ndarray,
    y_grid: np.ndarray,
    bandwidth_covariance: np.ndarray,
    target_quantile: float,
    positive_support_renormalized: bool,
    bisection_iterations: int,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    hyy = float(bandwidth_covariance[0, 0])
    hyr = float(bandwidth_covariance[0, 1])
    hrr = float(bandwidth_covariance[1, 1])
    slope = hyr / hyy
    conditional_variance = hrr - hyr * hyr / hyy
    if hyy <= 0.0 or conditional_variance <= 0.0:
        raise ValueError("KDE 带宽矩阵不能形成正的条件方差")
    conditional_std = float(np.sqrt(conditional_variance))

    quantiles = np.empty(y_grid.size, dtype=np.float64)
    ess = np.empty(y_grid.size, dtype=np.float64)
    errors = np.empty(y_grid.size, dtype=np.float64)
    negative_mass = np.empty(y_grid.size, dtype=np.float64)
    for start in range(0, y_grid.size, batch_size):
        stop = min(start + batch_size, y_grid.size)
        grid_batch = y_grid[start:stop]
        delta = grid_batch[:, None] - y[None, :]
        log_weights = -0.5 * delta * delta / hyy
        log_weights -= np.max(log_weights, axis=1, keepdims=True)
        weights = np.exp(log_weights)
        weights /= np.sum(weights, axis=1, keepdims=True)
        means = r[None, :] + slope * delta

        cdf_zero = np.sum(weights * ndtr((-means) / conditional_std), axis=1)
        target = (
            cdf_zero + target_quantile * (1.0 - cdf_zero)
            if positive_support_renormalized
            else np.full_like(cdf_zero, target_quantile)
        )

        low = (
            np.zeros(grid_batch.size, dtype=np.float64)
            if positive_support_renormalized
            else np.min(means, axis=1) - 10.0 * conditional_std
        )
        high = np.max(means, axis=1) + 10.0 * conditional_std
        for _ in range(bisection_iterations):
            middle = 0.5 * (low + high)
            cdf = np.sum(
                weights * ndtr((middle[:, None] - means) / conditional_std),
                axis=1,
            )
            move_low = cdf < target
            low = np.where(move_low, middle, low)
            high = np.where(move_low, high, middle)
        result = 0.5 * (low + high)
        final_cdf = np.sum(
            weights * ndtr((result[:, None] - means) / conditional_std), axis=1
        )
        quantiles[start:stop] = result
        ess[start:stop] = 1.0 / np.sum(weights * weights, axis=1)
        normalized_cdf = (
            (final_cdf - cdf_zero) / np.maximum(1.0 - cdf_zero, 1e-15)
            if positive_support_renormalized
            else final_cdf
        )
        errors[start:stop] = np.abs(normalized_cdf - target_quantile)
        negative_mass[start:stop] = cdf_zero
    return quantiles, ess, errors, negative_mass


def _conditional_quantiles_cuda(
    y: np.ndarray,
    r: np.ndarray,
    y_grid: np.ndarray,
    bandwidth_covariance: np.ndarray,
    target_quantile: float,
    positive_support_renormalized: bool,
    bisection_iterations: int,
    batch_size: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    import torch

    device = torch.device("cuda")
    dtype = torch.float64
    y_t = torch.as_tensor(y, dtype=dtype, device=device)
    r_t = torch.as_tensor(r, dtype=dtype, device=device)
    grid_t = torch.as_tensor(y_grid, dtype=dtype, device=device)
    covariance_t = torch.as_tensor(
        bandwidth_covariance, dtype=dtype, device=device
    )
    hyy = covariance_t[0, 0]
    hyr = covariance_t[0, 1]
    hrr = covariance_t[1, 1]
    slope = hyr / hyy
    conditional_variance = hrr - hyr * hyr / hyy
    if float(hyy.item()) <= 0.0 or float(conditional_variance.item()) <= 0.0:
        raise ValueError("KDE 带宽矩阵不能形成正的条件方差")
    conditional_std = torch.sqrt(conditional_variance)

    quantile_parts = []
    ess_parts = []
    error_parts = []
    negative_mass_parts = []
    for start in range(0, y_grid.size, batch_size):
        stop = min(start + batch_size, y_grid.size)
        grid_batch = grid_t[start:stop]
        delta = grid_batch[:, None] - y_t[None, :]
        log_weights = -0.5 * delta.square() / hyy
        log_weights -= torch.max(log_weights, dim=1, keepdim=True).values
        weights = torch.exp(log_weights)
        weights /= torch.sum(weights, dim=1, keepdim=True)
        means = r_t[None, :] + slope * delta

        cdf_zero = torch.sum(
            weights * torch.special.ndtr((-means) / conditional_std), dim=1
        )
        target = (
            cdf_zero + target_quantile * (1.0 - cdf_zero)
            if positive_support_renormalized
            else torch.full_like(cdf_zero, target_quantile)
        )

        low = (
            torch.zeros_like(cdf_zero)
            if positive_support_renormalized
            else torch.min(means, dim=1).values - 10.0 * conditional_std
        )
        high = torch.max(means, dim=1).values + 10.0 * conditional_std
        for _ in range(bisection_iterations):
            middle = 0.5 * (low + high)
            cdf = torch.sum(
                weights
                * torch.special.ndtr((middle[:, None] - means) / conditional_std),
                dim=1,
            )
            move_low = cdf < target
            low = torch.where(move_low, middle, low)
            high = torch.where(move_low, high, middle)
        result = 0.5 * (low + high)
        final_cdf = torch.sum(
            weights
            * torch.special.ndtr((result[:, None] - means) / conditional_std),
            dim=1,
        )
        quantile_parts.append(result.cpu())
        ess_parts.append((1.0 / torch.sum(weights.square(), dim=1)).cpu())
        normalized_cdf = (
            (final_cdf - cdf_zero) / torch.clamp(1.0 - cdf_zero, min=1e-15)
            if positive_support_renormalized
            else final_cdf
        )
        error_parts.append(torch.abs(normalized_cdf - target_quantile).cpu())
        negative_mass_parts.append(cdf_zero.cpu())

    quantiles = torch.cat(quantile_parts).numpy()
    ess = torch.cat(ess_parts).numpy()
    errors = torch.cat(error_parts).numpy()
    negative_mass = torch.cat(negative_mass_parts).numpy()
    return quantiles, ess, errors, negative_mass


def fit_feature_curve(
    y: np.ndarray,
    r: np.ndarray,
    y_grid: np.ndarray,
    tail_probability: float = DEFAULT_TAIL_PROBABILITY,
    positive_support_renormalized: bool = True,
    backend: str = "auto",
    bisection_iterations: int = 44,
    batch_size: Optional[int] = None,
) -> Dict[str, Any]:
    """在指定 y 网格上拟合一个特征的条件 KDE 分位曲线。"""
    y = np.asarray(y, dtype=np.float64).reshape(-1)
    r = np.asarray(r, dtype=np.float64).reshape(-1)
    y_grid = np.asarray(y_grid, dtype=np.float64).reshape(-1)
    if y.size != r.size or y.size < 3:
        raise ValueError("单特征 y/r 长度必须一致且至少包含 3 个样本")
    if not np.all(np.isfinite(y)) or not np.all(np.isfinite(r)):
        raise ValueError("单特征 y/r 含 NaN/Inf")
    if np.any(r < 0.0):
        raise ValueError("残差不能为负")
    if not 0.0 < tail_probability < 0.5:
        raise ValueError("tail_probability 必须位于 (0,0.5)")
    if y_grid.size < 2 or not np.all(np.diff(y_grid) > 0.0):
        raise ValueError("y_grid 必须严格递增且至少有两个点")

    data_covariance = np.cov(np.vstack((y, r)), ddof=1)
    if data_covariance.shape != (2, 2) or not np.all(np.isfinite(data_covariance)):
        raise ValueError("无法计算有效的二维样本协方差")
    if float(data_covariance[0, 0]) <= 1e-14 or float(data_covariance[1, 1]) <= 1e-14:
        raise ValueError("条件变量或残差方差过小，拒绝拟合")
    scott_factor = float(y.size ** (-1.0 / 6.0))
    bandwidth_covariance = data_covariance * scott_factor**2
    eigenvalues = np.linalg.eigvalsh(bandwidth_covariance)
    if np.min(eigenvalues) <= 1e-15:
        raise ValueError("KDE 带宽协方差不是正定矩阵")
    condition_number = float(np.linalg.cond(bandwidth_covariance))

    resolved_backend = _resolve_backend(backend)
    if batch_size is None:
        batch_size = 16 if resolved_backend == "cuda" else 32
    target_quantile = 1.0 - float(tail_probability)
    calculator = (
        _conditional_quantiles_cuda
        if resolved_backend == "cuda"
        else _conditional_quantiles_numpy
    )
    q_grid, ess, root_errors, negative_mass = calculator(
        y,
        r,
        y_grid,
        bandwidth_covariance,
        target_quantile,
        positive_support_renormalized,
        bisection_iterations,
        batch_size,
    )
    if not np.all(np.isfinite(q_grid)) or np.any(q_grid <= 0.0):
        raise ValueError("条件临界函数出现非有限值或非正阈值")
    return {
        "q_grid": q_grid,
        "ess": ess,
        "root_errors": root_errors,
        "negative_mass": negative_mass,
        "data_covariance": data_covariance,
        "bandwidth_covariance": bandwidth_covariance,
        "scott_factor": scott_factor,
        "condition_number": condition_number,
        "backend": resolved_backend,
    }


class ConditionalKDECriticalFunction:
    """逐特征联合 KDE 条件 99.9% 临界函数。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        tail_probability: float = DEFAULT_TAIL_PROBABILITY,
        grid_size: int = DEFAULT_GRID_SIZE,
        support_extension: float = DEFAULT_SUPPORT_EXTENSION,
        minimum_samples: int = 80,
        minimum_ess: float = 0.0,
        maximum_condition_number: float = 1e12,
        positive_support_renormalized: bool = True,
        backend: str = "auto",
        bisection_iterations: int = 44,
    ) -> None:
        if not 0.0 < tail_probability < 0.5:
            raise ValueError("tail_probability 必须位于 (0,0.5)")
        if grid_size < 16:
            raise ValueError("grid_size 至少为 16")
        if support_extension < 0.0:
            raise ValueError("support_extension 不能为负")
        if minimum_samples < 3:
            raise ValueError("minimum_samples 至少为 3")
        if minimum_ess < 0.0:
            raise ValueError("minimum_ess 不能为负")
        if maximum_condition_number <= 1.0:
            raise ValueError("maximum_condition_number 必须大于 1")
        self.tail_probability = float(tail_probability)
        self.grid_size = int(grid_size)
        self.support_extension = float(support_extension)
        self.minimum_samples = int(minimum_samples)
        self.minimum_ess = float(minimum_ess)
        self.maximum_condition_number = float(maximum_condition_number)
        self.positive_support_renormalized = bool(positive_support_renormalized)
        self.backend = backend
        self.bisection_iterations = int(bisection_iterations)

        self.y_grid_: Optional[np.ndarray] = None
        self.q_grid_: Optional[np.ndarray] = None
        self.ess_grid_: Optional[np.ndarray] = None
        self.data_covariance_: Optional[np.ndarray] = None
        self.bandwidth_covariance_: Optional[np.ndarray] = None
        self.scott_factor_: Optional[np.ndarray] = None
        self.condition_number_: Optional[np.ndarray] = None
        self.max_root_error_: Optional[np.ndarray] = None
        self.max_negative_mass_: Optional[np.ndarray] = None
        self.central_min_ess_: Optional[np.ndarray] = None
        self.central_p05_ess_: Optional[np.ndarray] = None
        self.central_median_ess_: Optional[np.ndarray] = None
        self.feature_pass_: Optional[np.ndarray] = None
        self.resolved_backend_: Optional[str] = None
        self.num_samples_: Optional[int] = None
        self.num_features_: Optional[int] = None

    def fit(
        self, reconstruction_mean: np.ndarray, residual_mean: np.ndarray
    ) -> "ConditionalKDECriticalFunction":
        y_all, r_all = _as_pair_arrays(
            reconstruction_mean, residual_mean, self.minimum_samples
        )
        n_samples, n_features = y_all.shape
        y_grid = np.empty((n_features, self.grid_size), dtype=np.float64)
        q_grid = np.empty_like(y_grid)
        ess_grid = np.empty_like(y_grid)
        data_covariance = np.empty((n_features, 2, 2), dtype=np.float64)
        bandwidth_covariance = np.empty_like(data_covariance)
        scott_factor = np.empty(n_features, dtype=np.float64)
        condition_number = np.empty(n_features, dtype=np.float64)
        max_root_error = np.empty(n_features, dtype=np.float64)
        max_negative_mass = np.empty(n_features, dtype=np.float64)
        central_min_ess = np.empty(n_features, dtype=np.float64)
        central_p05_ess = np.empty(n_features, dtype=np.float64)
        central_median_ess = np.empty(n_features, dtype=np.float64)
        feature_pass = np.ones(n_features, dtype=bool)
        backends = []

        for feature_index in range(n_features):
            y = y_all[:, feature_index]
            r = r_all[:, feature_index]
            span = float(np.max(y) - np.min(y))
            if not np.isfinite(span) or span <= 1e-12:
                raise ValueError(f"特征 {feature_index} 的 reconstruction 范围退化")
            lower = float(np.min(y) - self.support_extension * span)
            upper = float(np.max(y) + self.support_extension * span)
            grid = np.linspace(lower, upper, self.grid_size, dtype=np.float64)
            result = fit_feature_curve(
                y,
                r,
                grid,
                tail_probability=self.tail_probability,
                positive_support_renormalized=self.positive_support_renormalized,
                backend=self.backend,
                bisection_iterations=self.bisection_iterations,
            )
            y_grid[feature_index] = grid
            q_grid[feature_index] = result["q_grid"]
            ess_grid[feature_index] = result["ess"]
            data_covariance[feature_index] = result["data_covariance"]
            bandwidth_covariance[feature_index] = result["bandwidth_covariance"]
            scott_factor[feature_index] = result["scott_factor"]
            condition_number[feature_index] = result["condition_number"]
            max_root_error[feature_index] = float(np.max(result["root_errors"]))
            max_negative_mass[feature_index] = float(np.max(result["negative_mass"]))
            backends.append(result["backend"])

            q01, q99 = np.quantile(y, [0.01, 0.99])
            central = (grid >= q01) & (grid <= q99)
            central_ess = result["ess"][central]
            if central_ess.size == 0:
                raise ValueError(f"特征 {feature_index} 的中央 ESS 区域为空")
            central_min_ess[feature_index] = float(np.min(central_ess))
            central_p05_ess[feature_index] = float(np.quantile(central_ess, 0.05))
            central_median_ess[feature_index] = float(np.median(central_ess))
            feature_pass[feature_index] = bool(
                condition_number[feature_index] <= self.maximum_condition_number
                and central_min_ess[feature_index] >= self.minimum_ess
                and max_root_error[feature_index] <= 1e-10
            )

        self.y_grid_ = y_grid
        self.q_grid_ = q_grid
        self.ess_grid_ = ess_grid
        self.data_covariance_ = data_covariance
        self.bandwidth_covariance_ = bandwidth_covariance
        self.scott_factor_ = scott_factor
        self.condition_number_ = condition_number
        self.max_root_error_ = max_root_error
        self.max_negative_mass_ = max_negative_mass
        self.central_min_ess_ = central_min_ess
        self.central_p05_ess_ = central_p05_ess
        self.central_median_ess_ = central_median_ess
        self.feature_pass_ = feature_pass
        self.resolved_backend_ = backends[0] if len(set(backends)) == 1 else "mixed"
        self.num_samples_ = int(n_samples)
        self.num_features_ = int(n_features)
        return self

    @property
    def is_fitted(self) -> bool:
        return self.y_grid_ is not None and self.q_grid_ is not None

    def thresholds(self, reconstruction_mean: np.ndarray) -> np.ndarray:
        if not self.is_fitted:
            raise RuntimeError("策略尚未拟合")
        values = np.asarray(reconstruction_mean, dtype=np.float64)
        if values.ndim != 2 or values.shape[1] != self.num_features_:
            raise ValueError(
                f"reconstruction_mean 应为 (N,{self.num_features_})，实际 {values.shape}"
            )
        if not np.all(np.isfinite(values)):
            raise ValueError("reconstruction_mean 中存在 NaN/Inf")
        output = np.empty_like(values)
        assert self.y_grid_ is not None and self.q_grid_ is not None
        for feature_index in range(int(self.num_features_)):
            output[:, feature_index] = np.interp(
                values[:, feature_index],
                self.y_grid_[feature_index],
                self.q_grid_[feature_index],
                left=self.q_grid_[feature_index, 0],
                right=self.q_grid_[feature_index, -1],
            )
        return output

    def state_dict(self) -> Dict[str, Any]:
        if not self.is_fitted:
            raise RuntimeError("策略尚未拟合")
        return {
            "schema_version": np.asarray([SCHEMA_VERSION], dtype=np.int64),
            "strategy_id": np.asarray(STRATEGY_ID),
            "tail_probability": np.asarray([self.tail_probability], dtype=np.float64),
            "grid_size": np.asarray([self.grid_size], dtype=np.int64),
            "support_extension": np.asarray([self.support_extension], dtype=np.float64),
            "minimum_samples": np.asarray([self.minimum_samples], dtype=np.int64),
            "minimum_ess": np.asarray([self.minimum_ess], dtype=np.float64),
            "maximum_condition_number": np.asarray(
                [self.maximum_condition_number], dtype=np.float64
            ),
            "positive_support_renormalized": np.asarray(
                [self.positive_support_renormalized], dtype=np.bool_
            ),
            "bisection_iterations": np.asarray(
                [self.bisection_iterations], dtype=np.int64
            ),
            "resolved_backend": np.asarray(str(self.resolved_backend_)),
            "num_samples": np.asarray([self.num_samples_], dtype=np.int64),
            "num_features": np.asarray([self.num_features_], dtype=np.int64),
            "y_grid": np.asarray(self.y_grid_, dtype=np.float64),
            "q_grid": np.asarray(self.q_grid_, dtype=np.float64),
            "ess_grid": np.asarray(self.ess_grid_, dtype=np.float64),
            "data_covariance": np.asarray(self.data_covariance_, dtype=np.float64),
            "bandwidth_covariance": np.asarray(
                self.bandwidth_covariance_, dtype=np.float64
            ),
            "scott_factor": np.asarray(self.scott_factor_, dtype=np.float64),
            "condition_number": np.asarray(self.condition_number_, dtype=np.float64),
            "max_root_error": np.asarray(self.max_root_error_, dtype=np.float64),
            "max_negative_mass": np.asarray(
                self.max_negative_mass_, dtype=np.float64
            ),
            "central_min_ess": np.asarray(self.central_min_ess_, dtype=np.float64),
            "central_p05_ess": np.asarray(self.central_p05_ess_, dtype=np.float64),
            "central_median_ess": np.asarray(
                self.central_median_ess_, dtype=np.float64
            ),
            "feature_pass": np.asarray(self.feature_pass_, dtype=np.bool_),
        }

    @classmethod
    def from_state_dict(cls, state: Dict[str, Any]) -> "ConditionalKDECriticalFunction":
        def scalar(name: str) -> Any:
            return np.asarray(state[name]).reshape(-1)[0].item()

        if int(scalar("schema_version")) != SCHEMA_VERSION:
            raise ValueError("不支持的 02 state schema_version")
        if str(scalar("strategy_id")) != STRATEGY_ID:
            raise ValueError("state 不是 02_conditional_kde")
        instance = cls(
            tail_probability=float(scalar("tail_probability")),
            grid_size=int(scalar("grid_size")),
            support_extension=float(scalar("support_extension")),
            minimum_samples=int(scalar("minimum_samples")),
            minimum_ess=float(scalar("minimum_ess")),
            maximum_condition_number=float(scalar("maximum_condition_number")),
            positive_support_renormalized=bool(
                scalar("positive_support_renormalized")
            ),
            backend="numpy",
            bisection_iterations=int(scalar("bisection_iterations")),
        )
        instance.resolved_backend_ = str(scalar("resolved_backend"))
        instance.num_samples_ = int(scalar("num_samples"))
        instance.num_features_ = int(scalar("num_features"))
        instance.y_grid_ = np.asarray(state["y_grid"], dtype=np.float64)
        instance.q_grid_ = np.asarray(state["q_grid"], dtype=np.float64)
        instance.ess_grid_ = np.asarray(state["ess_grid"], dtype=np.float64)
        instance.data_covariance_ = np.asarray(
            state["data_covariance"], dtype=np.float64
        )
        instance.bandwidth_covariance_ = np.asarray(
            state["bandwidth_covariance"], dtype=np.float64
        )
        instance.scott_factor_ = np.asarray(state["scott_factor"], dtype=np.float64)
        instance.condition_number_ = np.asarray(
            state["condition_number"], dtype=np.float64
        )
        instance.max_root_error_ = np.asarray(
            state["max_root_error"], dtype=np.float64
        )
        instance.max_negative_mass_ = np.asarray(
            state["max_negative_mass"], dtype=np.float64
        )
        instance.central_min_ess_ = np.asarray(
            state["central_min_ess"], dtype=np.float64
        )
        instance.central_p05_ess_ = np.asarray(
            state["central_p05_ess"], dtype=np.float64
        )
        instance.central_median_ess_ = np.asarray(
            state["central_median_ess"], dtype=np.float64
        )
        instance.feature_pass_ = np.asarray(state["feature_pass"], dtype=bool)
        expected = (instance.num_features_, instance.grid_size)
        if instance.y_grid_.shape != expected or instance.q_grid_.shape != expected:
            raise ValueError("state 中临界函数形状不正确")
        if not np.all(np.isfinite(instance.q_grid_)) or np.any(instance.q_grid_ <= 0.0):
            raise ValueError("state 中临界函数含无效阈值")
        return instance
