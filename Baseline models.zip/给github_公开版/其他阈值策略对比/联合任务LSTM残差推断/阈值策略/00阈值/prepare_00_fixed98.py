# -*- coding: utf-8 -*-
"""只用正常标定集拟合 00 固定 98% 经验分位阈值。"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Sequence

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from main import DATASETS, compute, load_joint
from demo.anomaly_detection_demo import generate_synthetic_windows

from artifact_utils import (
    SCHEMA_VERSION,
    SCHEME_ID,
    fit_score,
    load_feature_array,
    load_optional_npz_array,
    save_json,
    save_score_state,
    sha256_file,
)


FIXED_QUANTILE = 0.98


def save_histogram(path: Path, scores: np.ndarray, threshold: float) -> Optional[str]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"

    fig, axis = plt.subplots(figsize=(9, 5))
    axis.hist(scores, bins=min(60, max(15, scores.size // 10)), color="#557a9e", alpha=0.82)
    axis.axvline(threshold, color="#dc633f", linewidth=2, label="98th percentile")
    axis.set_xlabel("calibration anomaly score")
    axis.set_ylabel("count")
    axis.set_title("Scheme 00 calibration score distribution")
    axis.grid(alpha=0.2)
    axis.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="准备 00 阈值方案：正常标定得分的固定 98% 经验分位数"
    )
    parser.add_argument("--dataset", required=True, choices=list(DATASETS))
    parser.add_argument("--calibration", type=Path, help="纯正常标定数据 .npy")
    parser.add_argument(
        "--array-key", default="X", help="当标定文件为 .npz 时使用的特征数组键"
    )
    parser.add_argument(
        "--label-key", default="y", help=".npz 中可选的正常标签键；存在时必须全为0"
    )
    parser.add_argument(
        "--input-space",
        choices=["raw", "standardized"],
        default="raw",
        help="标定特征所在空间；已标准化的数据必须显式选择 standardized",
    )
    parser.add_argument(
        "--score",
        choices=["mean", "max_robust", "mahalanobis"],
        default="mahalanobis",
        help="主实验默认 mahalanobis；正式对比中应保持不变",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=SCRIPT_DIR / "artifacts" / "formal",
    )
    parser.add_argument(
        "--self-check",
        action="store_true",
        help="没有真实标定集时使用合成正常数据验证流程；产物不可用于论文结果",
    )
    parser.add_argument("--self-check-size", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--batch-size", type=int, default=1024)
    return parser


def run(args: argparse.Namespace):
    if args.calibration is None and not args.self_check:
        raise ValueError("正式准备需要 --calibration；无数据时只能显式使用 --self-check")
    if args.calibration is not None and args.self_check:
        raise ValueError("--calibration 与 --self-check 不能同时使用")
    if args.self_check_size < 30:
        raise ValueError("--self-check-size 至少为 30")
    if args.batch_size < 1:
        raise ValueError("--batch-size 必须大于 0")

    print(f"加载 {args.dataset} 联合任务 LSTM……")
    bundle = load_joint(args.dataset)
    _, mean, std, cfg = bundle
    dataset_info = DATASETS[args.dataset]
    checkpoint_path = Path(dataset_info["ckpt"]).resolve()
    checkpoint_hash = sha256_file(checkpoint_path)

    if args.self_check:
        calibration, self_check_test, self_check_labels = generate_synthetic_windows(
            mean=mean,
            std=std,
            window_size=dataset_info["window_size"],
            calibration_size=args.self_check_size,
            test_size=40,
            anomaly_strength=5.0,
            seed=args.seed,
        )
        source_type = "synthetic_self_check"
        source_path = None
        source_hash = None
        formal = False
        input_metadata = {"format": "synthetic", "array_key": None, "available_keys": None}
        label_audit = None
        metadata_audit = None
        input_space = "raw"
    else:
        calibration_path = args.calibration.resolve()
        calibration, input_metadata = load_feature_array(calibration_path, args.array_key)
        label_audit = None
        if calibration_path.suffix.lower() == ".npz":
            available_keys = input_metadata["available_keys"] or []
            if args.label_key in available_keys:
                labels = load_optional_npz_array(calibration_path, args.label_key).reshape(-1)
                if labels.size != calibration.shape[0]:
                    raise ValueError(
                        f"标签数 {labels.size} 与标定窗口数 {calibration.shape[0]} 不一致"
                    )
                unique, counts = np.unique(labels, return_counts=True)
                label_audit = {
                    "label_key": args.label_key,
                    "counts": {str(key): int(value) for key, value in zip(unique, counts)},
                }
                if not np.all(labels == 0):
                    raise ValueError("正常标定集的标签并非全部为0，拒绝拟合正式阈值")
            metadata_audit = {}
            scalar_expectations = {
                "dataset": args.dataset,
                "input_space": args.input_space,
                "window_size": int(dataset_info["window_size"]),
                "feature_dimension": int(cfg["input_dim"]),
                "checkpoint_sha256": checkpoint_hash,
            }
            for key, expected in scalar_expectations.items():
                if key in available_keys:
                    actual = load_optional_npz_array(calibration_path, key).item()
                    actual = actual.item() if isinstance(actual, np.generic) else actual
                    metadata_audit[key] = {"file": actual, "expected": expected, "match": actual == expected}
                    if actual != expected:
                        raise ValueError(
                            f"标定文件元数据 {key}={actual!r} 与当前设置 {expected!r} 不一致"
                        )
            if "standardizer_mean" in available_keys:
                mean_in_file = load_optional_npz_array(calibration_path, "standardizer_mean")
                match = bool(np.allclose(mean_in_file, mean, rtol=1e-6, atol=1e-6))
                metadata_audit["standardizer_mean_match"] = match
                if not match:
                    raise ValueError("标定文件 standardizer_mean 与模型 checkpoint 不一致")
            if "standardizer_std" in available_keys:
                std_in_file = load_optional_npz_array(calibration_path, "standardizer_std")
                match = bool(np.allclose(std_in_file, std, rtol=1e-6, atol=1e-6))
                metadata_audit["standardizer_std_match"] = match
                if not match:
                    raise ValueError("标定文件 standardizer_std 与模型 checkpoint 不一致")
        else:
            metadata_audit = None
        source_type = "real_normal_calibration"
        source_path = str(calibration_path)
        source_hash = sha256_file(calibration_path)
        formal = True
        input_space = args.input_space

    if calibration.shape[-1] != int(cfg["input_dim"]):
        raise ValueError(
            f"标定特征维 {calibration.shape[-1]} 与 {args.dataset} 的 "
            f"input_dim={cfg['input_dim']} 不一致"
        )

    # main.compute 接收原始量纲。若文件已在 checkpoint 标准化空间，先精确反变换；
    # compute 内部会使用同一 mean/std 还原到模型需要的标准化输入，避免二次标准化。
    if input_space == "standardized":
        calibration_for_model = (
            calibration * std[None, None, :] + mean[None, None, :]
            if calibration.ndim == 3
            else calibration * std[None, :] + mean[None, :]
        ).astype(np.float32)
    else:
        calibration_for_model = calibration

    print(f"提取正常标定残差：input shape={calibration.shape}")
    if calibration_for_model.ndim == 3:
        residual_chunks = []
        total = calibration_for_model.shape[0]
        for start in range(0, total, args.batch_size):
            end = min(start + args.batch_size, total)
            full_chunk = compute(
                calibration_for_model[start:end],
                dataset=args.dataset,
                absolute=True,
                standardized=True,
                model_bundle=bundle,
            )
            residual_chunks.append(full_chunk.mean(axis=1))
        residual = np.concatenate(residual_chunks, axis=0)
    else:
        full_residual = compute(
            calibration_for_model,
            dataset=args.dataset,
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual = full_residual.mean(axis=1)
    scores, score_state = fit_score(residual, args.score)
    threshold = float(np.quantile(scores, FIXED_QUANTILE))

    args.output_dir.mkdir(parents=True, exist_ok=True)
    state_path = args.output_dir / "score_state.npz"
    scores_path = args.output_dir / "calibration_scores.npy"
    artifact_path = args.output_dir / "threshold_artifact.json"
    histogram_path = args.output_dir / "calibration_histogram.png"
    save_score_state(state_path, score_state)
    np.save(scores_path, scores.astype(np.float64))
    if args.self_check:
        np.save(args.output_dir / "synthetic_test_for_self_check.npy", self_check_test)
        np.save(args.output_dir / "synthetic_labels_for_self_check.npy", self_check_labels)

    quantiles = {
        str(q): float(np.quantile(scores, q))
        for q in (0.50, 0.90, 0.95, 0.98, 0.99, 0.995)
    }
    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    artifact = {
        "schema_version": SCHEMA_VERSION,
        "scheme_id": SCHEME_ID,
        "scheme_name": "固定 98% 经验分位阈值",
        "status": "READY_FOR_TEST" if formal else "SELF_CHECK_ONLY_NOT_FOR_RESULTS",
        "created_at_china": now_cn,
        "dataset": args.dataset,
        "model": {
            "checkpoint": checkpoint_path.name,
            "checkpoint_sha256": checkpoint_hash,
            "window_size": int(dataset_info["window_size"]),
            "input_dim": int(cfg["input_dim"]),
        },
        "residual": {
            "definition": "mean over time of abs(reconstruction - input)",
            "space": "standardized",
            "feature_dimension": int(residual.shape[1]),
        },
        "score": {
            "method": args.score,
            "state_file": state_path.name,
            "calibration_scores_file": scores_path.name,
        },
        "threshold": {
            "method": "empirical_quantile",
            "quantile": FIXED_QUANTILE,
            "value": threshold,
            "decision_rule": "score > threshold",
            "persistence": {"k": 1, "m": 1},
        },
        "calibration": {
            "source_type": source_type,
            "source_path": source_path,
            "source_sha256": source_hash,
            "input_shape": list(calibration.shape),
            "input_space": input_space,
            "file_structure": input_metadata,
            "label_audit": label_audit,
            "metadata_audit": metadata_audit,
            "num_windows": int(scores.size),
            "score_mean": float(np.mean(scores)),
            "score_std": float(np.std(scores)),
            "score_quantiles": quantiles,
            "inference_batch_size": int(args.batch_size),
        },
        "formal_result_allowed": formal,
        "notes": (
            "正式工件：仅由真实纯正常标定集生成，测试阶段不得重新拟合。"
            if formal
            else "合成数据自检工件：仅验证程序链路，严禁用于论文结果或真实测试。"
        ),
    }
    if args.self_check:
        artifact["self_check_files"] = {
            "test": "synthetic_test_for_self_check.npy",
            "labels": "synthetic_labels_for_self_check.npy",
        }
    plot_warning = save_histogram(histogram_path, scores, threshold)
    if plot_warning:
        artifact["histogram_warning"] = plot_warning
    else:
        artifact["histogram_file"] = histogram_path.name
    save_json(artifact_path, artifact)

    print(f"00 固定阈值（q=0.98）：{threshold:.8f}")
    print(f"状态：{artifact['status']}")
    print(f"阈值工件：{artifact_path.resolve()}")
    return artifact


def main(argv: Optional[Sequence[str]] = None):
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()

