# -*- coding: utf-8 -*-
"""运行分钟级/秒级各 5 个测试集，并生成统一评价汇总。"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from detect_00_fixed98 import run as run_detection
from artifact_utils import save_json


METRICS = (
    "precision",
    "recall",
    "specificity",
    "f1",
    "balanced_accuracy",
    "mcc",
    "roc_auc",
    "pr_auc",
    "false_positive_rate",
    "false_alarms_per_1000_normal_windows",
)


def seed_from_path(path: Path) -> int:
    match = re.search(r"seed(\d+)", path.stem)
    if not match:
        raise ValueError(f"无法从文件名读取 seed：{path.name}")
    return int(match.group(1))


def pooled_metrics(summaries: List[Dict[str, Any]]) -> Dict[str, float]:
    tp = sum(item["point_metrics"]["tp"] for item in summaries)
    fp = sum(item["point_metrics"]["fp"] for item in summaries)
    tn = sum(item["point_metrics"]["tn"] for item in summaries)
    fn = sum(item["point_metrics"]["fn"] for item in summaries)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    specificity = tn / max(tn + fp, 1)
    return {
        "tp": int(tp),
        "fp": int(fp),
        "tn": int(tn),
        "fn": int(fn),
        "precision": float(precision),
        "recall": float(recall),
        "specificity": float(specificity),
        "f1": float(2 * precision * recall / max(precision + recall, 1e-12)),
        "balanced_accuracy": float(0.5 * (recall + specificity)),
        "false_positive_rate": float(1.0 - specificity),
    }


def aggregate(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    aggregate_metrics: Dict[str, Any] = {}
    for metric in METRICS:
        values = np.asarray(
            [item["point_metrics"][metric] for item in summaries], dtype=np.float64
        )
        aggregate_metrics[metric] = {
            "mean": float(values.mean()),
            "std": float(values.std(ddof=1)) if values.size > 1 else 0.0,
            "min": float(values.min()),
            "max": float(values.max()),
        }

    all_types = sorted(
        {
            type_name
            for item in summaries
            for type_name in (item.get("type_metrics") or {}).keys()
        }
    )
    type_summary = {}
    for type_name in all_types:
        records = [
            item["type_metrics"][type_name]
            for item in summaries
            if type_name in (item.get("type_metrics") or {})
        ]
        if records and "point_recall" in records[0]:
            values = np.asarray([record["point_recall"] for record in records])
            type_summary[type_name] = {
                "kind": "anomaly",
                "count_per_seed": int(records[0]["count"]),
                "recall_mean": float(values.mean()),
                "recall_std": float(values.std(ddof=1)) if values.size > 1 else 0.0,
            }
        elif records and "point_false_positive_rate" in records[0]:
            values = np.asarray(
                [record["point_false_positive_rate"] for record in records]
            )
            type_summary[type_name] = {
                "kind": "normal",
                "count_per_seed": int(records[0]["count"]),
                "false_positive_rate_mean": float(values.mean()),
                "false_positive_rate_std": float(values.std(ddof=1))
                if values.size > 1
                else 0.0,
            }
    return {
        "num_seeds": len(summaries),
        "metrics_mean_std": aggregate_metrics,
        "pooled_confusion_metrics": pooled_metrics(summaries),
        "type_metrics": type_summary,
    }


def audit_test_design(test_files: List[Path]) -> Dict[str, Any]:
    records = []
    for path in test_files:
        with np.load(path, allow_pickle=False) as archive:
            records.append(
                {
                    "path": path,
                    "x": archive["x"],
                    "y": archive["y_true"].astype(np.int64),
                    "types": archive["y_type"].astype(str),
                }
            )
    base = records[0]
    anomaly_mask = base["y"] == 1
    normal_mask = ~anomaly_mask
    anomalies_identical = all(
        np.array_equal(base["x"][anomaly_mask], item["x"][item["y"] == 1])
        for item in records[1:]
    )
    normals_identical = all(
        np.array_equal(base["x"][normal_mask], item["x"][item["y"] == 0])
        for item in records[1:]
    )
    suspicious_types = sorted(
        {
            str(type_name)
            for type_name in base["types"][anomaly_mask]
            if "正常" in str(type_name)
        }
    )
    return {
        "num_test_files": len(records),
        "windows_per_file": int(base["y"].size),
        "normal_per_file": int(normal_mask.sum()),
        "anomaly_per_file": int(anomaly_mask.sum()),
        "label_transitions_per_file": int(np.count_nonzero(np.diff(base["y"]) != 0)),
        "anomaly_windows_identical_across_seeds": bool(anomalies_identical),
        "normal_windows_identical_across_seeds": bool(normals_identical),
        "timestamps_or_event_ids_available": False,
        "model_input_array": "x",
        "ignored_array": "x_std",
        "suspicious_positive_type_names_containing_normal": suspicious_types,
        "interpretation": (
            "五个种子共享相同异常窗口，仅正常窗口抽样不同；均值±标准差主要反映误报波动。"
        ),
    }


def write_seed_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fields = ["dataset", "time_scale", "seed", "threshold", *METRICS, "tp", "fp", "tn", "fn"]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            metrics = row["summary"]["point_metrics"]
            writer.writerow(
                {
                    "dataset": row["dataset"],
                    "time_scale": row["time_scale"],
                    "seed": row["seed"],
                    "threshold": row["summary"]["threshold"],
                    **{key: metrics[key] for key in METRICS},
                    **{key: metrics[key] for key in ("tp", "fp", "tn", "fn")},
                }
            )


def fmt(mean_std: Dict[str, float], digits: int = 4) -> str:
    return f"{mean_std['mean']:.{digits}f} ± {mean_std['std']:.{digits}f}"


def write_report(path: Path, result: Dict[str, Any]) -> None:
    lines = [
        "# 00固定98%阈值：分钟级与秒级测试评价",
        "",
        "## 评价口径",
        "",
        "- 主结果使用纯阈值判定（K=1，M=1）。",
        "- Primary：Recall、Precision、F1、PR-AUC、每1000正常窗口误报数。",
        "- Secondary：Specificity、Balanced Accuracy、MCC、ROC-AUC。",
        "- 每个时间尺度报告5个正常抽样种子的均值±样本标准差。",
        "- 5个种子的异常样本相同、正常样本不同，因此标准差主要反映误报抽样波动。",
        "- 文件没有真实时间戳或事件ID，不正式解释事件召回、检测提前量或检测延迟。",
        "",
        "## 总体结果",
        "",
        "| 时间尺度 | 阈值 | Precision | Recall | F1 | PR-AUC | Specificity | MCC | 误报/1000正常窗口 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        data = result[dataset]
        metrics = data["aggregate"]["metrics_mean_std"]
        lines.append(
            f"| {label} | {data['threshold']:.8f} | {fmt(metrics['precision'])} | "
            f"{fmt(metrics['recall'])} | {fmt(metrics['f1'])} | {fmt(metrics['pr_auc'])} | "
            f"{fmt(metrics['specificity'])} | {fmt(metrics['mcc'])} | "
            f"{fmt(metrics['false_alarms_per_1000_normal_windows'], 2)} |"
        )

    lines.extend(["", "## 单种子结果", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend(
            [
                f"### {label}",
                "",
                "| Seed | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |",
                "|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for run in result[dataset]["runs"]:
            metrics = run["point_metrics"]
            lines.append(
                f"| {run['seed']} | {metrics['precision']:.4f} | {metrics['recall']:.4f} | "
                f"{metrics['f1']:.4f} | {metrics['pr_auc']:.4f} | "
                f"{metrics['specificity']:.4f} | "
                f"{metrics['false_alarms_per_1000_normal_windows']:.2f} |"
            )
        lines.append("")

    lines.extend(["## 异常类型召回", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend(
            [
                f"### {label}",
                "",
                "| y_type | 每个seed样本数 | Recall均值 | Recall标准差 |",
                "|---|---:|---:|---:|",
            ]
        )
        for type_name, metrics in result[dataset]["aggregate"]["type_metrics"].items():
            if metrics["kind"] != "anomaly":
                continue
            lines.append(
                f"| {type_name} | {metrics['count_per_seed']} | "
                f"{metrics['recall_mean']:.4f} | {metrics['recall_std']:.4f} |"
            )
        lines.append("")

    lines.extend(
        [
            "## 测试集有效性审查",
            "",
            "| 时间尺度 | 每文件窗口 | 正常 | 异常 | 异常跨seed相同 | 正常跨seed相同 | 标签跳变数 |",
            "|---|---:|---:|---:|---|---|---:|",
        ]
    )
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        audit = result[dataset]["data_audit"]
        lines.append(
            f"| {label} | {audit['windows_per_file']} | {audit['normal_per_file']} | "
            f"{audit['anomaly_per_file']} | {audit['anomaly_windows_identical_across_seeds']} | "
            f"{audit['normal_windows_identical_across_seeds']} | "
            f"{audit['label_transitions_per_file']} |"
        )
    lines.extend(
        [
            "",
            "检测使用原始量纲数组 `x`，由对应模型 checkpoint 的标准化器处理；测试文件中的 "
            "`x_std` 未作为模型输入。五个 seed 的异常窗口完全相同、正常窗口不同，因此 "
            "Recall 的 seed 标准差为0是测试集设计所致，不表示对不同异常样本的泛化方差为0。",
            "",
            "测试文件没有时间戳或事件ID，且标签只有一次正常/异常跳变，所以不把自动计算的 "
            "事件召回和检测延迟作为正式结论。",
            "",
        ]
    )

    lines.extend(
        [
            "## 指标解释",
            "",
            "- Recall：异常窗口被检出的比例，漏报敏感，风机故障检测中应重点关注。",
            "- Precision：报警中真实异常的比例，反映告警可信度。",
            "- F1：Precision 与 Recall 的调和平均，用于综合比较。",
            "- PR-AUC：适用于类别不平衡数据，作为主要连续得分指标。",
            "- Specificity：正常窗口被正确识别的比例。",
            "- 误报/1000正常窗口：直接反映运维告警负担。",
            "- MCC / Balanced Accuracy：补充评价二分类整体质量。",
            "- ROC-AUC：作为补充指标，不单独用于选择阈值策略。",
            "",
            "完整逐点结果、混淆矩阵和异常类型召回见各 seed 目录及 evaluation_summary.json。",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="批量评价 00 阈值的双测试集")
    parser.add_argument("--test-root", type=Path, default=PROJECT_ROOT / "测试集数据")
    parser.add_argument("--output-root", type=Path, default=SCRIPT_DIR / "00实验结果")
    parser.add_argument("--batch-size", type=int, default=1024)
    return parser


def main() -> Dict[str, Any]:
    args = build_parser().parse_args()
    configs = {
        "dataset1": {
            "time_scale": "minute",
            "input_dir": args.test_root / "dataset1",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset1" / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset1_minute",
        },
        "dataset2": {
            "time_scale": "second",
            "input_dir": args.test_root / "dataset2",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset2" / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset2_second",
        },
    }
    all_rows = []
    final: Dict[str, Any] = {
        "scheme_id": "00_fixed98",
        "evaluation_rule": "point-level, K=1, M=1, five normal-sampling seeds",
        "event_metrics_formally_used": False,
        "event_metrics_exclusion_reason": "测试文件无真实时间戳或事件ID，且标签按正常块/异常块排列。",
    }
    for dataset, config in configs.items():
        test_files = sorted(config["input_dir"].glob("test_seed*.npz"), key=seed_from_path)
        if not test_files:
            raise FileNotFoundError(f"{config['input_dir']} 中没有 test_seed*.npz")
        summaries = []
        runs = []
        for test_file in test_files:
            seed = seed_from_path(test_file)
            output_dir = config["output_dir"] / f"seed{seed}"
            namespace = SimpleNamespace(
                artifact=config["artifact"],
                test=test_file,
                labels=None,
                output_dir=output_dir,
                k=1,
                m=1,
                batch_size=args.batch_size,
                allow_synthetic_artifact=False,
                array_key="x",
                label_key="y_true",
                type_key="y_type",
                input_space="raw",
            )
            summary = run_detection(namespace)
            summaries.append(summary)
            runs.append({"seed": seed, **summary})
            all_rows.append(
                {
                    "dataset": dataset,
                    "time_scale": config["time_scale"],
                    "seed": seed,
                    "summary": summary,
                }
            )
        final[dataset] = {
            "time_scale": config["time_scale"],
            "threshold": float(summaries[0]["threshold"]),
            "num_test_sets": len(summaries),
            "runs": runs,
            "aggregate": aggregate(summaries),
            "data_audit": audit_test_design(test_files),
        }

    args.output_root.mkdir(parents=True, exist_ok=True)
    save_json(args.output_root / "evaluation_summary.json", final)
    write_seed_csv(args.output_root / "per_seed_metrics.csv", all_rows)
    write_report(args.output_root / "evaluation_report.md", final)
    print(f"双测试集汇总：{(args.output_root / 'evaluation_report.md').resolve()}")
    return final


if __name__ == "__main__":
    main()

