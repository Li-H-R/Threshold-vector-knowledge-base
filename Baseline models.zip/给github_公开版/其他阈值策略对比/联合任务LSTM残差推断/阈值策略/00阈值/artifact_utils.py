# -*- coding: utf-8 -*-
"""00 固定 98% 分位方案的可复现得分工件工具。"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Tuple

import numpy as np
from sklearn.covariance import LedoitWolf


SCHEMA_VERSION = 1
SCHEME_ID = "00_fixed98"


def load_feature_array(path: Path, array_key: str = "X") -> Tuple[np.ndarray, Dict[str, Any]]:
    """读取 .npy 或 .npz 特征数组，并返回可审计的文件结构信息。"""
    path = path.resolve()
    if path.suffix.lower() == ".npy":
        array = np.load(path, allow_pickle=False)
        metadata = {"format": "npy", "array_key": None, "available_keys": None}
    elif path.suffix.lower() == ".npz":
        with np.load(path, allow_pickle=False) as archive:
            if array_key not in archive.files:
                raise ValueError(
                    f"{path.name} 中没有数组键 {array_key!r}；可选 {archive.files}"
                )
            array = archive[array_key]
            metadata = {
                "format": "npz",
                "array_key": array_key,
                "available_keys": list(archive.files),
            }
    else:
        raise ValueError("输入数据仅支持 .npy 或 .npz")
    array = np.asarray(array, dtype=np.float32)
    if array.ndim not in (2, 3):
        raise ValueError(f"特征数组应为 (T,D) 或 (N,T,D)，实际为 {array.shape}")
    if not np.all(np.isfinite(array)):
        raise ValueError("特征数组中存在 NaN 或 Inf")
    return array, metadata


def load_optional_npz_array(path: Path, key: str) -> np.ndarray:
    if path.suffix.lower() != ".npz":
        raise ValueError("只有 .npz 文件支持从内部读取额外数组")
    with np.load(path, allow_pickle=False) as archive:
        if key not in archive.files:
            raise ValueError(f"{path.name} 中没有数组键 {key!r}")
        return np.asarray(archive[key])


def check_residual(residual: np.ndarray) -> np.ndarray:
    residual = np.asarray(residual, dtype=np.float64)
    if residual.ndim != 2 or residual.shape[0] == 0:
        raise ValueError("残差应为非空的 (N, D) 数组")
    if not np.all(np.isfinite(residual)):
        raise ValueError("残差中存在 NaN 或 Inf")
    return residual


def fit_score(
    residual: np.ndarray, method: str
) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
    """仅使用正常标定残差拟合得分变换，并返回标定得分。"""
    residual = check_residual(residual)
    if method == "mean":
        return residual.mean(axis=1), {}

    if method == "max_robust":
        center = np.median(residual, axis=0)
        q25, q75 = np.quantile(residual, [0.25, 0.75], axis=0)
        scale = (q75 - q25) / 1.349
        positive = scale[scale > 1e-8]
        fallback = float(np.median(positive)) if positive.size else 1.0
        scale = np.where(scale > 1e-8, scale, fallback)
        state = {"center": center, "scale": scale}
        return transform_score(residual, method, state), state

    if method == "mahalanobis":
        estimator = LedoitWolf().fit(residual)
        state = {
            "location": estimator.location_.astype(np.float64),
            "precision": estimator.precision_.astype(np.float64),
            "covariance": estimator.covariance_.astype(np.float64),
            "shrinkage": np.asarray([estimator.shrinkage_], dtype=np.float64),
        }
        return transform_score(residual, method, state), state

    raise ValueError(f"未知得分方法 {method!r}")


def transform_score(
    residual: np.ndarray, method: str, state: Dict[str, np.ndarray]
) -> np.ndarray:
    """使用标定阶段保存的参数变换新残差；不在测试数据上重新拟合。"""
    residual = check_residual(residual)
    if method == "mean":
        score = residual.mean(axis=1)
    elif method == "max_robust":
        center = np.asarray(state["center"], dtype=np.float64)
        scale = np.asarray(state["scale"], dtype=np.float64)
        score = np.max((residual - center) / scale, axis=1)
    elif method == "mahalanobis":
        location = np.asarray(state["location"], dtype=np.float64)
        precision = np.asarray(state["precision"], dtype=np.float64)
        delta = residual - location
        squared = np.einsum("ni,ij,nj->n", delta, precision, delta)
        score = np.sqrt(np.maximum(squared, 0.0))
    else:
        raise ValueError(f"未知得分方法 {method!r}")
    if not np.all(np.isfinite(score)):
        raise ValueError("异常得分中存在 NaN 或 Inf")
    return score.astype(np.float64)


def save_score_state(path: Path, state: Dict[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **state)


def load_score_state(path: Path) -> Dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as data:
        return {key: data[key] for key in data.files}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def save_json(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def load_artifact(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        artifact = json.load(handle)
    if artifact.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("不支持的阈值工件 schema_version")
    if artifact.get("scheme_id") != SCHEME_ID:
        raise ValueError("该工件不是 00_fixed98 方案")
    return artifact

