# -*- coding: utf-8 -*-
"""加载已冻结的 00 固定 98% 阈值工件，对未来测试集执行检测。"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Optional, Sequence

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from main import DATASETS, compute, load_joint
from demo.anomaly_detection_demo import align_labels, evaluate, event_ranges, load_labels
from demo.threshold_strategies import causal_k_of_m

from artifact_utils import (
    load_feature_array,
    load_artifact,
    load_optional_npz_array,
    load_score_state,
    save_json,
    sha256_file,
    transform_score,
)


def save_plot(
    path: Path,
    scores: np.ndarray,
    threshold: float,
    labels: Optional[np.ndarray],
) -> Optional[str]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"
    x = np.arange(scores.size)
    fig, axis = plt.subplots(figsize=(13, 5))
    axis.plot(x, scores, color="#24496e", linewidth=1.1, label="anomaly score")
    axis.axhline(threshold, color="#e56b3f", linewidth=1.5, label="fixed q98 threshold")
    if labels is not None:
        for start, end in event_ranges(labels):
            axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.14)
    axis.set_xlabel("test window index")
    axis.set_ylabel("score")
    axis.set_title("Scheme 00: fixed empirical 98th-percentile threshold")
    axis.grid(alpha=0.2)
    axis.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="运行 00 固定 98% 阈值测试")
    parser.add_argument("--artifact", required=True, type=Path)
    parser.add_argument("--test", required=True, type=Path)
    parser.add_argument("--labels", type=Path)
    parser.add_argument("--array-key", default="X", help="测试文件为 .npz 时的特征数组键")
    parser.add_argument(
        "--label-key", default="y", help="未提供 --labels 时，从测试 .npz 读取该标签键"
    )
    parser.add_argument(
        "--type-key", default="y_type", help="测试 .npz 中可选的异常类型数组键"
    )
    parser.add_argument(
        "--input-space",
        choices=["artifact", "raw", "standardized"],
        default="artifact",
        help="默认继承标定工件记录的输入空间",
    )
    parser.add_argument("--output-dir", type=Path, default=SCRIPT_DIR / "00实验结果")
    parser.add_argument("--k", type=int, default=1)
    parser.add_argument("--m", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument(
        "--allow-synthetic-artifact",
        action="store_true",
        help="仅供程序自检；正式实验严禁使用合成标定工件",
    )
    return parser


def run(args: argparse.Namespace):
    if args.batch_size < 1:
        raise ValueError("--batch-size 必须大于 0")
    artifact_path = args.artifact.resolve()
    artifact = load_artifact(artifact_path)
    if not artifact["formal_result_allowed"] and not args.allow_synthetic_artifact:
        raise ValueError(
            "该工件由合成标定数据生成，只能自检。请用真实纯正常标定集重新 prepare，"
            "或仅在明确自检时使用 --allow-synthetic-artifact。"
        )

    dataset = artifact["dataset"]
    bundle = load_joint(dataset)
    _, mean, std, cfg = bundle
    checkpoint = Path(DATASETS[dataset]["ckpt"]).resolve()
    actual_hash = sha256_file(checkpoint)
    expected_hash = artifact["model"]["checkpoint_sha256"]
    if actual_hash != expected_hash:
        raise ValueError("当前模型 checkpoint 与标定阈值使用的 checkpoint 不一致")

    test_path = args.test.resolve()
    test, test_metadata = load_feature_array(test_path, args.array_key)
    if test.shape[-1] != int(cfg["input_dim"]):
        raise ValueError(
            f"测试特征维 {test.shape[-1]} 与 {dataset} 的 input_dim={cfg['input_dim']} 不一致"
        )
    input_space = (
        artifact["calibration"].get("input_space", "raw")
        if args.input_space == "artifact"
        else args.input_space
    )
    if input_space == "standardized":
        test_for_model = (
            test * std[None, None, :] + mean[None, None, :]
            if test.ndim == 3
            else test * std[None, :] + mean[None, :]
        ).astype(np.float32)
    else:
        test_for_model = test
    if test_for_model.ndim == 3:
        residual_chunks = []
        for start in range(0, test_for_model.shape[0], args.batch_size):
            end = min(start + args.batch_size, test_for_model.shape[0])
            full_chunk = compute(
                test_for_model[start:end],
                dataset=dataset,
                absolute=True,
                standardized=True,
                model_bundle=bundle,
            )
            residual_chunks.append(full_chunk.mean(axis=1))
        residual = np.concatenate(residual_chunks, axis=0)
    else:
        full_residual = compute(
            test_for_model,
            dataset=dataset,
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual = full_residual.mean(axis=1)
    state_file = artifact_path.parent / artifact["score"]["state_file"]
    score_state = load_score_state(state_file)
    scores = transform_score(residual, artifact["score"]["method"], score_state)
    threshold = float(artifact["threshold"]["value"])
    point_pred = scores > threshold
    alarm = causal_k_of_m(point_pred, k=args.k, m=args.m)

    labels = None
    anomaly_types = None
    if args.labels is not None:
        labels = align_labels(load_labels(args.labels), test, scores.size)
    elif test_path.suffix.lower() == ".npz":
        available_keys = test_metadata["available_keys"] or []
        if args.label_key in available_keys:
            embedded_labels = load_optional_npz_array(test_path, args.label_key)
            labels = align_labels(embedded_labels, test, scores.size)
    if test_path.suffix.lower() == ".npz":
        available_keys = test_metadata["available_keys"] or []
        if args.type_key in available_keys:
            anomaly_types = load_optional_npz_array(test_path, args.type_key).reshape(-1)
            if anomaly_types.size == test.shape[0] and anomaly_types.size != scores.size:
                anomaly_types = anomaly_types[-scores.size :]
            if anomaly_types.size != scores.size:
                raise ValueError(
                    f"异常类型数 {anomaly_types.size} 与模型输出窗口数 {scores.size} 不一致"
                )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.output_dir / "detections.csv"
    summary_path = args.output_dir / "summary.json"
    plot_path = args.output_dir / "fixed98_detection.png"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "index",
                "label",
                "anomaly_type",
                "score",
                "threshold",
                "point_pred",
                "alarm",
            ]
        )
        for i in range(scores.size):
            writer.writerow(
                [
                    i,
                    "" if labels is None else int(labels[i]),
                    "" if anomaly_types is None else str(anomaly_types[i]),
                    float(scores[i]),
                    threshold,
                    int(point_pred[i]),
                    int(alarm[i]),
                ]
            )

    decision_margin = scores - threshold
    type_metrics = None
    if labels is not None and anomaly_types is not None:
        type_metrics = {}
        for type_name in np.unique(anomaly_types):
            mask = anomaly_types == type_name
            count = int(mask.sum())
            positive_count = int(labels[mask].sum())
            item = {
                "count": count,
                "positive_count": positive_count,
                "point_predicted_positive": int(point_pred[mask].sum()),
                "alarm_predicted_positive": int(alarm[mask].sum()),
            }
            if positive_count == count:
                item["point_recall"] = float(point_pred[mask].mean())
                item["alarm_recall"] = float(alarm[mask].mean())
            elif positive_count == 0:
                item["point_false_positive_rate"] = float(point_pred[mask].mean())
                item["alarm_false_positive_rate"] = float(alarm[mask].mean())
            type_metrics[str(type_name)] = item

    label_transitions = (
        int(np.count_nonzero(np.diff(labels) != 0))
        if labels is not None and labels.size > 1
        else None
    )
    chronological_metadata = bool(
        set(test_metadata.get("available_keys") or [])
        & {"timestamp", "timestamp_start", "timestamp_end", "event_id"}
    )
    summary = {
        "scheme_id": artifact["scheme_id"],
        "artifact": str(artifact_path),
        "artifact_status": artifact["status"],
        "dataset": dataset,
        "test_file": str(test_path),
        "test_sha256": sha256_file(test_path),
        "test_file_structure": test_metadata,
        "test_input_space": input_space,
        "test_input_shape": list(test.shape),
        "num_windows": int(scores.size),
        "score_method": artifact["score"]["method"],
        "threshold_quantile": artifact["threshold"]["quantile"],
        "threshold": threshold,
        "persistence": {"k": args.k, "m": args.m},
        "num_point_exceedances": int(point_pred.sum()),
        "num_alarms": int(alarm.sum()),
        "type_metrics": type_metrics,
        "sequence_audit": {
            "label_transitions": label_transitions,
            "chronological_or_event_metadata_available": chronological_metadata,
            "event_metrics_physically_interpretable": chronological_metadata,
            "note": (
                "无时间戳或事件ID；事件召回和检测延迟仅反映文件排列，不作为正式评价。"
                if not chronological_metadata
                else "存在时间或事件元数据，仍需确认文件保持真实时间顺序。"
            ),
        },
        "point_metrics": (
            evaluate(labels, point_pred, decision_margin) if labels is not None else None
        ),
        "alarm_metrics": (
            evaluate(labels, alarm, decision_margin) if labels is not None else None
        ),
        "formal_result_allowed": bool(artifact["formal_result_allowed"]),
    }
    warning = save_plot(plot_path, scores, threshold, labels)
    if warning:
        summary["plot_warning"] = warning
    else:
        summary["plot"] = str(plot_path.resolve())
    save_json(summary_path, summary)
    print(f"测试窗口数：{scores.size}")
    print(f"固定阈值：{threshold:.8f}")
    print(f"点级超限：{int(point_pred.sum())}，最终报警：{int(alarm.sum())}")
    print(f"结果：{summary_path.resolve()}")
    return summary


def main(argv: Optional[Sequence[str]] = None):
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()

