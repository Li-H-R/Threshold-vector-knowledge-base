# 00 阈值方案：固定 98% 经验分位数

## 当前正式阈值

| 时间尺度 | 模型 | 正常标定窗口 | 特征维数 | 固定 98% 阈值 | 工件状态 |
|---|---|---:|---:|---:|---|
| 分钟级 | `dataset1` | 1960 | 8 | `5.12051469` | `READY_FOR_TEST` |
| 秒级 | `dataset2` | 20000 | 15 | `6.83805071` | `READY_FOR_TEST` |

两个阈值分别位于 `artifacts/formal_dataset1` 和 `artifacts/formal_dataset2`，不能跨数据集使用。

## 双测试集正式结果

当前状态：`TESTED_BOTH_DATASETS`。

分钟级和秒级各检测5个测试文件。主结果使用 `K=1, M=1`，报告5个正常抽样种子的
均值 ± 样本标准差：

| 时间尺度 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |
|---|---:|---:|---:|---:|---:|---:|
| 分钟级 | 0.9880 ± 0.0027 | 0.7842 ± 0.0000 | 0.8744 ± 0.0010 | 0.9621 ± 0.0006 | 0.9904 ± 0.0022 | 9.57 ± 2.15 |
| 秒级 | 0.9646 ± 0.0080 | 0.6086 ± 0.0000 | 0.7463 ± 0.0024 | 0.9075 ± 0.0030 | 0.9776 ± 0.0053 | 22.42 ± 5.27 |

完整评价见 [00实验结果/evaluation_report.md](00实验结果/evaluation_report.md)。

测试文件没有真实时间戳或事件ID，且每个文件按正常块/异常块排列，因此本次不把自动
计算的事件召回和检测延迟作为正式结论。5个种子的异常窗口相同、正常窗口不同，Recall
标准差为0主要由测试集构造方式导致。

## 方案定义

`00` 是项目设置的简单基线，没有对应论文。它使用纯正常标定数据建立异常得分分布，
并取第 98 百分位作为固定阈值：

```text
threshold = empirical_quantile(normal_calibration_score, 0.98)
prediction = test_score > threshold
```

为保证后续阈值策略公平比较，本方案沿用 Demo 的统一得分口径：

1. 联合任务 LSTM 输出标准化空间绝对重构残差；
2. 沿窗口时间维求均值，得到逐特征残差 `(N, D)`；
3. 只在正常标定集上拟合 Ledoit-Wolf 收缩 Mahalanobis 得分；
4. 取正常标定得分的 98% 经验分位数；
5. 测试阶段加载冻结的得分参数和阈值，不重新拟合。

## 当前状态

测试集尚未提供，因此目前能完成：

- 00 方案的固定实现；
- 模型和数据维度检查；
- 正常标定接口；
- 阈值、得分参数和数据/模型哈希固化；
- 合成正常数据的程序自检；
- 未来测试集检测入口；
- 标签可选的指标、CSV 和曲线输出。

正式阈值还需要一份**纯正常标定集**，支持 `.npy` 和 `.npz`，测试集不参与这一步。

## 第一步：无真实数据时做程序自检

`dataset2` 示例：

```powershell
python 阈值策略\00阈值\prepare_00_fixed98.py `
  --dataset dataset2 `
  --self-check `
  --output-dir 阈值策略\00阈值\artifacts\self_check
```

该命令生成的 `threshold_artifact.json` 会明确标记：

```text
SELF_CHECK_ONLY_NOT_FOR_RESULTS
```

它只能证明程序能够运行，不能用于真实测试或论文结果。
自检目录还会生成 `synthetic_test_for_self_check.npy` 和
`synthetic_labels_for_self_check.npy`，用于验证未来测试入口。

完整自检命令：

```powershell
python 阈值策略\00阈值\detect_00_fixed98.py `
  --artifact 阈值策略\00阈值\artifacts\self_check\threshold_artifact.json `
  --test 阈值策略\00阈值\artifacts\self_check\synthetic_test_for_self_check.npy `
  --labels 阈值策略\00阈值\artifacts\self_check\synthetic_labels_for_self_check.npy `
  --allow-synthetic-artifact `
  --output-dir 阈值策略\00阈值\artifacts\self_check_detection
```

## 第二步：提供正常标定集后生成正式阈值

数据可以是已切好的窗口 `(N, 10, D)`，也可以是连续序列 `(T, D)`：

```powershell
python 阈值策略\00阈值\prepare_00_fixed98.py `
  --dataset dataset2 `
  --calibration data\normal_calibration.npy `
  --score mahalanobis `
  --output-dir 阈值策略\00阈值\artifacts\formal_dataset2
```

如果标定文件是 `.npz`，特征保存在 `X`，且数据已经使用模型标准化器标准化：

```powershell
python 阈值策略\00阈值\prepare_00_fixed98.py `
  --dataset dataset1 `
  --calibration 阈值标定集.npz `
  --array-key X `
  --label-key y `
  --input-space standardized `
  --score mahalanobis `
  --output-dir 阈值策略\00阈值\artifacts\formal_dataset1
```

如果 `.npz` 中存在 `y`，正式标定会强制检查所有标签均为0；出现异常标签时拒绝拟合。

正式输出包括：

| 文件 | 作用 |
|---|---|
| `threshold_artifact.json` | 固定阈值、数据口径、模型哈希和标定摘要 |
| `score_state.npz` | Mahalanobis 中心和收缩精度矩阵 |
| `calibration_scores.npy` | 正常标定异常得分，便于审计 |
| `calibration_histogram.png` | 正常得分分布和 98% 阈值 |

正式工件状态为 `READY_FOR_TEST`。

## 第三步：未来测试集到位后检测

无标签也可以先检测：

```powershell
python 阈值策略\00阈值\detect_00_fixed98.py `
  --artifact 阈值策略\00阈值\artifacts\formal_dataset2\threshold_artifact.json `
  --test data\test_windows.npy `
  --output-dir 阈值策略\00阈值\00实验结果\dataset2
```

有标签时增加：

```text
--labels data\test_labels.npy
```

00 方案的纯阈值复现固定使用：

```text
--k 1 --m 1
```

K-of-M 应作为后续独立实验，不能混入 00 纯阈值主结果。

## 防止数据泄漏

- 正常标定集不能包含异常或故障发展阶段；
- 测试集不能参与 Mahalanobis 中心、协方差或 98% 阈值计算；
- 测试阶段不能因为结果不好重新调整 0.98；
- 标定和测试必须使用同一个 checkpoint、标准化器和特征顺序；
- 正式测试脚本会校验 checkpoint SHA-256；
- 合成自检工件默认禁止用于测试，除非显式使用仅供调试的开关。

## 等待的数据

下一步只需要先提供：

```text
纯正常标定数据 .npy
数据集类型：dataset1 或 dataset2
```

测试数据和标签可以稍后提供。

