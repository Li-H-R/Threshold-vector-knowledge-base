# -*- coding: utf-8 -*-
"""只用纯正常标定得分准备 01 Gaussian KDE 99.7% 阈值工件。"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np
import torch


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from strategy_01_kde997 import (  # noqa: E402
    DEFAULT_CONFIDENCE_LEVEL,
    KDE997Threshold,
    SCHEMA_VERSION,
    STRATEGY_ID,
)


CONFIG_PATH = SCRIPT_DIR / "experiment_config.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"{path} 的顶层必须是 JSON object")
    return value


def save_json(path: Path, value: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def resolve_project_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="准备 01 阈值：正常 Mahalanobis 得分的 Gaussian KDE 99.7% 分位点"
    )
    parser.add_argument("--dataset", required=True, choices=("dataset1", "dataset2"))
    parser.add_argument(
        "--upstream-score-artifact",
        type=Path,
        help="00 正式得分工件目录；默认从 experiment_config.json 读取",
    )
    parser.add_argument(
        "--confidence-level", type=float, default=DEFAULT_CONFIDENCE_LEVEL
    )
    parser.add_argument("--bandwidth-rule", choices=("scott",), default="scott")
    parser.add_argument(
        "--bootstrap-replicates",
        type=int,
        default=200,
        help="只用正常标定得分进行阈值稳定性审计；0 表示跳过",
    )
    parser.add_argument("--bootstrap-seed", type=int, default=20261104)
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="正式输出目录；默认从 experiment_config.json 读取",
    )
    return parser


def audit_normal_calibration(
    calibration_path: Path,
    dataset: str,
    contract: Dict[str, Any],
    upstream_artifact: Dict[str, Any],
) -> Tuple[Dict[str, Any], int]:
    expected_hash = str(contract["calibration_sha256"])
    actual_hash = sha256_file(calibration_path)
    if actual_hash != expected_hash:
        raise ValueError("正常标定文件 SHA-256 与冻结配置不一致")
    if actual_hash != upstream_artifact["calibration"]["source_sha256"]:
        raise ValueError("正常标定文件 SHA-256 与上游 00 工件不一致")

    with np.load(calibration_path, allow_pickle=False) as archive:
        if "X" not in archive.files or "y" not in archive.files:
            raise ValueError("正常标定 NPZ 必须同时包含 X 和 y")
        features = np.asarray(archive["X"])
        labels = np.asarray(archive["y"]).reshape(-1)
        if list(features.shape) != list(contract["calibration_shape"]):
            raise ValueError(
                f"正常标定 X 形状 {features.shape} 与冻结配置不一致"
            )
        if labels.size != features.shape[0]:
            raise ValueError("正常标定 y 长度与窗口数不一致")
        if not np.all(labels == 0):
            raise ValueError("正常标定标签并非全部为 0，拒绝正式拟合")
        if not np.all(np.isfinite(features)):
            raise ValueError("正常标定特征中存在 NaN 或 Inf")

        unique, counts = np.unique(labels, return_counts=True)
        label_counts = {
            str(key.item() if isinstance(key, np.generic) else key): int(value)
            for key, value in zip(unique, counts)
        }
        present_metadata = {}
        for key in (
            "dataset",
            "input_space",
            "window_size",
            "feature_dimension",
            "checkpoint_name",
            "checkpoint_sha256",
        ):
            if key in archive.files:
                value = archive[key]
                present_metadata[key] = (
                    value.item() if np.asarray(value).ndim == 0 else value.tolist()
                )

    if dataset == "dataset2":
        expected_metadata = {
            "dataset": dataset,
            "input_space": contract["input_space"],
            "window_size": 10,
            "feature_dimension": int(contract["input_dim"]),
            "checkpoint_sha256": contract["model_sha256"],
        }
        for key, expected in expected_metadata.items():
            if present_metadata.get(key) != expected:
                raise ValueError(
                    f"秒级正常标定元数据 {key}={present_metadata.get(key)!r}，"
                    f"期望 {expected!r}"
                )

    metadata_gaps = [
        key
        for key in (
            "dataset",
            "input_space",
            "window_size",
            "feature_dimension",
            "checkpoint_sha256",
        )
        if key not in present_metadata
    ]
    audit = {
        "dataset": dataset,
        "source_path": str(calibration_path),
        "source_sha256": actual_hash,
        "input_shape": list(features.shape),
        "label_counts": label_counts,
        "all_labels_normal": True,
        "all_features_finite": True,
        "expected_input_space": contract["input_space"],
        "input_space_evidence": contract["input_space_evidence"],
        "present_source_metadata": present_metadata,
        "source_metadata_gaps": metadata_gaps,
        "source_file_modified": False,
        "test_data_used": False,
    }
    return audit, int(features.shape[0])


def audit_model(model_path: Path, contract: Dict[str, Any]) -> Dict[str, Any]:
    actual_hash = sha256_file(model_path)
    if actual_hash != contract["model_sha256"]:
        raise ValueError("模型 checkpoint SHA-256 与冻结配置不一致")
    checkpoint = torch.load(model_path, map_location="cpu", weights_only=False)
    model_config = checkpoint.get("model_config", {})
    input_dim = int(model_config.get("input_dim", -1))
    if input_dim != int(contract["input_dim"]):
        raise ValueError("模型 input_dim 与数据集冻结配置不一致")
    standardizer = checkpoint.get("standardizer", {})
    if len(standardizer.get("mean", [])) != input_dim:
        raise ValueError("checkpoint standardizer.mean 维数不正确")
    if len(standardizer.get("std", [])) != input_dim:
        raise ValueError("checkpoint standardizer.std 维数不正确")
    return {
        "checkpoint": model_path.name,
        "checkpoint_path": str(model_path),
        "checkpoint_sha256": actual_hash,
        "model_config": model_config,
        "standardizer_dimension": input_dim,
    }


def audit_upstream_scores(
    upstream_dir: Path,
    dataset: str,
    contract: Dict[str, Any],
    num_windows: int,
) -> Tuple[np.ndarray, Dict[str, Any], Dict[str, Any]]:
    artifact_path = upstream_dir / "threshold_artifact.json"
    score_path = upstream_dir / "calibration_scores.npy"
    score_state_path = upstream_dir / "score_state.npz"
    for path in (artifact_path, score_path, score_state_path):
        if not path.is_file():
            raise FileNotFoundError(f"缺少上游公共得分工件：{path}")

    artifact = load_json(artifact_path)
    if artifact.get("scheme_id") != "00_fixed98":
        raise ValueError("上游工件不是 00_fixed98")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("上游 00 工件状态不是 READY_FOR_TEST")
    if artifact.get("formal_result_allowed") is not True:
        raise ValueError("上游 00 工件不是正式真实标定工件")
    if artifact.get("dataset") != dataset:
        raise ValueError("上游 00 工件的数据集标识不匹配")
    if artifact["model"]["checkpoint_sha256"] != contract["model_sha256"]:
        raise ValueError("上游 00 工件的模型哈希与冻结配置不一致")
    if artifact["calibration"]["source_sha256"] != contract["calibration_sha256"]:
        raise ValueError("上游 00 工件的正常标定哈希与冻结配置不一致")
    if artifact["score"]["method"] != "mahalanobis":
        raise ValueError("01 主实验只允许复用 Mahalanobis 公共得分")
    if artifact["residual"]["space"] != "standardized":
        raise ValueError("上游残差不在标准化空间")
    if artifact["calibration"]["num_windows"] != num_windows:
        raise ValueError("上游得分窗口数与正常标定窗口数不一致")

    scores = np.load(score_path, allow_pickle=False)
    scores = np.asarray(scores, dtype=np.float64).reshape(-1)
    if scores.size != num_windows:
        raise ValueError("上游 calibration_scores 长度不正确")

    with np.load(score_state_path, allow_pickle=False) as state:
        required = {"location", "precision", "covariance", "shrinkage"}
        if not required.issubset(state.files):
            raise ValueError("上游 Mahalanobis score_state 字段不完整")
        input_dim = int(contract["input_dim"])
        if np.asarray(state["location"]).shape != (input_dim,):
            raise ValueError("上游 Mahalanobis location 维数不正确")
        if np.asarray(state["precision"]).shape != (input_dim, input_dim):
            raise ValueError("上游 Mahalanobis precision 维数不正确")

    audit = {
        "artifact_dir": str(upstream_dir),
        "artifact_file": str(artifact_path),
        "artifact_sha256": sha256_file(artifact_path),
        "score_state_file": str(score_state_path),
        "score_state_sha256": sha256_file(score_state_path),
        "calibration_scores_file": str(score_path),
        "calibration_scores_sha256": sha256_file(score_path),
        "num_scores": int(scores.size),
        "score_method": "ledoit_wolf_mahalanobis",
        "upstream_empirical_threshold_not_used": True,
    }
    return scores, artifact, audit


def bootstrap_thresholds(
    scores: np.ndarray,
    confidence_level: float,
    bandwidth_rule: str,
    replicates: int,
    seed: int,
) -> np.ndarray:
    if replicates < 0:
        raise ValueError("--bootstrap-replicates 不能为负数")
    if replicates == 0:
        return np.empty(0, dtype=np.float64)
    rng = np.random.default_rng(seed)
    thresholds = np.empty(replicates, dtype=np.float64)
    for index in range(replicates):
        sampled = scores[rng.integers(0, scores.size, size=scores.size)]
        strategy = KDE997Threshold(
            confidence_level=confidence_level,
            bandwidth_rule=bandwidth_rule,
        ).fit(sampled)
        thresholds[index] = float(strategy.threshold_)
    return thresholds


def save_curve_and_plot(
    output_dir: Path,
    scores: np.ndarray,
    strategy: KDE997Threshold,
    dataset: str,
) -> Dict[str, Any]:
    assert strategy.threshold_ is not None
    assert strategy.effective_bandwidth_ is not None
    upper = max(
        float(strategy.threshold_ * 1.25),
        float(np.quantile(scores, 0.9995) + 3.0 * strategy.effective_bandwidth_),
    )
    grid = np.linspace(0.0, upper, 1200)
    pdf = np.asarray(strategy.pdf(grid), dtype=np.float64)
    cdf = np.asarray(strategy.cdf_positive(grid), dtype=np.float64)
    curve = np.column_stack((grid, pdf, cdf))
    curve_path = output_dir / "calibration_kde_curve.csv"
    np.savetxt(
        curve_path,
        curve,
        delimiter=",",
        header="score,pdf,cdf_positive",
        comments="",
        fmt="%.12g",
    )

    plot_path = output_dir / "calibration_kde_plot.png"
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        figure, axis = plt.subplots(figsize=(9.5, 5.5))
        axis.hist(
            scores,
            bins=80,
            range=(0.0, upper),
            density=True,
            color="#5f7f9f",
            alpha=0.55,
            label="normal calibration scores",
        )
        axis.plot(grid, pdf, color="#173f5f", linewidth=2.0, label="Gaussian KDE")
        axis.axvline(
            strategy.threshold_,
            color="#d1495b",
            linewidth=2.0,
            label=f"99.7% threshold = {strategy.threshold_:.6f}",
        )
        axis.set_xlim(0.0, upper)
        axis.set_xlabel("Mahalanobis calibration score")
        axis.set_ylabel("density")
        axis.set_title(f"01 KDE calibration only - {dataset}")
        axis.grid(alpha=0.2)
        axis.legend()
        figure.tight_layout()
        figure.savefig(plot_path, dpi=180, bbox_inches="tight")
        plt.close(figure)
        plot_warning = None
    except ImportError:
        plot_warning = "matplotlib_not_installed"

    return {
        "curve_file": curve_path.name,
        "plot_file": plot_path.name if plot_warning is None else None,
        "plot_warning": plot_warning,
        "plot_x_max": upper,
        "scores_above_plot_range": int(np.sum(scores > upper)),
    }


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config = load_json(CONFIG_PATH)
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("experiment_config.json 的 strategy_id 不正确")
    if not np.isclose(
        args.confidence_level, DEFAULT_CONFIDENCE_LEVEL, rtol=0.0, atol=1e-15
    ):
        raise ValueError("正式主实验 confidence_level 必须固定为 0.997")

    contract = config["datasets"][args.dataset]
    model_path = resolve_project_path(contract["model"])
    calibration_path = resolve_project_path(contract["calibration"])
    upstream_dir = (
        args.upstream_score_artifact.resolve()
        if args.upstream_score_artifact
        else resolve_project_path(contract["upstream_score_artifact"])
    )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir
        else resolve_project_path(contract["artifact_dir"])
    )
    if "测试集数据" in output_dir.parts:
        raise ValueError("准备阶段禁止把输出写入测试集目录")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖正式工件：{output_dir}")

    model_audit = audit_model(model_path, contract)
    upstream_artifact = load_json(upstream_dir / "threshold_artifact.json")
    calibration_audit, num_windows = audit_normal_calibration(
        calibration_path, args.dataset, contract, upstream_artifact
    )
    scores, _, upstream_audit = audit_upstream_scores(
        upstream_dir, args.dataset, contract, num_windows
    )

    strategy = KDE997Threshold(
        confidence_level=args.confidence_level,
        bandwidth_rule=args.bandwidth_rule,
    ).fit(scores)
    state = strategy.state_dict()
    if state["root_residual"] > 1e-10:
        raise RuntimeError("KDE 阈值求根残差未通过门禁")

    print(
        f"{args.dataset}: 正常得分 {scores.size} 个，开始 "
        f"{args.bootstrap_replicates} 次 bootstrap 稳定性审计……"
    )
    bootstrap = bootstrap_thresholds(
        scores,
        args.confidence_level,
        args.bandwidth_rule,
        args.bootstrap_replicates,
        args.bootstrap_seed,
    )
    bootstrap_summary: Dict[str, Any]
    if bootstrap.size:
        bootstrap_summary = {
            "replicates": int(bootstrap.size),
            "seed": int(args.bootstrap_seed),
            "mean": float(np.mean(bootstrap)),
            "std": float(np.std(bootstrap, ddof=1)) if bootstrap.size > 1 else 0.0,
            "median": float(np.median(bootstrap)),
            "ci_2_5": float(np.quantile(bootstrap, 0.025)),
            "ci_97_5": float(np.quantile(bootstrap, 0.975)),
            "min": float(np.min(bootstrap)),
            "max": float(np.max(bootstrap)),
            "changes_formal_threshold": False,
        }
    else:
        bootstrap_summary = {
            "replicates": 0,
            "seed": int(args.bootstrap_seed),
            "changes_formal_threshold": False,
        }

    output_dir.mkdir(parents=True, exist_ok=False)
    copied_scores_path = output_dir / "calibration_scores.npy"
    shutil.copy2(upstream_dir / "calibration_scores.npy", copied_scores_path)
    if sha256_file(copied_scores_path) != upstream_audit["calibration_scores_sha256"]:
        raise RuntimeError("复制后的正常标定得分哈希不一致")

    state_path = output_dir / "kde_state.json"
    save_json(state_path, state)
    if bootstrap.size:
        np.save(output_dir / "bootstrap_thresholds.npy", bootstrap)
    save_json(output_dir / "normal_calibration_audit.json", calibration_audit)
    plot_audit = save_curve_and_plot(output_dir, scores, strategy, args.dataset)

    reloaded_state = load_json(state_path)
    reloaded_scores = np.load(copied_scores_path, allow_pickle=False)
    restored = KDE997Threshold.from_state_dict(reloaded_state, reloaded_scores)
    if not np.isclose(
        restored.threshold_, strategy.threshold_, rtol=0.0, atol=1e-10
    ):
        raise RuntimeError("保存并重载后阈值不一致")

    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    threshold = float(strategy.threshold_)
    artifact = {
        "schema_version": SCHEMA_VERSION,
        "strategy_id": STRATEGY_ID,
        "strategy_name": "Gaussian KDE 99.7% threshold on Mahalanobis scores",
        "reproduction_type": "migrated",
        "status": "READY_FOR_TEST",
        "formal_result_allowed": True,
        "created_at_china": now_cn,
        "dataset": args.dataset,
        "time_scale": contract["time_scale"],
        "model": model_audit,
        "calibration": {
            **calibration_audit,
            "num_windows": num_windows,
            "audit_file": "normal_calibration_audit.json",
        },
        "residual": {
            "definition": "mean over time of abs(reconstruction - input)",
            "space": "standardized",
            "feature_dimension": int(contract["input_dim"]),
        },
        "score": {
            "method": "ledoit_wolf_mahalanobis",
            "upstream": upstream_audit,
            "copied_calibration_scores_file": copied_scores_path.name,
            "copied_calibration_scores_sha256": sha256_file(copied_scores_path),
        },
        "threshold": {
            "method": "gaussian_kde_quantile",
            "confidence_level": args.confidence_level,
            "kernel": "gaussian",
            "bandwidth_rule": args.bandwidth_rule,
            "bandwidth_factor": state["bandwidth_factor"],
            "effective_bandwidth": state["effective_bandwidth"],
            "score_support": state["score_support"],
            "positive_support_renormalized": True,
            "negative_kde_mass": state["negative_kde_mass"],
            "value": threshold,
            "decision_rule_for_future_use": "score > threshold",
            "persistence_for_main_experiment": {"k": 1, "m": 1},
            "state_file": state_path.name,
            "root_residual": state["root_residual"],
        },
        "bootstrap_stability_audit": {
            **bootstrap_summary,
            "thresholds_file": (
                "bootstrap_thresholds.npy" if bootstrap.size else None
            ),
        },
        "calibration_visualization": plot_audit,
        "reproducibility_check": {
            "state_reload_passed": True,
            "threshold_atol": 1e-10,
        },
        "data_isolation": {
            "test_data_used": False,
            "test_labels_used": False,
            "detection_executed": False,
            "metrics_computed": False,
        },
        "notes": [
            "正式阈值只由纯正常标定 Mahalanobis 得分拟合。",
            "未读取测试集；未生成异常判定；未计算检测指标。",
            "论文案例带宽 0.5626 未迁移，本实现使用 Scott 确定性带宽。",
            "bootstrap 仅审计阈值稳定性，不改变全量标定得分得到的正式阈值。",
        ],
    }
    artifact_path = output_dir / "threshold_artifact.json"
    save_json(artifact_path, artifact)

    print(f"01 KDE 99.7% 阈值：{threshold:.10f}")
    print(f"状态：{artifact['status']}")
    print("测试数据使用：否；异常检测执行：否")
    print(f"正式工件：{artifact_path}")
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
