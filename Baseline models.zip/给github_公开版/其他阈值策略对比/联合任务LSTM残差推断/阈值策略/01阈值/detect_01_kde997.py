# -*- coding: utf-8 -*-
"""加载已冻结的 01 KDE 99.7% 阈值工件，对测试集执行异常检测。"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
COMMON_DIR = PROJECT_ROOT / "阈值策略" / "00阈值"
for path in (PROJECT_ROOT, COMMON_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from main import DATASETS, compute, load_joint  # noqa: E402
from demo.anomaly_detection_demo import (  # noqa: E402
    align_labels,
    evaluate,
    event_ranges,
    load_labels,
)
from demo.threshold_strategies import causal_k_of_m  # noqa: E402
from artifact_utils import (  # noqa: E402
    load_feature_array,
    load_optional_npz_array,
    load_score_state,
    save_json,
    sha256_file,
    transform_score,
)


STRATEGY_ID = "01_kde997"


def load_artifact(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        artifact = json.load(handle)
    if artifact.get("schema_version") != 1:
        raise ValueError("不支持的 01 阈值工件 schema_version")
    if artifact.get("strategy_id") != STRATEGY_ID:
        raise ValueError("该工件不是 01_kde997")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("01 阈值工件状态不是 READY_FOR_TEST")
    if artifact.get("formal_result_allowed") is not True:
        raise ValueError("01 阈值工件不是正式真实标定工件")
    isolation = artifact.get("data_isolation", {})
    if isolation.get("test_data_used") is not False:
        raise ValueError("01 阈值工件的数据隔离记录异常")
    return artifact


def load_and_validate_score_state(artifact: Dict[str, Any]) -> Dict[str, np.ndarray]:
    upstream = artifact["score"]["upstream"]
    state_path = Path(upstream["score_state_file"]).resolve()
    if not state_path.is_file():
        raise FileNotFoundError(f"找不到冻结的 Mahalanobis 状态：{state_path}")
    actual_hash = sha256_file(state_path)
    if actual_hash != upstream["score_state_sha256"]:
        raise ValueError("冻结的 Mahalanobis score_state SHA-256 不一致")
    return load_score_state(state_path)


def validate_kde_state(artifact_path: Path, artifact: Dict[str, Any]) -> None:
    state_path = artifact_path.parent / artifact["threshold"]["state_file"]
    with state_path.open("r", encoding="utf-8") as handle:
        state = json.load(handle)
    if state.get("strategy_id") != STRATEGY_ID:
        raise ValueError("KDE state 的 strategy_id 不正确")
    if not np.isclose(
        float(state["threshold"]),
        float(artifact["threshold"]["value"]),
        rtol=0.0,
        atol=1e-10,
    ):
        raise ValueError("KDE state 与阈值工件中的阈值不一致")
    if not np.isclose(
        float(state["confidence_level"]), 0.997, rtol=0.0, atol=1e-15
    ):
        raise ValueError("正式 01 工件的置信水平不是 0.997")


def validate_test_npz_standardizer(
    test_path: Path,
    available_keys: Sequence[str],
    test_raw: np.ndarray,
    model_mean: np.ndarray,
    model_std: np.ndarray,
) -> Dict[str, Any]:
    audit: Dict[str, Any] = {
        "mean_std_present": False,
        "mean_matches_checkpoint": None,
        "std_matches_checkpoint": None,
        "mean_max_abs_difference_from_checkpoint": None,
        "std_max_abs_difference_from_checkpoint": None,
        "x_std_present": False,
        "x_std_matches_stored_standardizer": None,
        "max_abs_x_std_internal_difference": None,
        "model_input_array": "x",
        "model_input_uses_checkpoint_standardizer": True,
        "stored_x_std_used_for_model": False,
    }
    test_mean = None
    test_std = None
    if "mean" in available_keys and "std" in available_keys:
        test_mean = load_optional_npz_array(test_path, "mean").reshape(-1)
        test_std = load_optional_npz_array(test_path, "std").reshape(-1)
        mean_match = bool(np.allclose(test_mean, model_mean, rtol=1e-6, atol=1e-6))
        std_match = bool(np.allclose(test_std, model_std, rtol=1e-6, atol=1e-6))
        audit.update(
            {
                "mean_std_present": True,
                "mean_matches_checkpoint": mean_match,
                "std_matches_checkpoint": std_match,
                "mean_max_abs_difference_from_checkpoint": float(
                    np.max(np.abs(test_mean - model_mean))
                ),
                "std_max_abs_difference_from_checkpoint": float(
                    np.max(np.abs(test_std - model_std))
                ),
            }
        )

    if "x_std" in available_keys:
        if test_mean is None or test_std is None:
            raise ValueError("测试文件包含 x_std，但缺少配套 mean/std")
        stored = load_optional_npz_array(test_path, "x_std").astype(np.float32)
        expected = (
            (test_raw - test_mean[None, None, :])
            / (test_std[None, None, :] + 1e-8)
        ).astype(np.float32)
        if stored.shape != expected.shape:
            raise ValueError("测试文件 x_std 与 x 的形状不一致")
        max_diff = float(np.max(np.abs(stored - expected)))
        match = bool(np.allclose(stored, expected, rtol=1e-5, atol=1e-5))
        audit.update(
            {
                "x_std_present": True,
                "x_std_matches_stored_standardizer": match,
                "max_abs_x_std_internal_difference": max_diff,
            }
        )
        if not match:
            raise ValueError("测试文件 x_std 与其内置 mean/std 的计算结果不一致")
    return audit


def save_plot(
    path: Path,
    scores: np.ndarray,
    threshold: float,
    labels: Optional[np.ndarray],
    dataset: str,
) -> Optional[str]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"

    x = np.arange(scores.size)
    figure, axis = plt.subplots(figsize=(13, 5.2))
    axis.plot(x, scores, color="#24496e", linewidth=1.0, label="Mahalanobis score")
    axis.axhline(
        threshold,
        color="#d1495b",
        linewidth=1.7,
        label=f"01 KDE 99.7% threshold = {threshold:.6f}",
    )
    if labels is not None:
        for start, end in event_ranges(labels):
            axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.13)
    axis.set_xlabel("test window index")
    axis.set_ylabel("score")
    axis.set_title(f"01 KDE anomaly detection - {dataset}")
    axis.grid(alpha=0.2)
    axis.legend()
    figure.tight_layout()
    figure.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(figure)
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="运行 01 KDE 99.7% 阈值异常检测")
    parser.add_argument("--artifact", required=True, type=Path)
    parser.add_argument("--test", required=True, type=Path)
    parser.add_argument("--labels", type=Path)
    parser.add_argument("--array-key", default="x")
    parser.add_argument("--label-key", default="y_true")
    parser.add_argument("--type-key", default="y_type")
    parser.add_argument(
        "--input-space", choices=("raw", "standardized"), default="raw"
    )
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--k", type=int, default=1)
    parser.add_argument("--m", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=1024)
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    if args.batch_size < 1:
        raise ValueError("--batch-size 必须大于 0")
    if args.k != 1 or args.m != 1:
        raise ValueError("01 主实验固定使用 K=1, M=1；持续性规则应另做消融实验")

    artifact_path = args.artifact.resolve()
    artifact = load_artifact(artifact_path)
    validate_kde_state(artifact_path, artifact)
    score_state = load_and_validate_score_state(artifact)

    dataset = artifact["dataset"]
    bundle = load_joint(dataset)
    _, mean, std, cfg = bundle
    checkpoint_path = Path(DATASETS[dataset]["ckpt"]).resolve()
    checkpoint_hash = sha256_file(checkpoint_path)
    if checkpoint_hash != artifact["model"]["checkpoint_sha256"]:
        raise ValueError("当前模型 checkpoint 与 01 阈值工件不一致")

    test_path = args.test.resolve()
    test, test_metadata = load_feature_array(test_path, args.array_key)
    if test.shape[-1] != int(cfg["input_dim"]):
        raise ValueError(
            f"测试特征维 {test.shape[-1]} 与 {dataset} input_dim={cfg['input_dim']} 不一致"
        )
    if test.ndim != 3 or test.shape[1] != int(DATASETS[dataset]["window_size"]):
        raise ValueError("正式测试文件必须是已切好的 (N, 10, D) 窗口批")

    available_keys = test_metadata.get("available_keys") or []
    standardizer_audit = validate_test_npz_standardizer(
        test_path, available_keys, test, mean, std
    )
    if args.input_space == "standardized":
        test_for_model = (
            test * std[None, None, :] + mean[None, None, :]
        ).astype(np.float32)
    else:
        test_for_model = test

    residual_chunks = []
    for start in range(0, test_for_model.shape[0], args.batch_size):
        end = min(start + args.batch_size, test_for_model.shape[0])
        residual = compute(
            test_for_model[start:end],
            dataset=dataset,
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual_chunks.append(residual.mean(axis=1))
    residual_mean = np.concatenate(residual_chunks, axis=0)
    scores = transform_score(residual_mean, "mahalanobis", score_state)

    threshold = float(artifact["threshold"]["value"])
    point_pred = scores > threshold
    alarm = causal_k_of_m(point_pred, k=args.k, m=args.m)

    labels = None
    if args.labels is not None:
        labels = align_labels(load_labels(args.labels), test, scores.size)
    elif args.label_key in available_keys:
        labels = align_labels(
            load_optional_npz_array(test_path, args.label_key), test, scores.size
        )
    anomaly_types = None
    if args.type_key in available_keys:
        anomaly_types = load_optional_npz_array(test_path, args.type_key).reshape(-1)
        if anomaly_types.size != scores.size:
            raise ValueError("异常类型数组长度与得分长度不一致")

    output_dir = args.output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖检测结果：{output_dir}")
    output_dir.mkdir(parents=True, exist_ok=False)

    detections_path = output_dir / "detections.csv"
    with detections_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "index",
                "label",
                "anomaly_type",
                "score",
                "threshold",
                "point_pred",
                "alarm",
            ]
        )
        for index in range(scores.size):
            writer.writerow(
                [
                    index,
                    "" if labels is None else int(labels[index]),
                    "" if anomaly_types is None else str(anomaly_types[index]),
                    float(scores[index]),
                    threshold,
                    int(point_pred[index]),
                    int(alarm[index]),
                ]
            )

    type_metrics = None
    if labels is not None and anomaly_types is not None:
        type_metrics = {}
        for type_name in np.unique(anomaly_types):
            mask = anomaly_types == type_name
            count = int(mask.sum())
            positive_count = int(labels[mask].sum())
            item: Dict[str, Any] = {
                "count": count,
                "positive_count": positive_count,
                "point_predicted_positive": int(point_pred[mask].sum()),
                "alarm_predicted_positive": int(alarm[mask].sum()),
            }
            if positive_count == count:
                item["point_recall"] = float(point_pred[mask].mean())
                item["alarm_recall"] = float(alarm[mask].mean())
            elif positive_count == 0:
                item["point_false_positive_rate"] = float(point_pred[mask].mean())
                item["alarm_false_positive_rate"] = float(alarm[mask].mean())
            type_metrics[str(type_name)] = item

    decision_margin = scores - threshold
    label_transitions = (
        int(np.count_nonzero(np.diff(labels) != 0))
        if labels is not None and labels.size > 1
        else None
    )
    chronological_metadata = bool(
        set(available_keys)
        & {"timestamp", "timestamp_start", "timestamp_end", "event_id"}
    )
    summary: Dict[str, Any] = {
        "strategy_id": STRATEGY_ID,
        "artifact": str(artifact_path),
        "artifact_status": artifact["status"],
        "dataset": dataset,
        "time_scale": artifact["time_scale"],
        "test_file": str(test_path),
        "test_sha256": sha256_file(test_path),
        "test_file_structure": test_metadata,
        "test_input_space": args.input_space,
        "test_input_shape": list(test.shape),
        "test_standardizer_audit": standardizer_audit,
        "num_windows": int(scores.size),
        "score_method": "ledoit_wolf_mahalanobis",
        "score_state_refit_on_test": False,
        "kde_refit_on_test": False,
        "threshold_confidence_level": 0.997,
        "threshold": threshold,
        "persistence": {"k": args.k, "m": args.m},
        "num_point_exceedances": int(point_pred.sum()),
        "num_alarms": int(alarm.sum()),
        "type_metrics": type_metrics,
        "sequence_audit": {
            "label_transitions": label_transitions,
            "chronological_or_event_metadata_available": chronological_metadata,
            "event_metrics_physically_interpretable": chronological_metadata,
            "note": (
                "无时间戳或事件ID；事件召回和检测延迟仅反映文件排列，不作为正式评价。"
                if not chronological_metadata
                else "存在时间或事件元数据，仍需确认文件保持真实时间顺序。"
            ),
        },
        "point_metrics": (
            evaluate(labels, point_pred, decision_margin) if labels is not None else None
        ),
        "alarm_metrics": (
            evaluate(labels, alarm, decision_margin) if labels is not None else None
        ),
        "formal_result_allowed": True,
    }
    plot_path = output_dir / "kde997_detection.png"
    warning = save_plot(plot_path, scores, threshold, labels, dataset)
    if warning:
        summary["plot_warning"] = warning
    else:
        summary["plot"] = str(plot_path)
    save_json(output_dir / "summary.json", summary)

    print(f"{dataset}: 测试窗口 {scores.size}，阈值 {threshold:.10f}")
    print(f"点级超限 {int(point_pred.sum())}，报警 {int(alarm.sum())}")
    print(f"结果：{output_dir / 'summary.json'}")
    return summary


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
