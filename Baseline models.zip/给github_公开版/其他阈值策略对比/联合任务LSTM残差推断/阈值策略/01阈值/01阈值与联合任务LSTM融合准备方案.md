# 01 阈值与联合任务 LSTM 融合：异常检测前准备方案

## 0. 本文件的范围

本方案只设计和约束 **异常检测之前** 的工作，当前不读取测试集、不生成测试得分、不输出异常标签，也不计算 Precision、Recall、F1 等检测指标。

本阶段允许使用的数据只有：

- 已训练完成的联合任务 LSTM checkpoint；
- 两套纯正常阈值标定集；
- 由同一模型、同一残差定义和同一正常标定集产生的公共 Mahalanobis 标定得分；
- 人工构造且不代表真实业务数据的单元测试数组。

本阶段的停止点为：

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1 / CALIBRATED_DATASET2
→ READY_FOR_TEST
→ 停止
```

`READY_FOR_TEST` 只表示阈值和依赖工件已经冻结，不表示已经执行异常检测。

---

## 1. 参考依据与复现定位

### 1.1 统一实验约束

本方案遵循 `阈值策略/统一阈值实验工作流.md`：

- 分钟级和秒级使用各自的模型、正常标定数据和阈值工件；
- 两套数据使用相同的残差定义、时间聚合方式和 Mahalanobis 得分定义；
- 01 方案只替换阈值拟合方法；
- 测试集不得参与 Mahalanobis 拟合、KDE 拟合、带宽选择或阈值确定；
- 分钟级和秒级分别标定，绝不共用一个 KDE 或一个阈值；
- 正式工件生成后冻结，后续不能根据测试表现重新调参。

### 1.2 01 论文信息

| 项目 | 内容 |
|---|---|
| 标题 | *Anomaly detection and diagnosis for wind turbines using long short-term memory-based stacked denoising autoencoders and XGBoost* |
| 作者 | Chen Zhang, Di Hu, Tao Yang |
| 期刊 | Reliability Engineering & System Safety 222 (2022) 108445 |
| DOI | `10.1016/j.ress.2022.108445` |
| 本地全文 | `阈值策略/01阈值/01.pdf` |
| 与阈值直接相关的内容 | 第 4.2 节公式 (6)～(8)，以及第 5.4 节 |

论文的阈值链路为：

```text
正常数据的多维重构误差
→ Mahalanobis distance（MD）
→ Gaussian KDE 拟合 MD 分布
→ 取 99.7% 置信水平对应的阈值 η
→ 后续在线阶段再进行滑动窗口报警
```

### 1.3 复现类型

本项目应标记为 **迁移实现（migrated implementation）**，不能标记为严格复现，原因如下：

1. 论文使用 LSTM-SDAE，本项目使用已训练的联合任务 LSTM-AE + 分类头；
2. 论文的数据、变量数和预处理方式与本项目不同；
3. 本项目固定使用标准化空间绝对重构残差的时间均值；
4. 本项目固定使用 Ledoit-Wolf 收缩协方差的 Mahalanobis 得分，以保证高维稳定性并与 00 方案公平比较；
5. 论文报告了一个案例带宽 `0.5626`，该值属于论文数据，不能复制到本项目；
6. 论文引用了自适应带宽文献，但正文没有给出足以无歧义复现完整带宽算法的实现细节；
7. 秒级数据上的应用属于跨采样频率迁移，论文案例本身为分钟级数据。

因此，01 的核心保留为：**正常 Mahalanobis 得分 + Gaussian KDE + 99.7% 阈值**；所有偏离项必须写入工件。

---

## 2. 两套数据的固定对应关系

| 项目 | 分钟级 | 秒级 |
|---|---|---|
| 数据集标识 | `dataset1` | `dataset2` |
| 时间尺度 | 1 分钟级 | 秒级 |
| checkpoint | `models/dataset1_joint_seed10.pth` | `models/dataset2_joint_seed10.pth` |
| checkpoint SHA-256 | `adc97f5c48eb4b8e15dab7fa7ac09afe54cc01f88dab8986c5f7340daa96a4fa` | `ec92a82289f8e0e1f497570eedc9c008e19b86d70a24982d4a9d83fb19718d61` |
| 正常标定集 | `正常数据/阈值标定集.npz` | `正常数据/new_raw_阈值标定集.npz` |
| 标定集 SHA-256 | `99376a1f9cb781b0f51be4fe61f4cca64c880e27b5cf742cc942ccd8ac7cd42d` | `a95fd8ce46860252f2ea01bd33f26fc39f467be43316cd654cd3d0b6e62cfabc` |
| 标定形状 | `(1960, 10, 8)` | `(20000, 10, 15)` |
| 标签审计 | `y=0` 共 1960 个 | `y=0` 共 20000 个 |
| 窗口长度 | 10 | 10 |
| 特征维数 | 8 | 15 |
| 输入空间 | 现有 00 工件记录为 `standardized` | 标定文件元数据明确为 `standardized` |
| 目标工件目录 | `01阈值/artifacts/formal_dataset1` | `01阈值/artifacts/formal_dataset2` |

固定映射：

```text
分钟级正常标定集 → dataset1 模型/公共得分状态 → dataset1 的 KDE → 分钟级阈值工件
秒级正常标定集   → dataset2 模型/公共得分状态 → dataset2 的 KDE → 秒级阈值工件
```

禁止：

- 把分钟级和秒级标定得分合并后拟合一个 KDE；
- 让分钟级工件读取 `dataset2` 的模型或得分状态；
- 让秒级工件读取 `dataset1` 的模型或得分状态；
- 使用论文案例中的数值带宽 `0.5626` 直接处理本项目数据；
- 使用任何测试集分布决定带宽、置信水平或回退规则。

### 2.1 分钟级标定数据的已知审计缺口

`正常数据/阈值标定集.npz` 当前含有 `X/y/sample_id/timestamp` 等字段，但文件内部没有：

- `dataset`；
- `input_space`；
- `window_size`；
- `feature_dimension`；
- `checkpoint_sha256`；
- `standardizer_mean/std`。

现有 00 正式工件将它按 `standardized` 使用，但 01 正式准备前仍应执行以下门禁之一：

1. 推荐：建立只读审计 sidecar，记录其来源、输入空间、特征顺序和 checkpoint；
2. 或生成一个带完整元数据的新标定 NPZ，同时保留原文件及两个文件的 SHA-256；
3. 如果无法确认输入空间或特征顺序，则停止正式标定，不依靠数值“看起来合理”进行猜测。

不要原地覆盖现有标定文件。

---

## 3. 固定的融合数学链路

### 3.1 联合任务 LSTM 只负责产生残差

对第 `i` 个窗口，模型输入为：

\[
X_i \in \mathbb{R}^{10 \times D},\quad D=8\ \text{或}\ 15
\]

模型在 `eval()` 和 `torch.no_grad()` 下输出重构结果。公共残差定义固定为：

\[
R_i = \frac{1}{10}\sum_{t=1}^{10}
\left|\hat X_{i,t}-X_{i,t}\right|
\in \mathbb{R}^{D}
\]

要求：

- 输入和重构误差均在 checkpoint 对应的标准化空间；
- 使用绝对残差；
- 沿窗口时间维取均值；
- 不使用测试集重新估计任何模型或得分参数；
- 01 不改变 LSTM 权重，不重新训练模型。

### 3.2 公共 Mahalanobis 得分

只用正常标定残差拟合中心与协方差。项目主实验沿用 00 方案的 Ledoit-Wolf 收缩估计：

\[
s_i = \sqrt{(R_i-\mu)^T\Omega(R_i-\mu)}
\]

其中 `μ` 是正常标定残差中心，`Ω` 是收缩协方差的精度矩阵。

01 不重新定义异常得分。为确保 00 与 01 的差异只来自阈值方法，推荐直接复用并校验：

```text
00阈值/artifacts/formal_dataset1/score_state.npz
00阈值/artifacts/formal_dataset1/calibration_scores.npy

00阈值/artifacts/formal_dataset2/score_state.npz
00阈值/artifacts/formal_dataset2/calibration_scores.npy
```

复用时只读取公共得分状态和正常标定得分，不读取 00 的 `0.98` 阈值作为 01 的输入。

更长期的整洁做法是将公共得分工件迁移到 `阈值策略/common/artifacts/`，让 00 和 01 同时引用；在迁移完成前，可以通过上游工件 SHA-256 保证依赖可追溯。

### 3.3 01 的 Gaussian KDE

对某一数据集的 `n` 个正常标定得分 `s_1,...,s_n`，拟合：

\[
\hat f_h(x)=\frac{1}{nh}\sum_{i=1}^{n}
\phi\left(\frac{x-s_i}{h}\right)
\]

其中 `φ` 为标准高斯核，`h>0` 为带宽。

正式首版建议采用以下冻结规则：

```text
kernel = gaussian
bandwidth_rule = scott
confidence_level = 0.997
score_support = [0, +∞)
```

理由：

- `scott` 是确定性的、只依赖当前正常标定得分；
- 与仓库现有 `demo/threshold_strategies.py` 中 `scipy.stats.gaussian_kde` 默认行为一致；
- 不需要验证集或测试集搜索参数；
- 相比直接复制论文的 `0.5626`，更符合跨数据集迁移原则。

这与论文所称的自适应带宽并不完全相同，必须在 README 和工件中记为复现偏差。以后若严格实现论文引用 [47] 的带宽算法，应作为独立的 `bandwidth_rule`，不能覆盖首版正式结果。

### 3.4 99.7% 阈值

论文公式 (8) 的思想为：

\[
\alpha=P(s<\eta)=\int_0^\eta \hat f_h(x)\,dx,
\quad \alpha=0.997
\]

由于 Gaussian KDE 会在 0 以下产生少量边界泄漏，而 Mahalanobis 得分理论上非负，正式实现建议使用正半轴归一化 CDF：

\[
F_+(x)=
\frac{\hat F(x)-\hat F(0)}{1-\hat F(0)},\quad x\ge0
\]

并求解：

\[
\tau_{01}=F_+^{-1}(0.997)
\]

这是一项数值边界修正，应记录：

```text
cdf_lower_bound = 0.0
positive_support_renormalized = true
negative_kde_mass = F_hat(0)
```

求根可以使用 `scipy.optimize.brentq`。上界先取 `max(score) + 10 * std(score)`；若仍未包围根，只能按确定性倍增规则扩展上界，并记录扩展次数。

正式标定中不建议在 KDE 失败时静默退回经验分位数。以下情况应直接失败并要求检查数据：

- 得分数量不足；
- 得分含 NaN/Inf；
- 得分为负；
- 得分方差接近 0；
- KDE 或求根结果非有限数；
- 重新加载工件后无法复现相同阈值。

经验分位回退可以用于合成自检，但该工件必须标记 `SELF_CHECK_ONLY_NOT_FOR_RESULTS`。

---

## 4. 论文滑动窗口与本阶段的边界

论文在阈值之后还使用一段时间内 MD 的平滑均值来降低瞬时误报。该部分属于 **报警规则**，不是本阶段的 KDE 阈值拟合。

为遵循统一阈值主实验，本项目应拆成两层：

### 4.1 主阈值对比层

```text
score = 公共 Mahalanobis score
threshold = KDE 99.7% threshold
point_rule = score > threshold
K = 1, M = 1
```

当前只准备 `score_state + KDE_state + threshold`，不执行 `point_rule`。

### 4.2 后续论文报警机制复现实验

得到主实验结果后，才单独研究：

\[
\bar s_t=\frac{1}{L}\sum_{j=t-L+1}^{t}s_j,
\quad \bar s_t>\tau_{01}
\]

时间尺度转换不能把相同的点数机械用于两套数据：

| 数据 | 如果采样严格规则 | 论文一小时平滑的候选长度 |
|---|---|---:|
| 分钟级 | 1 点/分钟 | `L=60` |
| 秒级 | 1 点/秒 | `L=3600` |

秒级数据的真实采样间隔必须通过时间戳核对。如果存在缺测、非 1 Hz 或不规则间隔，应使用基于时间戳的一小时滚动区间，而不是固定 `3600` 点。

论文平滑实验必须与纯 KDE 阈值主实验分开报告，不能用平滑后的结果替代主阈值比较。

---

## 5. 推荐程序结构

在 `阈值策略/01阈值/` 下准备：

```text
01阈值/
├── 01.pdf
├── 01阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_01_kde997.py
├── prepare_01_kde997.py
├── experiment_config.json
├── tests/
│   └── test_strategy_01_kde997.py
└── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
```

当前阶段不需要运行 `detect_01.py`。如果为接口完整性提前创建该文件，也只能保留加载和校验骨架，不得接入测试文件或产生判定结果。

### 5.1 策略类职责

`strategy_01_kde997.py` 只实现一维正常得分上的 KDE，不加载模型、不读取原始数据：

```python
class KDE997Threshold:
    strategy_id = "01_kde997"

    def fit(self, calibration_scores):
        """只用正常标定得分拟合 KDE 并冻结阈值。"""
        ...

    def state_dict(self):
        """返回带宽、阈值、支持域和数值审计信息。"""
        ...

    @classmethod
    def from_state_dict(cls, state):
        """从工件恢复；恢复后阈值必须完全一致。"""
        ...
```

本阶段不需要在该类中调用真实测试得分。

### 5.2 准备脚本职责

`prepare_01_kde997.py` 的流程：

```text
读取 dataset1 或 dataset2 配置
→ 校验正常标定源、模型和 SHA-256
→ 校验上游公共 score_state 与 calibration_scores
→ 确认所有得分有限且非负
→ 仅用正常标定得分拟合 Gaussian KDE
→ 求 99.7% 阈值
→ 保存并重新加载工件
→ 检查重载结果一致
→ 状态写为 READY_FOR_TEST
→ 停止，不读取测试集
```

推荐参数：

```text
--dataset dataset1|dataset2
--upstream-score-artifact <00 的正式工件目录>
--confidence-level 0.997
--bandwidth-rule scott
--output-dir <01 的对应正式目录>
```

不提供以下参数：

```text
--test
--labels
--test-input-space
```

这样可以从命令行层面阻止本阶段意外读取测试数据。

### 5.3 配置文件建议

`experiment_config.json` 至少固定：

```json
{
  "strategy_id": "01_kde997",
  "reproduction_type": "migrated",
  "confidence_level": 0.997,
  "kernel": "gaussian",
  "bandwidth_rule": "scott",
  "score_support": [0.0, "positive_infinity"],
  "positive_support_renormalized": true,
  "residual_definition": "mean over time of abs(reconstruction - input) in standardized space",
  "score_method": "ledoit_wolf_mahalanobis",
  "persistence": {"k": 1, "m": 1},
  "test_file": null,
  "test_labels": null
}
```

---

## 6. 正式准备阶段的输出

每套数据分别生成：

```text
artifacts/formal_datasetX/
├── threshold_artifact.json
├── kde_state.json
├── calibration_scores.npy
├── calibration_kde_curve.csv
└── calibration_kde_plot.png
```

其中 `calibration_scores.npy` 可以是经过哈希校验后的公共得分副本，也可以只保存上游路径与哈希。若复制，必须验证与上游逐元素一致。

### 6.1 `threshold_artifact.json` 的最低字段

```json
{
  "schema_version": 1,
  "strategy_id": "01_kde997",
  "status": "READY_FOR_TEST",
  "formal_result_allowed": true,
  "dataset": "dataset1_or_dataset2",
  "model": {
    "checkpoint": null,
    "checkpoint_sha256": null,
    "window_size": 10,
    "input_dim": null
  },
  "calibration": {
    "source_path": null,
    "source_sha256": null,
    "label_counts": {"0": null},
    "num_windows": null,
    "input_space": "standardized"
  },
  "residual": {
    "definition": "mean over time of abs(reconstruction - input)",
    "space": "standardized"
  },
  "score": {
    "method": "ledoit_wolf_mahalanobis",
    "upstream_state_sha256": null,
    "upstream_scores_sha256": null
  },
  "threshold": {
    "method": "gaussian_kde_quantile",
    "confidence_level": 0.997,
    "kernel": "gaussian",
    "bandwidth_rule": "scott",
    "bandwidth_factor": null,
    "effective_bandwidth": null,
    "positive_support_renormalized": true,
    "negative_kde_mass": null,
    "value": null,
    "decision_rule_for_future_use": "score > threshold",
    "persistence_for_main_experiment": {"k": 1, "m": 1}
  },
  "test_data_used": false,
  "detection_executed": false
}
```

### 6.2 只基于正常标定数据的图与审计

`calibration_kde_plot.png` 只允许包含：

- 正常标定得分直方图；
- KDE 密度曲线；
- 99.7% 阈值竖线；
- 数据集标识、带宽规则和标定样本数。

不得叠加测试得分、故障区间、测试标签或检测结果。

---

## 7. 不使用真实测试集的单元测试门禁

所有测试均使用小型人工数组或固定随机种子生成的合成正常得分：

1. **输入检查**：空数组、NaN、Inf、负得分和近零方差必须报错；
2. **输出检查**：阈值为有限非负标量；
3. **CDF 检查**：`F_plus(threshold)` 与 `0.997` 的误差小于指定数值容差；
4. **单调性检查**：CDF 随 `x` 单调不减；
5. **带宽检查**：分钟级与秒级分别拟合并保存自己的带宽；
6. **独立性检查**：改变另一个数据集的标定数组不能影响当前数据集工件；
7. **保存/加载检查**：重载后阈值和 CDF 计算一致；
8. **哈希门禁**：上游模型、标定文件或得分文件哈希变化时拒绝继续；
9. **配置门禁**：`confidence_level` 不是 `0.997` 时，除非明确创建消融配置，否则拒绝写入主实验目录；
10. **无测试数据检查**：准备脚本的参数和工件中不存在非空测试文件路径；
11. **确定性检查**：同一环境、同一输入和同一配置重复拟合得到相同阈值；
12. **正式/自检隔离**：合成自检工件不能标记为 `formal_result_allowed=true`。

### 7.1 尾部稳定性提示

99.7% 对尾部样本量要求较高：

- 分钟级 `n=1960`，尾部概率 `0.003` 约对应 5.88 个样本；
- 秒级 `n=20000`，尾部概率 `0.003` 约对应 60 个样本。

因此分钟级阈值会比秒级阈值更受带宽和极端正常样本影响。准备阶段建议只用正常标定得分做固定随机种子的 bootstrap 阈值稳定性审计，并将置信区间记录为诊断信息；不得根据未来测试性能选择某次 bootstrap 或改变带宽。

bootstrap 不改变正式阈值，正式阈值仍由全量正常标定得分一次拟合得到。

---

## 8. 推荐实施顺序

### 步骤 1：冻结方法卡

- 确认论文公式 (6)～(8)；
- 将复现类型写为 `migrated`；
- 固定 `alpha=0.997`、Gaussian kernel、Scott 带宽；
- 记录正半轴 CDF 边界修正；
- 明确论文滑动平均不属于当前阶段。

完成状态：`FORMULA_VERIFIED`。

### 步骤 2：完成两套输入审计

- 核对模型哈希；
- 核对正常标定文件哈希；
- 核对 `y` 全为 0；
- 核对窗口长度和特征维数；
- 补强分钟级标定集输入空间和特征顺序证据；
- 核对上游公共 Mahalanobis 工件与对应数据集一致。

完成状态：`INTERFACE_DEFINED`。

### 步骤 3：只实现 KDE 策略和准备脚本

- 新增 `strategy_01_kde997.py`；
- 新增 `prepare_01_kde997.py`；
- 新增冻结配置；
- 不接入测试数据；
- 不实现或不运行评价指标。

完成状态：`IMPLEMENTED`。

### 步骤 4：运行无真实测试集的单元测试

- 公式测试；
- 边界测试；
- 工件重载测试；
- 双数据集隔离测试；
- 哈希和数据泄漏门禁测试。

完成状态：`UNIT_TESTED`。

### 步骤 5：分别生成两个正常标定工件

建议未来执行的准备命令如下，本文件创建阶段不运行：

```powershell
python 阈值策略\01阈值\prepare_01_kde997.py `
  --dataset dataset1 `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset1 `
  --confidence-level 0.997 `
  --bandwidth-rule scott `
  --output-dir 阈值策略\01阈值\artifacts\formal_dataset1
```

```powershell
python 阈值策略\01阈值\prepare_01_kde997.py `
  --dataset dataset2 `
  --upstream-score-artifact 阈值策略\00阈值\artifacts\formal_dataset2 `
  --confidence-level 0.997 `
  --bandwidth-rule scott `
  --output-dir 阈值策略\01阈值\artifacts\formal_dataset2
```

完成状态：

```text
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
```

随后立即停止，等待用户另行授权异常检测阶段。

---

## 9. 当前阶段验收清单

- [x] 已阅读 01 全文并确认阈值相关公式；
- [x] 已确认 01 为 Gaussian KDE + 99.7% MD 阈值；
- [x] 已确认本项目只能标记为迁移实现；
- [x] 已固定模型、残差和公共 Mahalanobis 得分口径；
- [x] 已区分分钟级与秒级工件；
- [x] 已核对两套正常标定数据形状及 `y=0`；
- [x] 已识别分钟级标定元数据缺口；
- [x] 已明确不复制论文案例带宽 `0.5626`；
- [x] 已将论文滑动窗口移到后续独立实验；
- [x] 当前未读取或使用测试集；
- [x] 当前未执行异常检测；
- [x] 已实现 01 源代码；
- [x] 已运行 01 单元测试（7 项全部通过）；
- [x] 已拟合分钟级 KDE，阈值为 `7.2023327542`；
- [x] 已拟合秒级 KDE，阈值为 `13.2969608547`；
- [x] 已生成并重载验证两套 01 正式阈值工件；
- [x] 已在后续用户授权后完成分钟级与秒级各 5 个测试文件的异常检测；主结果固定 `K=1, M=1`。

---

## 10. 最终原则

01 与联合任务 LSTM 的正确融合不是重新训练一个模型，而是保持前半段完全固定，只把 00 的经验分位阈值替换为 01 的 KDE 99.7% 阈值：

```text
固定联合任务 LSTM
→ 固定标准化绝对重构残差
→ 固定时间均值聚合
→ 固定收缩 Mahalanobis 得分
→ 分钟级单独拟合 Gaussian KDE 99.7% 阈值
→ 秒级单独拟合 Gaussian KDE 99.7% 阈值
→ 冻结两个工件
→ 停止，暂不异常检测
```

只要测试数据未参与上述任何一步，就满足当前“异常检测前准备”的数据隔离要求。
