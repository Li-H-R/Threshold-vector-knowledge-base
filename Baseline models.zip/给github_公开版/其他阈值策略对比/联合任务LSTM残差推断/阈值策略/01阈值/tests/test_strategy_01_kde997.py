# -*- coding: utf-8 -*-

import sys
import unittest
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from strategy_01_kde997 import KDE997Threshold


class KDE997ThresholdTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(20261104)
        self.scores = rng.lognormal(mean=0.7, sigma=0.35, size=600)

    def test_fit_returns_finite_nonnegative_threshold(self):
        strategy = KDE997Threshold().fit(self.scores)
        self.assertTrue(np.isfinite(strategy.threshold_))
        self.assertGreaterEqual(strategy.threshold_, 0.0)
        self.assertAlmostEqual(
            strategy.cdf_positive(strategy.threshold_), 0.997, places=10
        )

    def test_positive_cdf_is_monotonic_and_bounded(self):
        strategy = KDE997Threshold().fit(self.scores)
        grid = np.linspace(0.0, float(np.max(self.scores) * 3.0), 200)
        cdf = strategy.cdf_positive(grid)
        self.assertAlmostEqual(float(cdf[0]), 0.0, places=14)
        self.assertTrue(np.all(np.diff(cdf) >= -1e-13))
        self.assertTrue(np.all((cdf >= 0.0) & (cdf <= 1.0)))

    def test_rejects_invalid_scores(self):
        invalid_cases = [
            np.ones(99),
            np.r_[np.ones(119), np.nan],
            np.r_[np.ones(119), np.inf],
            np.r_[np.ones(119), -0.1],
            np.ones(120),
        ]
        for values in invalid_cases:
            with self.subTest(case=repr(values[-3:])):
                with self.assertRaises(ValueError):
                    KDE997Threshold().fit(values)

    def test_state_roundtrip_reproduces_threshold(self):
        fitted = KDE997Threshold().fit(self.scores)
        restored = KDE997Threshold.from_state_dict(
            fitted.state_dict(), self.scores
        )
        self.assertAlmostEqual(fitted.threshold_, restored.threshold_, places=12)
        self.assertAlmostEqual(
            fitted.effective_bandwidth_, restored.effective_bandwidth_, places=12
        )

    def test_fit_is_deterministic(self):
        first = KDE997Threshold().fit(self.scores)
        second = KDE997Threshold().fit(self.scores.copy())
        self.assertAlmostEqual(first.threshold_, second.threshold_, places=12)
        self.assertAlmostEqual(
            first.bandwidth_factor_, second.bandwidth_factor_, places=12
        )

    def test_two_calibration_distributions_remain_independent(self):
        low = KDE997Threshold().fit(self.scores)
        low_threshold = float(low.threshold_)
        high = KDE997Threshold().fit(self.scores * 5.0)
        self.assertGreater(high.threshold_, low_threshold)
        self.assertEqual(low.threshold_, low_threshold)

    def test_pdf_is_nonnegative_on_supported_domain(self):
        strategy = KDE997Threshold().fit(self.scores)
        grid = np.linspace(0.0, float(strategy.threshold_ * 1.2), 100)
        self.assertTrue(np.all(strategy.pdf(grid) >= 0.0))


if __name__ == "__main__":
    unittest.main()
