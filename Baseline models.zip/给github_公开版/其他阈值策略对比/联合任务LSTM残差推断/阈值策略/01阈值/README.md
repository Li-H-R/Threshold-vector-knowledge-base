# 01 阈值实验：Gaussian KDE 99.7% 标定与双测试集异常检测

## 当前结论

01 阈值已经完成正常标定和分钟级/秒级双测试集异常检测。分钟级和秒级分别使用各自的正常标定 Mahalanobis 得分拟合 Gaussian KDE，并冻结 99.7% 阈值：

| 时间尺度 | 数据集 | 正常标定窗口 | Scott factor | 有效带宽 | 01 KDE 99.7% 阈值 | 工件状态 |
|---|---|---:|---:|---:|---:|---|
| 分钟级 | `dataset1` | 1960 | 0.21955776 | 0.22058350 | **7.2023327542** | `READY_FOR_TEST` |
| 秒级 | `dataset2` | 20000 | 0.13797297 | 0.20685556 | **13.2969608547** | `READY_FOR_TEST` |

在用户另行授权后，已使用冻结阈值检测 `测试集数据` 中两种时间尺度各 5 个 seed。测试阶段没有重新拟合 Mahalanobis、KDE、带宽或阈值。

| 时间尺度 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |
|---|---:|---:|---:|---:|---:|---:|
| 分钟级 | 0.9968 ± 0.0013 | 0.6349 ± 0.0000 | 0.7757 ± 0.0004 | 0.9621 ± 0.0006 | 0.9980 ± 0.0008 | 2.01 ± 0.82 |
| 秒级 | 0.9872 ± 0.0036 | 0.4294 ± 0.0000 | 0.5985 ± 0.0007 | 0.9075 ± 0.0030 | 0.9944 ± 0.0016 | 5.58 ± 1.58 |

完整评价见 `01实验结果/evaluation_report.md`。

## 方法口径

本实验为论文方法向项目联合任务 LSTM 的迁移实现：

```text
固定联合任务 LSTM
→ 标准化空间绝对重构残差
→ 窗口时间维均值
→ Ledoit-Wolf 收缩 Mahalanobis 得分
→ Gaussian KDE（Scott 带宽）
→ 正半轴归一化 CDF 的 99.7% 分位点
→ 冻结阈值工件
```

只替换 00 方案中的经验 98% 阈值。模型、正常标定集、残差和 Mahalanobis 得分均保持一致。

论文案例带宽 `0.5626` 没有直接迁移，因为该数值只适用于论文数据。当前实现采用只依赖正常标定得分的确定性 Scott 带宽。

## 正式标定结果

### 分钟级 `dataset1`

- 模型：`models/dataset1_joint_seed10.pth`
- 正常标定集：`正常数据/阈值标定集.npz`
- 正常标定得分数：1960
- KDE 负半轴泄漏质量：`4.1753719864e-06`
- 正半轴归一化 99.7% 阈值：`7.2023327542`
- 200 次 bootstrap 均值：`7.2605239687`
- 200 次 bootstrap 95% 区间：`[6.2428047477, 8.1524930133]`
- 正式工件：`artifacts/formal_dataset1/threshold_artifact.json`

分钟级源 NPZ 本身缺少 `dataset/input_space/window_size/checkpoint_sha256` 等元数据。正式工件没有修改源文件，而是在 `normal_calibration_audit.json` 中记录了缺口，并使用冻结配置及 00 正式工件的来源记录作为输入空间证据。

### 秒级 `dataset2`

- 模型：`models/dataset2_joint_seed10.pth`
- 正常标定集：`正常数据/new_raw_阈值标定集.npz`
- 正常标定得分数：20000
- KDE 负半轴泄漏质量：`6.6170656244e-12`
- 正半轴归一化 99.7% 阈值：`13.2969608547`
- 200 次 bootstrap 均值：`13.6315258738`
- 200 次 bootstrap 95% 区间：`[11.9684193229, 15.8529829881]`
- 正式工件：`artifacts/formal_dataset2/threshold_artifact.json`

bootstrap 只用于正常数据上的阈值稳定性审计，不改变正式阈值。正式阈值始终由全量正常标定得分一次拟合得到。

## 生成的文件

两个正式目录均包含：

| 文件 | 作用 |
|---|---|
| `threshold_artifact.json` | 完整阈值、模型/数据哈希、上游依赖和数据隔离声明 |
| `kde_state.json` | KDE 带宽、阈值、边界质量和求根审计 |
| `calibration_scores.npy` | 从 00 公共工件逐字节复制的正常 Mahalanobis 得分 |
| `calibration_kde_curve.csv` | 只基于正常标定数据的 score/PDF/CDF 曲线 |
| `calibration_kde_plot.png` | 正常得分直方图、KDE 曲线和 99.7% 阈值 |
| `bootstrap_thresholds.npy` | 固定种子的 200 次正常数据 bootstrap 阈值 |
| `normal_calibration_audit.json` | 正常标签、形状、元数据和来源审计 |

## 实现文件

| 文件 | 作用 |
|---|---|
| `strategy_01_kde997.py` | Gaussian KDE、正半轴 CDF、99.7% 求根和状态重建 |
| `prepare_01_kde997.py` | 只读正常工件、执行门禁并生成正式标定工件 |
| `detect_01_kde997.py` | 加载冻结工件并对一个测试文件生成逐点判定与指标 |
| `evaluate_all_test_sets.py` | 批量运行分钟级/秒级各 5 个 seed 并汇总评价 |
| `experiment_config.json` | 双数据集固定映射、哈希、阈值参数和数据隔离配置 |
| `tests/test_strategy_01_kde997.py` | 不使用真实测试集的策略单元测试 |

## 验证结果

已执行：

```powershell
python -m unittest discover -s 阈值策略\01阈值\tests -p "test_*.py" -v
```

结果：7 项测试全部通过，包括：

- 阈值有限且非负；
- 正半轴 CDF 单调并满足 `CDF(threshold)=0.997`；
- NaN、Inf、负值、样本不足和退化分布拒绝拟合；
- 同一输入重复拟合确定性一致；
- 状态保存/重建后阈值一致；
- 分钟级和秒级分布互不影响。

两个正式工件均通过保存后重载复现，阈值绝对误差门限为 `1e-10`，实际求根残差为 0。

## 已执行的正常标定命令

```powershell
python 阈值策略\01阈值\prepare_01_kde997.py `
  --dataset dataset1 `
  --bootstrap-replicates 200
```

```powershell
python 阈值策略\01阈值\prepare_01_kde997.py `
  --dataset dataset2 `
  --bootstrap-replicates 200
```

准备脚本没有 `--test`、`--labels` 或测试输入参数，从命令行接口上隔离了测试阶段。

## 异常检测执行

已执行：

```powershell
python 阈值策略\01阈值\evaluate_all_test_sets.py
```

结果目录为 `01实验结果/`：

- `dataset1_minute/seed*/`：分钟级 5 个 seed 的逐点 CSV、摘要和检测图；
- `dataset2_second/seed*/`：秒级 5 个 seed 的逐点 CSV、摘要和检测图；
- `evaluation_summary.json`：完整机器可读汇总；
- `per_seed_metrics.csv`：10 次检测的单 seed 指标；
- `evaluation_report.md`：双时间尺度评价报告。

测试文件内置 `mean/std` 与当前 seed10 checkpoint 存在小幅版本差异。正式检测使用原始量纲 `x`，并由当前 checkpoint 自带的标准化器处理；测试文件的 `x_std` 没有作为模型输入，只用于核对其与文件自身 `mean/std` 的一致性。差异已记录在每个 `summary.json` 中。

## 当前停止点

```text
FORMULA_VERIFIED
→ INTERFACE_DEFINED
→ IMPLEMENTED
→ UNIT_TESTED
→ CALIBRATED_DATASET1
→ CALIBRATED_DATASET2
→ READY_FOR_TEST
→ TESTED_BOTH_DATASETS
→ RESULT_FROZEN
```

当前结果固定使用 `K=1, M=1`。论文滑动窗口平滑或其他 K-of-M 规则如需评估，应作为后续独立消融实验，不能覆盖本次主结果。
