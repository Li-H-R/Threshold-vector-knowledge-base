# -*- coding: utf-8 -*-
"""01 阈值策略：正常 Mahalanobis 得分的 Gaussian KDE 99.7% 阈值。"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
from scipy.optimize import brentq
from scipy.stats import gaussian_kde


STRATEGY_ID = "01_kde997"
SCHEMA_VERSION = 1
DEFAULT_CONFIDENCE_LEVEL = 0.997
SUPPORTED_BANDWIDTH_RULES = ("scott", "silverman")
EPS = 1e-12


def validate_calibration_scores(
    values: np.ndarray, *, min_samples: int = 100
) -> np.ndarray:
    """返回一维 float64 正常标定得分，并执行正式拟合门禁。"""
    scores = np.asarray(values, dtype=np.float64).reshape(-1)
    if scores.size < min_samples:
        raise ValueError(
            f"KDE 正式拟合至少需要 {min_samples} 个正常得分，实际 {scores.size}"
        )
    if not np.all(np.isfinite(scores)):
        raise ValueError("正常标定得分中存在 NaN 或 Inf")
    if np.any(scores < 0.0):
        raise ValueError("Mahalanobis 得分理论上非负，输入中发现负值")
    if float(np.std(scores)) <= EPS:
        raise ValueError("正常标定得分方差接近 0，无法拟合 KDE")
    return np.ascontiguousarray(scores)


class KDE997Threshold:
    """Gaussian KDE 阈值器，只负责正常标定阶段的拟合与冻结。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        confidence_level: float = DEFAULT_CONFIDENCE_LEVEL,
        bandwidth_rule: str = "scott",
        min_samples: int = 100,
    ) -> None:
        if not 0.0 < confidence_level < 1.0:
            raise ValueError("confidence_level 必须位于 (0, 1)")
        if bandwidth_rule not in SUPPORTED_BANDWIDTH_RULES:
            raise ValueError(
                f"bandwidth_rule 必须是 {SUPPORTED_BANDWIDTH_RULES} 之一"
            )
        if min_samples < 5:
            raise ValueError("min_samples 至少为 5")

        self.confidence_level = float(confidence_level)
        self.bandwidth_rule = bandwidth_rule
        self.min_samples = int(min_samples)

        self.scores_: Optional[np.ndarray] = None
        self.kde_: Optional[gaussian_kde] = None
        self.threshold_: Optional[float] = None
        self.bandwidth_factor_: Optional[float] = None
        self.effective_bandwidth_: Optional[float] = None
        self.negative_kde_mass_: Optional[float] = None
        self.positive_kde_mass_: Optional[float] = None
        self.root_residual_: Optional[float] = None
        self.root_upper_bound_: Optional[float] = None
        self.root_expansions_: Optional[int] = None

    def fit(self, calibration_scores: np.ndarray) -> "KDE997Threshold":
        """只用纯正常标定得分拟合 KDE 并求解冻结阈值。"""
        scores = validate_calibration_scores(
            calibration_scores, min_samples=self.min_samples
        )
        kde = gaussian_kde(scores, bw_method=self.bandwidth_rule)

        bandwidth_factor = float(kde.factor)
        effective_bandwidth = float(np.sqrt(np.asarray(kde.covariance).squeeze()))
        if not np.isfinite(effective_bandwidth) or effective_bandwidth <= 0.0:
            raise RuntimeError("KDE 产生了无效带宽")

        negative_mass = float(kde.integrate_box_1d(-np.inf, 0.0))
        positive_mass = float(kde.integrate_box_1d(0.0, np.inf))
        if not 0.0 <= negative_mass < 1.0:
            raise RuntimeError("KDE 的负半轴概率质量无效")
        if not np.isfinite(positive_mass) or positive_mass <= EPS:
            raise RuntimeError("KDE 在非负得分支持域上的概率质量无效")

        self.scores_ = scores.copy()
        self.kde_ = kde
        self.bandwidth_factor_ = bandwidth_factor
        self.effective_bandwidth_ = effective_bandwidth
        self.negative_kde_mass_ = negative_mass
        self.positive_kde_mass_ = positive_mass

        score_std = float(np.std(scores))
        high = max(
            float(np.max(scores) + 10.0 * score_std),
            float(np.max(scores) + 10.0 * effective_bandwidth),
            1.0,
        )
        expansions = 0
        while self.cdf_positive(high) < self.confidence_level and expansions < 20:
            high *= 2.0
            expansions += 1
        if self.cdf_positive(high) < self.confidence_level:
            raise RuntimeError("无法为 99.7% KDE 分位点建立求根上界")

        threshold = float(
            brentq(
                lambda x: self.cdf_positive(x) - self.confidence_level,
                0.0,
                high,
                xtol=1e-12,
                rtol=1e-12,
                maxiter=200,
            )
        )
        if not np.isfinite(threshold) or threshold < 0.0:
            raise RuntimeError("KDE 求得的阈值无效")

        self.threshold_ = threshold
        self.root_residual_ = float(
            abs(self.cdf_positive(threshold) - self.confidence_level)
        )
        self.root_upper_bound_ = float(high)
        self.root_expansions_ = int(expansions)
        return self

    def _require_fit(self) -> gaussian_kde:
        if self.kde_ is None or self.threshold_ is None:
            raise RuntimeError("请先调用 fit()")
        return self.kde_

    def cdf_positive(self, values: Any) -> Any:
        """正半轴归一化 CDF；Mahalanobis 得分的理论支持域为 [0,+∞)。"""
        if self.kde_ is None or self.positive_kde_mass_ is None:
            raise RuntimeError("请先调用 fit()")
        array = np.asarray(values, dtype=np.float64)
        flat = array.reshape(-1)
        result = np.zeros(flat.size, dtype=np.float64)
        for index, value in enumerate(flat):
            if value > 0.0:
                mass = float(self.kde_.integrate_box_1d(0.0, float(value)))
                result[index] = np.clip(mass / self.positive_kde_mass_, 0.0, 1.0)
        result = result.reshape(array.shape)
        return float(result.item()) if result.ndim == 0 else result

    def pdf(self, values: Any) -> Any:
        """返回正半轴归一化后的 KDE 密度。"""
        kde = self._require_fit()
        if self.positive_kde_mass_ is None:
            raise RuntimeError("KDE 状态不完整")
        array = np.asarray(values, dtype=np.float64)
        flat = array.reshape(-1)
        result = np.zeros(flat.size, dtype=np.float64)
        mask = flat >= 0.0
        if np.any(mask):
            result[mask] = kde(flat[mask]) / self.positive_kde_mass_
        result = result.reshape(array.shape)
        return float(result.item()) if result.ndim == 0 else result

    def state_dict(self) -> Dict[str, Any]:
        """返回可 JSON 序列化的冻结状态摘要，不包含测试数据或判定结果。"""
        self._require_fit()
        assert self.scores_ is not None
        return {
            "schema_version": SCHEMA_VERSION,
            "strategy_id": STRATEGY_ID,
            "confidence_level": self.confidence_level,
            "kernel": "gaussian",
            "bandwidth_rule": self.bandwidth_rule,
            "bandwidth_factor": self.bandwidth_factor_,
            "effective_bandwidth": self.effective_bandwidth_,
            "score_support": [0.0, "positive_infinity"],
            "positive_support_renormalized": True,
            "negative_kde_mass": self.negative_kde_mass_,
            "positive_kde_mass": self.positive_kde_mass_,
            "threshold": self.threshold_,
            "num_calibration_scores": int(self.scores_.size),
            "score_min": float(np.min(self.scores_)),
            "score_max": float(np.max(self.scores_)),
            "score_mean": float(np.mean(self.scores_)),
            "score_std": float(np.std(self.scores_)),
            "root_residual": self.root_residual_,
            "root_upper_bound": self.root_upper_bound_,
            "root_expansions": self.root_expansions_,
        }

    @classmethod
    def from_state_dict(
        cls,
        state: Dict[str, Any],
        calibration_scores: np.ndarray,
        *,
        atol: float = 1e-10,
    ) -> "KDE997Threshold":
        """用冻结配置和正常标定得分重建 KDE，并验证阈值可复现。"""
        if state.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("不支持的 KDE state schema_version")
        if state.get("strategy_id") != STRATEGY_ID:
            raise ValueError("state 不是 01_kde997 工件")
        strategy = cls(
            confidence_level=float(state["confidence_level"]),
            bandwidth_rule=str(state["bandwidth_rule"]),
        ).fit(calibration_scores)
        expected = float(state["threshold"])
        if not np.isclose(strategy.threshold_, expected, rtol=0.0, atol=atol):
            raise ValueError(
                f"重建阈值 {strategy.threshold_} 与冻结值 {expected} 不一致"
            )
        return strategy
