# -*- coding: utf-8 -*-
"""运行 05 Welch-NDT 的分钟级/秒级各 5 个测试集并汇总评价。"""

from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Dict, List

import numpy as np


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
COMMON_DIR = SCRIPT_DIR.parent / "00阈值"
for path in (PROJECT_ROOT, COMMON_DIR, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from artifact_utils import save_json  # noqa: E402
from detect_05_welch_ndt import run as run_detection  # noqa: E402


METRICS = (
    "precision",
    "recall",
    "specificity",
    "f1",
    "balanced_accuracy",
    "mcc",
    "roc_auc",
    "pr_auc",
    "false_positive_rate",
    "false_alarms_per_1000_normal_windows",
)


def seed_from_path(path: Path) -> int:
    match = re.search(r"seed(\d+)", path.stem)
    if not match:
        raise ValueError(f"无法从文件名读取 seed：{path.name}")
    return int(match.group(1))


def pooled_metrics(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    tp = sum(item["point_metrics"]["tp"] for item in summaries)
    fp = sum(item["point_metrics"]["fp"] for item in summaries)
    tn = sum(item["point_metrics"]["tn"] for item in summaries)
    fn = sum(item["point_metrics"]["fn"] for item in summaries)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    specificity = tn / max(tn + fp, 1)
    return {
        "tp": int(tp),
        "fp": int(fp),
        "tn": int(tn),
        "fn": int(fn),
        "precision": float(precision),
        "recall": float(recall),
        "specificity": float(specificity),
        "f1": float(2.0 * precision * recall / max(precision + recall, 1e-12)),
        "balanced_accuracy": float(0.5 * (recall + specificity)),
        "false_positive_rate": float(1.0 - specificity),
    }


def aggregate(summaries: List[Dict[str, Any]]) -> Dict[str, Any]:
    metrics_mean_std: Dict[str, Any] = {}
    for metric in METRICS:
        values = np.asarray(
            [item["point_metrics"][metric] for item in summaries],
            dtype=np.float64,
        )
        metrics_mean_std[metric] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            "min": float(np.min(values)),
            "max": float(np.max(values)),
        }

    threshold_fields = (
        "threshold_min",
        "threshold_max",
        "threshold_mean",
        "threshold_final",
    )
    threshold_summary = {}
    for field in threshold_fields:
        values = np.asarray([item[field] for item in summaries], dtype=np.float64)
        threshold_summary[field] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=1)) if values.size > 1 else 0.0,
            "min": float(np.min(values)),
            "max": float(np.max(values)),
        }

    type_names = sorted({
        type_name
        for item in summaries
        for type_name in (item.get("type_metrics") or {}).keys()
    })
    type_summary: Dict[str, Any] = {}
    for type_name in type_names:
        records = [
            item["type_metrics"][type_name]
            for item in summaries
            if type_name in (item.get("type_metrics") or {})
        ]
        if records and "point_recall" in records[0]:
            values = np.asarray([record["point_recall"] for record in records])
            type_summary[type_name] = {
                "kind": "anomaly",
                "count_per_seed": int(records[0]["count"]),
                "recall_mean": float(np.mean(values)),
                "recall_std": float(np.std(values, ddof=1))
                if values.size > 1 else 0.0,
            }
        elif records and "point_false_positive_rate" in records[0]:
            values = np.asarray([
                record["point_false_positive_rate"] for record in records
            ])
            type_summary[type_name] = {
                "kind": "normal",
                "count_per_seed": int(records[0]["count"]),
                "false_positive_rate_mean": float(np.mean(values)),
                "false_positive_rate_std": float(np.std(values, ddof=1))
                if values.size > 1 else 0.0,
            }
    return {
        "num_seeds": len(summaries),
        "metrics_mean_std": metrics_mean_std,
        "threshold_summary": threshold_summary,
        "pooled_confusion_metrics": pooled_metrics(summaries),
        "type_metrics": type_summary,
    }


def audit_test_design(test_files: List[Path]) -> Dict[str, Any]:
    records = []
    for path in test_files:
        with np.load(path, allow_pickle=False) as archive:
            records.append({
                "x": archive["x"],
                "y": archive["y_true"].astype(np.int64),
                "types": archive["y_type"].astype(str),
            })
    base = records[0]
    anomaly_mask = base["y"] == 1
    normal_mask = ~anomaly_mask
    anomalies_identical = all(
        np.array_equal(base["x"][anomaly_mask], item["x"][item["y"] == 1])
        for item in records[1:]
    )
    normals_identical = all(
        np.array_equal(base["x"][normal_mask], item["x"][item["y"] == 0])
        for item in records[1:]
    )
    suspicious_types = sorted({
        str(type_name)
        for type_name in base["types"][anomaly_mask]
        if "正常" in str(type_name)
    })
    return {
        "num_test_files": len(records),
        "windows_per_file": int(base["y"].size),
        "normal_per_file": int(normal_mask.sum()),
        "anomaly_per_file": int(anomaly_mask.sum()),
        "label_transitions_per_file": int(
            np.count_nonzero(np.diff(base["y"]) != 0)
        ),
        "anomaly_windows_identical_across_seeds": bool(anomalies_identical),
        "normal_windows_identical_across_seeds": bool(normals_identical),
        "timestamps_or_event_ids_available": False,
        "file_order": "sampled_normal_block_then_fixed_anomaly_block",
        "dynamic_threshold_uses_file_order": True,
        "event_metrics_physically_interpretable": False,
        "model_input_array": "x",
        "x_std_used_for_consistency_audit_only": True,
        "suspicious_positive_type_names_containing_normal": suspicious_types,
        "interpretation": (
            "五个 seed 共享相同异常窗口，仅正常窗口抽样不同；"
            "动态阈值按文件顺序运行，均值和标准差反映正常抽样及运行状态差异。"
        ),
    }


def write_seed_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fields = [
        "dataset",
        "time_scale",
        "seed",
        "threshold_initial",
        "threshold_min",
        "threshold_max",
        "threshold_final",
        *METRICS,
        "tp",
        "fp",
        "tn",
        "fn",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            summary = row["summary"]
            metrics = summary["point_metrics"]
            writer.writerow({
                "dataset": row["dataset"],
                "time_scale": row["time_scale"],
                "seed": row["seed"],
                "threshold_initial": summary["threshold_initial"],
                "threshold_min": summary["threshold_min"],
                "threshold_max": summary["threshold_max"],
                "threshold_final": summary["threshold_final"],
                **{key: metrics[key] for key in METRICS},
                **{key: metrics[key] for key in ("tp", "fp", "tn", "fn")},
            })


def fmt(value: Dict[str, float], digits: int = 4) -> str:
    return f"{value['mean']:.{digits}f} ± {value['std']:.{digits}f}"


def write_report(path: Path, result: Dict[str, Any]) -> None:
    lines = [
        "# 05 Welch-NDT：分钟级与秒级异常检测评价",
        "",
        "## 评价口径",
        "",
        "- 使用纯正常准备阶段冻结的模型、Mahalanobis 状态、05 参数和动态初始状态。",
        "- 每个测试文件从正式状态的独立深拷贝开始；运行时状态只写入结果目录。",
        "- 测试标签只用于事后评价，不参与阈值更新、冻结或参数选择。",
        "- 主结果固定 `K=1, M=1`，连续指标使用 `EWMA score - dynamic threshold`。",
        "- 每个时间尺度报告 5 个正常抽样 seed 的均值 ± 样本标准差。",
        "- 测试文件没有真实时间戳或事件 ID，动态阈值按文件顺序运行；不正式解释事件延迟。",
        "",
        "## 总体结果",
        "",
        "| 时间尺度 | 初始阈值 | 运行阈值总范围 | Precision | Recall | F1 | PR-AUC | Specificity | MCC | 误报/1000正常窗口 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        data = result[dataset]
        metrics = data["aggregate"]["metrics_mean_std"]
        threshold_summary = data["aggregate"]["threshold_summary"]
        runtime_range = (
            f"{threshold_summary['threshold_min']['min']:.6f} - "
            f"{threshold_summary['threshold_max']['max']:.6f}"
        )
        lines.append(
            f"| {label} | {data['threshold_initial']:.8f} | {runtime_range} | "
            f"{fmt(metrics['precision'])} | {fmt(metrics['recall'])} | "
            f"{fmt(metrics['f1'])} | {fmt(metrics['pr_auc'])} | "
            f"{fmt(metrics['specificity'])} | {fmt(metrics['mcc'])} | "
            f"{fmt(metrics['false_alarms_per_1000_normal_windows'], 2)} |"
        )

    lines.extend(["", "## 单 seed 结果", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend([
            f"### {label}",
            "",
            "| Seed | 阈值范围 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000正常窗口 |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|",
        ])
        for run in result[dataset]["runs"]:
            metrics = run["point_metrics"]
            lines.append(
                f"| {run['seed']} | {run['threshold_min']:.4f}-{run['threshold_max']:.4f} | "
                f"{metrics['precision']:.4f} | {metrics['recall']:.4f} | "
                f"{metrics['f1']:.4f} | {metrics['pr_auc']:.4f} | "
                f"{metrics['specificity']:.4f} | "
                f"{metrics['false_alarms_per_1000_normal_windows']:.2f} |"
            )
        lines.append("")

    lines.extend(["## 异常类型召回", ""])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        lines.extend([
            f"### {label}",
            "",
            "| y_type | 每个 seed 样本数 | Recall 均值 | Recall 标准差 |",
            "|---|---:|---:|---:|",
        ])
        for type_name, metrics in result[dataset]["aggregate"]["type_metrics"].items():
            if metrics["kind"] != "anomaly":
                continue
            lines.append(
                f"| {type_name} | {metrics['count_per_seed']} | "
                f"{metrics['recall_mean']:.4f} | {metrics['recall_std']:.4f} |"
            )
        lines.append("")

    lines.extend([
        "## 测试集设计审查",
        "",
        "| 时间尺度 | 每文件窗口 | 正常 | 异常 | 异常跨 seed 相同 | 正常跨 seed 相同 | 标签跳变数 |",
        "|---|---:|---:|---:|---|---|---:|",
    ])
    for dataset, label in (("dataset1", "分钟级"), ("dataset2", "秒级")):
        audit = result[dataset]["data_audit"]
        lines.append(
            f"| {label} | {audit['windows_per_file']} | {audit['normal_per_file']} | "
            f"{audit['anomaly_per_file']} | "
            f"{audit['anomaly_windows_identical_across_seeds']} | "
            f"{audit['normal_windows_identical_across_seeds']} | "
            f"{audit['label_transitions_per_file']} |"
        )

    lines.extend([
        "",
        "测试文件由随机抽样正常窗口块和固定异常窗口块拼接而成，没有真实时间戳。"
        "因此点级 Precision、Recall、F1、PR-AUC、Specificity 和误报负担可用于当前统一"
        "阈值对比，但动态阈值轨迹不等同于真实设备的连续在线轨迹。",
        "",
        "模型输入使用原始量纲数组 `x`，由 seed10 checkpoint 自带的标准化器处理；"
        "测试文件的 `x_std` 只用于内部一致性审计。每个 seed 的在线状态保存在各自结果"
        "目录，正式 `artifacts/formal_datasetX/welch_ndt_state.npz` 未被覆盖。",
        "",
        "完整逐点原始得分、EWMA 得分、动态阈值、标签、异常类型、判定及更新类型见各"
        "seed 目录中的 `detections.csv`、`summary.json` 和 `welch_ndt_detection.png`。",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="批量评价 05 Welch-NDT 双测试集")
    parser.add_argument("--test-root", type=Path, default=PROJECT_ROOT / "测试集数据")
    parser.add_argument(
        "--output-root", type=Path, default=SCRIPT_DIR / "05实验结果"
    )
    parser.add_argument("--batch-size", type=int, default=1024)
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    configs = {
        "dataset1": {
            "time_scale": "minute",
            "input_dir": args.test_root / "dataset1",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset1"
            / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset1_minute",
        },
        "dataset2": {
            "time_scale": "second",
            "input_dir": args.test_root / "dataset2",
            "artifact": SCRIPT_DIR / "artifacts" / "formal_dataset2"
            / "threshold_artifact.json",
            "output_dir": args.output_root / "dataset2_second",
        },
    }
    if args.output_root.exists() and any(args.output_root.iterdir()):
        raise FileExistsError(f"结果目录非空，拒绝覆盖：{args.output_root}")

    rows: List[Dict[str, Any]] = []
    result: Dict[str, Any] = {
        "strategy_id": "05_welch_ndt_algorithm1",
        "status": "TESTED_BOTH_DATASETS",
        "completion_status": "RESULT_FROZEN",
        "evaluation_rule": "point-level, K=1, M=1, five normal-sampling seeds",
        "runtime_online_updates": True,
        "score_or_threshold_hyperparameters_refit_on_test": False,
        "test_labels_used_by_strategy": False,
        "event_metrics_formally_used": False,
        "event_metrics_exclusion_reason": (
            "测试文件无真实时间戳或事件ID，且按正常块/异常块排列。"
        ),
    }
    for dataset, config in configs.items():
        test_files = sorted(
            config["input_dir"].glob("test_seed*.npz"), key=seed_from_path
        )
        if len(test_files) != 5:
            raise ValueError(f"{dataset} 应有 5 个测试文件，实际 {len(test_files)}")
        summaries: List[Dict[str, Any]] = []
        runs: List[Dict[str, Any]] = []
        for test_file in test_files:
            seed = seed_from_path(test_file)
            output_dir = config["output_dir"] / f"seed{seed}"
            namespace = SimpleNamespace(
                artifact=config["artifact"],
                test=test_file,
                labels=None,
                output_dir=output_dir,
                k=1,
                m=1,
                batch_size=args.batch_size,
                array_key="x",
                label_key="y_true",
                type_key="y_type",
                input_space="raw",
            )
            summary = run_detection(namespace)
            summaries.append(summary)
            runs.append({"seed": seed, **summary})
            rows.append({
                "dataset": dataset,
                "time_scale": config["time_scale"],
                "seed": seed,
                "summary": summary,
            })
        result[dataset] = {
            "time_scale": config["time_scale"],
            "threshold_initial": float(summaries[0]["threshold_initial"]),
            "num_test_sets": len(summaries),
            "runs": runs,
            "aggregate": aggregate(summaries),
            "data_audit": audit_test_design(test_files),
        }

    args.output_root.mkdir(parents=True, exist_ok=True)
    save_json(args.output_root / "evaluation_summary.json", result)
    write_seed_csv(args.output_root / "per_seed_metrics.csv", rows)
    write_report(args.output_root / "evaluation_report.md", result)
    print(f"双测试集汇总：{args.output_root / 'evaluation_report.md'}")
    return result


def main() -> Dict[str, Any]:
    return run(build_parser().parse_args())


if __name__ == "__main__":
    main()
