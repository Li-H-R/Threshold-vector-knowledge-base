# -*- coding: utf-8 -*-
"""只用纯正常连续公共得分准备 05 Welch-NDT 阈值初始状态。"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
BASELINE_DIR = SCRIPT_DIR.parent / "00阈值"
for candidate in (PROJECT_ROOT, SCRIPT_DIR, BASELINE_DIR):
    if str(candidate) not in sys.path:
        sys.path.insert(0, str(candidate))

from main import DATASETS
from strategy_05_welch_ndt import (
    STRATEGY_ID,
    WelchNDTThreshold,
    ewma_series,
    load_state_npz,
    save_state_npz,
    search_ndt_threshold,
    select_next_threshold,
    validate_scores,
    welch_test,
)


FORBIDDEN_PATH_MARKERS = ("测试集数据", "实验结果", "test_seed")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(
            value,
            handle,
            ensure_ascii=False,
            indent=2,
            allow_nan=False,
        )


def resolve_project_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def reject_forbidden_path(path: Path, label: str) -> None:
    rendered = str(path.resolve()).lower()
    if any(marker.lower() in rendered for marker in FORBIDDEN_PATH_MARKERS):
        raise ValueError(f"准备阶段拒绝 {label} 路径：{path}")


def require_hash(path: Path, expected: str, label: str) -> str:
    if not path.is_file():
        raise FileNotFoundError(f"{label}不存在：{path}")
    actual = sha256_file(path)
    if actual.lower() != str(expected).lower():
        raise ValueError(f"{label} SHA-256 不匹配：{actual} != {expected}")
    return actual


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=True, choices=("dataset1", "dataset2"))
    parser.add_argument(
        "--config", type=Path, default=SCRIPT_DIR / "experiment_config.json"
    )
    parser.add_argument("--output-dir", type=Path)
    return parser


def validate_isolation_contract(config: Dict[str, Any]) -> None:
    isolation = config.get("data_isolation", {})
    required_false = (
        "paper_first_test_fraction_used",
        "test_data_allowed_during_prepare",
        "detection_allowed_during_prepare",
        "metrics_allowed_during_prepare",
        "manual_false_alarm_feedback",
        "model_retraining_during_detection",
    )
    for key in required_false:
        if isolation.get(key) is not False:
            raise ValueError(f"准备配置必须设置 {key}=false")
    if isolation.get("test_file") is not None:
        raise ValueError("准备配置不得包含测试文件")
    if isolation.get("test_labels") is not None:
        raise ValueError("准备配置不得包含测试标签")
    if isolation.get("initialization_source") != "normal_calibration_only":
        raise ValueError("05 初始状态只能来自纯正常标定")


def audit_dataset1_source(source: Path, expected_count: int) -> Dict[str, Any]:
    with np.load(source, allow_pickle=False) as archive:
        required = {
            "X",
            "y",
            "source_row_start",
            "source_row_end",
            "timestamp_start",
            "timestamp_end",
        }
        missing = sorted(required - set(archive.files))
        if missing:
            raise ValueError(f"分钟级正常标定缺少字段：{missing}")
        x_shape = tuple(int(value) for value in archive["X"].shape)
        labels = np.asarray(archive["y"]).reshape(-1)
        starts = np.asarray(
            archive["source_row_start"], dtype=np.int64
        ).reshape(-1)
        ends = np.asarray(
            archive["source_row_end"], dtype=np.int64
        ).reshape(-1)
        timestamp_starts = np.asarray(archive["timestamp_start"]).astype(
            "datetime64[s]"
        )
        timestamp_ends = np.asarray(archive["timestamp_end"]).astype(
            "datetime64[s]"
        )
    if x_shape != (expected_count, 10, 8):
        raise ValueError(f"分钟级正常标定形状错误：{x_shape}")
    if labels.size != expected_count or not np.all(labels == 0):
        raise ValueError("分钟级正常标定标签必须全部为 0")
    if not np.all(np.diff(starts) == 1) or not np.all(np.diff(ends) == 1):
        raise ValueError("分钟级正常标定窗口不是步长 1 的连续序列")
    timestamp_steps = np.diff(timestamp_starts).astype(
        "timedelta64[s]"
    ).astype(np.int64)
    if not np.all(timestamp_steps == 60):
        raise ValueError("分钟级正常标定时间戳未按 60 秒连续递增")
    return {
        "input_shape": list(x_shape),
        "label_counts": {"0": int(labels.size)},
        "normal_only": True,
        "chronological": True,
        "contiguous": True,
        "sampling_interval_seconds_observed": 60,
        "source_row_start": int(starts[0]),
        "source_row_last_window_start": int(starts[-1]),
        "source_row_last_window_end": int(ends[-1]),
        "timestamp_start": str(timestamp_starts[0]),
        "timestamp_last_window_start": str(timestamp_starts[-1]),
        "timestamp_last_window_end": str(timestamp_ends[-1]),
    }


def audit_dataset2_source(
    source: Path,
    *,
    start_row: int,
    score_count: int,
) -> Dict[str, Any]:
    raw = np.load(source, mmap_mode="r", allow_pickle=False)
    if raw.ndim != 2 or raw.shape[1] != 15:
        raise ValueError(f"秒级正常源应为 (T,15)，实际 {raw.shape}")
    window_size = 10
    last_window_start = start_row + score_count - 1
    required_end_row_exclusive = last_window_start + window_size
    if start_row < 0 or required_end_row_exclusive > raw.shape[0]:
        raise ValueError("秒级连续标定范围越界")
    selected = np.asarray(
        raw[start_row:required_end_row_exclusive], dtype=np.float64
    )
    if not np.all(np.isfinite(selected)):
        raise ValueError("秒级连续正常源范围中存在 NaN 或 Inf")
    return {
        "source_shape": [int(raw.shape[0]), int(raw.shape[1])],
        "normality_assumption": "source_file_supplied_as_normal_data",
        "normal_only": True,
        "chronological": True,
        "contiguous": True,
        "continuous_start_row": int(start_row),
        "continuous_last_window_start": int(last_window_start),
        "continuous_required_end_row_exclusive": int(
            required_end_row_exclusive
        ),
        "selected_source_values_finite": True,
        "window_size": window_size,
        "window_stride": 1,
    }


def validate_upstream_score_artifact(
    dataset: str,
    dataset_cfg: Dict[str, Any],
    model_hash: str,
) -> Tuple[Path, Dict[str, Any], str, str]:
    upstream_dir = resolve_project_path(dataset_cfg["upstream_score_artifact"])
    reject_forbidden_path(upstream_dir, "公共得分工件")
    artifact_path = upstream_dir / "threshold_artifact.json"
    artifact_hash = require_hash(
        artifact_path,
        dataset_cfg["upstream_artifact_sha256"],
        "00 上游阈值工件",
    )
    state_path = upstream_dir / "score_state.npz"
    state_hash = require_hash(
        state_path,
        dataset_cfg["upstream_score_state_sha256"],
        "00 上游 Mahalanobis 状态",
    )
    artifact = load_json(artifact_path)
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("00 上游得分工件未达到 READY_FOR_TEST")
    if artifact.get("dataset") != dataset:
        raise ValueError("00 上游得分工件数据集映射错误")
    if artifact.get("score", {}).get("method") != "mahalanobis":
        raise ValueError("05 主实验只接受公共 Mahalanobis 得分")
    upstream_model_hash = artifact.get("model", {}).get(
        "checkpoint_sha256", ""
    )
    if upstream_model_hash.lower() != model_hash.lower():
        raise ValueError("00 上游模型哈希与 05 配置不一致")
    return upstream_dir, artifact, artifact_hash, state_hash


def validate_dataset2_score_provenance(
    dataset_cfg: Dict[str, Any],
    *,
    source_hash: str,
    model_hash: str,
    upstream_state_hash: str,
    score_hash: str,
    expected_count: int,
) -> Dict[str, Any]:
    path = resolve_project_path(
        dataset_cfg["continuous_score_provenance_artifact"]
    )
    reject_forbidden_path(path, "秒级连续得分来源工件")
    provenance_hash = require_hash(
        path,
        dataset_cfg["continuous_score_provenance_sha256"],
        "秒级连续得分来源工件",
    )
    artifact = load_json(path)
    checks = {
        "status_ready": artifact.get("status") == "READY_FOR_TEST",
        "dataset_match": artifact.get("dataset") == "dataset2",
        "normal_source_match": artifact.get("calibration", {}).get(
            "source_sha256", ""
        ).lower() == source_hash.lower(),
        "model_match": artifact.get("model", {}).get(
            "checkpoint_sha256", ""
        ).lower() == model_hash.lower(),
        "upstream_score_state_match": artifact.get("score", {}).get(
            "upstream_state_sha256", ""
        ).lower() == upstream_state_hash.lower(),
        "score_count_match": int(
            artifact.get("calibration", {}).get("score_count", -1)
        ) == expected_count,
        "score_hash_match": artifact.get("calibration", {}).get(
            "scores_sha256", ""
        ).lower() == score_hash.lower(),
        "chronological": artifact.get("calibration", {}).get("chronological")
        is True,
        "contiguous": artifact.get("calibration", {}).get("contiguous") is True,
        "normal_only": artifact.get("calibration", {}).get("normal_only") is True,
        "test_data_not_used": artifact.get("test_data_used") is False,
        "test_labels_not_used": artifact.get("test_labels_used") is False,
        "detection_not_executed": artifact.get("detection_executed") is False,
        "metrics_not_computed": artifact.get("metrics_computed") is False,
    }
    failed = sorted(key for key, passed in checks.items() if not passed)
    if failed:
        raise ValueError(f"秒级连续得分来源审计失败：{failed}")
    return {
        "artifact_path": str(path),
        "artifact_sha256": provenance_hash,
        "checks": checks,
        "reused_component": "calibration_scores_only",
        "aspot_state_reused": False,
    }


def load_continuous_scores(
    dataset: str,
    dataset_cfg: Dict[str, Any],
    *,
    source_hash: str,
    model_hash: str,
    upstream_state_hash: str,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    score_path = resolve_project_path(dataset_cfg["continuous_score_source"])
    reject_forbidden_path(score_path, "连续正常得分")
    score_hash = require_hash(
        score_path,
        dataset_cfg["continuous_score_sha256"],
        "连续正常得分",
    )
    scores = validate_scores(
        np.load(score_path, allow_pickle=False),
        min_samples=int(dataset_cfg["threshold_window_size"]) + 1,
    )
    expected_count = int(dataset_cfg["calibration_score_count"])
    if scores.size != expected_count:
        raise ValueError(
            f"连续正常得分数 {scores.size} != 配置 {expected_count}"
        )
    provenance: Dict[str, Any]
    if dataset == "dataset1":
        provenance = {
            "source": "ordered calibration_scores from frozen 00 artifact",
            "score_path": str(score_path),
            "score_sha256": score_hash,
        }
    else:
        provenance = validate_dataset2_score_provenance(
            dataset_cfg,
            source_hash=source_hash,
            model_hash=model_hash,
            upstream_state_hash=upstream_state_hash,
            score_hash=score_hash,
            expected_count=expected_count,
        )
        provenance.update({
            "score_path": str(score_path),
            "score_sha256": score_hash,
        })
    return scores, provenance


def audit_indices(total: int, history_size: int, stride: int) -> List[int]:
    if stride < 1:
        raise ValueError("audit_stride_samples 必须为正")
    first = history_size + 1
    if total < first:
        raise ValueError("连续正常得分不足 H+1")
    indices = list(range(first, total + 1, stride))
    if not indices or indices[-1] != total:
        indices.append(total)
    return indices


def build_calibration_trace(
    scores: np.ndarray,
    strategy_cfg: Dict[str, Any],
    dataset_cfg: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    history_size = int(dataset_cfg["threshold_window_size"])
    ewma_span = int(dataset_cfg["ewma_span"])
    stride = int(dataset_cfg["audit_stride_samples"])
    smoothed = ewma_series(scores, ewma_span)
    indices = audit_indices(smoothed.size, history_size, stride)
    rows: List[Dict[str, Any]] = []
    previous_audit_threshold: Optional[float] = None
    initial_grid_invalid = 0
    fallback_count = 0
    branch_counts = {
        "initial_ndt": 0,
        "significant_drift_recompute": 0,
        "stable_history_adjustment": 0,
        "fallback_ndt_invalid_history_adjustment": 0,
    }

    for end_exclusive in indices:
        previous = smoothed[
            end_exclusive - history_size - 1:end_exclusive - 1
        ]
        current = smoothed[end_exclusive - history_size:end_exclusive]
        ndt = search_ndt_threshold(
            current,
            z_min=float(strategy_cfg["z_min"]),
            z_max_exclusive=float(strategy_cfg["z_max_exclusive"]),
            z_step=float(strategy_cfg["z_step"]),
            sequence_min_length=int(strategy_cfg["sequence_min_length"]),
        )
        try:
            search_ndt_threshold(
                current,
                z_min=float(strategy_cfg["initial_candidate_z_min"]),
                z_max_exclusive=float(strategy_cfg["z_max_exclusive"]),
                z_step=float(strategy_cfg["z_step"]),
                sequence_min_length=int(strategy_cfg["sequence_min_length"]),
            )
        except ValueError:
            initial_grid_invalid += 1
        welch = welch_test(previous, current)
        if previous_audit_threshold is None:
            adjusted_threshold = ndt.threshold
            update_type = "initial_ndt"
            factor = 0.0
            fallback = False
        else:
            adjusted_threshold, update_type, factor, fallback = (
                select_next_threshold(
                    p_value=welch.p_value,
                    alpha=float(strategy_cfg["welch_alpha"]),
                    previous_threshold=previous_audit_threshold,
                    ndt_threshold=ndt.threshold,
                    previous_mean=welch.previous_mean,
                    current_mean=welch.current_mean,
                    previous_std=welch.previous_std,
                    current_std=welch.current_std,
                    delta_mean=float(strategy_cfg["delta_mean"]),
                    delta_std=float(strategy_cfg["delta_std"]),
                )
            )
        previous_audit_threshold = float(adjusted_threshold)
        branch_counts[update_type] += 1
        fallback_count += int(fallback)
        rows.append({
            "end_index_exclusive": int(end_exclusive),
            "raw_score": float(scores[end_exclusive - 1]),
            "smoothed_score": float(smoothed[end_exclusive - 1]),
            "ndt_threshold": float(ndt.threshold),
            "audit_adjusted_threshold": float(adjusted_threshold),
            "ndt_objective": float(ndt.objective),
            "ndt_z_value": float(ndt.z_value),
            "ndt_exceedance_count": int(ndt.exceedance_count),
            "ndt_sequence_count": int(ndt.sequence_count),
            "ndt_valid_candidate_count": int(ndt.valid_candidate_count),
            "welch_t": float(welch.statistic),
            "welch_df": float(welch.degrees_of_freedom),
            "welch_p": float(welch.p_value),
            "history_adjustment_factor": float(factor),
            "update_type": update_type,
        })

    numeric_fields = (
        "raw_score",
        "smoothed_score",
        "ndt_threshold",
        "audit_adjusted_threshold",
        "ndt_objective",
        "ndt_z_value",
        "welch_t",
        "welch_df",
        "welch_p",
        "history_adjustment_factor",
    )
    for field in numeric_fields:
        values = np.asarray([row[field] for row in rows], dtype=np.float64)
        if not np.all(np.isfinite(values)):
            raise ValueError(f"正常标定轨迹字段 {field} 包含 NaN/Inf")
    thresholds = np.asarray(
        [row["audit_adjusted_threshold"] for row in rows], dtype=np.float64
    )
    if np.any(thresholds <= 0.0):
        raise ValueError("正常标定轨迹包含非正阈值")
    fallback_fraction = fallback_count / max(1, len(rows) - 1)
    diagnostics = {
        "audit_point_count": int(len(rows)),
        "audit_stride_samples": stride,
        "audit_stride_seconds": stride
        * int(dataset_cfg["sampling_interval_seconds"]),
        "initial_candidate_z_min": float(
            strategy_cfg["initial_candidate_z_min"]
        ),
        "initial_grid_invalid_audit_windows": int(initial_grid_invalid),
        "initial_grid_invalid_fraction": float(
            initial_grid_invalid / len(rows)
        ),
        "frozen_z_min": float(strategy_cfg["z_min"]),
        "frozen_grid_invalid_audit_windows": 0,
        "history_adjustment_fallback_count": int(fallback_count),
        "history_adjustment_fallback_fraction": float(fallback_fraction),
        "branch_counts": branch_counts,
        "threshold_min": float(np.min(thresholds)),
        "threshold_max": float(np.max(thresholds)),
        "threshold_mean": float(np.mean(thresholds)),
        "threshold_std": float(np.std(thresholds)),
        "threshold_max_absolute_step": float(
            np.max(np.abs(np.diff(thresholds))) if thresholds.size > 1 else 0.0
        ),
        "trace_is_normal_calibration_audit": True,
        "trace_is_anomaly_detection": False,
    }
    return rows, diagnostics


def save_trace(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        raise ValueError("正常标定轨迹不能为空")
    fields = list(rows[0].keys())
    if any(field in fields for field in ("label", "point_pred", "alarm")):
        raise ValueError("准备轨迹不得包含检测或标签字段")
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def save_plot(
    path: Path,
    rows: List[Dict[str, Any]],
    dataset: str,
) -> Optional[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"
    x = np.asarray([row["end_index_exclusive"] for row in rows])
    smoothed = np.asarray([row["smoothed_score"] for row in rows])
    ndt = np.asarray([row["ndt_threshold"] for row in rows])
    adjusted = np.asarray([row["audit_adjusted_threshold"] for row in rows])
    fig, axis = plt.subplots(figsize=(12, 5.5))
    axis.plot(
        x,
        smoothed,
        color="#376996",
        linewidth=0.8,
        label="normal EWMA score",
    )
    axis.plot(
        x,
        ndt,
        color="#d18f00",
        linewidth=1.0,
        label="NDT threshold",
    )
    axis.plot(
        x,
        adjusted,
        color="#c65146",
        linewidth=1.1,
        label="Welch-adjusted audit threshold",
    )
    axis.set_title(f"05 Welch-NDT normal-calibration audit ({dataset})")
    axis.set_xlabel("normal calibration score end index")
    axis.set_ylabel("common Mahalanobis score")
    axis.grid(alpha=0.2)
    axis.legend(loc="best")
    fig.tight_layout()
    fig.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(fig)
    return None


def compare_states(left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
    if set(left) != set(right):
        raise ValueError("重载状态字段集合不一致")
    max_absolute_difference = 0.0
    for key in left:
        a = np.asarray(left[key])
        b = np.asarray(right[key])
        if a.shape != b.shape:
            raise ValueError(f"重载状态字段 {key} 形状不一致")
        if a.dtype.kind in "fiu" and b.dtype.kind in "fiu":
            if a.size:
                difference = float(
                    np.max(np.abs(a.astype(float) - b.astype(float)))
                )
                max_absolute_difference = max(
                    max_absolute_difference, difference
                )
            if not np.array_equal(a, b):
                raise ValueError(f"重载状态字段 {key} 未逐元素一致")
        elif not np.array_equal(a, b):
            raise ValueError(f"重载状态字段 {key} 不一致")
    return {
        "all_fields_equal": True,
        "max_absolute_difference": max_absolute_difference,
    }


def enforce_stability_gates(
    config: Dict[str, Any], diagnostics: Dict[str, Any]
) -> None:
    gates = config["stability_gates"]
    if (
        gates.get("require_all_audit_windows_have_valid_ndt") is True
        and diagnostics["frozen_grid_invalid_audit_windows"] != 0
    ):
        raise ValueError("冻结 z 网格仍存在无有效 NDT 候选的审计窗口")
    maximum_fallback = float(
        gates["maximum_history_adjustment_fallback_fraction"]
    )
    if diagnostics["history_adjustment_fallback_fraction"] > maximum_fallback:
        raise ValueError("历史阈值修正回退比例超过稳定性门禁")
    if gates.get("require_positive_finite_thresholds") is not True:
        raise ValueError("正式配置必须启用正有限阈值门禁")
    if gates.get("require_exact_state_replay") is not True:
        raise ValueError("正式配置必须启用精确状态重放门禁")


def run(args: argparse.Namespace) -> Dict[str, Any]:
    config_path = args.config.resolve()
    reject_forbidden_path(config_path, "配置")
    config = load_json(config_path)
    if config.get("schema_version") != 1:
        raise ValueError("不支持的 experiment_config schema_version")
    if config.get("strategy_id") != STRATEGY_ID:
        raise ValueError("配置 strategy_id 错误")
    validate_isolation_contract(config)

    dataset_cfg = config["datasets"][args.dataset]
    strategy_cfg = config["strategy_contract"]
    model_path = resolve_project_path(dataset_cfg["model"])
    normal_source = resolve_project_path(dataset_cfg["normal_source"])
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else resolve_project_path(dataset_cfg["artifact_dir"])
    )
    reject_forbidden_path(model_path, "模型")
    reject_forbidden_path(normal_source, "正常源")
    reject_forbidden_path(output_dir, "输出")
    expected_output = resolve_project_path(dataset_cfg["artifact_dir"])
    if output_dir != expected_output:
        raise ValueError("正式准备输出目录必须与冻结配置一致")

    model_hash = require_hash(model_path, dataset_cfg["model_sha256"], "模型")
    source_hash = require_hash(
        normal_source, dataset_cfg["normal_source_sha256"], "正常源"
    )
    _, upstream_artifact, upstream_artifact_hash, upstream_state_hash = (
        validate_upstream_score_artifact(
            args.dataset, dataset_cfg, model_hash
        )
    )
    if args.dataset == "dataset1":
        source_audit = audit_dataset1_source(
            normal_source,
            int(dataset_cfg["calibration_score_count"]),
        )
        if upstream_artifact.get("calibration", {}).get(
            "source_sha256", ""
        ).lower() != source_hash.lower():
            raise ValueError("分钟级 00 工件的正常源哈希不匹配")
    else:
        source_audit = audit_dataset2_source(
            normal_source,
            start_row=int(dataset_cfg["continuous_start_row"]),
            score_count=int(dataset_cfg["calibration_score_count"]),
        )

    scores, score_provenance = load_continuous_scores(
        args.dataset,
        dataset_cfg,
        source_hash=source_hash,
        model_hash=model_hash,
        upstream_state_hash=upstream_state_hash,
    )
    sampling_interval = int(dataset_cfg["sampling_interval_seconds"])
    history_size = int(dataset_cfg["threshold_window_size"])
    ewma_span = int(dataset_cfg["ewma_span"])
    if (
        history_size * sampling_interval
        != int(strategy_cfg["threshold_window_duration_seconds"])
    ):
        raise ValueError("threshold_window_size 与统一物理时长不一致")
    if (
        ewma_span * sampling_interval
        != int(strategy_cfg["ewma_duration_seconds"])
    ):
        raise ValueError("ewma_span 与统一物理时长不一致")

    print(
        f"准备 {args.dataset} Welch-NDT：scores={scores.size}, "
        f"history={history_size}, ewma_span={ewma_span}",
        flush=True,
    )
    trace_rows, diagnostics = build_calibration_trace(
        scores, strategy_cfg, dataset_cfg
    )
    enforce_stability_gates(config, diagnostics)
    strategy = WelchNDTThreshold(
        history_size=history_size,
        ewma_span=ewma_span,
        z_min=float(strategy_cfg["z_min"]),
        z_max_exclusive=float(strategy_cfg["z_max_exclusive"]),
        z_step=float(strategy_cfg["z_step"]),
        sequence_min_length=int(strategy_cfg["sequence_min_length"]),
        welch_alpha=float(strategy_cfg["welch_alpha"]),
        delta_mean=float(strategy_cfg["delta_mean"]),
        delta_std=float(strategy_cfg["delta_std"]),
    ).fit(scores)
    state = strategy.state_dict()

    output_dir.mkdir(parents=True, exist_ok=True)
    scores_path = output_dir / "calibration_scores.npy"
    state_path = output_dir / "welch_ndt_state.npz"
    trace_path = output_dir / "calibration_trace.csv"
    diagnostics_path = output_dir / "threshold_diagnostics.json"
    audit_path = output_dir / "normal_calibration_audit.json"
    decisions_path = output_dir / "method_decisions.json"
    replay_path = output_dir / "state_replay_check.json"
    plot_path = output_dir / "calibration_threshold_trace.png"
    artifact_path = output_dir / "threshold_artifact.json"

    np.save(scores_path, scores.astype(np.float64, copy=False))
    save_state_npz(state_path, state)
    save_trace(trace_path, trace_rows)
    save_json(diagnostics_path, diagnostics)

    restored = WelchNDTThreshold.from_state_dict(load_state_npz(state_path))
    replay = compare_states(state, restored.state_dict())
    probe_score = float(state["previous_ewma"])
    original_probe_strategy = WelchNDTThreshold.from_state_dict(state)
    restored_probe_strategy = WelchNDTThreshold.from_state_dict(
        load_state_npz(state_path)
    )
    probe_original = original_probe_strategy.step(probe_score)
    probe_restored = restored_probe_strategy.step(probe_score)
    if probe_original != probe_restored:
        raise RuntimeError("重载后合成探针的下一步输出不一致")
    compare_states(
        original_probe_strategy.state_dict(),
        restored_probe_strategy.state_dict(),
    )
    replay.update({
        "synthetic_probe_score": probe_score,
        "synthetic_probe_output": asdict(probe_original),
        "next_step_equal": True,
        "next_state_equal": True,
        "probe_is_test_data": False,
        "probe_is_synthetic_state_check": True,
    })
    save_json(replay_path, replay)

    audit = {
        "dataset": args.dataset,
        "time_scale": dataset_cfg["time_scale"],
        "normal_source": str(normal_source),
        "normal_source_sha256": source_hash,
        "normal_only": True,
        "score_count": int(scores.size),
        "sampling_interval_seconds": sampling_interval,
        "sampling_interval_evidence": dataset_cfg[
            "sampling_interval_evidence"
        ],
        "sampling_interval_is_assumption": bool(
            dataset_cfg.get("sampling_interval_is_assumption", False)
        ),
        "threshold_window_size": history_size,
        "threshold_window_duration_seconds": history_size
        * sampling_interval,
        "ewma_span": ewma_span,
        "ewma_duration_seconds": ewma_span * sampling_interval,
        "model": str(model_path),
        "model_sha256": model_hash,
        "upstream_artifact_sha256": upstream_artifact_hash,
        "upstream_score_state_sha256": upstream_state_hash,
        "score_min": float(np.min(scores)),
        "score_max": float(np.max(scores)),
        "score_mean": float(np.mean(scores)),
        "score_std": float(np.std(scores)),
        "score_quantiles": {
            str(q): float(np.quantile(scores, q))
            for q in (0.5, 0.9, 0.95, 0.98, 0.99)
        },
        "source_audit": source_audit,
        "continuous_score_provenance": score_provenance,
        "test_data_used": False,
        "test_labels_used": False,
        "detection_executed": False,
        "metrics_computed": False,
    }
    save_json(audit_path, audit)

    decisions = {
        "strategy_id": STRATEGY_ID,
        "reproduction_type": "threshold_module_migrated",
        "p_value_branch": "algorithm1_consistent",
        "paper_prose_conflict_acknowledged": True,
        "paper_equation_22_literal_used": False,
        "welch_df_interpretation": (
            "standard_welch_satterthwaite_variance_formula"
        ),
        "candidate_grid_source": (
            "Hundman-style mean-plus-z-standard-deviation grid"
        ),
        "initial_z_min": float(strategy_cfg["initial_candidate_z_min"]),
        "frozen_z_min": float(strategy_cfg["z_min"]),
        "z_min_revision_reason": (
            "The initial z_min=2.5 produced windows with no valid candidate "
            "during normal-only calibration audit; z_min=1.0 produced a valid "
            "candidate for every audited normal window."
        ),
        "revision_used_test_data": False,
        "revision_used_test_labels": False,
        "initial_grid_invalid_audit_windows": diagnostics[
            "initial_grid_invalid_audit_windows"
        ],
        "frozen_grid_invalid_audit_windows": diagnostics[
            "frozen_grid_invalid_audit_windows"
        ],
        "delta_mean": float(strategy_cfg["delta_mean"]),
        "delta_std": float(strategy_cfg["delta_std"]),
        "current_point_uses_pre_observation_threshold": True,
        "anomaly_update": strategy_cfg["anomaly_update"],
        "manual_false_alarm_feedback": False,
        "model_retraining": False,
    }
    save_json(decisions_path, decisions)
    plot_warning = save_plot(plot_path, trace_rows, args.dataset)

    now_cn = datetime.now(timezone(timedelta(hours=8))).isoformat()
    artifact = {
        "schema_version": 1,
        "strategy_id": STRATEGY_ID,
        "status": "READY_FOR_TEST",
        "formal_result_allowed": True,
        "created_at_china": now_cn,
        "dataset": args.dataset,
        "time_scale": dataset_cfg["time_scale"],
        "config": {
            "path": str(config_path),
            "sha256": sha256_file(config_path),
        },
        "model": {
            "checkpoint": model_path.name,
            "checkpoint_sha256": model_hash,
            "window_size": int(DATASETS[args.dataset]["window_size"]),
            "input_dim": int(DATASETS[args.dataset]["input_dim"]),
            "retrained": False,
        },
        "calibration": {
            "source_path": str(normal_source),
            "source_sha256": source_hash,
            "score_count": int(scores.size),
            "sampling_interval_seconds": sampling_interval,
            "sampling_interval_evidence": dataset_cfg[
                "sampling_interval_evidence"
            ],
            "sampling_interval_is_assumption": bool(
                dataset_cfg.get("sampling_interval_is_assumption", False)
            ),
            "chronological": True,
            "contiguous": True,
            "normal_only": True,
            "scores_file": scores_path.name,
            "scores_sha256": sha256_file(scores_path),
        },
        "score": {
            "method": "ledoit_wolf_mahalanobis",
            "upstream_artifact_sha256": upstream_artifact_hash,
            "upstream_state_sha256": upstream_state_hash,
            "residual_definition": (
                "mean over time of abs(reconstruction - input)"
            ),
            "space": "standardized",
        },
        "threshold": {
            "method": "ewma_nonparametric_dynamic_threshold_with_welch_gate",
            "state_file": state_path.name,
            "state_sha256": sha256_file(state_path),
            "threshold_window_size": history_size,
            "threshold_window_duration_seconds": history_size
            * sampling_interval,
            "ewma_span": ewma_span,
            "ewma_duration_seconds": ewma_span * sampling_interval,
            "candidate_rule": strategy_cfg["candidate_rule"],
            "z_min": float(state["z_min"]),
            "z_max_exclusive": float(state["z_max_exclusive"]),
            "z_step": float(state["z_step"]),
            "welch_alpha": float(state["welch_alpha"]),
            "welch_df": strategy_cfg["welch_df"],
            "p_value_branch": strategy_cfg["p_value_branch"],
            "delta_mean": float(state["delta_mean"]),
            "delta_std": float(state["delta_std"]),
            "initial_runtime_threshold": float(state["threshold"]),
            "initial_ndt_threshold": float(state["ndt_threshold"]),
            "initial_ndt_z_value": float(state["ndt_z_value"]),
            "initial_welch_p_value": float(state["welch_p_value"]),
            "invalid_history_adjustment_fallback": strategy_cfg[
                "invalid_history_adjustment_fallback"
            ],
            "invalid_ndt_fallback": None,
        },
        "future_decision_contract": {
            "rule": strategy_cfg["decision_rule"],
            "anomaly_update": strategy_cfg["anomaly_update"],
            "normal_update": strategy_cfg["normal_update"],
            "test_labels_available_to_strategy": False,
            "model_retraining": False,
            "persistence_for_main_experiment": {"k": 1, "m": 1},
        },
        "files": {
            "calibration_trace": trace_path.name,
            "threshold_diagnostics": diagnostics_path.name,
            "normal_calibration_audit": audit_path.name,
            "method_decisions": decisions_path.name,
            "state_replay_check": replay_path.name,
            "calibration_threshold_trace": (
                None if plot_warning else plot_path.name
            ),
        },
        "paper_deviations": [
            "MSTGL-AD front-end replaced by the frozen joint-task LSTM",
            "paper score replaced by the common frozen Mahalanobis score",
            "standard Welch-Satterthwaite variance formula resolves equation 22 typesetting",
            "Algorithm 1 p-value branch is frozen despite prose conflict",
            "z_min was changed from 2.5 to 1.0 using only normal-calibration stability",
            "manual false-alarm feedback and model retraining are disabled",
            "point-adjust is not used",
        ],
        "test_data_used": False,
        "test_labels_used": False,
        "detection_executed": False,
        "metrics_computed": False,
        "model_retrained": False,
    }
    if plot_warning:
        artifact["plot_warning"] = plot_warning
    save_json(artifact_path, artifact)
    print(f"状态：READY_FOR_TEST；工件：{artifact_path}")
    print(
        f"冻结初始阈值：{state['threshold']:.8f}；"
        f"NDT z={state['ndt_z_value']:.2f}；"
        f"正常审计点={diagnostics['audit_point_count']}",
        flush=True,
    )
    return artifact


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
