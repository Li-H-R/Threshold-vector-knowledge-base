# 05 阈值与联合任务 LSTM 融合准备方案

> 更新说明（2026-11-05）：本文件最初用于冻结异常检测前的准备合同。准备阶段完成后，
> 用户已另行明确授权分钟级与秒级异常检测，检测现已完成。第 1-12 节保留准备阶段的
> 无测试集约束，第 13-15 节记录授权后的执行合同与结果状态。

## 1. 本文件的目标与边界

本方案说明如何把 `05.pdf` 中的“非参数动态阈值 + Welch t 检验 + 历史阈值修正”迁移到
本项目已经训练完成的联合任务 LSTM 后端。

准备阶段只做异常检测前的以下工作：

- 阅读并冻结论文阈值公式及本项目中的实现解释；
- 固定模型、残差、公共 Mahalanobis 得分和双数据集映射；
- 设计策略代码、配置、单元测试、纯正常标定和工件格式；
- 分别为分钟级 `dataset1` 和秒级 `dataset2` 准备可冻结的初始状态；
- 停在 `READY_FOR_TEST`，等待后续单独授权检测。

准备阶段明确不做：

- 不读取任何测试样本或测试标签；
- 不运行分钟级或秒级异常检测；
- 不计算 Precision、Recall、F1、PR-AUC、误报率或检测延迟；
- 不根据测试结果选择阈值参数；
- 不重新训练或微调联合任务 LSTM；
- 不把论文的图网络、预测网络或 VAE 替换进现有模型；
- 不执行论文所述“将人工确认的误报重新加入模型训练”。

参考项目文件：

- `../统一阈值实验工作流.md`；
- `../../demo/阈值策略对比实验流程.md`；
- `../../demo/异常检测Demo使用说明.md`；
- `../04阈值/04阈值与联合任务LSTM融合准备方案.md`。

---

## 2. 论文方法卡

| 项目 | 内容 |
|---|---|
| 编号 | `05` |
| 论文 | *An Online Anomaly Monitoring Method Based on Multiscale Spatiotemporal Graph Learning for Wind Turbine* |
| 作者 | Qing Xu, Dazhong Ma, Haoran Zhao, Qiuye Sun |
| 期刊 | *IEEE Transactions on Industrial Informatics*, 21(11), 8750-8758 |
| 年份 | 2025 |
| DOI | `10.1109/TII.2025.3586066` |
| 本地原文 | `05.pdf` |
| 原文阈值输入 | 预测误差与重构误差融合后的标量 anomaly score |
| 原文预处理 | 对误差向量做 EWMA 平滑 |
| 原文基础阈值 | 式 (17)-(20) 的非参数动态阈值搜索 |
| 漂移判断 | 相邻滑动窗口的 Welch t 检验，`alpha=0.05` |
| 历史修正 | 式 (23) 使用前一阈值、均值比、标准差比和当前非参数阈值 |
| 在线性质 | 动态、依赖历史、必须保持时间顺序 |
| 本项目复现类型 | `threshold_module_migrated`，不是整篇论文的严格复现 |

05 论文的完整模型同时使用预测网络和重构网络，并通过式 (16) 生成它自己的异常得分。
本项目的研究问题是“同一模型、同一残差、同一异常得分下比较阈值策略”，因此只迁移
式 (17)-(23) 的阈值模块。不能换成论文模型或论文式 (16)，否则差异将不再只来自阈值。

迁移后的主链路为：

```text
固定联合任务 LSTM
-> 固定标准化空间绝对重构残差
-> 固定时间维均值残差
-> 固定公共 Ledoit-Wolf Mahalanobis 得分 s_t
-> 因果 EWMA 得分 e_t
-> 非参数候选阈值 tau_ndt
-> Welch 漂移门控与历史阈值修正
-> 冻结动态阈值初始状态
-> 准备阶段停止并等待单独授权
-> 获得授权后，从冻结状态的深拷贝执行检测
```

---

## 3. 固定实验合同

### 3.1 两个时间尺度的固定映射

| 项目 | 分钟级 | 秒级 |
|---|---|---|
| 数据集标识 | `dataset1` | `dataset2` |
| 时间尺度 | 1 分钟级 | 秒级 |
| checkpoint | `models/dataset1_joint_seed10.pth` | `models/dataset2_joint_seed10.pth` |
| checkpoint SHA-256 | `adc97f5c48eb4b8e15dab7fa7ac09afe54cc01f88dab8986c5f7340daa96a4fa` | `ec92a82289f8e0e1f497570eedc9c008e19b86d70a24982d4a9d83fb19718d61` |
| 输入特征数 | 8 | 15 |
| LSTM 窗口长度 | 10 | 10 |
| 正常连续源 | `正常数据/阈值标定集.npz` | `正常数据/new_raw_data.npy` |
| 正常源 SHA-256 | `99376a1f9cb781b0f51be4fe61f4cca64c880e27b5cf742cc942ccd8ac7cd42d` | `fb1e0d0c1dfcd61d94bced2f3fc5ea30fb78f1e1ab27579f0ad502ecd62c96ca` |
| 公共得分状态 | `00阈值/artifacts/formal_dataset1/score_state.npz` | `00阈值/artifacts/formal_dataset2/score_state.npz` |
| 05 工件目录 | `05阈值/artifacts/formal_dataset1` | `05阈值/artifacts/formal_dataset2` |

必须保持以下一一对应关系：

```text
分钟级正常数据 -> dataset1 模型 -> dataset1 公共得分状态 -> formal_dataset1
秒级正常数据   -> dataset2 模型 -> dataset2 公共得分状态 -> formal_dataset2
```

禁止合并两个时间尺度的正常得分、交叉使用模型或工件、重新拟合新的残差定义，或为 05
单独更换主异常得分。

### 3.2 固定残差与公共得分

对窗口 `X_i in R^(10 x D)`，模型必须在 `eval()` 与 `torch.no_grad()` 下运行。残差为：

\[
R_i=\frac{1}{10}\sum_{j=1}^{10}|\hat X_{i,j}-X_{i,j}|\in\mathbb{R}^{D}.
\]

主异常得分固定为 00 正式工件中的收缩 Mahalanobis 距离：

\[
s_i=\sqrt{(R_i-\mu)^T\Omega(R_i-\mu)}.
\]

其中 `mu` 和 `Omega` 必须从对应的 00 `score_state.npz` 读取。05 不重新拟合
Mahalanobis 状态，不使用 `mode_w`、`latent`，也不改变 `K=1, M=1` 的主实验合同。

### 3.3 模型窗口与阈值窗口必须分开命名

论文重复使用符号 `w`，既描述模型输入滑窗，又出现在阈值更新公式中。本项目必须明确：

- `model_window_size=10`：联合任务 LSTM 的固定输入窗口，不得修改；
- `threshold_window_size=H`：05 阈值器比较得分分布所用的历史窗口；
- `ewma_span=L`：EWMA 的平滑跨度。

不能为了照搬论文实验中的 `w=60` 而把现有 LSTM 的输入窗口从 10 改为 60。

---

## 4. 正常标定数据的可用性与连续性

### 4.1 分钟级数据可直接作为连续得分流

`正常数据/阈值标定集.npz` 已核验：

- `X.shape=(1960,10,8)`；
- `y` 共 1960 个且全部为 0；
- `source_row_start` 从 3261 到 5220，差分全部为 1；
- `timestamp_start` 从 `2024-01-03T06:21:00` 开始；
- 最后一个窗口的 `timestamp_end` 为 `2024-01-04T15:09:00`；
- 数据已在 checkpoint 对应的标准化空间。

因此分钟级可直接复用：

```text
阈值策略/00阈值/artifacts/formal_dataset1/calibration_scores.npy
SHA-256 = 5633f2bb35314fca3fbe5a5d88e0305ef20e47b92ab2e996992308cdafda0729
```

该得分顺序与连续正常窗口一致，无需再次运行 LSTM。

### 4.2 秒级现有 20000 窗口不能用于动态阈值时序初始化

`正常数据/new_raw_阈值标定集.npz` 虽然是纯正常数据，但其 20000 个窗口采用：

```text
sampling_strategy = uniform_over_all_valid_window_starts
```

相邻 `source_row_start` 的差为 61 或 62。它适合估计静态分布，不是逐秒连续得分流，
不能拿来计算 EWMA、相邻窗口 Welch 检验或动态阈值轨迹。

秒级必须从 `正常数据/new_raw_data.npy` 的连续行构造长度 10、步长 1 的模型窗口，使用
dataset2 模型和已经冻结的 dataset2 `score_state.npz` 生成连续公共得分。

现有 04 准备阶段已经生成了一份可核验的纯正常连续公共得分缓存：

```text
阈值策略/04阈值/artifacts/formal_dataset2/calibration_scores.npy
score_count = 117600
SHA-256 = 3d88de079b6012384330bb64a8b92f8823789424e52eac94790f5db9c5955580
```

05 可以采用以下两种等价方式之一，必须在配置中固定：

1. 推荐方式：从同一正常源重新生成，要求结果与上述哈希逐元素/逐字节一致；
2. 缓存复用方式：只把上述文件当作“公共连续得分缓存”，同时核验其正常源、模型、
   `score_state`、起始行、得分数和 SHA-256；不得读取或复用 04 的 ASPOT 状态。

长期建议把这类连续公共得分移动到 `阈值策略/common/artifacts/`，让 04、05 等动态方法
共同引用，避免策略间形成不必要的依赖。

### 4.3 秒级采样间隔证据

`new_raw_data.npy` 没有时间戳。现有项目合同将 dataset2 定义为秒级，因此首版可冻结：

```text
sampling_interval_seconds = 1
sampling_interval_evidence = project_contract
sampling_interval_is_assumption = true
```

若后续获得源时间戳或采样说明，应在任何测试前补充证据并重新冻结配置。若无法接受这一
假设，秒级状态只能标记为 `CALIBRATION_BLOCKED`，不能伪装成已完成正式准备。

---

## 5. 05 阈值数学合同

### 5.1 因果 EWMA

令公共原始得分为 `s_t`。EWMA 状态使用：

\[
e_t=(1-\beta)e_{t-1}+\beta s_t,
\qquad \beta=\frac{2}{L+1}.
\]

实现固定 `adjust=False`，首个正常得分初始化 `e_0=s_0`。在线时先基于上一个已接纳正常
EWMA 状态计算候选 `e_t`，但只有当前点被接纳为正常后才提交状态，避免异常污染后续平滑。

论文只说明使用 EWMA，没有给出平滑系数。为使分钟级和秒级使用相同物理尺度，首版建议：

```text
threshold_window_duration_seconds = 3600   # 60 分钟
ewma_duration_seconds = 180                # 阈值窗口的 5%

dataset1: H=60,   L=3
dataset2: H=3600, L=180  # 建立在 1 秒采样假设上
```

这些是迁移参数，不是 05 论文报告值。最终值必须在读取测试集前写入配置并冻结。

### 5.2 非参数动态阈值目标

对当前历史 EWMA 得分向量 `E={e_i}` 和候选阈值 `tau`，定义：

\[
E_{<\tau}=\{e_i\in E\mid e_i<\tau\},
\]

\[
\Delta\mu(E)=\mu(E)-\mu(E_{<\tau}),
\qquad
\Delta\sigma(E)=\sigma(E)-\sigma(E_{<\tau}),
\]

\[
e_\tau=\{e_i\in E\mid e_i>\tau\}.
\]

令 `E_seq` 为 `e_i>tau` 的连续区间集合，则论文式 (17) 的目标为：

\[
J(\tau)=
\frac{
\Delta\mu(E)/\mu(E)+\Delta\sigma(E)/\sigma(E)
}{
|e_\tau|+|E_{seq}|^2
},
\qquad
\tau_{ndt}=\arg\max_{\tau\in\mathcal{T}}J(\tau).
\]

05 论文没有给出候选集合 `T` 的构造方式。该目标与 Hundman 等人的非参数动态阈值方法
及其公开实现一致：

- 论文：<https://arxiv.org/abs/1802.04431>
- 参考实现：<https://github.com/khundman/telemanom/blob/master/telemanom/errors.py>

为了让式 (17) 可执行，初始方案参考公开实现建议 `z_min=2.5`。正式纯正常审计发现该下界
在分钟级 1900 个审计窗口中有 1293 个无有效候选，在秒级 1901 个审计窗口中有 329 个
无有效候选。按照本文件第 9.3 节允许的“测试前、只基于正常标定稳定性修订”，正式冻结：

```text
candidate_rule = mean_plus_z_std
initial_candidate_z_min = 2.5
z_min = 1.0
z_max_exclusive = 12.0
z_step = 0.5
tau(z) = mean(E) + z * std(E, ddof=0)
sequence_min_length = 2
tie_break = larger_tau
```

改为 `z_min=1.0` 后，两套纯正常审计的无有效候选窗口均为 0。该修订没有读取测试样本、
测试标签或测试指标，旧值、失败数量和修订原因已写入 `method_decisions.json`。

只借用候选阈值网格，不引入参考实现中的 error buffer、反向阈值、异常段剪枝或标签评价。
否则 05 会变成另一套复合检测器，无法保持“只替换阈值策略”的边界。

每个候选必须满足：

- `E`、`tau`、均值和标准差均有限；
- `mu(E)>0` 且 `sigma(E)>0`；
- `E_<tau` 非空并至少保留两个元素；
- `e_tau` 非空；
- 目标函数分母大于 0；
- 计算结果为有限数。

若无有效候选，正式准备应失败并标记 `CALIBRATION_UNSTABLE`，不得静默回退到 98% 分位数。

### 5.3 Welch t 检验

使用两个按时间相邻、长度都为 `H` 的 EWMA 窗口：

```text
W_prev = E[t-H : t]
W_curr = E[t-H+1 : t+1]
```

它们是论文“moving sliding window”的因果解释，因此会有 `H-1` 个重叠点。Welch 统计量为：

\[
t=\frac{\bar e_{curr}-\bar e_{prev}}
{\sqrt{s_{curr}^2/H+s_{prev}^2/H}}.
\]

自由度使用标准 Welch-Satterthwaite 公式：

\[
\nu=\frac{(s_{curr}^2/H+s_{prev}^2/H)^2}
{(s_{curr}^2/H)^2/(H-1)+(s_{prev}^2/H)^2/(H-1)}.
\]

执行双侧检验，`alpha=0.05`。样本标准差使用 `ddof=1`。

05 论文式 (22) 的排版显示为均值的四次项，但 Welch 自由度应由样本方差构成。项目采用
标准 Welch-Satterthwaite 公式，并在工件中记录：

```text
paper_equation_22_literal_used = false
welch_df_interpretation = standard_welch_satterthwaite_variance_formula
reproduction_deviation = likely_typesetting_error_resolved
```

若两个窗口方差均为 0：均值相同则令 `p=1`，均值不同则令 `p=0`；其他退化情况必须明确
报错或按冻结规则处理，不能产生 NaN 后继续。

### 5.4 历史阈值修正

论文式 (23) 为：

\[
\tau_t=
\left(
1-\delta_1\frac{\mu_{t-1}}{\mu_t}
-\delta_2\frac{\sigma_{t-1}}{\sigma_t}
\right)\tau_{t-1}+\tau_{ndt,t}.
\]

论文没有给出 `delta_1` 和 `delta_2` 的数值。首版建议固定：

```text
delta_mean = 0.5
delta_std = 0.5
```

这样在两个窗口均值、标准差几乎不变时，历史系数接近 0，`tau_t` 接近当前
`tau_ndt,t`；当分布上移或下移时，历史项提供方向性修正。该选择属于迁移决定，必须在
测试前冻结，不能看到测试表现后修改。

如果均值或标准差比值的分母接近 0、式 (23) 得到非有限值或 `tau_t<=0`，首版允许的唯一
显式回退为：

```text
tau_t = tau_ndt,t
update_type = fallback_ndt_invalid_history_adjustment
```

回退次数必须写入审计文件。不得回退到其他阈值方法。

---

## 6. 论文歧义与项目冻结解释

### 6.1 p 值分支方向不一致

论文正文与 Algorithm 1 存在冲突：

- 正文称 `p<=alpha` 时差异显著，并使用历史调整因子更新阈值；
- Algorithm 1 写成 `p>alpha` 时按式 (21)-(23) 更新，否则按式 (17)-(20) 获取阈值。

主实现建议采用 Algorithm 1 的可操作流程：

```text
若 p <= alpha（显著漂移）：
    tau_next = tau_ndt
    update_type = significant_drift_recompute

若 p > alpha（未发现显著漂移）：
    tau_next = historical_adjustment(tau_prev, tau_ndt)
    update_type = stable_history_adjustment
```

理由是显著漂移时重新依赖当前窗口的非参数阈值，未显著漂移时保留历史连续性，更符合
Algorithm 1 的分支和在线适应目的。工件必须写明：

```text
p_value_branch = algorithm1_consistent
paper_prose_conflict_acknowledged = true
```

如果以后要研究正文相反分支，必须提前注册为独立策略
`05b_welch_ndt_prose_branch`，不能在查看测试结果后替换主 05 的分支。

### 6.2 当前点是否参与自己的阈值

为满足统一工作流的因果性门禁，当前点 `t` 的判定阈值 `tau_t` 必须由 `t-1` 时刻已经
冻结的状态产生。禁止先把 `s_t` 放入历史窗口，再计算 `tau_t` 并判定自身。

未来在线执行顺序固定为：

```text
读取 t-1 冻结状态中的 tau_t
-> 读取当前公共得分 s_t
-> 由上一已接纳 EWMA 状态计算候选 e_t
-> point_pred[t] = (e_t > tau_t)
-> 若异常：不提交 EWMA、不更新历史窗口和阈值状态
-> 若正常：提交 EWMA、追加历史，计算 tau_(t+1)
```

这是避免异常污染阈值的迁移规则。05 论文没有完整说明异常点进入更新窗口的处理方式，
因此必须披露，不能称为原文逐行复现。

### 6.3 人工误报反馈不进入主实验

论文提到若发现误报，可把异常片段作为正常数据加入训练。这需要人工反馈并改变模型，
与本项目“固定模型、只比较阈值”冲突。主实验中固定：

```text
manual_false_alarm_feedback = false
model_retraining_during_detection = false
test_labels_available_to_strategy = false
```

若未来单独研究反馈学习，应作为模型在线学习消融，不得混入阈值策略主表。

---

## 7. 推荐程序结构

```text
05阈值/
├── 05.pdf
├── 05阈值与联合任务LSTM融合准备方案.md
├── README.md
├── strategy_05_welch_ndt.py
├── prepare_05_welch_ndt.py
├── experiment_config.json
├── tests/
│   └── test_strategy_05_welch_ndt.py
└── artifacts/
    ├── formal_dataset1/
    └── formal_dataset2/
```

准备阶段不创建、不运行 `detect_05_welch_ndt.py`，也不创建 `05实验结果/`。后续获得用户
明确授权后，已创建检测入口和独立结果目录；准备工件本身未被改写。

### 7.1 策略代码职责

`strategy_05_welch_ndt.py` 只实现 05 特有逻辑，建议公开以下可单测函数：

```python
def ewma_candidate(previous_ewma, score, span): ...

def count_consecutive_runs(mask, min_length=2): ...

def ndt_objective(smoothed_scores, threshold): ...

def search_ndt_threshold(smoothed_scores, z_min, z_max, z_step): ...

def welch_test(previous_window, current_window): ...

def historical_threshold_update(
    previous_threshold,
    current_ndt_threshold,
    previous_mean,
    current_mean,
    previous_std,
    current_std,
    delta_mean,
    delta_std,
): ...
```

状态类建议：

```python
class WelchNDTThreshold:
    strategy_id = "05_welch_ndt_algorithm1"

    def fit(self, normal_calibration_scores):
        """只读取按时间排序的纯正常公共得分，建立可冻结初始状态。"""

    def step(self, score):
        """未来单步因果判定；准备阶段不对真实测试数据调用。"""

    def state_dict(self): ...

    @classmethod
    def from_state_dict(cls, state): ...
```

### 7.2 准备脚本职责

`prepare_05_welch_ndt.py` 的流程固定为：

```text
读取冻结配置
-> 核验模型、正常源、公共得分状态和所有 SHA-256
-> 核验正常标签、时间顺序、连续性、输入空间、窗口和特征维数
-> dataset1 读取连续公共正常得分
-> dataset2 生成或严格复用连续公共正常得分
-> 按时间顺序计算因果 EWMA
-> 用纯正常历史计算 NDT 候选阈值、Welch 统计量和阈值状态
-> 保存状态、重新加载并进行状态重放
-> 生成正常标定审计和阈值轨迹
-> 全部门禁通过后写为 READY_FOR_TEST
-> 停止
```

准备脚本命令行只允许 `--dataset`、`--config` 和 `--output-dir`。正常源、公共得分工件、
连续范围和参数必须来自已冻结配置。脚本不得提供：

```text
--test
--test-labels
--detect
--evaluate
--point-adjust
--tune-on-test
```

---

## 8. 冻结配置建议

下面是实现时应落盘的核心配置骨架。`dataset2` 的一秒采样仍需保留假设标记。

```json
{
  "schema_version": 1,
  "strategy_id": "05_welch_ndt_algorithm1",
  "strategy_name": "Causal EWMA nonparametric dynamic threshold with Welch drift gate",
  "reproduction_type": "threshold_module_migrated",
  "fixed_contract": {
    "model_seed": 10,
    "model_window_size": 10,
    "residual": "mean over time of abs(reconstruction - input) in standardized space",
    "score_method": "ledoit_wolf_mahalanobis",
    "persistence": {"k": 1, "m": 1}
  },
  "strategy_contract": {
    "interface_type": "causal_dynamic_upper_threshold",
    "required_inputs": ["score", "timestamp_or_monotonic_index"],
    "threshold_window_duration_seconds": 3600,
    "ewma_duration_seconds": 180,
    "ewma_adjust": false,
    "candidate_rule": "mean_plus_z_std",
    "initial_candidate_z_min": 2.5,
    "z_min": 1.0,
    "z_max_exclusive": 12.0,
    "z_step": 0.5,
    "sequence_min_length": 2,
    "tie_break": "larger_tau",
    "welch_alpha": 0.05,
    "welch_alternative": "two_sided",
    "welch_df": "standard_welch_satterthwaite",
    "p_value_branch": "algorithm1_consistent",
    "delta_mean": 0.5,
    "delta_std": 0.5,
    "decision_rule": "smoothed_score > pre_observation_threshold",
    "anomaly_update": "freeze_ewma_history_and_threshold",
    "normal_update": "commit_ewma_then_compute_next_threshold",
    "invalid_history_adjustment_fallback": "current_ndt_threshold",
    "invalid_ndt_fallback": null
  },
  "data_isolation": {
    "initialization_source": "normal_calibration_only",
    "test_file": null,
    "test_labels": null,
    "test_data_allowed_during_prepare": false,
    "detection_allowed_during_prepare": false,
    "metrics_allowed_during_prepare": false,
    "manual_false_alarm_feedback": false,
    "model_retraining_during_detection": false
  },
  "datasets": {
    "dataset1": {
      "time_scale": "minute",
      "sampling_interval_seconds": 60,
      "threshold_window_size": 60,
      "ewma_span": 3,
      "model": "models/dataset1_joint_seed10.pth",
      "normal_source": "正常数据/阈值标定集.npz",
      "continuous_score_source": "阈值策略/00阈值/artifacts/formal_dataset1/calibration_scores.npy",
      "artifact_dir": "阈值策略/05阈值/artifacts/formal_dataset1"
    },
    "dataset2": {
      "time_scale": "second",
      "sampling_interval_seconds": 1,
      "sampling_interval_is_assumption": true,
      "threshold_window_size": 3600,
      "ewma_span": 180,
      "model": "models/dataset2_joint_seed10.pth",
      "normal_source": "正常数据/new_raw_data.npy",
      "continuous_score_count": 117600,
      "continuous_score_expected_sha256": "3d88de079b6012384330bb64a8b92f8823789424e52eac94790f5db9c5955580",
      "artifact_dir": "阈值策略/05阈值/artifacts/formal_dataset2"
    }
  }
}
```

配置落盘时还必须补全模型、正常源、公共得分状态和连续得分文件的 SHA-256。任何输入哈希
变化都应拒绝覆盖原正式工件。

---

## 9. 纯正常准备与参数冻结规则

### 9.1 允许使用的数据

只允许：

- 对应模型 checkpoint 中的标准化器；
- 纯正常标定数据；
- 00 正式工件冻结的 Mahalanobis 状态；
- 固定随机种子的人工合成数组，用于单元测试。

不允许：

- 测试数据的任何特征、得分、时间范围或标签；
- 测试集上的阈值曲线；
- 测试指标或故障事件位置；
- 根据测试表现改变 `H`、`L`、`z` 网格、`delta` 或 p 值分支。

### 9.2 正常数据只用于稳定性门禁，不计算检测指标

准备阶段可在纯正常得分上生成因果阈值轨迹，检查：

- 阈值、EWMA、t 值、自由度和 p 值是否有限；
- 有效 NDT 候选数；
- 历史修正系数的范围；
- 阈值最小值、最大值、分位数和最大单步变化；
- Welch 两个分支的触发次数；
- 式 (23) 退化到 `tau_ndt` 的次数；
- 保存/加载与逐点重放是否完全一致。

这些是标定稳定性统计，不输出异常标签，不计算分类指标，也不把纯正常窗口写入检测结果目录。

### 9.3 参数修改的唯一允许时点

若纯正常标定出现数值失败，可在未接触测试集的前提下修改迁移参数，但必须：

1. 记录旧值、失败原因和新值；
2. 重新执行全部合成测试和正常标定；
3. 生成新的配置哈希和工件版本；
4. 在首次测试前冻结；
5. 测试后不得回头修改同一策略 ID。

如果想比较两个合理解释，应预先建立两个独立策略 ID，而不是测试后选择较优解释。

---

## 10. 正式准备输出

每个数据集分别生成：

```text
artifacts/formal_datasetX/
├── threshold_artifact.json
├── welch_ndt_state.npz
├── calibration_scores.npy
├── calibration_trace.csv
├── normal_calibration_audit.json
├── method_decisions.json
├── state_replay_check.json
└── calibration_threshold_trace.png
```

`calibration_trace.csv` 建议包含：

```text
index
raw_score
smoothed_score
ndt_threshold
audit_adjusted_threshold
welch_t
welch_df
welch_p
history_adjustment_factor
update_type
```

准备轨迹不包含 `label`、`point_pred`、`alarm` 或测试指标。

`threshold_artifact.json` 至少记录：

- 策略 ID、状态、论文和复现类型；
- 数据集、时间尺度与采样间隔证据；
- 模型、正常源、公共得分状态和配置 SHA-256；
- LSTM 窗口、阈值窗口和 EWMA 跨度；
- 候选网格、p 值分支、标准 Welch 自由度解释；
- `delta_mean`、`delta_std` 和所有回退规则；
- 冻结时刻的 EWMA、历史窗口、上一 NDT 阈值和下一判定阈值；
- 稳定性审计摘要与重放误差；
- 论文歧义及项目选择。

并明确写入：

```json
{
  "test_data_used": false,
  "test_labels_used": false,
  "detection_executed": false,
  "metrics_computed": false,
  "model_retrained": false
}
```

---

## 11. 不使用真实测试集的单元测试门禁

所有测试只能使用人工数组、固定随机种子合成得分和纯正常标定元数据。

1. 空数组、NaN、Inf、错误维数和非单调索引明确报错；
2. EWMA `adjust=False` 的逐点结果与参考计算一致；
3. 当前候选 EWMA 未被接纳前不能修改已冻结状态；
4. 连续区间计数正确处理单点、双点、多段和边界；
5. 式 (17) 的分子、分母和候选最大化与手算小样本一致；
6. `z` 网格端点、步长和并列时取更大阈值正确；
7. 均值为 0、标准差为 0、候选下方集合为空时明确失败；
8. Welch t 值、标准自由度和双侧 p 值与 `scipy.stats` 参考一致；
9. 两个常数窗口相同得到 `p=1`，均值不同的零方差窗口得到 `p=0`；
10. `p<=0.05` 进入 `significant_drift_recompute`；
11. `p>0.05` 进入 `stable_history_adjustment`；
12. 式 (23) 与手算值一致；
13. 式 (23) 非有限或非正时只回退到当前 `tau_ndt` 并记录；
14. 时刻 `t` 的阈值只依赖 `t-1` 及更早状态；
15. 修改未来得分不影响此前任一 EWMA、阈值或分支；
16. 合成异常点冻结 EWMA、历史窗口和阈值状态；
17. 合成正常点提交 EWMA并生成下一时刻阈值；
18. 逐点、分块和一次性合成流的结果一致；
19. 保存/加载后下一步输出逐元素一致；
20. dataset1 与 dataset2 工件不能交叉加载；
21. 模型、正常源、得分状态或配置哈希变化时拒绝正式输出；
22. 秒级稀疏 20000 窗口不能通过连续性门禁；
23. 准备脚本不存在测试文件、测试标签、检测或评价参数；
24. 合成工件只能标记 `SELF_CHECK_ONLY_NOT_FOR_RESULTS`；
25. 正式准备工件必须写入 `detection_executed=false` 和 `metrics_computed=false`。

---

## 12. 正式准备失败规则

出现以下任一情况应停止并标记 `CALIBRATION_BLOCKED` 或 `CALIBRATION_UNSTABLE`：

- 正常标签不全为 0；
- 得分为空、逆序、存在未披露缺口或包含 NaN/Inf；
- 输入空间、特征数、LSTM 窗口或 checkpoint 不匹配；
- 任一模型、数据、公共得分或配置哈希不匹配；
- 可用连续得分不足 `H+1`；
- EWMA、NDT 目标、Welch 统计量或阈值出现非有限值；
- 所有候选阈值均无效；
- 式 (23) 回退频繁且无法通过正常稳定性审计；
- 阈值为非正值或出现未解释的剧烈跳变；
- 保存/加载、逐点/分块或状态重放不一致；
- 秒级采样间隔假设未被接受或连续范围无法审计；
- 发现脚本读取了测试目录、测试标签或检测结果。

不得静默回退到固定分位数、KDE、POT、ASPOT 或其他 05 变体。需要替代方案时必须使用新
策略 ID 并独立报告。

---

## 13. 已执行的双测试集检测合同

完成准备并获得后续授权后，检测按以下固定映射执行：

```text
分钟级测试数据
-> dataset1 模型
-> dataset1 公共 Mahalanobis 状态
-> formal_dataset1 Welch-NDT 初始状态的深拷贝
-> 分钟级结果

秒级测试数据
-> dataset2 模型
-> dataset2 公共 Mahalanobis 状态
-> formal_dataset2 Welch-NDT 初始状态的深拷贝
-> 秒级结果
```

本次运行状态只写入结果目录，没有覆盖 `welch_ndt_state.npz`。动态更新可以使用当前时刻
之前的无标签测试得分，但不能：

- 使用测试标签决定是否更新；
- 用整段测试分数重新拟合候选网格或超参数；
- 根据测试指标改变 p 值分支或回退规则；
- 让当前点或未来点进入当前阈值；
- 把分钟级和秒级得分或状态混合；
- 只报告表现较好的一个时间尺度。

统一输出已分别保存：

```text
05实验结果/
├── dataset1_minute/
│   └── seedXXX/
│       ├── detections.csv
│       ├── summary.json
│       └── welch_ndt_detection.png
└── dataset2_second/
    └── seedXXX/
        ├── detections.csv
        ├── summary.json
        └── welch_ndt_detection.png
```

主实验保持 `K=1, M=1`。持续性规则另做消融，不覆盖纯阈值结果。

---

## 14. 推荐实施顺序

1. 将本文件中的论文公式、歧义解释和迁移参数复制到 `README.md` 与冻结配置；
2. 核验两套模型、正常源、00 公共得分状态和连续得分哈希；
3. 实现 `strategy_05_welch_ndt.py` 的纯函数和状态类；
4. 实现只接受正常数据的 `prepare_05_welch_ndt.py`；
5. 编写并运行全部合成公式、因果性、状态持久化和泄漏门禁测试；
6. 先生成分钟级纯正常工件并执行状态重放；
7. 再生成或复用经核验的秒级连续纯正常得分，生成秒级工件；
8. 两套工件均通过门禁后标记 `READY_FOR_TEST`；
9. 在用户后续明确授权前停止，不执行检测；获得授权后再按第 13 节合同运行。

已执行的准备命令：

```powershell
python 阈值策略\05阈值\prepare_05_welch_ndt.py `
  --dataset dataset1 `
  --config 阈值策略\05阈值\experiment_config.json `
  --output-dir 阈值策略\05阈值\artifacts\formal_dataset1
```

```powershell
python 阈值策略\05阈值\prepare_05_welch_ndt.py `
  --dataset dataset2 `
  --config 阈值策略\05阈值\experiment_config.json `
  --output-dir 阈值策略\05阈值\artifacts\formal_dataset2
```

以上命令仅处理纯正常数据，已在准备阶段执行完成；当时没有创建或运行异常检测入口。

后续授权后的正式检测命令：

```powershell
python 阈值策略\05阈值\evaluate_all_test_sets.py `
  --test-root 测试集数据 `
  --output-root 阈值策略\05阈值\05实验结果 `
  --batch-size 1024
```

该命令已完成分钟级和秒级各 5 个 seed 的检测。每个 seed 从冻结状态的独立深拷贝开始，
测试标签只用于事后评价；模型、公共 Mahalanobis 状态和阈值超参数均未在测试集上重拟合。

---

## 15. 当前验收清单

- [x] 已阅读 05 论文阈值相关全文与 Algorithm 1；
- [x] 已确认 EWMA、式 (17)-(20)、Welch 检验和式 (23)；
- [x] 已确认只迁移阈值模块，不替换联合任务 LSTM；
- [x] 已固定标准化绝对重构残差与公共 Mahalanobis 得分；
- [x] 已固定分钟级和秒级模型/正常源/工件映射；
- [x] 已识别正文与 Algorithm 1 的 p 值分支冲突；
- [x] 已识别式 (22) 的 Welch 自由度疑似排版错误；
- [x] 已给出可执行且可审计的主分支解释；
- [x] 已区分 LSTM 模型窗口与阈值统计窗口；
- [x] 已确认分钟级标定得分连续；
- [x] 已确认秒级 20000 窗口为稀疏抽样，不能用于动态初始化；
- [x] 已确定秒级连续公共得分的生成/严格复用方案；
- [x] 已设计不使用测试集的公式、因果性、状态重放和泄漏测试；
- [x] 准备阶段未读取任何测试样本或测试标签；
- [x] 准备阶段未执行异常检测或分类指标计算；
- [x] 已创建 05 策略源代码；
- [x] 已创建并冻结 `experiment_config.json`；
- [x] 已通过 20 项公式、因果性、状态重放和泄漏门禁测试；
- [x] 已生成分钟级与秒级两套 05 正式状态；
- [x] 两套工件均达到 `READY_FOR_TEST`；
- [x] 获得后续明确授权后，已执行分钟级与秒级异常检测；
- [x] 已完成两种时间尺度各 5 个 seed 的点级评价；
- [x] 已核验 10 个运行均未覆盖冻结状态、未使用标签更新策略、未在测试集重拟合。

当前状态：

```text
FORMULA_VERIFIED
INTERFACE_DEFINED
IMPLEMENTED
UNIT_TESTED
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
TESTED_BOTH_DATASETS
RESULT_FROZEN
FORMAL_STATE_UNCHANGED
```

---

## 16. 最终原则

05 与现有联合任务 LSTM 的正确融合不是重做论文的图网络，也不是更换异常得分，而是：

```text
固定联合任务 LSTM、标准化器、残差和 Mahalanobis 得分
-> 分钟级与秒级分别准备纯正常连续得分流
-> 按相同物理时长换算 EWMA 和 Welch 窗口
-> 冻结非参数阈值候选搜索
-> 冻结 p 值分支、标准 Welch 自由度和历史阈值修正
-> 保存两套可重放的动态阈值初始状态
-> 记录所有论文歧义与迁移决定
-> 准备阶段停止，等待单独授权
-> 授权后从冻结状态的深拷贝执行分钟级和秒级检测
-> 标签仅用于事后评价，运行状态与结果写入独立目录
```

只有在模型、数据、残差、得分和评价口径保持一致时，未来分钟级和秒级实验相对于
00-04 阈值方法的差异才能归因于 05 阈值策略。
