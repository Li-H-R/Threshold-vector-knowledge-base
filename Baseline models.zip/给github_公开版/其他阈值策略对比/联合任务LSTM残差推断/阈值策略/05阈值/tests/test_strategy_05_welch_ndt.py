# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
import tempfile
import unittest
import json
from pathlib import Path

import numpy as np
from scipy.stats import ttest_ind


SCRIPT_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from strategy_05_welch_ndt import (
    WelchNDTThreshold,
    count_consecutive_runs,
    ewma_series,
    historical_threshold_update,
    load_state_npz,
    ndt_objective,
    save_state_npz,
    search_ndt_threshold,
    select_next_threshold,
    welch_test,
)
from prepare_05_welch_ndt import (
    audit_indices,
    build_parser,
    reject_forbidden_path,
    validate_isolation_contract,
)


def calibration(seed: int = 17, n: int = 500) -> np.ndarray:
    rng = np.random.default_rng(seed)
    base = 4.0 + 0.25 * np.sin(np.linspace(0.0, 18.0, n))
    return np.maximum(base + rng.normal(0.0, 0.65, n), 0.05)


class FormulaTests(unittest.TestCase):
    def test_ewma_adjust_false(self):
        got = ewma_series(np.asarray([1.0, 2.0, 3.0]), span=3)
        np.testing.assert_allclose(got, [1.0, 1.5, 2.25])

    def test_consecutive_run_count(self):
        mask = np.asarray([0, 1, 1, 0, 1, 0, 1, 1, 1], dtype=bool)
        self.assertEqual(count_consecutive_runs(mask, min_length=2), 2)
        self.assertEqual(count_consecutive_runs(mask, min_length=1), 3)

    def test_ndt_objective_matches_manual_formula(self):
        values = np.asarray([1.0, 1.1, 1.2, 1.3, 3.0, 3.1])
        threshold = 2.0
        objective, details = ndt_objective(values, threshold)
        below = values[values <= threshold]
        expected = (
            (values.mean() - below.mean()) / values.mean()
            + (values.std(ddof=0) - below.std(ddof=0))
            / values.std(ddof=0)
        ) / (2 + 1 ** 2)
        self.assertAlmostEqual(objective, expected)
        self.assertEqual(int(details["exceedance_count"]), 2)
        self.assertEqual(int(details["sequence_count"]), 1)

    def test_ndt_search_returns_grid_candidate(self):
        values = ewma_series(calibration(n=120), span=3)[-60:]
        result = search_ndt_threshold(
            values,
            z_min=1.0,
            z_max_exclusive=5.0,
            z_step=0.5,
        )
        grid = np.arange(1.0, 5.0, 0.5)
        self.assertTrue(np.any(np.isclose(result.z_value, grid)))
        self.assertGreater(result.threshold, 0.0)
        self.assertGreaterEqual(result.valid_candidate_count, 1)

    def test_welch_matches_scipy(self):
        previous = np.asarray([1.0, 1.2, 1.1, 0.9, 1.4, 1.3])
        current = np.asarray([1.5, 1.7, 1.4, 1.9, 1.6, 1.8])
        got = welch_test(previous, current)
        reference = ttest_ind(current, previous, equal_var=False)
        self.assertAlmostEqual(got.statistic, float(reference.statistic))
        self.assertAlmostEqual(got.p_value, float(reference.pvalue))

    def test_welch_zero_variance_rules(self):
        same = welch_test(np.ones(10), np.ones(10))
        self.assertEqual(same.p_value, 1.0)
        shifted = welch_test(np.ones(10), np.full(10, 2.0))
        self.assertEqual(shifted.p_value, 0.0)

    def test_welch_accepts_small_positive_variance(self):
        previous = 2.0 + np.linspace(-1.0e-4, 1.0e-4, 3600)
        current = np.roll(previous, -1)
        current[-1] = 2.0
        result = welch_test(previous, current)
        self.assertTrue(np.isfinite(result.degrees_of_freedom))
        self.assertGreater(result.degrees_of_freedom, 0.0)
        self.assertTrue(0.0 <= result.p_value <= 1.0)

    def test_historical_update_matches_formula(self):
        threshold, factor, fallback = historical_threshold_update(
            previous_threshold=5.0,
            current_ndt_threshold=4.0,
            previous_mean=2.0,
            current_mean=4.0,
            previous_std=1.0,
            current_std=2.0,
            delta_mean=0.5,
            delta_std=0.5,
        )
        self.assertAlmostEqual(factor, 0.5)
        self.assertAlmostEqual(threshold, 6.5)
        self.assertFalse(fallback)

    def test_algorithm1_branch_contract(self):
        drift = select_next_threshold(
            p_value=0.01,
            alpha=0.05,
            previous_threshold=5.0,
            ndt_threshold=4.0,
            previous_mean=2.0,
            current_mean=2.1,
            previous_std=1.0,
            current_std=1.1,
            delta_mean=0.5,
            delta_std=0.5,
        )
        self.assertEqual(drift[0], 4.0)
        self.assertEqual(drift[1], "significant_drift_recompute")
        stable = select_next_threshold(
            p_value=0.5,
            alpha=0.05,
            previous_threshold=5.0,
            ndt_threshold=4.0,
            previous_mean=2.0,
            current_mean=2.1,
            previous_std=1.0,
            current_std=1.1,
            delta_mean=0.5,
            delta_std=0.5,
        )
        self.assertIn(
            stable[1],
            {
                "stable_history_adjustment",
                "fallback_ndt_invalid_history_adjustment",
            },
        )


class StrategyTests(unittest.TestCase):
    def make_strategy(self) -> WelchNDTThreshold:
        return WelchNDTThreshold(
            history_size=60,
            ewma_span=3,
            z_min=1.0,
            z_max_exclusive=8.0,
            z_step=0.5,
        ).fit(calibration())

    def test_fit_is_preparation_only(self):
        strategy = self.make_strategy()
        state = strategy.state_dict()
        self.assertEqual(state["initialization_score_count"], 500)
        self.assertEqual(state["accepted_normal_count"], 0)
        self.assertEqual(state["frozen_anomaly_count"], 0)
        self.assertEqual(strategy.trace_, [])
        self.assertEqual(len(state["smoothed_history"]), 61)
        self.assertGreater(state["threshold"], 0.0)

    def test_extreme_freezes_all_online_state(self):
        strategy = self.make_strategy()
        before = strategy.state_dict()
        output = strategy.step(1.0e6)
        after = strategy.state_dict()
        self.assertTrue(output.point_pred)
        self.assertEqual(output.update_type, "frozen_anomaly")
        for key in (
            "previous_ewma",
            "smoothed_history",
            "threshold",
            "ndt_threshold",
            "welch_p_value",
            "accepted_normal_count",
        ):
            np.testing.assert_array_equal(before[key], after[key])
        self.assertEqual(
            after["frozen_anomaly_count"],
            before["frozen_anomaly_count"] + 1,
        )

    def test_normal_commits_ewma_and_next_threshold(self):
        strategy = self.make_strategy()
        before = strategy.state_dict()
        output = strategy.step(float(before["previous_ewma"]))
        after = strategy.state_dict()
        self.assertFalse(output.point_pred)
        self.assertEqual(after["accepted_normal_count"], 1)
        self.assertTrue(np.isfinite(after["threshold"]))
        self.assertGreater(after["threshold"], 0.0)

    def test_future_changes_do_not_change_prefix(self):
        base = self.make_strategy().state_dict()
        left = WelchNDTThreshold.from_state_dict(base)
        right = WelchNDTThreshold.from_state_dict(base)
        prefix = [4.0, 4.1, 3.9]
        left_prefix = left.process(prefix)
        right_prefix = right.process(prefix)
        left.process([4.0, 4.0])
        right.process([1.0e6, 1.0e6])
        self.assertEqual(left_prefix, right_prefix)

    def test_save_load_next_step_is_exact(self):
        strategy = self.make_strategy()
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "state.npz"
            save_state_npz(path, strategy.state_dict())
            restored = WelchNDTThreshold.from_state_dict(load_state_npz(path))
        probe = 4.05
        self.assertEqual(strategy.step(probe), restored.step(probe))
        left = strategy.state_dict()
        right = restored.state_dict()
        for key in left:
            np.testing.assert_array_equal(left[key], right[key])

    def test_dataset_specific_state_cannot_be_reinterpreted_silently(self):
        state = self.make_strategy().state_dict()
        state["history_size"] = 3600
        with self.assertRaises(ValueError):
            WelchNDTThreshold.from_state_dict(state)

    def test_invalid_scores_rejected(self):
        with self.assertRaises(ValueError):
            WelchNDTThreshold(history_size=20, ewma_span=2).fit(
                np.r_[np.ones(30), np.nan]
            )


class PreparationIsolationTests(unittest.TestCase):
    def test_prepare_parser_has_no_detection_or_test_arguments(self):
        destinations = {action.dest for action in build_parser()._actions}
        self.assertEqual(
            destinations,
            {"help", "dataset", "config", "output_dir"},
        )
        self.assertNotIn("test", destinations)
        self.assertNotIn("test_labels", destinations)
        self.assertNotIn("detect", destinations)
        self.assertNotIn("evaluate", destinations)

    def test_forbidden_test_path_is_rejected(self):
        with self.assertRaises(ValueError):
            reject_forbidden_path(
                Path("测试集数据/dataset1/test_seed7.npz"), "测试"
            )

    def test_frozen_config_enforces_no_test_or_detection(self):
        with (SCRIPT_DIR / "experiment_config.json").open(
            "r", encoding="utf-8"
        ) as handle:
            config = json.load(handle)
        validate_isolation_contract(config)

    def test_audit_indices_include_final_state(self):
        self.assertEqual(audit_indices(21, history_size=10, stride=6), [11, 17, 21])


if __name__ == "__main__":
    unittest.main()
