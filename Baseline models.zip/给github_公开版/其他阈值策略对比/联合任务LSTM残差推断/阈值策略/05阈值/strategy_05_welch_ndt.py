# -*- coding: utf-8 -*-
"""05 阈值策略：EWMA 非参数动态阈值与 Welch 漂移门控。"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
from scipy.stats import t as student_t


STRATEGY_ID = "05_welch_ndt_algorithm1"
SCHEMA_VERSION = 1
EPS = 1.0e-12


def validate_scores(values: np.ndarray, *, min_samples: int = 2) -> np.ndarray:
    scores = np.asarray(values, dtype=np.float64).reshape(-1)
    if scores.size < min_samples:
        raise ValueError(f"至少需要 {min_samples} 个得分，实际 {scores.size}")
    if not np.all(np.isfinite(scores)):
        raise ValueError("得分中存在 NaN 或 Inf")
    if np.any(scores < 0.0):
        raise ValueError("公共 Mahalanobis 得分不能为负")
    return np.ascontiguousarray(scores)


def ewma_candidate(previous_ewma: float, score: float, span: int) -> float:
    if span < 1:
        raise ValueError("EWMA span 必须为正整数")
    if not np.isfinite(previous_ewma) or previous_ewma < 0.0:
        raise ValueError("previous_ewma 必须为有限非负数")
    if not np.isfinite(score) or score < 0.0:
        raise ValueError("score 必须为有限非负数")
    alpha = 2.0 / (float(span) + 1.0)
    value = (1.0 - alpha) * float(previous_ewma) + alpha * float(score)
    if not np.isfinite(value) or value < 0.0:
        raise ValueError("EWMA 产生无效值")
    return float(value)


def ewma_series(scores: np.ndarray, span: int) -> np.ndarray:
    values = validate_scores(scores, min_samples=1)
    if span < 1:
        raise ValueError("EWMA span 必须为正整数")
    result = np.empty(values.size, dtype=np.float64)
    result[0] = values[0]
    for index in range(1, values.size):
        result[index] = ewma_candidate(result[index - 1], values[index], span)
    return result


def count_consecutive_runs(mask: np.ndarray, min_length: int = 2) -> int:
    values = np.asarray(mask, dtype=bool).reshape(-1)
    if min_length < 1:
        raise ValueError("min_length 必须为正整数")
    if values.size == 0 or not np.any(values):
        return 0
    starts = np.flatnonzero(values & np.r_[True, ~values[:-1]])
    ends = np.flatnonzero(values & np.r_[~values[1:], True])
    lengths = ends - starts + 1
    return int(np.sum(lengths >= min_length))


@dataclass(frozen=True)
class NDTSearchResult:
    threshold: float
    objective: float
    z_value: float
    exceedance_count: int
    sequence_count: int
    full_mean: float
    full_std: float
    pruned_mean: float
    pruned_std: float
    valid_candidate_count: int


def ndt_objective(
    smoothed_scores: np.ndarray,
    threshold: float,
    *,
    sequence_min_length: int = 2,
) -> Tuple[float, Dict[str, float]]:
    values = validate_scores(smoothed_scores, min_samples=3)
    if not np.isfinite(threshold):
        raise ValueError("候选阈值必须为有限数")
    full_mean = float(np.mean(values))
    full_std = float(np.std(values, ddof=0))
    if full_mean <= EPS or full_std <= EPS:
        raise ValueError("NDT 历史均值或标准差接近 0")

    exceedance_mask = values > float(threshold)
    exceedance_count = int(np.sum(exceedance_mask))
    if exceedance_count == 0:
        raise ValueError("候选阈值没有超限点")
    pruned = values[~exceedance_mask]
    if pruned.size < 2:
        raise ValueError("候选阈值下方至少需要两个得分")
    pruned_mean = float(np.mean(pruned))
    pruned_std = float(np.std(pruned, ddof=0))
    sequence_count = count_consecutive_runs(
        exceedance_mask, min_length=sequence_min_length
    )
    denominator = float(exceedance_count + sequence_count * sequence_count)
    if denominator <= 0.0:
        raise ValueError("NDT 目标函数分母无效")
    objective = (
        (full_mean - pruned_mean) / full_mean
        + (full_std - pruned_std) / full_std
    ) / denominator
    if not np.isfinite(objective):
        raise ValueError("NDT 目标函数不是有限数")
    return float(objective), {
        "exceedance_count": float(exceedance_count),
        "sequence_count": float(sequence_count),
        "full_mean": full_mean,
        "full_std": full_std,
        "pruned_mean": pruned_mean,
        "pruned_std": pruned_std,
    }


def search_ndt_threshold(
    smoothed_scores: np.ndarray,
    *,
    z_min: float,
    z_max_exclusive: float,
    z_step: float,
    sequence_min_length: int = 2,
) -> NDTSearchResult:
    values = validate_scores(smoothed_scores, min_samples=3)
    if not np.isfinite(z_min) or not np.isfinite(z_max_exclusive):
        raise ValueError("z 网格边界必须为有限数")
    if z_min <= 0.0 or z_max_exclusive <= z_min:
        raise ValueError("z 网格必须满足 0 < z_min < z_max_exclusive")
    if not np.isfinite(z_step) or z_step <= 0.0:
        raise ValueError("z_step 必须为有限正数")
    if sequence_min_length < 1:
        raise ValueError("sequence_min_length 必须为正整数")

    mean = float(np.mean(values))
    std = float(np.std(values, ddof=0))
    if mean <= EPS or std <= EPS:
        raise ValueError("NDT 历史均值或标准差接近 0")

    best: Optional[NDTSearchResult] = None
    valid_candidate_count = 0
    for z_value in np.arange(z_min, z_max_exclusive, z_step, dtype=np.float64):
        threshold = mean + float(z_value) * std
        try:
            objective, details = ndt_objective(
                values,
                threshold,
                sequence_min_length=sequence_min_length,
            )
        except ValueError:
            continue
        valid_candidate_count += 1
        candidate = NDTSearchResult(
            threshold=float(threshold),
            objective=float(objective),
            z_value=float(z_value),
            exceedance_count=int(details["exceedance_count"]),
            sequence_count=int(details["sequence_count"]),
            full_mean=float(details["full_mean"]),
            full_std=float(details["full_std"]),
            pruned_mean=float(details["pruned_mean"]),
            pruned_std=float(details["pruned_std"]),
            valid_candidate_count=0,
        )
        # z 按升序遍历，>= 在目标并列时选择更大的阈值。
        if best is None or candidate.objective >= best.objective:
            best = candidate

    if best is None:
        raise ValueError("当前历史窗口没有有效 NDT 候选阈值")
    return NDTSearchResult(
        threshold=best.threshold,
        objective=best.objective,
        z_value=best.z_value,
        exceedance_count=best.exceedance_count,
        sequence_count=best.sequence_count,
        full_mean=best.full_mean,
        full_std=best.full_std,
        pruned_mean=best.pruned_mean,
        pruned_std=best.pruned_std,
        valid_candidate_count=valid_candidate_count,
    )


@dataclass(frozen=True)
class WelchResult:
    statistic: float
    degrees_of_freedom: float
    p_value: float
    previous_mean: float
    previous_std: float
    current_mean: float
    current_std: float


def welch_test(previous_window: np.ndarray, current_window: np.ndarray) -> WelchResult:
    previous = validate_scores(previous_window, min_samples=2)
    current = validate_scores(current_window, min_samples=2)
    if previous.size != current.size:
        raise ValueError("Welch 相邻窗口长度必须一致")
    n_previous = int(previous.size)
    n_current = int(current.size)
    previous_mean = float(np.mean(previous))
    current_mean = float(np.mean(current))
    previous_variance = float(np.var(previous, ddof=1))
    current_variance = float(np.var(current, ddof=1))
    previous_std = float(np.sqrt(previous_variance))
    current_std = float(np.sqrt(current_variance))

    if previous_variance <= EPS and current_variance <= EPS:
        same_mean = bool(np.isclose(
            previous_mean, current_mean, rtol=0.0, atol=EPS
        ))
        return WelchResult(
            statistic=0.0 if same_mean else (
                float("inf") if current_mean > previous_mean else float("-inf")
            ),
            degrees_of_freedom=float("inf"),
            p_value=1.0 if same_mean else 0.0,
            previous_mean=previous_mean,
            previous_std=previous_std,
            current_mean=current_mean,
            current_std=current_std,
        )

    previous_term = previous_variance / n_previous
    current_term = current_variance / n_current
    standard_error_squared = previous_term + current_term
    if standard_error_squared <= 0.0 or not np.isfinite(standard_error_squared):
        raise ValueError("Welch 标准误无效")
    statistic = (current_mean - previous_mean) / np.sqrt(standard_error_squared)
    denominator = (
        previous_term * previous_term / (n_previous - 1)
        + current_term * current_term / (n_current - 1)
    )
    # 自由度分母含方差项的平方；在长窗口、平滑序列上可以远小于
    # 通用的 1e-12 容差，但只要严格为正就是有效数值。
    if denominator <= 0.0 or not np.isfinite(denominator):
        raise ValueError("Welch 自由度分母无效")
    degrees_of_freedom = standard_error_squared * standard_error_squared / denominator
    p_value = float(2.0 * student_t.sf(abs(statistic), degrees_of_freedom))
    if (
        not np.isfinite(statistic)
        or not np.isfinite(degrees_of_freedom)
        or not np.isfinite(p_value)
        or not 0.0 <= p_value <= 1.0
    ):
        raise ValueError("Welch 检验产生无效结果")
    return WelchResult(
        statistic=float(statistic),
        degrees_of_freedom=float(degrees_of_freedom),
        p_value=p_value,
        previous_mean=previous_mean,
        previous_std=previous_std,
        current_mean=current_mean,
        current_std=current_std,
    )


def historical_threshold_update(
    previous_threshold: float,
    current_ndt_threshold: float,
    previous_mean: float,
    current_mean: float,
    previous_std: float,
    current_std: float,
    delta_mean: float,
    delta_std: float,
) -> Tuple[float, float, bool]:
    values = (
        previous_threshold,
        current_ndt_threshold,
        previous_mean,
        current_mean,
        previous_std,
        current_std,
        delta_mean,
        delta_std,
    )
    if not all(np.isfinite(value) for value in values):
        raise ValueError("历史阈值修正参数必须为有限数")
    if previous_threshold <= 0.0 or current_ndt_threshold <= 0.0:
        raise ValueError("历史阈值和 NDT 阈值必须为正")
    if previous_mean < 0.0 or previous_std < 0.0:
        raise ValueError("历史窗口均值和标准差不能为负")
    if current_mean <= EPS or current_std <= EPS:
        return float(current_ndt_threshold), float("nan"), True
    if delta_mean < 0.0 or delta_std < 0.0:
        raise ValueError("delta_mean 和 delta_std 不能为负")

    factor = (
        1.0
        - delta_mean * previous_mean / current_mean
        - delta_std * previous_std / current_std
    )
    threshold = factor * previous_threshold + current_ndt_threshold
    fallback = not np.isfinite(threshold) or threshold <= 0.0
    if fallback:
        threshold = current_ndt_threshold
    return float(threshold), float(factor), bool(fallback)


def select_next_threshold(
    *,
    p_value: float,
    alpha: float,
    previous_threshold: float,
    ndt_threshold: float,
    previous_mean: float,
    current_mean: float,
    previous_std: float,
    current_std: float,
    delta_mean: float,
    delta_std: float,
) -> Tuple[float, str, float, bool]:
    if not np.isfinite(p_value) or not 0.0 <= p_value <= 1.0:
        raise ValueError("p_value 必须位于 [0,1]")
    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha 必须位于 (0,1)")
    if p_value <= alpha:
        return (
            float(ndt_threshold),
            "significant_drift_recompute",
            0.0,
            False,
        )
    threshold, factor, fallback = historical_threshold_update(
        previous_threshold,
        ndt_threshold,
        previous_mean,
        current_mean,
        previous_std,
        current_std,
        delta_mean,
        delta_std,
    )
    return (
        threshold,
        "fallback_ndt_invalid_history_adjustment"
        if fallback else "stable_history_adjustment",
        factor,
        fallback,
    )


@dataclass(frozen=True)
class WelchNDTStepOutput:
    raw_score: float
    smoothed_score: float
    used_threshold: float
    point_pred: bool
    next_threshold: float
    next_ndt_threshold: float
    welch_p_value: float
    history_adjustment_factor: float
    update_type: str


class WelchNDTThreshold:
    """05 论文阈值模块的可冻结、严格因果迁移实现。"""

    strategy_id = STRATEGY_ID

    def __init__(
        self,
        *,
        history_size: int,
        ewma_span: int,
        z_min: float = 1.0,
        z_max_exclusive: float = 12.0,
        z_step: float = 0.5,
        sequence_min_length: int = 2,
        welch_alpha: float = 0.05,
        delta_mean: float = 0.5,
        delta_std: float = 0.5,
    ) -> None:
        if history_size < 10:
            raise ValueError("history_size 至少为 10")
        if ewma_span < 1:
            raise ValueError("ewma_span 必须为正整数")
        if not 0.0 < welch_alpha < 1.0:
            raise ValueError("welch_alpha 必须位于 (0,1)")
        if delta_mean < 0.0 or delta_std < 0.0:
            raise ValueError("delta_mean 和 delta_std 不能为负")
        # 复用搜索函数验证 z 网格的标量约束。
        if z_min <= 0.0 or z_max_exclusive <= z_min or z_step <= 0.0:
            raise ValueError("z 网格参数无效")
        if sequence_min_length < 1:
            raise ValueError("sequence_min_length 必须为正整数")

        self.history_size = int(history_size)
        self.ewma_span = int(ewma_span)
        self.z_min = float(z_min)
        self.z_max_exclusive = float(z_max_exclusive)
        self.z_step = float(z_step)
        self.sequence_min_length = int(sequence_min_length)
        self.welch_alpha = float(welch_alpha)
        self.delta_mean = float(delta_mean)
        self.delta_std = float(delta_std)

        self.previous_ewma_: Optional[float] = None
        self.smoothed_history_: Optional[deque] = None
        self.threshold_: Optional[float] = None
        self.ndt_threshold_: Optional[float] = None
        self.last_ndt_: Optional[NDTSearchResult] = None
        self.last_welch_: Optional[WelchResult] = None
        self.initialization_score_count_: int = 0
        self.accepted_normal_count_: int = 0
        self.frozen_anomaly_count_: int = 0
        self.significant_drift_count_: int = 0
        self.stable_adjustment_count_: int = 0
        self.fallback_count_: int = 0
        self.trace_: List[WelchNDTStepOutput] = []

    def _require_fit(self) -> None:
        required = (
            self.previous_ewma_,
            self.smoothed_history_,
            self.threshold_,
            self.ndt_threshold_,
            self.last_ndt_,
            self.last_welch_,
        )
        if any(value is None for value in required):
            raise RuntimeError("请先调用 fit()")

    def _window_results(self) -> Tuple[NDTSearchResult, WelchResult]:
        assert self.smoothed_history_ is not None
        history = np.asarray(self.smoothed_history_, dtype=np.float64)
        if history.size != self.history_size + 1:
            raise RuntimeError("冻结 EWMA 历史长度错误")
        previous = history[:-1]
        current = history[1:]
        ndt = search_ndt_threshold(
            current,
            z_min=self.z_min,
            z_max_exclusive=self.z_max_exclusive,
            z_step=self.z_step,
            sequence_min_length=self.sequence_min_length,
        )
        welch = welch_test(previous, current)
        return ndt, welch

    def fit(self, normal_calibration_scores: np.ndarray) -> "WelchNDTThreshold":
        scores = validate_scores(
            normal_calibration_scores, min_samples=self.history_size + 1
        )
        smoothed = ewma_series(scores, self.ewma_span)
        self.previous_ewma_ = float(smoothed[-1])
        self.smoothed_history_ = deque(
            smoothed[-(self.history_size + 1):].tolist(),
            maxlen=self.history_size + 1,
        )
        ndt, welch = self._window_results()
        self.threshold_ = float(ndt.threshold)
        self.ndt_threshold_ = float(ndt.threshold)
        self.last_ndt_ = ndt
        self.last_welch_ = welch
        self.initialization_score_count_ = int(scores.size)
        self.accepted_normal_count_ = 0
        self.frozen_anomaly_count_ = 0
        self.significant_drift_count_ = 0
        self.stable_adjustment_count_ = 0
        self.fallback_count_ = 0
        self.trace_ = []
        return self

    def step(
        self,
        score: float,
        *,
        record_trace: bool = False,
    ) -> WelchNDTStepOutput:
        self._require_fit()
        if not np.isfinite(score) or score < 0.0:
            raise ValueError("单步公共得分必须为有限非负数")
        assert self.previous_ewma_ is not None
        assert self.smoothed_history_ is not None
        assert self.threshold_ is not None
        assert self.ndt_threshold_ is not None
        assert self.last_welch_ is not None

        used_threshold = float(self.threshold_)
        candidate_ewma = ewma_candidate(
            self.previous_ewma_, float(score), self.ewma_span
        )
        point_pred = bool(candidate_ewma > used_threshold)
        if point_pred:
            self.frozen_anomaly_count_ += 1
            output = WelchNDTStepOutput(
                raw_score=float(score),
                smoothed_score=candidate_ewma,
                used_threshold=used_threshold,
                point_pred=True,
                next_threshold=used_threshold,
                next_ndt_threshold=float(self.ndt_threshold_),
                welch_p_value=float(self.last_welch_.p_value),
                history_adjustment_factor=0.0,
                update_type="frozen_anomaly",
            )
        else:
            self.previous_ewma_ = candidate_ewma
            self.smoothed_history_.append(candidate_ewma)
            ndt, welch = self._window_results()
            next_threshold, update_type, factor, fallback = select_next_threshold(
                p_value=welch.p_value,
                alpha=self.welch_alpha,
                previous_threshold=used_threshold,
                ndt_threshold=ndt.threshold,
                previous_mean=welch.previous_mean,
                current_mean=welch.current_mean,
                previous_std=welch.previous_std,
                current_std=welch.current_std,
                delta_mean=self.delta_mean,
                delta_std=self.delta_std,
            )
            self.threshold_ = float(next_threshold)
            self.ndt_threshold_ = float(ndt.threshold)
            self.last_ndt_ = ndt
            self.last_welch_ = welch
            self.accepted_normal_count_ += 1
            if update_type == "significant_drift_recompute":
                self.significant_drift_count_ += 1
            elif update_type == "stable_history_adjustment":
                self.stable_adjustment_count_ += 1
            if fallback:
                self.fallback_count_ += 1
            output = WelchNDTStepOutput(
                raw_score=float(score),
                smoothed_score=candidate_ewma,
                used_threshold=used_threshold,
                point_pred=False,
                next_threshold=float(next_threshold),
                next_ndt_threshold=float(ndt.threshold),
                welch_p_value=float(welch.p_value),
                history_adjustment_factor=float(factor),
                update_type=update_type,
            )
        if record_trace:
            self.trace_.append(output)
        return output

    def process(self, scores: Iterable[float]) -> List[WelchNDTStepOutput]:
        return [self.step(float(value)) for value in scores]

    def state_dict(self) -> Dict[str, Any]:
        self._require_fit()
        assert self.smoothed_history_ is not None
        assert self.last_ndt_ is not None
        assert self.last_welch_ is not None
        return {
            "schema_version": SCHEMA_VERSION,
            "strategy_id": STRATEGY_ID,
            "history_size": self.history_size,
            "ewma_span": self.ewma_span,
            "z_min": self.z_min,
            "z_max_exclusive": self.z_max_exclusive,
            "z_step": self.z_step,
            "sequence_min_length": self.sequence_min_length,
            "welch_alpha": self.welch_alpha,
            "delta_mean": self.delta_mean,
            "delta_std": self.delta_std,
            "previous_ewma": float(self.previous_ewma_),
            "smoothed_history": np.asarray(
                self.smoothed_history_, dtype=np.float64
            ),
            "threshold": float(self.threshold_),
            "ndt_threshold": float(self.ndt_threshold_),
            "ndt_objective": float(self.last_ndt_.objective),
            "ndt_z_value": float(self.last_ndt_.z_value),
            "ndt_exceedance_count": int(self.last_ndt_.exceedance_count),
            "ndt_sequence_count": int(self.last_ndt_.sequence_count),
            "ndt_valid_candidate_count": int(
                self.last_ndt_.valid_candidate_count
            ),
            "ndt_full_mean": float(self.last_ndt_.full_mean),
            "ndt_full_std": float(self.last_ndt_.full_std),
            "ndt_pruned_mean": float(self.last_ndt_.pruned_mean),
            "ndt_pruned_std": float(self.last_ndt_.pruned_std),
            "welch_statistic": float(self.last_welch_.statistic),
            "welch_degrees_of_freedom": float(
                self.last_welch_.degrees_of_freedom
            ),
            "welch_p_value": float(self.last_welch_.p_value),
            "welch_previous_mean": float(self.last_welch_.previous_mean),
            "welch_previous_std": float(self.last_welch_.previous_std),
            "welch_current_mean": float(self.last_welch_.current_mean),
            "welch_current_std": float(self.last_welch_.current_std),
            "initialization_score_count": int(self.initialization_score_count_),
            "accepted_normal_count": int(self.accepted_normal_count_),
            "frozen_anomaly_count": int(self.frozen_anomaly_count_),
            "significant_drift_count": int(self.significant_drift_count_),
            "stable_adjustment_count": int(self.stable_adjustment_count_),
            "fallback_count": int(self.fallback_count_),
        }

    @classmethod
    def from_state_dict(cls, state: Dict[str, Any]) -> "WelchNDTThreshold":
        def scalar(name: str) -> Any:
            value = state[name]
            return (
                value.item()
                if isinstance(value, np.ndarray) and value.ndim == 0
                else value
            )

        if int(scalar("schema_version")) != SCHEMA_VERSION:
            raise ValueError("不支持的 Welch-NDT schema_version")
        if str(scalar("strategy_id")) != STRATEGY_ID:
            raise ValueError("state 不是 05_welch_ndt_algorithm1 工件")
        obj = cls(
            history_size=int(scalar("history_size")),
            ewma_span=int(scalar("ewma_span")),
            z_min=float(scalar("z_min")),
            z_max_exclusive=float(scalar("z_max_exclusive")),
            z_step=float(scalar("z_step")),
            sequence_min_length=int(scalar("sequence_min_length")),
            welch_alpha=float(scalar("welch_alpha")),
            delta_mean=float(scalar("delta_mean")),
            delta_std=float(scalar("delta_std")),
        )
        history = validate_scores(
            np.asarray(state["smoothed_history"]),
            min_samples=obj.history_size + 1,
        )
        if history.size != obj.history_size + 1:
            raise ValueError("冻结 smoothed_history 长度错误")
        obj.previous_ewma_ = float(scalar("previous_ewma"))
        if not np.isclose(
            obj.previous_ewma_, history[-1], rtol=0.0, atol=1.0e-12
        ):
            raise ValueError("previous_ewma 与冻结历史末值不一致")
        obj.smoothed_history_ = deque(
            history.tolist(), maxlen=obj.history_size + 1
        )
        obj.threshold_ = float(scalar("threshold"))
        obj.ndt_threshold_ = float(scalar("ndt_threshold"))
        if (
            not np.isfinite(obj.threshold_)
            or not np.isfinite(obj.ndt_threshold_)
            or obj.threshold_ <= 0.0
            or obj.ndt_threshold_ <= 0.0
        ):
            raise ValueError("冻结阈值无效")
        obj.last_ndt_ = NDTSearchResult(
            threshold=obj.ndt_threshold_,
            objective=float(scalar("ndt_objective")),
            z_value=float(scalar("ndt_z_value")),
            exceedance_count=int(scalar("ndt_exceedance_count")),
            sequence_count=int(scalar("ndt_sequence_count")),
            full_mean=float(scalar("ndt_full_mean")),
            full_std=float(scalar("ndt_full_std")),
            pruned_mean=float(scalar("ndt_pruned_mean")),
            pruned_std=float(scalar("ndt_pruned_std")),
            valid_candidate_count=int(scalar("ndt_valid_candidate_count")),
        )
        obj.last_welch_ = WelchResult(
            statistic=float(scalar("welch_statistic")),
            degrees_of_freedom=float(scalar("welch_degrees_of_freedom")),
            p_value=float(scalar("welch_p_value")),
            previous_mean=float(scalar("welch_previous_mean")),
            previous_std=float(scalar("welch_previous_std")),
            current_mean=float(scalar("welch_current_mean")),
            current_std=float(scalar("welch_current_std")),
        )
        obj.initialization_score_count_ = int(
            scalar("initialization_score_count")
        )
        obj.accepted_normal_count_ = int(scalar("accepted_normal_count"))
        obj.frozen_anomaly_count_ = int(scalar("frozen_anomaly_count"))
        obj.significant_drift_count_ = int(scalar("significant_drift_count"))
        obj.stable_adjustment_count_ = int(scalar("stable_adjustment_count"))
        obj.fallback_count_ = int(scalar("fallback_count"))
        obj.trace_ = []

        rebuilt_ndt, rebuilt_welch = obj._window_results()
        frozen_ndt = obj.last_ndt_
        ndt_values = (
            frozen_ndt.threshold,
            frozen_ndt.objective,
            frozen_ndt.z_value,
            frozen_ndt.full_mean,
            frozen_ndt.full_std,
            frozen_ndt.pruned_mean,
            frozen_ndt.pruned_std,
        )
        rebuilt_ndt_values = (
            rebuilt_ndt.threshold,
            rebuilt_ndt.objective,
            rebuilt_ndt.z_value,
            rebuilt_ndt.full_mean,
            rebuilt_ndt.full_std,
            rebuilt_ndt.pruned_mean,
            rebuilt_ndt.pruned_std,
        )
        if not np.allclose(
            ndt_values, rebuilt_ndt_values, rtol=0.0, atol=1.0e-12
        ):
            raise ValueError("冻结 NDT 统计量与历史重建结果不一致")
        if (
            frozen_ndt.exceedance_count != rebuilt_ndt.exceedance_count
            or frozen_ndt.sequence_count != rebuilt_ndt.sequence_count
            or frozen_ndt.valid_candidate_count
            != rebuilt_ndt.valid_candidate_count
        ):
            raise ValueError("冻结 NDT 计数与历史重建结果不一致")
        frozen_welch = obj.last_welch_
        welch_values = (
            frozen_welch.statistic,
            frozen_welch.degrees_of_freedom,
            frozen_welch.p_value,
            frozen_welch.previous_mean,
            frozen_welch.previous_std,
            frozen_welch.current_mean,
            frozen_welch.current_std,
        )
        rebuilt_welch_values = (
            rebuilt_welch.statistic,
            rebuilt_welch.degrees_of_freedom,
            rebuilt_welch.p_value,
            rebuilt_welch.previous_mean,
            rebuilt_welch.previous_std,
            rebuilt_welch.current_mean,
            rebuilt_welch.current_std,
        )
        if not np.allclose(
            welch_values,
            rebuilt_welch_values,
            rtol=0.0,
            atol=1.0e-12,
            equal_nan=True,
        ):
            raise ValueError("冻结 Welch 统计量与历史重建结果不一致")
        return obj


def save_state_npz(path: Any, state: Dict[str, Any]) -> None:
    np.savez_compressed(path, **state)


def load_state_npz(path: Any) -> Dict[str, Any]:
    with np.load(path, allow_pickle=False) as archive:
        return {key: archive[key] for key in archive.files}
