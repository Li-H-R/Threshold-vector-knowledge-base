# 05 Welch-NDT 阈值策略

## 当前状态

```text
FORMULA_VERIFIED
INTERFACE_DEFINED
IMPLEMENTED
UNIT_TESTED
CALIBRATED_DATASET1
CALIBRATED_DATASET2
READY_FOR_TEST
TESTED_BOTH_DATASETS
RESULT_FROZEN
FORMAL_STATE_UNCHANGED
```

本目录将 05 论文的 EWMA、非参数动态阈值、Welch t 检验和历史阈值修正迁移到项目
统一的联合任务 LSTM + Mahalanobis 得分后端。这里只替换阈值策略，不更换或重训模型。

## 固定方法合同

- 策略 ID：`05_welch_ndt_algorithm1`；
- 复现类型：`threshold_module_migrated`；
- 模型窗口：10；
- 阈值历史物理时长：3600 秒；
- EWMA 物理时长：180 秒；
- 候选阈值：`mean(E) + z * std(E)`；
- 正式 `z` 网格：`[1.0, 12.0)`，步长 0.5；
- Welch：双侧、`alpha=0.05`、标准 Welch-Satterthwaite 自由度；
- p 值分支：采用论文 Algorithm 1 的解释；
- 历史修正：`delta_mean=delta_std=0.5`；
- 主实验持续性：`K=1, M=1`。

原建议的 `z_min=2.5` 在纯正常标定审计中会产生无有效候选的窗口。正式值改为 1.0：

| 数据集 | `z_min=2.5` 无效审计窗口 | `z_min=1.0` 无效审计窗口 |
|---|---:|---:|
| dataset1 | 1293 / 1900 | 0 / 1900 |
| dataset2 | 329 / 1901 | 0 / 1901 |

该修订只使用纯正常标定数据，没有使用测试样本、测试标签或测试指标。

## 文件职责

```text
strategy_05_welch_ndt.py      公式、因果在线状态与保存/恢复
prepare_05_welch_ndt.py       纯正常准备、审计和正式工件冻结
experiment_config.json        已冻结的模型、数据、参数和隔离合同
tests/                        合成公式、因果性、重放和泄漏门禁测试
artifacts/formal_dataset1/    分钟级 READY_FOR_TEST 工件
artifacts/formal_dataset2/    秒级 READY_FOR_TEST 工件
detect_05_welch_ndt.py        单测试文件因果检测与逐点结果输出
evaluate_all_test_sets.py     双时间尺度、五 seed 汇总评价
05实验结果/                   已冻结的正式检测结果与报告
```

## 验证命令

```powershell
python -m py_compile `
  阈值策略\05阈值\strategy_05_welch_ndt.py `
  阈值策略\05阈值\prepare_05_welch_ndt.py `
  阈值策略\05阈值\detect_05_welch_ndt.py `
  阈值策略\05阈值\evaluate_all_test_sets.py

python -m unittest discover -s 阈值策略\05阈值\tests -v
```

当前结果：20 项测试全部通过。

正式检测命令：

```powershell
python 阈值策略\05阈值\evaluate_all_test_sets.py `
  --test-root 测试集数据 `
  --output-root 阈值策略\05阈值\05实验结果 `
  --batch-size 1024
```

## 已执行的纯正常准备命令

```powershell
python 阈值策略\05阈值\prepare_05_welch_ndt.py `
  --dataset dataset1 `
  --config 阈值策略\05阈值\experiment_config.json `
  --output-dir 阈值策略\05阈值\artifacts\formal_dataset1
```

```powershell
python 阈值策略\05阈值\prepare_05_welch_ndt.py `
  --dataset dataset2 `
  --config 阈值策略\05阈值\experiment_config.json `
  --output-dir 阈值策略\05阈值\artifacts\formal_dataset2
```

准备脚本只接受 `dataset/config/output-dir`，没有测试文件、测试标签、检测或评价参数。

## 冻结结果

| 数据集 | 时间尺度 | 正常得分数 | `H` | EWMA span | 初始阈值 | NDT z | 状态 |
|---|---|---:|---:|---:|---:|---:|---|
| dataset1 | 分钟级 | 1960 | 60 | 3 | 2.9510115117 | 3.0 | READY_FOR_TEST |
| dataset2 | 秒级 | 117600 | 3600 | 180 | 4.6376058542 | 2.5 | READY_FOR_TEST |

两套状态的保存/加载重放最大绝对误差均为 0。正式工件明确记录：

```text
test_data_used = false
test_labels_used = false
detection_executed = false
metrics_computed = false
model_retrained = false
```

这些字段描述的是准备工件的生成过程，因此即使后续已在独立结果目录执行检测，工件中的
`detection_executed=false` 仍保持不变。检测没有覆盖正式初始状态。

## 异常检测结果

每个时间尺度使用 5 个正常抽样 seed，主实验固定 `K=1, M=1`。均值与样本标准差如下：

| 时间尺度 | Precision | Recall | F1 | PR-AUC | Specificity | 误报/1000 正常窗口 |
|---|---:|---:|---:|---:|---:|---:|
| 分钟级 | 0.5774 ± 0.0380 | 0.9704 ± 0.0168 | 0.7230 ± 0.0269 | 0.9658 ± 0.0019 | 0.2794 ± 0.1365 | 720.58 ± 136.53 |
| 秒级 | 0.9998 ± 0.0004 | 0.8351 ± 0.1153 | 0.9066 ± 0.0688 | 0.9968 ± 0.0034 | 0.9999 ± 0.0003 | 0.11 ± 0.25 |

分钟级召回很高，但误报负担过大；秒级几乎没有误报，但召回对正常抽样 seed 较敏感。
完整结果见 `05实验结果/evaluation_report.md`、`evaluation_summary.json` 和
`per_seed_metrics.csv`。

## 检测执行边界

异常检测是在用户明确授权后执行的。每个测试文件都从对应正式状态的独立深拷贝开始；
运行状态只写入各 seed 结果目录。检测未覆盖 `welch_ndt_state.npz`，未利用测试标签更新
阈值或重新选择参数，标签仅用于事后评价。

测试文件按“抽样正常块 + 固定异常块”排列，且没有真实时间戳或事件 ID。因此点级指标可用于
当前统一阈值比较，但动态轨迹不能解释为真实设备连续在线轨迹，事件延迟不作正式结论。
