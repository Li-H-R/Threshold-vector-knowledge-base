# -*- coding: utf-8 -*-
"""加载冻结的 05 Welch-NDT 状态，对一个测试文件执行因果异常检测。"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import numpy as np


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
COMMON_DIR = SCRIPT_DIR.parent / "00阈值"
for path in (PROJECT_ROOT, SCRIPT_DIR, COMMON_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from main import DATASETS, compute, load_joint  # noqa: E402
from demo.anomaly_detection_demo import (  # noqa: E402
    align_labels,
    evaluate,
    event_ranges,
    load_labels,
)
from demo.threshold_strategies import causal_k_of_m  # noqa: E402
from artifact_utils import (  # noqa: E402
    load_feature_array,
    load_optional_npz_array,
    load_score_state,
    save_json,
    sha256_file,
    transform_score,
)
from strategy_05_welch_ndt import (  # noqa: E402
    STRATEGY_ID,
    WelchNDTThreshold,
    load_state_npz,
    save_state_npz,
)


def load_artifact(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        artifact = json.load(handle)
    if artifact.get("schema_version") != 1:
        raise ValueError("不支持的 05 阈值工件 schema_version")
    if artifact.get("strategy_id") != STRATEGY_ID:
        raise ValueError("该工件不是 05_welch_ndt_algorithm1")
    if artifact.get("status") != "READY_FOR_TEST":
        raise ValueError("05 阈值工件状态不是 READY_FOR_TEST")
    if artifact.get("formal_result_allowed") is not True:
        raise ValueError("05 阈值工件不是正式纯正常标定工件")
    required_false = (
        "test_data_used",
        "test_labels_used",
        "detection_executed",
        "metrics_computed",
        "model_retrained",
    )
    for key in required_false:
        if artifact.get(key) is not False:
            raise ValueError(f"05 冻结工件隔离字段 {key} 异常")
    config_path = Path(artifact["config"]["path"]).resolve()
    if not config_path.is_file():
        raise FileNotFoundError(f"找不到 05 冻结配置：{config_path}")
    if sha256_file(config_path) != artifact["config"]["sha256"]:
        raise ValueError("05 冻结配置 SHA-256 与工件不一致")
    return artifact


def load_and_validate_strategy_state(
    artifact_path: Path,
    artifact: Dict[str, Any],
) -> WelchNDTThreshold:
    state_path = artifact_path.parent / artifact["threshold"]["state_file"]
    if not state_path.is_file():
        raise FileNotFoundError(f"找不到冻结的 Welch-NDT 状态：{state_path}")
    if sha256_file(state_path) != artifact["threshold"]["state_sha256"]:
        raise ValueError("冻结 Welch-NDT 状态 SHA-256 不一致")
    strategy = WelchNDTThreshold.from_state_dict(load_state_npz(state_path))
    state = strategy.state_dict()
    checks = {
        "threshold_window_size": "history_size",
        "ewma_span": "ewma_span",
        "z_min": "z_min",
        "z_max_exclusive": "z_max_exclusive",
        "z_step": "z_step",
        "welch_alpha": "welch_alpha",
        "delta_mean": "delta_mean",
        "delta_std": "delta_std",
        "initial_runtime_threshold": "threshold",
        "initial_ndt_threshold": "ndt_threshold",
        "initial_ndt_z_value": "ndt_z_value",
        "initial_welch_p_value": "welch_p_value",
    }
    for artifact_key, state_key in checks.items():
        if not np.isclose(
            float(artifact["threshold"][artifact_key]),
            float(state[state_key]),
            rtol=0.0,
            atol=1.0e-12,
        ):
            raise ValueError(
                f"冻结状态字段 {state_key} 与工件 {artifact_key} 不一致"
            )
    return strategy


def load_and_validate_score_state(
    artifact: Dict[str, Any], dataset: str
) -> Dict[str, np.ndarray]:
    directory = COMMON_DIR / "artifacts" / f"formal_{dataset}"
    path = directory / "score_state.npz"
    if not path.is_file():
        raise FileNotFoundError(f"找不到公共 Mahalanobis 状态：{path}")
    if sha256_file(path) != artifact["score"]["upstream_state_sha256"]:
        raise ValueError("公共 Mahalanobis score_state SHA-256 不一致")
    return load_score_state(path)


def validate_test_npz_standardizer(
    test_path: Path,
    available_keys: Sequence[str],
    test_raw: np.ndarray,
    model_mean: np.ndarray,
    model_std: np.ndarray,
) -> Dict[str, Any]:
    audit: Dict[str, Any] = {
        "mean_std_present": False,
        "mean_matches_checkpoint": None,
        "std_matches_checkpoint": None,
        "mean_max_abs_difference_from_checkpoint": None,
        "std_max_abs_difference_from_checkpoint": None,
        "x_std_present": False,
        "x_std_matches_stored_standardizer": None,
        "max_abs_x_std_internal_difference": None,
        "model_input_array": "x",
        "model_input_uses_checkpoint_standardizer": True,
        "stored_x_std_used_for_model": False,
    }
    test_mean = None
    test_std = None
    if "mean" in available_keys and "std" in available_keys:
        test_mean = load_optional_npz_array(test_path, "mean").reshape(-1)
        test_std = load_optional_npz_array(test_path, "std").reshape(-1)
        if test_mean.shape != model_mean.shape or test_std.shape != model_std.shape:
            raise ValueError("测试文件 mean/std 维数与 checkpoint 不一致")
        audit.update({
            "mean_std_present": True,
            "mean_matches_checkpoint": bool(np.allclose(
                test_mean, model_mean, rtol=1e-6, atol=1e-6
            )),
            "std_matches_checkpoint": bool(np.allclose(
                test_std, model_std, rtol=1e-6, atol=1e-6
            )),
            "mean_max_abs_difference_from_checkpoint": float(
                np.max(np.abs(test_mean - model_mean))
            ),
            "std_max_abs_difference_from_checkpoint": float(
                np.max(np.abs(test_std - model_std))
            ),
        })
    if "x_std" in available_keys:
        if test_mean is None or test_std is None:
            raise ValueError("测试文件包含 x_std，但缺少配套 mean/std")
        stored = load_optional_npz_array(test_path, "x_std").astype(np.float32)
        expected = (
            (test_raw - test_mean[None, None, :])
            / (test_std[None, None, :] + 1e-8)
        ).astype(np.float32)
        if stored.shape != expected.shape:
            raise ValueError("测试文件 x_std 与 x 的形状不一致")
        max_difference = float(np.max(np.abs(stored - expected)))
        matches = bool(np.allclose(stored, expected, rtol=1e-5, atol=1e-5))
        audit.update({
            "x_std_present": True,
            "x_std_matches_stored_standardizer": matches,
            "max_abs_x_std_internal_difference": max_difference,
        })
        if not matches:
            raise ValueError("测试文件 x_std 与其内置 mean/std 计算不一致")
    return audit


def save_plot(
    path: Path,
    raw_scores: np.ndarray,
    smoothed_scores: np.ndarray,
    thresholds: np.ndarray,
    point_pred: np.ndarray,
    labels: Optional[np.ndarray],
    dataset: str,
) -> Optional[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"
    x = np.arange(raw_scores.size)
    figure, (raw_axis, decision_axis) = plt.subplots(
        2,
        1,
        figsize=(13, 8.0),
        sharex=True,
        gridspec_kw={"height_ratios": [1.0, 1.35]},
    )
    raw_axis.plot(
        x,
        raw_scores,
        color="#6f88a6",
        linewidth=0.75,
        alpha=0.8,
        label="raw Mahalanobis score",
    )
    decision_axis.plot(
        x,
        smoothed_scores,
        color="#24496e",
        linewidth=1.0,
        label="causal EWMA score",
    )
    decision_axis.plot(
        x,
        thresholds,
        color="#d1495b",
        linewidth=1.3,
        label="05 Welch-NDT threshold",
    )
    if labels is not None:
        for start, end in event_ranges(labels):
            raw_axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.12)
            decision_axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.12)
    if np.any(point_pred):
        indices = np.flatnonzero(point_pred)
        decision_axis.scatter(
            indices,
            smoothed_scores[indices],
            s=9,
            color="#7d3c98",
            alpha=0.7,
            label="point exceedance",
        )
    raw_axis.set_ylabel("raw score")
    raw_axis.set_title(
        f"05 Welch-NDT anomaly detection ({dataset}, file order)"
    )
    raw_axis.grid(alpha=0.2)
    raw_axis.legend(loc="best")
    decision_axis.set_xlabel("test file window index")
    decision_axis.set_ylabel("EWMA / threshold")
    decision_axis.grid(alpha=0.2)
    decision_axis.legend(loc="best")
    figure.tight_layout()
    figure.savefig(path, dpi=170, bbox_inches="tight")
    plt.close(figure)
    return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="运行 05 Welch-NDT 异常检测")
    parser.add_argument("--artifact", required=True, type=Path)
    parser.add_argument("--test", required=True, type=Path)
    parser.add_argument("--labels", type=Path)
    parser.add_argument("--array-key", default="x")
    parser.add_argument("--label-key", default="y_true")
    parser.add_argument("--type-key", default="y_type")
    parser.add_argument(
        "--input-space", choices=("raw", "standardized"), default="raw"
    )
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--k", type=int, default=1)
    parser.add_argument("--m", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=1024)
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    if args.batch_size < 1:
        raise ValueError("--batch-size 必须大于 0")
    if args.k != 1 or args.m != 1:
        raise ValueError("05 主实验固定 K=1, M=1；持续性规则应另做消融")

    artifact_path = args.artifact.resolve()
    artifact = load_artifact(artifact_path)
    strategy = load_and_validate_strategy_state(artifact_path, artifact)
    frozen_state_path = artifact_path.parent / artifact["threshold"]["state_file"]
    frozen_state_hash = sha256_file(frozen_state_path)

    dataset = artifact["dataset"]
    score_state = load_and_validate_score_state(artifact, dataset)
    bundle = load_joint(dataset)
    _, mean, std, cfg = bundle
    checkpoint_path = Path(DATASETS[dataset]["ckpt"]).resolve()
    checkpoint_hash = sha256_file(checkpoint_path)
    if checkpoint_hash != artifact["model"]["checkpoint_sha256"]:
        raise ValueError("当前模型 checkpoint 与 05 阈值工件不一致")

    test_path = args.test.resolve()
    test, test_metadata = load_feature_array(test_path, args.array_key)
    if test.ndim != 3:
        raise ValueError("正式测试文件必须是三维窗口批")
    if test.shape[1] != int(DATASETS[dataset]["window_size"]):
        raise ValueError("测试窗口长度与模型不一致")
    if test.shape[2] != int(cfg["input_dim"]):
        raise ValueError("测试特征维数与模型不一致")
    if not np.all(np.isfinite(test)):
        raise ValueError("测试数组包含 NaN 或 Inf")

    available_keys = test_metadata.get("available_keys") or []
    standardizer_audit = validate_test_npz_standardizer(
        test_path, available_keys, test, mean, std
    )
    if args.input_space == "standardized":
        test_for_model = (
            test * std[None, None, :] + mean[None, None, :]
        ).astype(np.float32)
    else:
        test_for_model = test

    residual_chunks = []
    for start in range(0, test_for_model.shape[0], args.batch_size):
        end = min(start + args.batch_size, test_for_model.shape[0])
        residual = compute(
            test_for_model[start:end],
            dataset=dataset,
            absolute=True,
            standardized=True,
            model_bundle=bundle,
        )
        residual_chunks.append(residual.mean(axis=1))
    residual_mean = np.concatenate(residual_chunks, axis=0)
    raw_scores = transform_score(residual_mean, "mahalanobis", score_state)
    outputs = strategy.process(raw_scores)
    smoothed_scores = np.asarray(
        [item.smoothed_score for item in outputs], dtype=np.float64
    )
    thresholds = np.asarray(
        [item.used_threshold for item in outputs], dtype=np.float64
    )
    next_thresholds = np.asarray(
        [item.next_threshold for item in outputs], dtype=np.float64
    )
    next_ndt_thresholds = np.asarray(
        [item.next_ndt_threshold for item in outputs], dtype=np.float64
    )
    welch_p_values = np.asarray(
        [item.welch_p_value for item in outputs], dtype=np.float64
    )
    history_factors = np.asarray(
        [item.history_adjustment_factor for item in outputs], dtype=np.float64
    )
    point_pred = np.asarray([item.point_pred for item in outputs], dtype=bool)
    update_types = np.asarray([item.update_type for item in outputs], dtype=str)
    numeric_outputs = (
        raw_scores,
        smoothed_scores,
        thresholds,
        next_thresholds,
        next_ndt_thresholds,
        welch_p_values,
        history_factors,
    )
    if not all(np.all(np.isfinite(values)) for values in numeric_outputs):
        raise ValueError("05 检测输出包含 NaN 或 Inf")
    if np.any(thresholds <= 0.0):
        raise ValueError("05 检测输出包含非正阈值")
    alarm = causal_k_of_m(point_pred, k=args.k, m=args.m)

    labels = None
    if args.labels is not None:
        labels = align_labels(load_labels(args.labels), test, raw_scores.size)
    elif args.label_key in available_keys:
        labels = align_labels(
            load_optional_npz_array(test_path, args.label_key),
            test,
            raw_scores.size,
        )
    anomaly_types = None
    if args.type_key in available_keys:
        anomaly_types = load_optional_npz_array(test_path, args.type_key).reshape(-1)
        if anomaly_types.size != raw_scores.size:
            raise ValueError("异常类型数组长度与得分长度不一致")

    output_dir = args.output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"输出目录非空，拒绝覆盖检测结果：{output_dir}")
    output_dir.mkdir(parents=True, exist_ok=False)
    detections_path = output_dir / "detections.csv"
    with detections_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "index",
            "label",
            "anomaly_type",
            "raw_score",
            "smoothed_score",
            "threshold",
            "point_pred",
            "alarm",
            "next_threshold",
            "next_ndt_threshold",
            "welch_p_value",
            "history_adjustment_factor",
            "update_type",
        ])
        for index in range(raw_scores.size):
            writer.writerow([
                index,
                "" if labels is None else int(labels[index]),
                "" if anomaly_types is None else str(anomaly_types[index]),
                float(raw_scores[index]),
                float(smoothed_scores[index]),
                float(thresholds[index]),
                int(point_pred[index]),
                int(alarm[index]),
                float(next_thresholds[index]),
                float(next_ndt_thresholds[index]),
                float(welch_p_values[index]),
                float(history_factors[index]),
                str(update_types[index]),
            ])

    type_metrics = None
    if labels is not None and anomaly_types is not None:
        type_metrics = {}
        for type_name in np.unique(anomaly_types):
            mask = anomaly_types == type_name
            count = int(mask.sum())
            positive_count = int(labels[mask].sum())
            item: Dict[str, Any] = {
                "count": count,
                "positive_count": positive_count,
                "point_predicted_positive": int(point_pred[mask].sum()),
                "alarm_predicted_positive": int(alarm[mask].sum()),
            }
            if positive_count == count:
                item["point_recall"] = float(point_pred[mask].mean())
                item["alarm_recall"] = float(alarm[mask].mean())
            elif positive_count == 0:
                item["point_false_positive_rate"] = float(
                    point_pred[mask].mean()
                )
                item["alarm_false_positive_rate"] = float(alarm[mask].mean())
            type_metrics[str(type_name)] = item

    runtime_state_path = output_dir / "runtime_state_end.npz"
    runtime_state = strategy.state_dict()
    save_state_npz(runtime_state_path, runtime_state)
    decision_margin = smoothed_scores - thresholds
    label_transitions = (
        int(np.count_nonzero(np.diff(labels) != 0))
        if labels is not None and labels.size > 1
        else None
    )
    chronological_metadata = bool(
        set(available_keys)
        & {"timestamp", "timestamp_start", "timestamp_end", "event_id"}
    )
    unique_updates, update_counts = np.unique(update_types, return_counts=True)
    summary: Dict[str, Any] = {
        "strategy_id": STRATEGY_ID,
        "artifact": str(artifact_path),
        "artifact_status": artifact["status"],
        "dataset": dataset,
        "time_scale": artifact["time_scale"],
        "test_file": str(test_path),
        "test_sha256": sha256_file(test_path),
        "test_file_structure": test_metadata,
        "test_input_space": args.input_space,
        "test_input_shape": list(test.shape),
        "test_standardizer_audit": standardizer_audit,
        "num_windows": int(raw_scores.size),
        "score_method": "ledoit_wolf_mahalanobis",
        "score_state_refit_on_test": False,
        "threshold_hyperparameters_refit_on_test": False,
        "test_labels_used_by_strategy": False,
        "test_labels_used_for_evaluation_only": labels is not None,
        "frozen_state_file": str(frozen_state_path),
        "frozen_state_sha256_before": frozen_state_hash,
        "frozen_state_sha256_after": sha256_file(frozen_state_path),
        "frozen_state_unchanged": sha256_file(frozen_state_path)
        == frozen_state_hash,
        "runtime_state_file": str(runtime_state_path),
        "runtime_state_sha256": sha256_file(runtime_state_path),
        "threshold_initial": float(artifact["threshold"]["initial_runtime_threshold"]),
        "threshold": float(artifact["threshold"]["initial_runtime_threshold"]),
        "threshold_min": float(np.min(thresholds)),
        "threshold_max": float(np.max(thresholds)),
        "threshold_mean": float(np.mean(thresholds)),
        "threshold_final": float(runtime_state["threshold"]),
        "smoothed_score_min": float(np.min(smoothed_scores)),
        "smoothed_score_max": float(np.max(smoothed_scores)),
        "persistence": {"k": args.k, "m": args.m},
        "num_point_exceedances": int(point_pred.sum()),
        "num_alarms": int(alarm.sum()),
        "runtime_update_counts": {
            str(key): int(value)
            for key, value in zip(unique_updates, update_counts)
        },
        "runtime_state_counters": {
            "accepted_normal_count": int(runtime_state["accepted_normal_count"]),
            "frozen_anomaly_count": int(runtime_state["frozen_anomaly_count"]),
            "significant_drift_count": int(runtime_state["significant_drift_count"]),
            "stable_adjustment_count": int(runtime_state["stable_adjustment_count"]),
            "fallback_count": int(runtime_state["fallback_count"]),
        },
        "type_metrics": type_metrics,
        "sequence_audit": {
            "label_transitions": label_transitions,
            "chronological_or_event_metadata_available": chronological_metadata,
            "event_metrics_physically_interpretable": False,
            "note": (
                "测试文件按正常块/异常块排列且无真实时间戳或事件ID；"
                "动态阈值按文件顺序因果运行，事件延迟不作物理解释。"
            ),
        },
        "continuous_metric_basis": "smoothed_score - dynamic_threshold",
        "point_metrics": (
            evaluate(labels, point_pred, decision_margin)
            if labels is not None else None
        ),
        "alarm_metrics": (
            evaluate(labels, alarm, decision_margin)
            if labels is not None else None
        ),
        "formal_result_allowed": True,
    }
    plot_path = output_dir / "welch_ndt_detection.png"
    warning = save_plot(
        plot_path,
        raw_scores,
        smoothed_scores,
        thresholds,
        point_pred,
        labels,
        dataset,
    )
    if warning:
        summary["plot_warning"] = warning
    else:
        summary["plot"] = str(plot_path)
    save_json(output_dir / "summary.json", summary)

    print(
        f"{dataset}: 窗口={raw_scores.size}，初始阈值="
        f"{summary['threshold_initial']:.8f}，动态范围="
        f"[{summary['threshold_min']:.8f}, {summary['threshold_max']:.8f}]"
    )
    print(f"点级超限={int(point_pred.sum())}，报警={int(alarm.sum())}")
    print(f"结果：{output_dir / 'summary.json'}")
    return summary


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    return run(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
