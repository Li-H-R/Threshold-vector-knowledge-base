# 联合任务 LSTM 接入不同阈值策略：实验 Demo

完整的正式实验步骤、参数搜索和结果表模板见
[阈值策略对比实验流程.md](阈值策略对比实验流程.md)。

固定 98% 经验分位数的 `00` 基线已拆成独立的“先标定、后测试”流程，见
[../阈值策略/00阈值/README.md](../阈值策略/00阈值/README.md)。

## 1. 这个 Demo 做什么

完整链路如下：

```text
正常标定数据 ─┐
              ├─> 同一个联合任务 LSTM ─> 逐特征重构残差 ─> 统一异常得分 ─> 阈值器 fit
测试数据 ─────┘                                                └─> 异常判定
```

实验中只有“阈值器”发生变化，LSTM 权重、残差定义、异常得分和测试数据全部固定，
因此可以把性能差异归因于阈值策略，而不是模型差异。

默认异常得分为：

1. 对每个窗口的 `abs(reconstruction - input)` 沿时间维求均值，得到 `(N, D)`；
2. 只使用正常标定集拟合 Ledoit-Wolf 收缩协方差；
3. 将每个 `(D,)` 残差向量转换为 Mahalanobis 距离。

也可以通过 `--score mean` 或 `--score max_robust` 改成平均残差或最大稳健标准化残差。
一次正式阈值对比应固定 `--score`，不能为每个阈值方法单独挑最有利的得分。

## 2. 已实现的阈值策略

| 命令名 | 实现 | 实验定位 |
|---|---|---|
| `fixed` | 正常标定得分的固定经验分位数 | 项目原始基线 |
| `kde` | KDE 拟合正常得分分布，数值求 CDF 分位点 | KDE 静态非参数路线 |
| `pot` | 超过初始高分位点的尾部用 GPD 拟合，再按目标尾概率求阈值 | POT/EVT 尾部路线 |
| `rolling` | 只用当前时刻之前的高置信正常得分计算滑动分位数，超限时冻结更新 | 因果动态分位数路线 |
| `soft` | 标定每个工况的加权分位阈值，再以 `mode_w` 对工况阈值软加权 | 本项目结合联合模型提出的迁移实验 |

`soft` 的公式是：

```text
threshold[i] = sum_k(mode_w[i, k] * threshold[k])
```

它利用了当前模型已经输出的 7 维软工况概率，但不是所选论文中某一篇的原公式，
写论文时应表述为“本文设计的工况条件化阈值”。

所有方法最后统一采用因果 K-of-M 持续性规则。默认是最近 5 个点中至少 3 个点
超限才报警。程序同时保存持续性规则前的 `point_pred` 和最终 `alarm`，便于报告
误报下降与检测延迟增加之间的权衡。

## 3. 先直接运行合成演示

项目当前没有附带原始标定集和测试集，因此脚本可以自动构造平滑正常窗口，并在
测试集的三个连续区间注入异常。该数据只用于验证程序链路，不可作为论文结果。

```bash
python demo/anomaly_detection_demo.py --output-dir demo/demo_outputs
```

默认使用 `dataset2`。运行 `dataset1`：

```bash
python demo/anomaly_detection_demo.py --dataset dataset1 --output-dir demo/demo_outputs_dataset1
```

只比较部分方法或换得分：

```bash
python demo/anomaly_detection_demo.py \
  --methods fixed,kde,pot,rolling \
  --score mean \
  --quantile 0.995 \
  --output-dir demo/demo_outputs_mean
```

PowerShell 可将多行命令写成一行，或把示例里的 `\` 换成反引号。

## 4. 换成你的真实数据

至少准备两个文件：

- `normal_calibration.npy`：只含正常样本，用于得分变换和阈值标定；
- `test_windows.npy`：正常和异常混合的测试数据。

二者可以是：

- 已切好的窗口 `(N, 10, D)`；
- 一段连续时间序列 `(T, D)`，程序会按步长 1 自动切成 `T-9` 个窗口。

`dataset1` 的 `D=8`，`dataset2` 的 `D=15`。若有标签，可再提供一维 0/1
文件 `test_labels.npy`。标签既可以有 `N` 个（每个窗口一个），也可以对二维长序列
提供 `T` 个（每个原始时刻一个）；后一种情况按窗口末端时刻自动对齐。

```bash
python demo/anomaly_detection_demo.py \
  --dataset dataset2 \
  --calibration normal_calibration.npy \
  --test test_windows.npy \
  --labels test_labels.npy \
  --output-dir demo/experiment_001
```

没有标签也可以运行检测，只是不计算 Precision、Recall、F1、AUC 和事件指标。

## 5. 输出文件

每次实验输出三个文件：

- `detections.csv`：每个测试窗口的得分、每种方法的阈值、原始超限和最终报警；
- `summary.json`：参数、阈值拟合结果、点级指标、事件召回和检测延迟；
- `threshold_comparison.png`：得分与各方法阈值随时间的对比图，红色背景为已知异常区间。

POT 尾部样本不足或 KDE 退化时，程序不会静默给出不可靠结果，而是在
`summary.json` 的 `fallback` 字段记录退化为经验分位数的原因。

## 6. 正式实验建议

按时间顺序至少划分四部分：模型训练集、纯正常阈值标定集、验证集和最终测试集。
同一故障事件的重叠窗口不能随机打散到不同集合。超参数只能在验证集上选择，测试集
只用于一次最终评价。

建议的第一轮参数网格：

| 部分 | 建议值 |
|---|---|
| 固定/KDE 分位数 | 0.99、0.995、0.997 |
| POT 初始分位数 | 0.90、0.95、0.97、0.98 |
| POT 尾概率 | 0.01、0.005、0.003、0.001 |
| 动态窗口 | 按采样频率换算为 1 天、7 天、30 天 |
| 持续性规则 | 1/1、2/3、3/5、5/10 |
| 统一异常得分 | mean、max_robust、mahalanobis（作为单独消融） |

正式报告至少包括点级 Precision、Recall、F1、PR-AUC，事件级召回、检测延迟和
单位时间误报数。动态阈值还应报告冻结更新次数和阈值变化曲线。

## 7. 如何继续添加一篇论文的阈值策略

在 `demo/threshold_strategies.py` 中新增一个类，保持两个方法：

```python
class PaperThreshold:
    name = "paper_threshold"

    def fit(self, scores, mode_weights=None):
        # 只能用正常标定集 scores 学参数
        return self

    def detect(self, scores, mode_weights=None):
        # 返回与 scores 等长的 threshold 和 point_pred
        return ThresholdOutput(self.name, threshold, scores > threshold, params)
```

然后在 `demo/anomaly_detection_demo.py` 的 `ALL_METHODS` 和 `create_strategies()` 中注册。
如果论文方法需要 MC dropout、不确定性或重新训练网络，它就不再是单纯的后端阈值器；
这类方法应另外扩展模型推理接口，不能为了凑齐方法而用一个普通分位数冒充复现。

## 8. 验证

阈值器单元测试：

```bash
python -m unittest discover -s demo/tests -v
```

其中包含动态阈值的因果性检查：改变测试序列未来部分，不得影响此前任何一个时刻的
阈值或判定。

