# -*- coding: utf-8 -*-

import sys
import unittest
from pathlib import Path

import numpy as np


FIXED98_DIR = Path(__file__).resolve().parents[2] / "阈值策略" / "00阈值"
if str(FIXED98_DIR) not in sys.path:
    sys.path.insert(0, str(FIXED98_DIR))

from artifact_utils import fit_score, transform_score


class Fixed98ArtifactTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(11)
        self.normal_residual = np.abs(rng.normal(size=(200, 8)))

    def test_frozen_mahalanobis_state_reproduces_calibration_scores(self):
        fitted_scores, state = fit_score(self.normal_residual, "mahalanobis")
        loaded_scores = transform_score(self.normal_residual, "mahalanobis", state)
        np.testing.assert_allclose(fitted_scores, loaded_scores, rtol=1e-12, atol=1e-12)

    def test_fixed_threshold_is_exact_empirical_98th_percentile(self):
        scores, _ = fit_score(self.normal_residual, "mean")
        threshold = float(np.quantile(scores, 0.98))
        self.assertEqual(threshold, float(np.quantile(scores, 0.98)))
        self.assertGreaterEqual(np.mean(scores <= threshold), 0.98)


if __name__ == "__main__":
    unittest.main()

