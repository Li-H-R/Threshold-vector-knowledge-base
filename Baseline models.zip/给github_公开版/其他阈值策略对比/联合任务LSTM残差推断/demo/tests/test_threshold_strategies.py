# -*- coding: utf-8 -*-

import unittest

import numpy as np

from demo.threshold_strategies import (
    CausalRollingQuantileThreshold,
    KDEQuantileThreshold,
    POTThreshold,
    SoftConditionQuantileThreshold,
    StaticQuantileThreshold,
    causal_k_of_m,
)


class ThresholdStrategyTests(unittest.TestCase):
    def setUp(self):
        self.rng = np.random.default_rng(7)
        self.calibration = self.rng.lognormal(mean=0.0, sigma=0.25, size=500)

    def test_static_strategies_return_aligned_output(self):
        test = np.r_[np.ones(20), np.full(5, 10.0)]
        strategies = [
            StaticQuantileThreshold(0.99),
            KDEQuantileThreshold(0.99),
            POTThreshold(0.90, 0.01, min_exceedances=10),
        ]
        for strategy in strategies:
            output = strategy.fit(self.calibration).detect(test)
            self.assertEqual(output.threshold.shape, test.shape)
            self.assertEqual(output.point_pred.shape, test.shape)
            self.assertTrue(np.all(output.point_pred[-5:]))

    def test_rolling_threshold_is_causal(self):
        prefix = self.rng.lognormal(mean=0.0, sigma=0.2, size=30)
        sequence_a = np.r_[prefix, np.ones(10)]
        sequence_b = np.r_[prefix, np.full(10, 1000.0)]

        strategy_a = CausalRollingQuantileThreshold(0.95, window_size=50)
        strategy_b = CausalRollingQuantileThreshold(0.95, window_size=50)
        output_a = strategy_a.fit(self.calibration).detect(sequence_a)
        output_b = strategy_b.fit(self.calibration).detect(sequence_b)

        np.testing.assert_allclose(output_a.threshold[:30], output_b.threshold[:30])
        np.testing.assert_array_equal(output_a.point_pred[:30], output_b.point_pred[:30])

    def test_soft_condition_threshold_blends_modes(self):
        scores = np.r_[np.linspace(0.0, 1.0, 100), np.linspace(9.0, 10.0, 100)]
        modes = np.zeros((200, 2))
        modes[:100, 0] = 1.0
        modes[100:, 1] = 1.0
        strategy = SoftConditionQuantileThreshold(0.9, min_effective_weight=10)
        strategy.fit(scores, modes)

        test_modes = np.array([[1.0, 0.0], [0.5, 0.5], [0.0, 1.0]])
        output = strategy.detect(np.array([0.0, 0.0, 0.0]), test_modes)
        self.assertLess(output.threshold[0], output.threshold[1])
        self.assertLess(output.threshold[1], output.threshold[2])

    def test_causal_k_of_m(self):
        point_pred = np.array([0, 1, 0, 1, 1, 0, 0], dtype=bool)
        expected = np.array([0, 0, 0, 0, 1, 1, 0], dtype=bool)
        np.testing.assert_array_equal(causal_k_of_m(point_pred, k=3, m=5), expected)


if __name__ == "__main__":
    unittest.main()

