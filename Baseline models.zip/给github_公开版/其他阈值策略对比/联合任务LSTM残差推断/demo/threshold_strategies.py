# -*- coding: utf-8 -*-
"""可插拔异常阈值策略。

所有策略都遵循同一个接口：

1. ``fit(normal_scores, mode_weights=None)`` 只用正常标定集；
2. ``detect(test_scores, mode_weights=None)`` 返回逐点阈值和原始超限标记。

本模块不依赖具体神经网络。模型只要能产生一维异常得分，就可以复用这些
阈值器。动态方法严格按时间顺序运行，时刻 t 的阈值不使用 t 或未来的数据。
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

import numpy as np
from scipy.optimize import brentq
from scipy.stats import gaussian_kde, genpareto


EPS = 1e-12


def _as_scores(values: np.ndarray, name: str = "scores") -> np.ndarray:
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    if values.size == 0:
        raise ValueError(f"{name} 不能为空")
    if not np.all(np.isfinite(values)):
        raise ValueError(f"{name} 中存在 NaN 或 Inf")
    return values


def _as_mode_weights(values: Optional[np.ndarray], n: int) -> np.ndarray:
    if values is None:
        raise ValueError("该阈值策略需要模型输出 mode_w")
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or values.shape[0] != n:
        raise ValueError(
            f"mode_w 应为 (N, K)，且 N={n}；实际为 {values.shape}"
        )
    if not np.all(np.isfinite(values)) or np.any(values < 0):
        raise ValueError("mode_w 必须是有限的非负数")
    row_sum = values.sum(axis=1, keepdims=True)
    if np.any(row_sum <= EPS):
        raise ValueError("mode_w 至少有一行的概率和为 0")
    return values / row_sum


def weighted_quantile(
    values: np.ndarray, weights: np.ndarray, quantile: float
) -> float:
    """线性加权经验分位数。"""
    values = _as_scores(values, "values")
    weights = np.asarray(weights, dtype=np.float64).reshape(-1)
    if values.size != weights.size:
        raise ValueError("values 与 weights 长度不一致")
    if not 0.0 < quantile < 1.0:
        raise ValueError("quantile 必须位于 (0, 1)")
    if np.any(weights < 0) or not np.all(np.isfinite(weights)):
        raise ValueError("weights 必须是有限的非负数")
    total = weights.sum()
    if total <= EPS:
        raise ValueError("weights 之和必须大于 0")

    order = np.argsort(values)
    sorted_values = values[order]
    sorted_weights = weights[order]
    # 使用权重区间的中点，减少少量大权重样本造成的跳变。
    cdf = (np.cumsum(sorted_weights) - 0.5 * sorted_weights) / total
    return float(np.interp(quantile, cdf, sorted_values))


def causal_k_of_m(point_pred: np.ndarray, k: int = 3, m: int = 5) -> np.ndarray:
    """因果 K-of-M 报警：当前点及此前 M-1 点中至少 K 点超限。"""
    point_pred = np.asarray(point_pred, dtype=bool).reshape(-1)
    if m < 1 or k < 1 or k > m:
        raise ValueError("K-of-M 参数应满足 1 <= k <= m")
    cumulative = np.r_[0, np.cumsum(point_pred.astype(np.int64))]
    alarm = np.zeros(point_pred.size, dtype=bool)
    for i in range(point_pred.size):
        left = max(0, i - m + 1)
        count = cumulative[i + 1] - cumulative[left]
        alarm[i] = count >= k
    return alarm


@dataclass
class ThresholdOutput:
    """一个阈值方法在测试序列上的完整输出。"""

    name: str
    threshold: np.ndarray
    point_pred: np.ndarray
    params: Dict[str, Any] = field(default_factory=dict)


class ThresholdStrategy:
    """阈值策略最小接口。"""

    name = "base"

    def fit(
        self, scores: np.ndarray, mode_weights: Optional[np.ndarray] = None
    ) -> "ThresholdStrategy":
        raise NotImplementedError

    def detect(
        self, scores: np.ndarray, mode_weights: Optional[np.ndarray] = None
    ) -> ThresholdOutput:
        raise NotImplementedError


class StaticQuantileThreshold(ThresholdStrategy):
    """正常标定得分的固定经验分位数。"""

    name = "fixed_quantile"

    def __init__(self, quantile: float = 0.997):
        if not 0.0 < quantile < 1.0:
            raise ValueError("quantile 必须位于 (0, 1)")
        self.quantile = quantile
        self.threshold_: Optional[float] = None

    def fit(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        self.threshold_ = float(np.quantile(scores, self.quantile))
        return self

    def detect(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        if self.threshold_ is None:
            raise RuntimeError("请先调用 fit()")
        tau = np.full(scores.size, self.threshold_, dtype=np.float64)
        return ThresholdOutput(
            self.name,
            tau,
            scores > tau,
            {"quantile": self.quantile, "threshold": self.threshold_},
        )


class KDEQuantileThreshold(ThresholdStrategy):
    """KDE 拟合正常得分分布，再求其 CDF 分位点。"""

    name = "kde_quantile"

    def __init__(self, quantile: float = 0.997, bandwidth: Optional[float] = None):
        if not 0.0 < quantile < 1.0:
            raise ValueError("quantile 必须位于 (0, 1)")
        if bandwidth is not None and bandwidth <= 0:
            raise ValueError("bandwidth 必须大于 0")
        self.quantile = quantile
        self.bandwidth = bandwidth
        self.threshold_: Optional[float] = None
        self.fallback_: Optional[str] = None

    def fit(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        empirical = float(np.quantile(scores, self.quantile))
        if scores.size < 5 or np.std(scores) <= EPS:
            self.threshold_ = empirical
            self.fallback_ = "empirical_quantile_degenerate_kde"
            return self

        try:
            kde = gaussian_kde(scores, bw_method=self.bandwidth)
            spread = max(float(np.std(scores)), EPS)
            low = float(np.min(scores) - 10.0 * spread)
            high = float(np.max(scores) + 10.0 * spread)
            cdf = lambda x: kde.integrate_box_1d(-np.inf, x) - self.quantile
            self.threshold_ = float(brentq(cdf, low, high))
        except (ValueError, np.linalg.LinAlgError):
            self.threshold_ = empirical
            self.fallback_ = "empirical_quantile_kde_failure"
        return self

    def detect(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        if self.threshold_ is None:
            raise RuntimeError("请先调用 fit()")
        tau = np.full(scores.size, self.threshold_, dtype=np.float64)
        params = {
            "quantile": self.quantile,
            "bandwidth": self.bandwidth,
            "threshold": self.threshold_,
        }
        if self.fallback_:
            params["fallback"] = self.fallback_
        return ThresholdOutput(self.name, tau, scores > tau, params)


class POTThreshold(ThresholdStrategy):
    """Peaks Over Threshold：用 GPD 拟合正常得分的高尾部。"""

    name = "pot_evt"

    def __init__(
        self,
        initial_quantile: float = 0.95,
        tail_probability: float = 0.003,
        min_exceedances: int = 10,
    ):
        if not 0.5 < initial_quantile < 1.0:
            raise ValueError("initial_quantile 应位于 (0.5, 1)")
        if not 0.0 < tail_probability < 1.0:
            raise ValueError("tail_probability 必须位于 (0, 1)")
        if min_exceedances < 3:
            raise ValueError("min_exceedances 至少为 3")
        self.initial_quantile = initial_quantile
        self.tail_probability = tail_probability
        self.min_exceedances = min_exceedances
        self.threshold_: Optional[float] = None
        self.params_: Dict[str, Any] = {}

    def fit(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        u = float(np.quantile(scores, self.initial_quantile))
        exceedances = scores[scores > u] - u
        p_u = exceedances.size / scores.size
        fallback_threshold = float(np.quantile(scores, 1.0 - self.tail_probability))

        if (
            exceedances.size < self.min_exceedances
            or p_u <= self.tail_probability
            or np.std(exceedances) <= EPS
        ):
            self.threshold_ = fallback_threshold
            self.params_ = {
                "fallback": "empirical_quantile_insufficient_tail",
                "num_exceedances": int(exceedances.size),
            }
            return self

        try:
            shape, _, scale = genpareto.fit(exceedances, floc=0.0)
            conditional_cdf = 1.0 - self.tail_probability / p_u
            tail_increment = genpareto.ppf(
                conditional_cdf, c=shape, loc=0.0, scale=scale
            )
            threshold = float(u + tail_increment)
            if not np.isfinite(threshold) or threshold < u:
                raise ValueError("无效的 GPD 阈值")
            self.threshold_ = threshold
            self.params_ = {
                "shape": float(shape),
                "scale": float(scale),
                "num_exceedances": int(exceedances.size),
            }
        except (ValueError, FloatingPointError):
            self.threshold_ = fallback_threshold
            self.params_ = {
                "fallback": "empirical_quantile_gpd_failure",
                "num_exceedances": int(exceedances.size),
            }
        return self

    def detect(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        if self.threshold_ is None:
            raise RuntimeError("请先调用 fit()")
        tau = np.full(scores.size, self.threshold_, dtype=np.float64)
        params = {
            "initial_quantile": self.initial_quantile,
            "tail_probability": self.tail_probability,
            "threshold": self.threshold_,
            **self.params_,
        }
        return ThresholdOutput(self.name, tau, scores > tau, params)


class CausalRollingQuantileThreshold(ThresholdStrategy):
    """只使用历史高置信正常得分的因果滑动分位数。"""

    name = "causal_rolling_quantile"

    def __init__(
        self,
        quantile: float = 0.997,
        window_size: int = 200,
        freeze_on_exceedance: bool = True,
    ):
        if not 0.0 < quantile < 1.0:
            raise ValueError("quantile 必须位于 (0, 1)")
        if window_size < 10:
            raise ValueError("window_size 至少为 10")
        self.quantile = quantile
        self.window_size = window_size
        self.freeze_on_exceedance = freeze_on_exceedance
        self.seed_: Optional[np.ndarray] = None

    def fit(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        self.seed_ = scores[-self.window_size :].copy()
        return self

    def detect(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        if self.seed_ is None:
            raise RuntimeError("请先调用 fit()")
        history = deque(self.seed_.tolist(), maxlen=self.window_size)
        tau = np.empty(scores.size, dtype=np.float64)
        pred = np.zeros(scores.size, dtype=bool)
        updates = 0
        for i, score in enumerate(scores):
            # 先用 t 之前的历史确定阈值，再判断 t，避免把当前异常抬进阈值。
            tau[i] = float(np.quantile(np.asarray(history), self.quantile))
            pred[i] = score > tau[i]
            if not (self.freeze_on_exceedance and pred[i]):
                history.append(float(score))
                updates += 1
        return ThresholdOutput(
            self.name,
            tau,
            pred,
            {
                "quantile": self.quantile,
                "window_size": self.window_size,
                "freeze_on_exceedance": self.freeze_on_exceedance,
                "num_updates": updates,
                "num_frozen": int(scores.size - updates),
            },
        )


class SoftConditionQuantileThreshold(ThresholdStrategy):
    """用 mode_w 对各工况阈值做软加权。

    这是面向本项目联合任务模型的迁移设计，不声称是任何一篇文献的原公式。
    标定时对每个工况使用 mode_w 作为样本权重；检测时采用
    ``tau_i = sum_k mode_w[i, k] * tau_k``。
    """

    name = "soft_condition_quantile"

    def __init__(
        self,
        quantile: float = 0.997,
        min_effective_weight: float = 10.0,
    ):
        if not 0.0 < quantile < 1.0:
            raise ValueError("quantile 必须位于 (0, 1)")
        if min_effective_weight <= 0:
            raise ValueError("min_effective_weight 必须大于 0")
        self.quantile = quantile
        self.min_effective_weight = min_effective_weight
        self.mode_thresholds_: Optional[np.ndarray] = None
        self.mode_mass_: Optional[np.ndarray] = None
        self.fallback_modes_: Tuple[int, ...] = ()

    def fit(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        weights = _as_mode_weights(mode_weights, scores.size)
        global_tau = float(np.quantile(scores, self.quantile))
        thresholds = np.empty(weights.shape[1], dtype=np.float64)
        fallback_modes = []
        for k in range(weights.shape[1]):
            mass = float(weights[:, k].sum())
            if mass < self.min_effective_weight:
                thresholds[k] = global_tau
                fallback_modes.append(k)
            else:
                thresholds[k] = weighted_quantile(
                    scores, weights[:, k], self.quantile
                )
        self.mode_thresholds_ = thresholds
        self.mode_mass_ = weights.sum(axis=0)
        self.fallback_modes_ = tuple(fallback_modes)
        return self

    def detect(self, scores, mode_weights=None):
        scores = _as_scores(scores)
        weights = _as_mode_weights(mode_weights, scores.size)
        if self.mode_thresholds_ is None or self.mode_mass_ is None:
            raise RuntimeError("请先调用 fit()")
        if weights.shape[1] != self.mode_thresholds_.size:
            raise ValueError("标定集与测试集的工况数不一致")
        tau = weights @ self.mode_thresholds_
        return ThresholdOutput(
            self.name,
            tau,
            scores > tau,
            {
                "quantile": self.quantile,
                "mode_thresholds": self.mode_thresholds_.tolist(),
                "mode_effective_weights": self.mode_mass_.tolist(),
                "fallback_modes": list(self.fallback_modes_),
            },
        )

