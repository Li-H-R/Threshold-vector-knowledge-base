# -*- coding: utf-8 -*-
"""联合任务 LSTM + 多阈值策略异常检测 demo。

无参数运行会自动生成正常标定窗口、带已知异常的测试窗口，经过项目中的
LSTM-AE 提取残差，然后公平比较多种阈值策略：

- 固定经验分位数；
- KDE 分位数；
- POT/EVT；
- 因果滑动窗口分位数；
- 使用联合模型 mode_w 的软工况条件分位数。

真实数据示例：

    python demo/anomaly_detection_demo.py \
        --dataset dataset2 \
        --calibration normal_calibration.npy \
        --test test_windows.npy \
        --labels test_labels.npy \
        --output-dir demo/demo_outputs_real

标定集必须只包含正常数据。二维长序列会由 ``main.compute`` 自动滑窗；若
标签按原始时刻给出，本脚本按每个窗口的末端时刻自动对齐。
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Sequence, Tuple

import numpy as np
from sklearn.covariance import LedoitWolf
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from main import DATASETS, compute, load_joint
from demo.threshold_strategies import (
    CausalRollingQuantileThreshold,
    KDEQuantileThreshold,
    POTThreshold,
    SoftConditionQuantileThreshold,
    StaticQuantileThreshold,
    ThresholdOutput,
    causal_k_of_m,
)


ALL_METHODS = ("fixed", "kde", "pot", "rolling", "soft")


class ResidualScorer:
    """把每个窗口的逐特征残差转换为一个标量异常得分。"""

    def __init__(self, method: str = "mahalanobis"):
        if method not in {"mean", "max_robust", "mahalanobis"}:
            raise ValueError(f"未知得分方法 {method!r}")
        self.method = method
        self.center_: Optional[np.ndarray] = None
        self.scale_: Optional[np.ndarray] = None
        self.covariance_: Optional[LedoitWolf] = None

    @staticmethod
    def _check(residual: np.ndarray) -> np.ndarray:
        residual = np.asarray(residual, dtype=np.float64)
        if residual.ndim != 2 or residual.shape[0] == 0:
            raise ValueError("residual 应为非空的 (N, D) 数组")
        if not np.all(np.isfinite(residual)):
            raise ValueError("residual 中存在 NaN 或 Inf")
        return residual

    def fit(self, residual: np.ndarray) -> "ResidualScorer":
        residual = self._check(residual)
        if self.method == "max_robust":
            self.center_ = np.median(residual, axis=0)
            q25, q75 = np.quantile(residual, [0.25, 0.75], axis=0)
            scale = (q75 - q25) / 1.349
            positive_scale = scale[scale > 1e-8]
            fallback = float(np.median(positive_scale)) if positive_scale.size else 1.0
            self.scale_ = np.where(scale > 1e-8, scale, fallback)
        elif self.method == "mahalanobis":
            # 收缩协方差比普通样本协方差更适合相关、维数较高的 SCADA 残差。
            self.covariance_ = LedoitWolf().fit(residual)
        return self

    def transform(self, residual: np.ndarray) -> np.ndarray:
        residual = self._check(residual)
        if self.method == "mean":
            return residual.mean(axis=1)
        if self.method == "max_robust":
            if self.center_ is None or self.scale_ is None:
                raise RuntimeError("请先调用 fit()")
            z = (residual - self.center_) / self.scale_
            return np.max(z, axis=1)
        if self.covariance_ is None:
            raise RuntimeError("请先调用 fit()")
        squared = self.covariance_.mahalanobis(residual)
        return np.sqrt(np.maximum(squared, 0.0))

    def describe(self) -> Dict[str, Any]:
        info: Dict[str, Any] = {"method": self.method}
        if self.method == "mahalanobis" and self.covariance_ is not None:
            info["covariance_shrinkage"] = float(self.covariance_.shrinkage_)
        return info


def generate_synthetic_windows(
    mean: np.ndarray,
    std: np.ndarray,
    window_size: int,
    calibration_size: int,
    test_size: int,
    anomaly_strength: float,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """生成平滑多变量窗口，并在测试集的三段连续区间注入异常。"""
    rng = np.random.default_rng(seed)
    dim = mean.size
    latent_dim = min(3, dim)
    loading = rng.normal(size=(latent_dim, dim))
    loading /= np.maximum(np.linalg.norm(loading, axis=0, keepdims=True), 1e-8)

    def normal_windows(n: int) -> np.ndarray:
        windows = np.empty((n, window_size, dim), dtype=np.float32)
        for i in range(n):
            factors = np.empty((window_size, latent_dim), dtype=np.float64)
            factors[0] = rng.normal(0.0, 0.30, size=latent_dim)
            for t in range(1, window_size):
                factors[t] = 0.85 * factors[t - 1] + rng.normal(
                    0.0, 0.12, size=latent_dim
                )
            z = 0.45 * (factors @ loading) + rng.normal(
                0.0, 0.08, size=(window_size, dim)
            )
            z += rng.normal(0.0, 0.08, size=(1, dim))
            windows[i] = (mean + std * z).astype(np.float32)
        return windows

    calibration = normal_windows(calibration_size)
    test = normal_windows(test_size)
    labels = np.zeros(test_size, dtype=np.int64)

    event_length = max(6, test_size // 18)
    starts = [int(test_size * fraction) for fraction in (0.22, 0.52, 0.78)]
    available_features = np.arange(dim)
    feature_groups = [
        available_features[[0, min(2, dim - 1)]],
        available_features[[min(4, dim - 1), min(7, dim - 1)]],
        available_features[[min(1, dim - 1), min(10, dim - 1)]],
    ]

    standardized_test = (test - mean[None, None, :]) / (
        std[None, None, :] + 1e-8
    )
    for event_id, (start, features) in enumerate(zip(starts, feature_groups)):
        end = min(test_size, start + event_length)
        labels[start:end] = 1
        for offset, i in enumerate(range(start, end)):
            ramp = 0.65 + 0.35 * (offset + 1) / max(end - start, 1)
            sign = -1.0 if event_id == 1 else 1.0
            standardized_test[i, window_size // 2 :, features] += (
                sign * anomaly_strength * ramp
            )
            if event_id == 2:
                standardized_test[i, :, features] += rng.normal(
                    0.0,
                    anomaly_strength * 0.35,
                    size=(window_size, features.size),
                ).T
    test = (
        mean[None, None, :] + std[None, None, :] * standardized_test
    ).astype(np.float32)
    return calibration, test, labels


def load_labels(path: Path) -> np.ndarray:
    if path.suffix.lower() == ".npy":
        labels = np.load(path, allow_pickle=False)
    else:
        labels = np.loadtxt(path, delimiter="," if path.suffix.lower() == ".csv" else None)
    labels = np.asarray(labels).reshape(-1)
    if not np.all(np.isin(labels, [0, 1, False, True])):
        raise ValueError("标签必须是 0/1")
    return labels.astype(np.int64)


def align_labels(labels: np.ndarray, test_input: np.ndarray, n_windows: int) -> np.ndarray:
    labels = np.asarray(labels).reshape(-1)
    if labels.size == n_windows:
        return labels.astype(np.int64)
    if test_input.ndim == 2 and labels.size == test_input.shape[0]:
        # 一个滑窗的预测对应其末端时刻。
        return labels[-n_windows:].astype(np.int64)
    raise ValueError(
        f"标签数为 {labels.size}，但模型输出 {n_windows} 个窗口；"
        "标签应按窗口给出，或对二维长序列按原始时刻给出"
    )


def event_ranges(labels: np.ndarray) -> Iterable[Tuple[int, int]]:
    padded = np.r_[0, np.asarray(labels, dtype=np.int8), 0]
    transitions = np.diff(padded)
    starts = np.where(transitions == 1)[0]
    ends = np.where(transitions == -1)[0]
    return zip(starts.tolist(), ends.tolist())


def evaluate(
    labels: np.ndarray, pred: np.ndarray, continuous_score: np.ndarray
) -> Dict[str, Any]:
    labels = np.asarray(labels, dtype=np.int64).reshape(-1)
    pred = np.asarray(pred, dtype=np.int64).reshape(-1)
    tn, fp, fn, tp = confusion_matrix(labels, pred, labels=[0, 1]).ravel()
    metrics: Dict[str, Any] = {
        "precision": float(precision_score(labels, pred, zero_division=0)),
        "recall": float(recall_score(labels, pred, zero_division=0)),
        "f1": float(f1_score(labels, pred, zero_division=0)),
        "accuracy": float(accuracy_score(labels, pred)),
        "tp": int(tp),
        "fp": int(fp),
        "tn": int(tn),
        "fn": int(fn),
        "specificity": float(tn / max(tn + fp, 1)),
        "false_positive_rate": float(fp / max(tn + fp, 1)),
        "balanced_accuracy": float(
            0.5 * (tp / max(tp + fn, 1) + tn / max(tn + fp, 1))
        ),
        "mcc": float(matthews_corrcoef(labels, pred)),
        "false_alarms_per_1000_normal_windows": float(
            1000.0 * fp / max(tn + fp, 1)
        ),
    }
    if np.unique(labels).size == 2:
        metrics["roc_auc"] = float(roc_auc_score(labels, continuous_score))
        metrics["pr_auc"] = float(average_precision_score(labels, continuous_score))

    events = list(event_ranges(labels))
    delays = []
    for start, end in events:
        detections = np.flatnonzero(pred[start:end])
        if detections.size:
            delays.append(int(detections[0]))
    metrics["num_events"] = len(events)
    metrics["detected_events"] = len(delays)
    metrics["event_recall"] = float(len(delays) / len(events)) if events else None
    metrics["mean_detection_delay_windows"] = (
        float(np.mean(delays)) if delays else None
    )
    return metrics


def create_strategies(args: argparse.Namespace):
    strategies = {
        "fixed": StaticQuantileThreshold(args.quantile),
        "kde": KDEQuantileThreshold(args.quantile),
        "pot": POTThreshold(
            initial_quantile=args.pot_initial_quantile,
            tail_probability=args.pot_tail_probability,
            min_exceedances=args.pot_min_exceedances,
        ),
        "rolling": CausalRollingQuantileThreshold(
            quantile=args.quantile,
            window_size=args.rolling_window,
            freeze_on_exceedance=True,
        ),
        "soft": SoftConditionQuantileThreshold(
            quantile=args.quantile,
            min_effective_weight=args.min_mode_weight,
        ),
    }
    return [(key, strategies[key]) for key in args.methods]


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def write_csv(
    path: Path,
    scores: np.ndarray,
    labels: Optional[np.ndarray],
    outputs: Dict[str, ThresholdOutput],
    alarms: Dict[str, np.ndarray],
) -> None:
    fieldnames = ["index", "label", "score"]
    for key in outputs:
        fieldnames.extend(
            [f"{key}_threshold", f"{key}_point_pred", f"{key}_alarm"]
        )
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for i, score in enumerate(scores):
            row: Dict[str, Any] = {
                "index": i,
                "label": "" if labels is None else int(labels[i]),
                "score": float(score),
            }
            for key, output in outputs.items():
                row[f"{key}_threshold"] = float(output.threshold[i])
                row[f"{key}_point_pred"] = int(output.point_pred[i])
                row[f"{key}_alarm"] = int(alarms[key][i])
            writer.writerow(row)


def save_plot(
    path: Path,
    scores: np.ndarray,
    labels: Optional[np.ndarray],
    outputs: Dict[str, ThresholdOutput],
) -> Optional[str]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return "matplotlib_not_installed"

    fig, axes = plt.subplots(
        len(outputs), 1, figsize=(13, max(3.0 * len(outputs), 4.0)), sharex=True
    )
    if len(outputs) == 1:
        axes = [axes]
    x = np.arange(scores.size)
    for axis, (key, output) in zip(axes, outputs.items()):
        axis.plot(x, scores, color="#24496e", linewidth=1.1, label="anomaly score")
        axis.plot(
            x,
            output.threshold,
            color="#e56b3f",
            linewidth=1.2,
            label="threshold",
        )
        if labels is not None:
            for start, end in event_ranges(labels):
                axis.axvspan(start, end - 1, color="#d94f4f", alpha=0.14)
        axis.set_title(key)
        axis.set_ylabel("score")
        axis.grid(alpha=0.2)
        axis.legend(loc="upper right", ncol=2)
    axes[-1].set_xlabel("test window index")
    fig.tight_layout()
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return None


def print_summary(summary: Dict[str, Any]) -> None:
    print("\n阈值策略对比（K-of-M 最终报警）")
    print("-" * 82)
    print(f"{'method':<12} {'alarms':>8} {'precision':>11} {'recall':>9} {'f1':>9} {'event_R':>10}")
    print("-" * 82)
    for key, result in summary["methods"].items():
        alarm_count = result["num_alarms"]
        metrics = result.get("alarm_metrics")
        if metrics is None:
            print(f"{key:<12} {alarm_count:>8} {'-':>11} {'-':>9} {'-':>9} {'-':>10}")
        else:
            event_recall = metrics["event_recall"]
            event_text = "-" if event_recall is None else f"{event_recall:.3f}"
            print(
                f"{key:<12} {alarm_count:>8} {metrics['precision']:>11.3f} "
                f"{metrics['recall']:>9.3f} {metrics['f1']:>9.3f} {event_text:>10}"
            )
    print("-" * 82)


def parse_methods(text: str) -> Sequence[str]:
    if text.strip().lower() == "all":
        return ALL_METHODS
    methods = tuple(item.strip().lower() for item in text.split(",") if item.strip())
    unknown = sorted(set(methods) - set(ALL_METHODS))
    if unknown:
        raise argparse.ArgumentTypeError(
            f"未知方法 {unknown}；可选 {list(ALL_METHODS)} 或 all"
        )
    if not methods:
        raise argparse.ArgumentTypeError("至少选择一个阈值方法")
    return methods


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="联合任务 LSTM + 可插拔阈值策略异常检测 demo"
    )
    parser.add_argument("--dataset", choices=list(DATASETS), default="dataset2")
    parser.add_argument("--calibration", type=Path, help="纯正常标定数据 .npy")
    parser.add_argument("--test", type=Path, help="测试数据 .npy")
    parser.add_argument("--labels", type=Path, help="可选的 0/1 标签 .npy/.csv/.txt")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "demo_outputs",
    )
    parser.add_argument(
        "--score",
        choices=["mean", "max_robust", "mahalanobis"],
        default="mahalanobis",
        help="所有阈值策略共用的异常得分，默认收缩 Mahalanobis 距离",
    )
    parser.add_argument("--methods", type=parse_methods, default=ALL_METHODS)
    parser.add_argument("--quantile", type=float, default=0.997)
    parser.add_argument("--pot-initial-quantile", type=float, default=0.95)
    parser.add_argument("--pot-tail-probability", type=float, default=0.003)
    parser.add_argument("--pot-min-exceedances", type=int, default=10)
    parser.add_argument("--rolling-window", type=int, default=200)
    parser.add_argument("--min-mode-weight", type=float, default=10.0)
    parser.add_argument("--k", type=int, default=3, help="K-of-M 中的 K")
    parser.add_argument("--m", type=int, default=5, help="K-of-M 中的 M")
    parser.add_argument("--calibration-size", type=int, default=300)
    parser.add_argument("--test-size", type=int, default=300)
    parser.add_argument("--anomaly-strength", type=float, default=5.0)
    parser.add_argument("--seed", type=int, default=42)
    return parser


def run(args: argparse.Namespace) -> Dict[str, Any]:
    if (args.calibration is None) != (args.test is None):
        raise ValueError("--calibration 和 --test 必须同时提供，或都不提供")
    if args.labels is not None and args.test is None:
        raise ValueError("合成演示会自动生成标签，请不要单独指定 --labels")

    print(f"加载 {args.dataset} 联合任务 LSTM……")
    bundle = load_joint(args.dataset)
    _, mean, std, _ = bundle
    info = DATASETS[args.dataset]

    if args.calibration is None:
        source = "synthetic_demo"
        calibration, test, labels = generate_synthetic_windows(
            mean,
            std,
            info["window_size"],
            args.calibration_size,
            args.test_size,
            args.anomaly_strength,
            args.seed,
        )
        print(
            f"使用合成演示数据：标定 {calibration.shape}，测试 {test.shape}，"
            f"异常窗口 {int(labels.sum())}"
        )
    else:
        source = "user_data"
        calibration = np.load(args.calibration, allow_pickle=False).astype(np.float32)
        test = np.load(args.test, allow_pickle=False).astype(np.float32)
        labels = load_labels(args.labels) if args.labels is not None else None
        print(f"使用真实数据：标定 {calibration.shape}，测试 {test.shape}")

    print("提取标定集残差与工况概率……")
    cal_full_residual, cal_mode = compute(
        calibration,
        dataset=args.dataset,
        absolute=True,
        standardized=True,
        return_soft=True,
        model_bundle=bundle,
    )
    print("提取测试集残差与工况概率……")
    test_full_residual, test_mode = compute(
        test,
        dataset=args.dataset,
        absolute=True,
        standardized=True,
        return_soft=True,
        model_bundle=bundle,
    )
    # 与项目既有口径一致：先沿窗口时间维求均值，保留逐特征残差。
    cal_residual = cal_full_residual.mean(axis=1)
    test_residual = test_full_residual.mean(axis=1)

    if labels is not None:
        labels = align_labels(labels, test, test_residual.shape[0])

    scorer = ResidualScorer(args.score).fit(cal_residual)
    cal_scores = scorer.transform(cal_residual)
    test_scores = scorer.transform(test_residual)

    outputs: Dict[str, ThresholdOutput] = {}
    alarms: Dict[str, np.ndarray] = {}
    method_summary: Dict[str, Any] = {}
    for key, strategy in create_strategies(args):
        strategy.fit(cal_scores, cal_mode)
        output = strategy.detect(test_scores, test_mode)
        alarm = causal_k_of_m(output.point_pred, k=args.k, m=args.m)
        # 动态方法的阈值会变化；用超阈值裕量计算 AUC 才能反映该策略本身。
        decision_margin = test_scores - output.threshold
        outputs[key] = output
        alarms[key] = alarm
        method_summary[key] = {
            "implementation_name": output.name,
            "params": output.params,
            "num_point_exceedances": int(output.point_pred.sum()),
            "num_alarms": int(alarm.sum()),
            "point_metrics": (
                evaluate(labels, output.point_pred, decision_margin)
                if labels is not None
                else None
            ),
            "alarm_metrics": (
                evaluate(labels, alarm, decision_margin) if labels is not None else None
            ),
        }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.output_dir / "detections.csv"
    json_path = args.output_dir / "summary.json"
    plot_path = args.output_dir / "threshold_comparison.png"
    write_csv(csv_path, test_scores, labels, outputs, alarms)

    summary = {
        "data": {
            "source": source,
            "dataset": args.dataset,
            "calibration_input_shape": list(calibration.shape),
            "test_input_shape": list(test.shape),
            "calibration_windows": int(cal_scores.size),
            "test_windows": int(test_scores.size),
            "labels_available": labels is not None,
        },
        "residual": {
            "definition": "mean over time of abs(reconstruction - input) in standardized space",
            "feature_dimension": int(cal_residual.shape[1]),
        },
        "scorer": scorer.describe(),
        "continuous_metric_basis": "anomaly_score - method_threshold",
        "persistence": {"rule": "causal_k_of_m", "k": args.k, "m": args.m},
        "methods": method_summary,
        "artifacts": {
            "detections_csv": str(csv_path.resolve()),
            "summary_json": str(json_path.resolve()),
            "comparison_plot": str(plot_path.resolve()),
        },
    }
    plot_warning = save_plot(plot_path, test_scores, labels, outputs)
    if plot_warning:
        summary["artifacts"]["comparison_plot_warning"] = plot_warning
        summary["artifacts"]["comparison_plot"] = None
    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(json_safe(summary), handle, ensure_ascii=False, indent=2)

    print_summary(summary)
    print(f"逐点结果：{csv_path.resolve()}")
    print(f"汇总结果：{json_path.resolve()}")
    if not plot_warning:
        print(f"对比图：  {plot_path.resolve()}")
    return summary


def main(argv: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    args = build_parser().parse_args(argv)
    return run(args)


if __name__ == "__main__":
    main()

