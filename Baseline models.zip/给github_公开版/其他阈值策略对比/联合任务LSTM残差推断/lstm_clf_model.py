# -*- coding: utf-8 -*-
"""
LSTM-AE + 7 工况分类头（联合任务 / 双任务模型）—— 用于加载 joint 系列 checkpoint。

结构：
  encoder(LSTM) -> to_latent(64) -> decoder(LSTM) -> output        （重构分支）
                \-> to_latent(64) -> classifier(MLP) -> 7 维 logits（分类分支，软工况）

forward 返回 (recon, clf_logits, mode_w)，return_latent=True 时额外返回 64 维编码向量 latent。

与训练脚本 lstm_clf_model.py（条件重构模型实验/基于LSTM的新阈值实验）完全一致，
checkpoint 的 model_state_dict 含全部键（重构分支 + 分类头），本类用 strict=True 加载。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class LSTMAEClassifier(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, latent_dim=64, num_layers=4,
                 num_classes=7, dropout=0.1, clf_hidden=None):
        super().__init__()
        # ── 重构分支（模块名与 checkpoint 键严格对应）──
        self.encoder = nn.LSTM(input_dim, hidden_dim, num_layers=num_layers,
                               batch_first=True, dropout=dropout)
        self.to_latent = nn.Linear(hidden_dim, latent_dim)
        self.decoder = nn.LSTM(latent_dim, hidden_dim, num_layers=num_layers,
                               batch_first=True, dropout=dropout)
        self.output = nn.Linear(hidden_dim, input_dim)

        # ── 分类分支：接在 64 维 latent 上 ──
        clf_hidden = clf_hidden or max(latent_dim // 2, num_classes)
        self.classifier = nn.Sequential(
            nn.Linear(latent_dim, clf_hidden),
            nn.ReLU(),
            nn.Linear(clf_hidden, num_classes),
        )

    def forward(self, inputs, return_latent=False):
        T = inputs.size(1)
        _, (hidden, _) = self.encoder(inputs)
        latent = self.to_latent(hidden[-1])                     # (B, latent_dim) 编码向量
        decoded, _ = self.decoder(latent.unsqueeze(1).expand(-1, T, -1))
        recon = self.output(decoded)                            # (B, T, D)
        clf_logits = self.classifier(latent)                    # (B, num_classes)
        mode_w = F.softmax(clf_logits, dim=-1)                  # (B, num_classes) 软工况概率
        if return_latent:
            return recon, clf_logits, mode_w, latent
        return recon, clf_logits, mode_w
