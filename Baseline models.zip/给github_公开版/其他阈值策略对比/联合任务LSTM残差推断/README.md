# 联合任务 LSTM 残差推断工具

给定一段风机运行时间序列，用 **联合任务 LSTM（LSTM-AE + 7 工况分类头，双任务模型）** 做前向，输出重构残差、64 维编码向量 latent、以及 7 维软工况概率 mode_w。覆盖两个数据集各自训练好的模型（均为 **seed=10**）。

与「纯AE残差推断」的差异：本工具加载的是**带分类头的联合训练模型**，因此除残差外还能输出聚类所需的 `latent`（64 维）与 `mode_w`（7 维软工况）——这是编码层聚类 / Softmax 软向量聚类两类特征。

## 可运行的异常检测阈值对比 Demo

现在可以直接把同一个联合任务 LSTM 接到 5 种阈值策略后面，统一比较固定分位数、
KDE、POT/EVT、因果滑动分位数和基于 `mode_w` 的软工况阈值：

```bash
python demo/anomaly_detection_demo.py --output-dir demo/demo_outputs
```

无参数运行会自动生成带标签的合成演示数据；接入真实 `.npy` 标定集、测试集和标签的
命令及实验设计说明见 **[demo/异常检测Demo使用说明.md](demo/异常检测Demo使用说明.md)**。
阈值实现位于 `demo/threshold_strategies.py`，运行结果包括逐点 CSV、指标 JSON 和阈值对比图。
用于正式开展验证集选参、测试集评估和消融实验的步骤见
**[demo/阈值策略对比实验流程.md](demo/阈值策略对比实验流程.md)**。

Demo 额外依赖 `scipy`、`scikit-learn` 和 `matplotlib`：

```bash
pip install scipy scikit-learn matplotlib
```

---

## 从基模型到异常检测模型

本工具只输出「中间量」（残差 / latent / soft），**不含**异常判定。它作为**残差提取基模型**：其他论文的阈值方法只需消费它输出的**残差**，即可拼成完整异常检测模型、做公平对比。衔接方法见 **[阈值策略衔接说明.md](阈值策略衔接说明.md)**（面向新手，含完整可运行示例）。本项目自己的阈值方法（聚类 + 阈值向量）已有结果，不在该文档内。

---

## 目录结构

```
联合任务LSTM残差推断/
├── models/
│   ├── dataset1_joint_seed10.pth   # 数据集一（1 分钟级）联合任务 LSTM，seed=10
│   └── dataset2_joint_seed10.pth   # 数据集二（秒级）联合任务 LSTM，seed=10
├── lstm_clf_model.py               # LSTM-AE + 7 工况分类头网络定义
├── main.py                         # 主函数：输入时间序列 → 输出残差/latent/软工况
└── README.md
```

---

## 两个数据集

| 数据集 | 时间分辨率 | 窗口长度 T | 特征维 D | 模型 | 输入原始数据 |
| --- | --- | --- | --- | --- | --- |
| `dataset1` | 1 分钟级 | 10 | 8 | `dataset1_joint_seed10.pth` | `raw_data.npy`（去掉最后 2 列非特征列） |
| `dataset2` | 秒级 | 10 | 15 | `dataset2_joint_seed10.pth` | `new_raw_data.npy`（全部 15 列） |

两个模型的网络结构完全一致：

```
encoder(LSTM, input_dim→128, 4 层) → to_latent(64)
   ├─ decoder(LSTM, 64→128, 4 层) → output(128→input_dim)   （重构分支）
   └─ classifier(MLP, 64→32→7) → softmax → 7 维软工况概率    （分类分支）
```

> checkpoint 内同时保存了 `model_config`（网络超参）与 `standardizer`（mean/std），
> 加载时无需外部配置。模型为联合训练（Loss = λ_rec·MSE + λ_clf·CrossEntropy），
> 由 `lstm_encoder_best.pth` 热启动重构分支后联合微调 60 epoch。

---

## 模型来源（seed=10）

| 目标模型 | 源 checkpoint（已复制） | 说明 |
| --- | --- | --- |
| `dataset1_joint_seed10.pth` | `条件重构模型实验/模型消融实验/clf_best_seed10.pth` | 数据集一（分钟级，8 维，`raw_data.npy`，`new_format=False`） |
| `dataset2_joint_seed10.pth` | `条件重构模型实验_new/模型消融实验/clf_best_seed10.pth` | 数据集二（秒级，15 维，`new_raw_data.npy`，`new_format=True`） |

两者均由 `模型消融实验/run_ablation.py` 的 `train_classifier(seed=10)` 训练：
过采样平衡、热启动 + 联合微调 60 epoch、`λ_rec=λ_clf=1.0`，仅训练数据不同。
seed 语义：控制初始化 / 过采样 / 划分（KMeans 与测试集抽样用固定 seed 42）。

---

## 环境

- Python 3 + `torch`（≥2.0）+ `numpy`
- 无 GPU 也可运行（自动回落到 CPU）

```bash
pip install torch numpy
```

---

## 用法

### 1. 命令行

```bash
# 数据集二（15 维），读入 .npy 时间序列，打印残差形状
python main.py --dataset dataset2 --input 输入序列.npy

# 同时保存残差，并输出时间维均值残差（逐特征）
python main.py --dataset dataset2 --input 输入序列.npy --output 残差.npy --mean 1

# 额外输出 64 维编码向量 latent 与 7 维软工况 mode_w（聚类特征）
python main.py --dataset dataset2 --input 输入序列.npy --latent 1 --soft 1

# 数据集一（8 维），残差回到原始量纲
python main.py --dataset dataset1 --input 输入序列.npy --standardized 0

# 无 --input 时用随机窗口演示链路
python main.py --dataset dataset2
```

参数说明：

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `--dataset` | `dataset2` | `dataset1`（8 维）/ `dataset2`（15 维） |
| `--input` | 空 | 输入时间序列 `.npy`，形状 `(T, D)` 或 `(B, T, D)` |
| `--output` | 空 | 残差保存路径（可选） |
| `--absolute` | `1` | `1` 返回 `|recon-x|`；`0` 返回 `recon-x` |
| `--standardized` | `1` | `1` 残差在标准化空间；`0` 反标准化回原始量纲 |
| `--mean` | `0` | `1` 额外打印时间维均值残差 `(N, D)` |
| `--latent` | `0` | `1` 额外打印 64 维编码向量 latent `(N, 64)` |
| `--soft` | `0` | `1` 额外打印 7 维软工况概率 mode_w `(N, 7)` |

### 2. Python 调用

```python
import numpy as np
from main import load_joint, compute_residual, compute_latent, compute_soft, residual_mean

# 方式 A：一段长序列 (T, 15)，自动按 stride=1 滑窗
x = np.load("你的时间序列.npy")            # (T, 15) float32
residual = compute_residual(x, dataset="dataset2")
# residual: (T-9, 10, 15)  逐窗口逐时刻逐特征的 |recon-x|

# 方式 B：直接给窗口批 (B, 10, 15)
x_win = np.random.randn(32, 10, 15).astype(np.float32)
residual = compute_residual(x_win, dataset="dataset2")

# 聚类特征（联合任务模型独有）
latent = compute_latent(x_win, dataset="dataset2")   # (32, 64)  编码层聚类特征
soft   = compute_soft(x_win, dataset="dataset2")     # (32, 7)   Softmax 软向量聚类特征

# 阈值检测实际参与判定的量：时间维均值残差 (N, D)
m = residual_mean(x, dataset="dataset2")

# 一次前向拿全部产物：残差 + latent + soft
residual, latent, soft = compute(x_win, dataset="dataset2", return_latent=True, return_soft=True)
```

---

## 输入 / 输出约定

**输入**

- 二维 `(T, D)`：视为一段连续时间序列，`T ≥ 10` 时按 `stride=1` 滑成
  `(T-9, 10, D)` 个窗口；`T = 10` 即单窗口。
- 三维 `(B, T, D)`：视为已切好的窗口批，第二维必须等于 `10`。
- 特征维 `D` 必须与数据集匹配：`dataset1` → 8，`dataset2` → 15。

**输出**

- `residual`：形状 `(N, 10, D)` 的 `float32` 数组。
  默认 `absolute=True, standardized=True`，即
  `residual = |recon(x_std) - x_std|`，**残差在标准化空间**（`(x - mean)/std` 之后的空间），
  与阈值消融实验里 `torch.abs(recon - x)` 的口径一致——阈值库就是在这个空间用
  98 分位建立的，故默认返回该空间便于直接对照。
- `latent`：形状 `(N, 64)` 的 `float32` 编码向量（编码层聚类特征）。
- `soft`：形状 `(N, 7)` 的 `float32` 软工况概率（Softmax 软向量聚类特征）。

---

## 说明

- 加载时使用 `strict=True`：checkpoint 含重构分支 + 分类头的全部权重，与
  `lstm_clf_model.LSTMAEClassifier` 的键一一对应。
- 标准化器（mean/std）随 checkpoint 一起加载，无需外部提供。
- `latent` / `soft` 与残差来自**同一次前向**（同一 encoder、同一 latent），
  与阈值消融实验「同一模型、同一前向」的对照口径一致。
