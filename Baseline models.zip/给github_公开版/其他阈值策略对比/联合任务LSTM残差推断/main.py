# -*- coding: utf-8 -*-
"""
联合任务 LSTM 残差推断工具（数据集一 / 数据集二）

给定一段风机运行时间序列，用对应数据集下训练好的联合任务 LSTM
（LSTM-AE + 7 工况分类头，seed=10）做前向，输出：
  - 重构残差（默认 |recon - x|，与阈值检测口径一致）
  - 编码向量 latent（64 维，用于编码层聚类）
  - 软工况概率 mode_w（7 维，用于 Softmax 软向量聚类）

两个数据集（窗口长度均为 10，特征维不同）：
  - dataset1（数据集一，1 分钟级）：input_dim = 8
  - dataset2（数据集二，秒级）      ：input_dim = 15

命令行用法：
  python main.py --dataset dataset2 --input 输入.npy [--output 残差.npy]
  python main.py --dataset dataset2 --input 输入.npy --latent 1 --soft 1
  python main.py --dataset dataset1                       # 无输入时用随机窗口演示

Python 用法：
  from main import load_joint, compute_residual, compute_latent, compute_soft, residual_mean
  residual = compute_residual(x, dataset="dataset2")     # x: (T,D) 或 (B,T,D)
  latent   = compute_latent(x, dataset="dataset2")       # (N, 64)
  soft     = compute_soft(x, dataset="dataset2")         # (N, 7)
"""

import os
import argparse

import numpy as np
import torch

from lstm_clf_model import LSTMAEClassifier


HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(HERE, "models")

# 两个数据集模型与输入配置（与训练脚本一致）
DATASETS = {
    "dataset1": {
        "ckpt": os.path.join(MODEL_DIR, "dataset1_joint_seed10.pth"),
        "window_size": 10,
        "input_dim": 8,
        "desc": "数据集一（1 分钟级，8 维特征）",
    },
    "dataset2": {
        "ckpt": os.path.join(MODEL_DIR, "dataset2_joint_seed10.pth"),
        "window_size": 10,
        "input_dim": 15,
        "desc": "数据集二（秒级，15 维特征）",
    },
}

_DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_joint(dataset="dataset2", device=None):
    """加载联合任务 LSTM 模型与标准化器。

    返回 (model, mean, std, cfg)，其中：
      model : LSTMAEClassifier（已 eval）
      mean/std : (input_dim,) float32，标准化器（来自 checkpoint 的 standardizer）
      cfg   : 模型配置 dict（input_dim / num_classes / hidden_dim / latent_dim /
              num_layers / dropout）
    """
    if dataset not in DATASETS:
        raise ValueError(f"未知数据集 {dataset!r}，可选 {list(DATASETS)}")
    device = device or _DEVICE
    ckpt = torch.load(DATASETS[dataset]["ckpt"], map_location=device, weights_only=False)
    cfg = ckpt["model_config"]
    model = LSTMAEClassifier(
        input_dim=cfg["input_dim"],
        hidden_dim=cfg.get("hidden_dim", 128),
        latent_dim=cfg.get("latent_dim", 64),
        num_layers=cfg.get("num_layers", 4),
        dropout=cfg.get("dropout", 0.1),
        num_classes=cfg.get("num_classes", 7),
    ).to(device)
    model.load_state_dict(ckpt["model_state_dict"], strict=True)
    model.eval()
    mean = np.asarray(ckpt["standardizer"]["mean"], dtype=np.float32)
    std = np.asarray(ckpt["standardizer"]["std"], dtype=np.float32)
    return model, mean, std, cfg


def _to_windows(x, window_size):
    """把输入统一成 (N, window_size, D) 的窗口批。

    - (T, D)  长序列：按 stride=1 滑窗切为 (T-window_size+1, window_size, D)
    - (B, T, D) 窗口批：原样返回（第二维须等于 window_size）
    """
    x = np.asarray(x, dtype=np.float32)
    if x.ndim == 2:
        T, D = x.shape
        if T < window_size:
            raise ValueError(f"时间序列长度 {T} 小于窗口 {window_size}，无法切窗")
        idx = np.arange(window_size)[None, :] + np.arange(T - window_size + 1)[:, None]
        return np.ascontiguousarray(x[idx])                       # (N, window_size, D)
    if x.ndim == 3:
        if x.shape[1] != window_size:
            raise ValueError(f"输入第二维应为窗口长度 {window_size}，实际 {x.shape[1]}")
        return np.ascontiguousarray(x)
    raise ValueError(f"输入应为 (T,D) 或 (B,T,D)，实际 shape {x.shape}")


def compute(x, dataset="dataset2", absolute=True, standardized=True,
            return_recon=False, return_latent=False, return_soft=False, device=None,
            model_bundle=None):
    """输入时间序列 -> 联合任务模型前向产物（单次前向，一次算完）。

    参数
      x            : (T, D) 长序列（自动滑窗）或 (B, T, D) 窗口批，float32/float64 均可
      dataset      : "dataset1"（8 维）或 "dataset2"（15 维）
      absolute     : True 返回 |recon - x|（默认，与阈值检测口径一致）；False 返回 recon - x
      standardized : True 残差在标准化空间（默认，阈值就是在这个空间建的）；
                     False 时先把重构反标准化回原始量纲再求残差
      return_recon : True 额外返回 recon
      return_latent: True 额外返回 64 维编码向量 latent (N, 64)
      return_soft  : True 额外返回 7 维软工况概率 mode_w (N, 7)
      model_bundle : 可选的 ``load_joint()`` 返回值。批量实验可只加载一次模型，
                     再对标定集和测试集分别前向

    返回
      至少返回 residual (N, window_size, D) float32 数组；
      开启开关时按 [residual, recon, latent, soft] 顺序返回元组。
    """
    if model_bundle is None:
        model, mean, std, cfg = load_joint(dataset, device=device)
    else:
        if len(model_bundle) != 4:
            raise ValueError("model_bundle 应为 load_joint() 返回的四元组")
        model, mean, std, cfg = model_bundle
    window_size = DATASETS[dataset]["window_size"]
    D = cfg["input_dim"]

    win = _to_windows(x, window_size)                              # (N, T, D)
    if win.shape[-1] != D:
        raise ValueError(f"输入特征维 {win.shape[-1]} 与 {dataset} 的 input_dim={D} 不符")

    x_std = (win - mean[None, None, :]) / (std[None, None, :] + 1e-8)

    dev = next(model.parameters()).device
    with torch.no_grad():
        xt = torch.from_numpy(x_std.astype(np.float32)).to(dev)
        recon, _, mode_w, latent = model(xt, return_latent=True)
        recon_np = recon.cpu().numpy()                             # 标准化空间重构
        latent_np = latent.cpu().numpy()
        soft_np = mode_w.cpu().numpy()

    if standardized:
        recon_out = recon_np
        x_out = x_std
    else:
        recon_out = recon_np * std[None, None, :] + mean[None, None, :]
        x_out = win

    residual = np.abs(recon_out - x_out) if absolute else (recon_out - x_out)
    residual = residual.astype(np.float32)

    out = [residual]
    if return_recon:
        out.append(recon_out.astype(np.float32))
    if return_latent:
        out.append(latent_np.astype(np.float32))
    if return_soft:
        out.append(soft_np.astype(np.float32))
    return tuple(out) if len(out) > 1 else out[0]


def compute_residual(x, dataset="dataset2", absolute=True, standardized=True, device=None):
    """返回重构残差 (N, window_size, D)。"""
    return compute(x, dataset=dataset, absolute=absolute, standardized=standardized, device=device)


def compute_latent(x, dataset="dataset2", device=None):
    """返回编码层向量 latent (N, 64)（编码层聚类用）。"""
    return compute(x, dataset=dataset, return_latent=True, device=device)[1]


def compute_soft(x, dataset="dataset2", device=None):
    """返回软工况概率 mode_w (N, 7)（Softmax 软向量聚类用）。"""
    return compute(x, dataset=dataset, return_soft=True, device=device)[1]


def residual_mean(x, dataset="dataset2", device=None):
    """返回逐窗口逐特征的「时间维均值残差」mean_t(|recon-x|)_d，形状 (N, D)。

    这是阈值检测里实际参与判定的量（对应 common.py 的 mean_res）。
    """
    r = compute_residual(x, dataset=dataset, absolute=True, standardized=True, device=device)
    return r.mean(axis=1)                                          # (N, D)


def main(argv=None):
    ap = argparse.ArgumentParser(description="联合任务 LSTM 残差推断（数据集一 / 数据集二）")
    ap.add_argument("--dataset", type=str, default="dataset2", choices=list(DATASETS),
                    help="数据集：dataset1（8 维）/ dataset2（15 维），默认 dataset2")
    ap.add_argument("--input", type=str, default="", help="输入时间序列 .npy，形状 (T,D) 或 (B,T,D)")
    ap.add_argument("--output", type=str, default="", help="可选，残差输出 .npy 路径")
    ap.add_argument("--absolute", type=int, default=1, help="1=返回 |recon-x|（默认），0=返回 recon-x")
    ap.add_argument("--standardized", type=int, default=1, help="1=标准化空间残差（默认），0=原始量纲")
    ap.add_argument("--mean", type=int, default=0, help="1=额外输出时间维均值残差 (N,D)")
    ap.add_argument("--latent", type=int, default=0, help="1=额外输出编码向量 latent (N,64)")
    ap.add_argument("--soft", type=int, default=0, help="1=额外输出软工况概率 mode_w (N,7)")
    args = ap.parse_args(argv)

    dataset = args.dataset
    info = DATASETS[dataset]
    print(f"数据集：{info['desc']}  |  窗口长度={info['window_size']}  |  联合任务 LSTM（seed=10）")

    # 准备输入
    if args.input:
        x = np.load(args.input, allow_pickle=False).astype(np.float32)
        print(f"输入时间序列：{x.shape}")
    else:
        rng = np.random.default_rng(0)
        x = rng.normal(0, 1, size=(info["window_size"], info["input_dim"])).astype(np.float32)
        print(f"未提供 --input，使用随机演示窗口 shape={x.shape}")

    out = compute(
        x, dataset=dataset,
        absolute=bool(args.absolute),
        standardized=bool(args.standardized),
        return_recon=False,
        return_latent=bool(args.latent),
        return_soft=bool(args.soft),
    )
    residual = out[0] if isinstance(out, tuple) else out
    print(f"残差输出：{residual.shape}  |  绝对值={'是' if args.absolute else '否'}  "
          f"|  空间={'标准化' if args.standardized else '原始量纲'}")

    if args.latent:
        print(f"编码向量 latent：{out[1].shape}")
    if args.soft:
        soft = out[-1]
        print(f"软工况概率 mode_w：{soft.shape}")
        print("软工况示例（第一个窗口，7 工况概率）:", np.round(soft[0], 4).tolist())
    if args.mean:
        m = residual.mean(axis=1)
        print(f"时间维均值残差：{m.shape}")
        print("均值残差示例（第一个窗口，逐特征）:", np.round(m[0], 4).tolist())

    if args.output:
        np.save(args.output, residual)
        print(f"已保存残差到：{args.output}")
    return residual


if __name__ == "__main__":
    main()
