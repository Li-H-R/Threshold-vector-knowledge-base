# -*- coding: utf-8 -*-
"""
RESCINet —— 门控残差 SCI 交互 + 分层残差修正 + 共形自适应门限 训练脚本
========================================================================
方法来源：Cao et al., MSSP 2026，多源不确定性感知分层 RESCINet 残差修正模型
（风电机组状态监测）。

方法要点（保留原文完整阈值策略）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 骨干 = 逐块堆叠的 RE-SCIBlock：奇数/偶数子序列拆分 → 交叉缩放
     odd ⊙ exp(φ(even)) → 交叉加减 ±ρ/η → 门控残差补充 → 交错还原。
  3. 头 = 分层残差修正：各层候选特征 H_j 经软注意力加权得到基础预测路径 ŷ^b，
     剔除主导深度后由剩余深度加权得到残差修正项 c_t，输出 ŷ = ŷ^b + c_t。
  4. 原文为「输入 128 步预测未来 6 步」；为适配平衡测试集（独立窗口、无未来
     上下文）改为「窗口自重构」监督，但保留其多源不确定性：
     - 对输入做 K 次重采样（数据不确定性 σ_d）、每次 S 次 MC Dropout 前向
       （模型不确定性 σ_m），得到预测标准差 σ_t（= K*S 次预测的总标准差，
       近似 σ_m² + σ_d² 之和开方）。
  5. 得分 = 每个窗口的标准化重构残差 mean(|x - ŷ| / (σ_t + eps))（原文共形残差
     e_i = |y_i - ŷ_i| / σ_i）。
  6. 阈值 = 健康校准集（不参与训练/早停）上标准化残差的共形分位数
     q = F_e^{-1}(1 - α)（默认 α=0.05），score > q 判异常。
     （原文「在线分位数自适应更新」与「连续 6 点越界报警」中，后者已按要求改为
       单次越界（1 次）判定：窗口得分 score 一次性与阈值比较，不要求连续多点越界。）

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --epochs 100 --K 5 --mc-samples 10
"""

import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn

SOTA_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "..", "SOTA"))
sys.path.insert(0, SOTA_DIR)
import common as C


# ---------------------------------------------------------------------------
# 基础卷积模块（ReplicationPad -> DilatedConv -> Mish -> Dropout -> Conv -> Tanh）
# ---------------------------------------------------------------------------
class ConvModule(nn.Module):
    def __init__(self, in_ch, out_ch, kernel=5, kernel2=5, dilation=2, dropout=0.3):
        super().__init__()
        pad_d = (kernel - 1) * dilation
        self.pad1 = nn.ReplicationPad1d((pad_d // 2, pad_d - pad_d // 2))
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel, dilation=dilation)
        self.mish = nn.Mish()
        self.dropout = nn.Dropout(dropout)
        pad2 = kernel2 - 1
        self.pad2 = nn.ReplicationPad1d((pad2 // 2, pad2 - pad2 // 2))
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel2)

    def forward(self, x):
        x = self.conv1(self.pad1(x))
        x = self.mish(x)
        x = self.dropout(x)
        x = self.conv2(self.pad2(x))
        return torch.tanh(x)


# ---------------------------------------------------------------------------
# 门控残差增强 SCI 交互块
# ---------------------------------------------------------------------------
class RESCIBlock(nn.Module):
    """长度保持的 RE-SCIBlock：奇偶拆分 -> 交叉缩放/加减 -> 门控残差 -> 交错还原。"""

    def __init__(self, channels, kernel=5, dilation=2, dropout=0.3):
        super().__init__()
        self.phi = ConvModule(channels, channels, kernel, kernel, dilation, dropout)
        self.delta = ConvModule(channels, channels, kernel, kernel, dilation, dropout)
        self.rho = ConvModule(channels, channels, kernel, kernel, dilation, dropout)
        self.eta = ConvModule(channels, channels, kernel, kernel, dilation, dropout)
        self.gate_odd = nn.Conv1d(2 * channels, channels, 1)
        self.gate_even = nn.Conv1d(2 * channels, channels, 1)

    def forward(self, x):
        B, C, L = x.shape
        odd = x[:, :, 0::2]
        even = x[:, :, 1::2]

        odd_s = odd * torch.exp(self.phi(even))
        even_s = even * torch.exp(self.delta(odd))

        odd2 = odd_s + self.rho(even_s)
        even2 = even_s - self.eta(odd_s)

        g_odd = torch.sigmoid(self.gate_odd(torch.cat([odd, odd2], dim=1)))
        g_even = torch.sigmoid(self.gate_even(torch.cat([even, even2], dim=1)))
        odd3 = odd2 + g_odd * odd
        even3 = even2 + g_even * even

        out = x.new_empty((B, C, L))
        out[:, :, 0::2] = odd3
        out[:, :, 1::2] = even3
        return out


# ---------------------------------------------------------------------------
# 分层残差修正网络
# ---------------------------------------------------------------------------
class RESCINet(nn.Module):
    def __init__(self, D, T, hidden=16, num_blocks=3, kernel=5, dilation=2, dropout=0.3):
        super().__init__()
        self.embed = nn.Conv1d(D, hidden, 1)
        self.blocks = nn.ModuleList(
            [RESCIBlock(hidden, kernel, dilation, dropout) for _ in range(num_blocks)])
        self.f_p = nn.Linear(hidden, 1)          # 基础路径深度权重
        self.base_head = nn.Conv1d(hidden, D, 1)
        self.f_w = nn.Linear(hidden, 1)          # 残差路径深度权重
        self.res_head = nn.Conv1d(hidden, D, 1)

    def forward(self, x):
        # x: (B, T, D) -> (B, T, D) 自重构
        x = x.transpose(1, 2)                    # (B, D, T)
        h = self.embed(x)                        # (B, hidden, T)
        Hs = []
        for blk in self.blocks:
            h = blk(h)
            Hs.append(h)                         # 各层候选特征 (B, hidden, T)

        J = len(Hs)
        B = x.shape[0]
        pooled = torch.stack([hh.mean(dim=2) for hh in Hs], dim=1)   # (B, J, hidden)

        # 基础预测路径
        p = torch.softmax(self.f_p(pooled), dim=1)                   # (B, J, 1)
        H_b = sum(p[:, j, :].unsqueeze(-1) * Hs[j] for j in range(J))  # (B, hidden, T)
        yb = self.base_head(H_b)                                     # (B, D, T)

        # 残差修正路径（剔除主导深度 b）
        b_idx = p.squeeze(-1).argmax(dim=1)                          # (B,)
        w_logits = self.f_w(pooled).clone()                          # (B, J, 1)
        w_logits[torch.arange(B, device=w_logits.device), b_idx, 0] = float("-inf")
        w = torch.softmax(w_logits, dim=1)                           # (B, J, 1)
        ct = sum(w[:, j, :].unsqueeze(-1) * self.res_head(Hs[j]) for j in range(J))  # (B, D, T)

        return (yb + ct).transpose(1, 2)        # (B, T, D)


# ---------------------------------------------------------------------------
# 多源不确定性（输入重采样 + MC Dropout）
# ---------------------------------------------------------------------------
def mc_predict(model, x, K, mc_samples, noise_std, rng):
    """x: (B, T, D) 标准化 -> (mean, sigma) 各 (B, T, D)。

    K 次输入重采样（数据不确定性） × 每次 mc_samples 次 MC Dropout 前向
    （模型不确定性），sigma 取 K*S 次预测的逐元素标准差（≈ σ_m²+σ_d² 开方）。
    """
    device = next(model.parameters()).device
    model.train()                               # 启用 dropout
    xb = torch.from_numpy(x).to(device)
    preds = []
    with torch.no_grad():
        for _ in range(K):
            if K > 1:
                noise = rng.normal(0.0, noise_std, size=x.shape).astype(np.float32)
                xk = xb + torch.from_numpy(noise).to(device)
            else:
                xk = xb
            for _ in range(mc_samples):
                preds.append(model(xk))
    preds = torch.stack(preds)                  # (K*S, B, T, D)
    return preds.mean(dim=0).cpu().numpy(), preds.std(dim=0).cpu().numpy()


# ---------------------------------------------------------------------------
# 得分（标准化重构残差）
# ---------------------------------------------------------------------------
def score_windows(model, windows, std, device, batch_size, K, mc_samples, noise_std, seed):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,) = mean(|x-ŷ|/(σ_t+eps))。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    rng = np.random.default_rng(seed)
    scores = []
    for i in range(0, N, batch_size):
        xb = x[i:i + batch_size]
        mean, sigma = mc_predict(model, xb, K, mc_samples, noise_std, rng)
        res = np.abs(xb - mean) / (sigma + 1e-6)
        scores.append(res.reshape(len(xb), -1).mean(axis=1))
    model.eval()
    return np.concatenate(scores)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW

    x_all = C.load_healthy_windows(dataset, window=T, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    n_val = int(n * (1 - args.train_ratio) * 0.5)
    w_tr = x_all[idx[:n_train]]
    w_va = x_all[idx[n_train:n_train + n_val]]
    w_cal = x_all[idx[n_train + n_val:]]         # 校准集（不参与训练/早停）

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32)
    va = std.transform(w_va).astype(np.float32)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n_val} "
          f"cal={len(w_cal)}) D={D} T={T}")

    model = RESCINet(D, T, hidden=args.hidden, num_blocks=args.num_blocks,
                     kernel=args.kernel, dilation=args.dilation,
                     dropout=args.dropout).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or 256

    tr_t = torch.from_numpy(tr)
    va_t = torch.from_numpy(va)
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr} "
          f"hidden={args.hidden} blocks={args.num_blocks}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            optimizer.zero_grad()
            loss = nn.functional.mse_loss(model(xb), xb)
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            v = nn.functional.mse_loss(model(va_t.to(device)), va_t.to(device)).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total / len(tr_t):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 共形校准：在健康校准集上算标准化残差，取 (1-α) 分位数作为阈值 q
    cal_scores = score_windows(model, w_cal, std, device, bs,
                               args.K, args.mc_samples, args.noise_std, args.seed)
    thr = float(np.quantile(cal_scores, 1.0 - args.alpha))
    print(f"[阈值] 共形校准分位数 q=P{(1 - args.alpha) * 100:g}(校准集残差)={thr:.6f}  "
          f"(alpha={args.alpha}, 校准残差 mean={cal_scores.mean():.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"D": D, "T": T, "hidden": args.hidden,
                         "num_blocks": args.num_blocks, "kernel": args.kernel,
                         "dilation": args.dilation, "dropout": args.dropout},
        "scoring": {"K": args.K, "mc_samples": args.mc_samples,
                    "noise_std": args.noise_std, "seed": args.seed},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, std, thr


def main():
    ap = argparse.ArgumentParser(description="RESCINet 训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden", type=int, default=16)
    ap.add_argument("--num-blocks", type=int, default=3)
    ap.add_argument("--kernel", type=int, default=5)
    ap.add_argument("--dilation", type=int, default=2)
    ap.add_argument("--dropout", type=float, default=0.3)
    ap.add_argument("--K", type=int, default=5, help="输入重采样数据集个数（数据不确定性）")
    ap.add_argument("--mc-samples", type=int, default=10, help="每次 MC Dropout 前向次数（模型不确定性）")
    ap.add_argument("--noise-std", type=float, default=0.05, help="输入重采样扰动标准差")
    ap.add_argument("--alpha", type=float, default=0.05, help="共形显著性水平")
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
