# 完整方法提取：多源不确定性感知分层 RESCINet 残差修正模型与共形自适应门限区间

> **文献来源**：Cao, L., Chang, W., Qian, Z., Meng, Z., & Li, J. (2026). Multi-source uncertainty-aware hierarchical RESCINet residual correction model with conformal adaptive threshold interval for wind turbine condition monitoring. *Mechanical Systems and Signal Processing*, 260, 115021.

---

## 1. 整体架构与运行流程 (Overall Framework)

本论文提出的风电机组状态监测方法由三大核心模块构成：
1. **数据预处理与多数据集重采样 (Data Preprocessing & Resampling)**
2. **分层 RESCINet 残差修正预测模型 (Hierarchical RESCINet Residual Correction Prediction Model)**
3. **多源不确定性驱动的共形自适应门限区间构建 (Multi-Source Uncertainty-Driven Conformal Adaptive Threshold Interval)**

```
【离线训练与校准阶段 (Offline Training & Calibration)】
 历史健康 SCADA 数据
        │
        ▼
 1. Kalman 滤波降噪 ➔ 2. Pearson 变量筛选 ➔ 3. Min-Max 归一化
        │
        ├── 训练集 (按 10 min 间隔下采样)
        │      │
        │      ▼
        │   训练 Hierarchical RESCINet 残差修正预测模型
        │
        └── 校准集 (健康数据)
               │
               ▼
            局部窗口多数据集随机重采样 (获得 K 个数据集 D_1, ..., D_K)
               │
               ▼
            输入已训练预测模型 (执行 S 次 MC Dropout 前向推理)
               │
               ▼
            计算校准集标准化共形残差 e_i = |y_i - \hat{y}_i| / \sigma_i
               │
               ▼
            根据显著性水平 \alpha 确定初始共形校准分位数 q

【在线监测阶段 (Online Monitoring)】
 实时在线 SCADA 测试数据
        │
        ▼
 1. 预处理 (Kalman + 变量筛选 + 归一化)
        │
        ▼
 2. 局部窗口多数据集随机重采样 (生成 K 个在线数据集 D_1, ..., D_K)
        │
        ▼
 3. 输入已训练模型 (每个数据集执行 S 次 MC Dropout 前向推理)
        │
        ├── 提取多数据集平均点预测结果 \hat{y}_t (作为区间中心)
        │
        └── 计算三大不确定性方差 (MC 离散度 \sigma_m^2 + 多数据集差异 \sigma_d^2 + 结构不确定性 \sigma_h^2)
               │
               ▼
            融合总不确定性标度 \sigma_t = \sqrt{\sigma_m^2 + \sigma_d^2 + \sigma_h^2}
               │
               ▼
 4. 构建共形自适应门限区间 T_t = [\hat{y}_t - h_t, \, \hat{y}_t + h_t],  其中 h_t = q_t \cdot \sigma_t
        │
        ├── 比较实际测量值 y_t 与区间 T_t，按规则动态更新下一时刻分位数 q_{t+1}
        │
        └── 判定：若测量值 y_t 连续 6 个采样点超出自适应区间 T_t ➔ 触发故障报警
```

---

## 2. 数据预处理与多数据集重采样 (Data Preprocessing)

### 2.1 一维 Kalman 滤波降噪
采用一维 Kalman 滤波平滑传感器高频噪声与短期波动。
- **状态预测步**：
  $$ \hat{s}_{t|t-1} = A\hat{s}_{t-1|t-1} + Bu_{t} $$
  $$ P_{t|t-1} = AP_{t-1|t-1}A^{T} + Q $$
- **状态更新步**：
  $$ K_{t} = P_{t|t-1}H^{T}(HP_{t|t-1}H^{T} + R)^{-1} $$
  $$ \hat{s}_{t|t} = \hat{s}_{t|t-1} + K_{t}(z_{t} - H\hat{s}_{t|t-1}) $$
*论文复现参数设置*：$A=1, H=1, P_0=1, Q=0.01, R=1$。

### 2.2 Pearson 相关系数变量筛选
计算各候选通道与目标监控参数之间的线性相关性：
$$ r = \frac{\sum_{i=1}^{n}(X_{i}-\bar{X})(Y_{i}-\bar{Y})}{\sqrt{\sum_{i=1}^{n}(X_{i}-\bar{X})^{2}}\sqrt{\sum_{i=1}^{n}(Y_{i}-\bar{Y})^{2}}} $$
筛选高相关系数变量，并结合子系统物理运行特性确定最终模型输入维度。

### 2.3 Min-Max 归一化
$$ x_{nom} = \frac{x-x_{min}}{x_{max}-x_{min}} $$

### 2.4 局部时间窗口多数据集随机重采样 (Multi-dataset Resampling)
为捕获局部时间窗口内的样本选择不确定性（数据不确定性）：
1. 划分连续的局部时间窗口（窗口大小设置为 10 min）。
2. 在每个非空局部窗口内**随机抽取 1 个有效样本**，按时间顺序排列组成一个重采样数据集 $D_k = \{x_1^k, x_2^k, \dots, x_M^k\}$。
3. 重复该过程 $K$ 次（论文中 $K=100$），生成数据集集合 $D' = \{D_1, D_2, \dots, D_K\}$。

---

## 3. 分层 RESCINet 残差修正预测模型 (Hierarchical RESCINet Model)

模型网络由 **Residual-Enhanced SCI Block (RE-SCIBlock)** 构成的编码器和 **分层残差修正模块 (Hierarchical Residual Correction Module)** 组成。

### 3.1 门控残差增强的 SCI 交互机制 (Residual-Enhanced SCI Interaction)
为了避免传统 SCINet 在下采样和卷积交互过程中丢失原始序列的局部波动信息，在奇偶交互更新后加入**门控残差路径**。

#### Step 1: 奇偶序列拆分 (Odd-Even Splitting)
输入特征序列 $V \in \mathbb{R}^{m \times L}$ 按照时间奇偶位置拆分为：
$$ V_{odd} = [V_1, V_3, \dots, V_{L-1}], \quad V_{even} = [V_2, V_4, \dots, V_L] $$

#### Step 2: 卷积交互与特征更新 (Interactive Learning)
1. **缩放特征计算**：
   $$ V'_{odd} = V_{odd} \odot \exp(\phi(V_{even})) $$
   $$ V'_{even} = V_{even} \odot \exp(\delta(V_{odd})) $$
   *(其中 $\phi, \delta$ 为一维卷积模块，$\odot$ 为元素相乘)*
2. **加减交互更新**：
   $$ V''_{odd} = V'_{odd} \pm \rho(V'_{even}) $$
   $$ V''_{even} = V'_{even} \pm \eta(V'_{odd}) $$
   *(其中 $\rho, \eta$ 为不同卷积核的一维卷积模块)*

#### Step 3: 门控残差补充 (Gated Residual Update)
计算自适应门控权重，将原始序列信息补充回更新后的分支：
$$ Gate_{odd} = \text{Sigmoid}\left(\text{Conv}_{odd}\left(\text{Concat}(V_{odd}, V''_{odd})\right)\right) $$
$$ Gate_{even} = \text{Sigmoid}\left(\text{Conv}_{even}\left(\text{Concat}(V_{even}, V''_{even})\right)\right) $$
输出门控残差更新后的分支特征：
$$ V'''_{odd} = V''_{odd} + Gate_{odd} \odot V_{odd} $$
$$ V'''_{even} = V''_{even} + Gate_{even} \odot V_{even} $$

---

### 3.2 分层残差修正机制 (Hierarchical Residual Correction)
将来自编码器不同交互深度 $j \in \{1, 2, \dots, J\}$ 的候选特征 $H_j$ 分解为**基础预测路径**与**残差修正路径**。

```
                   多深度候选特征 H_1, H_2, ..., H_J
                                 │
         ┌───────────────────────┴───────────────────────┐
         ▼                                               ▼
 【基础预测路径 (Base Path)】                    【残差修正路径 (Residual Path)】
 计算深度权重 p_j                               剔除主导深度 b = argmax(p_j)
 融合特征 H_b = \sum p_j H_j                    计算剩余特征权重 w_j (j ≠ b)
 输出基础预测 \hat{y}_t^b                       生成残差候选 C_j ➔ 融合残差修正项 c_t
         │                                               │
         └───────────────────────┬───────────────────────┘
                                 ▼
                     最终预测 \hat{y}_t = \hat{y}_t^b + c_t
```

#### 1. 基础预测路径 (Base Prediction Path)
- **基路径权重计算**：
  $$ p_j = \frac{\exp(f_p(\text{Pool}(H_j)))}{\sum_{a=1}^J \exp(f_p(\text{Pool}(H_a)))}, \quad j = 1, 2, \dots, J $$
  *(其中 $\text{Pool}(\cdot)$ 表示时间维度平均池化，$f_p(\cdot)$ 为由 Linear-ReLU-Dropout-Linear-Softmax 构成的映射网络)*
- **基特征融合与基础预测输出**：
  $$ H_b = \sum_{j=1}^J p_j H_j $$
  $$ \hat{y}_t^b = g_b(H_b) \quad (g_b \text{ 为全连接预测输出层}) $$

#### 2. 残差修正路径 (Residual Correction Path)
- **主导深度掩码**：获取基路径中权重最大的候选深度索引 $b = \arg\max_j (p_j)$。在残差修正中排除深度 $b$。
- **残差修正权重计算**：
  $$ w_j = \frac{\exp(f_w(\text{Pool}(H_j)))}{\sum_{a \neq b}^J \exp(f_w(\text{Pool}(H_a)))}, \quad j \neq b $$
- **残差修正项计算**：
  将剩余深度的特征 $H_j$ 通过全连接映射层得到残差候选 $C_j$，加权融合得到残差修正项 $c_t$：
  $$ c_t = \sum_{j \neq b} w_j C_j $$

#### 3. 最终点预测输出
$$ \hat{y}_t = \hat{y}_t^b + c_t $$

#### 4. 单次推理的网络结构不确定性 (Structural Uncertainty)
定义单次前向推理中各深度残差候选的加权离散度：
$$ v = \sum_{j \neq b} w_j |C_j - c_t| $$

---

## 4. 多源不确定性驱动的共形自适应门限区间 (Conformal Adaptive Threshold Interval)

### 4.1 三源预测不确定性融合 (Multi-Source Uncertainty Scale)
在每个监测时刻，利用 $K$ 个重采样数据集，每个数据集执行 $S$ 次带有 MC Dropout 的随机前向推理（Dropout 掩码 $\Omega_r \sim \text{Bernoulli}(\mu)$）。

#### 1. MC Dropout 预测离散度 $\sigma_m^2$（模型不确定性）
对于第 $k$ 个数据集，其 $S$ 次前向推理的预测均值为 $\bar{y}_k = \frac{1}{S}\sum_{r=1}^S \hat{y}_{r,k}$。在 $K$ 个数据集上取平均：
$$ \sigma_m^2 = \frac{1}{K} \sum_{k=1}^K \left[ \frac{1}{S} \sum_{r=1}^S (\hat{y}_{r,k} - \bar{y}_k)^2 \right] $$

#### 2. 多数据集预测差异 $\sigma_d^2$（数据不确定性）
计算所有数据集的总平均预测 $\hat{y} = \frac{1}{K}\sum_{k=1}^K \bar{y}_k$，多数据集均值之间的方差为：
$$ \sigma_d^2 = \frac{1}{K} \sum_{k=1}^K (\bar{y}_k - \hat{y})^2 $$

#### 3. 聚合结构不确定性 $\sigma_h^2$（网络结构不确定性）
对所有 $K$ 个数据集和 $S$ 次推理得到的结构不确定性 $v_{r,k}$ 求均值：
$$ \sigma_h^2 = \frac{1}{K \cdot S} \sum_{k=1}^K \sum_{r=1}^S v_{r,k} $$

#### 4. 多源总不确定性标度 (Combined Scale)
将三个不确定性分量在方差层面上叠加，得到总不确定性标度 $\sigma_t$：
$$ \sigma_t = \sqrt{\sigma_m^2 + \sigma_d^2 + \sigma_h^2} $$

---

### 4.2 共形校准分位数确定 (Conformal Calibration)

1. **标准化共形残差计算**：
   利用历史健康校准集 $i \in \{1, 2, \dots, n_{cal}\}$，计算由多源不确定性标度缩放后的残差：
   $$ e_i = \frac{|y_i - \hat{y}_i|}{\sigma_i} $$
2. **确定校准分位数 $q$**：
   设 $F_e$ 为 $e_i$ 的经验累积分布函数，根据指定的显著性水平 $\alpha$（如 $\alpha = 0.05$ 对应 95% 置信度），计算共形校准分位数：
   $$ q = F_e^{-1}(1 - \alpha) $$

---

### 4.3 在线自适应门限区间构建与动态更新 (Online Adaptive Threshold Interval)

在在线监测时刻 $t$：
1. **区间半宽与门限构建**：
   使用初始化为 $q_1 = q$ 的在线分位数 $q_t$ 与实时不确定性标度 $\sigma_t$ 计算半宽：
   $$ h_t = q_t \cdot \sigma_t $$
   构建以预测值 $\hat{y}_t$ 为中心的自适应门限区间：
   $$ T_t = [\hat{y}_t - h_t, \; \hat{y}_t + h_t] $$

2. **在线分位数自适应更新 (Online Quantile Update)**：
   获取实际测量值 $y_t$ 后，根据是否被当前门限区间覆盖，按以下逻辑更新 $q_{t+1}$：
   $$ q_{t+1} = \begin{cases} q_t + \lambda_t \alpha, & y_t \notin T_t \quad (\text{越界：扩大下一时刻区间}) \\ \max(0, \, q_t - \lambda_t (1-\alpha)), & y_t \in T_t \quad (\text{覆盖：微调缩小下一时刻区间}) \end{cases} $$
   *动态调整步长* $\lambda_t$ 定义为：
   $$ \lambda_t = \frac{\text{MAD}(e_1, e_2, \dots, e_{n_{cal}})}{n_{cal} + t} $$
   *(其中 $\text{MAD}$ 为校准集标准化残差的中位数绝对偏差。随着监测步数 $t$ 增加，$\lambda_t$ 逐渐衰减以保证在线更新的稳定性)*。

3. **连续越界触发报警规则 (Sustained Exceedance Criterion)**：
   为防止单个离群点引发误报，仅当测量值 $y_t$ **连续 6 个采样点**超出自适应门限区间 $T_t$（即 $y_t \notin T_t$）时，系统才正式触发风电机组故障预警。

---

## 5. 论文复现超参数汇总 (Hyperparameter Summary)

| 参数类别 | 超参数名称 | 论文推荐设置值 |
| :--- | :--- | :--- |
| **数据预处理** | SCADA 输入序列长度 (Input Length) | 128 |
| | 标签序列长度 (Label Length) | 96 |
| | 预测序列长度 (Prediction Length) | 6 |
| | 局部重采样时间窗口 (Local Window) | 10 min |
| |  Kalman 滤波参数 | $A=1, H=1, P_0=1, Q=0.01, R=1$ |
| **预测模型结构** | RE-SCIBlock 交互层级数 (Levels) | 3 |
| | 堆叠数 (Stack) | 1 |
| | 隐藏通道维度 (Hidden Size) | 16 |
| | 解码器层数 (Decoder Layers) | 1 |
| | 优化器 (Optimizer) / 学习率 (LR) | Adam / $1 \times 10^{-5}$ |
| | 训练 Epoch / Batch Size | 100 / 32 |
| **不确定性与门限** | 重采样数据集个数 ($K$) | 100 |
| | MC Dropout 前向推理次数 ($S$) | 50 |
| | MC Dropout 丢弃率 (Dropout Rate) | 0.3 (即 retention prob $\mu = 0.7$) |
| | 显著性水平 ($\alpha$) | 0.05 (对应 95% 置信度) |
| | 连续越界报警阈值 | 连续 6 个监测点 |
```

I have completed extracting the full methodology from the paper into a structured markdown file (`WT_Monitoring_Method_RESCINet.md`) formatted for your implementation and reference.