# -*- coding: utf-8 -*-
"""
EDAE —— 集成降噪自编码器（Ensemble Denoising Autoencoder）训练脚本
====================================================================

方法要点：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 模型 = num_models 个降噪自编码器（DAE）的集成：对输入加高斯噪声
     (noise_ratio)，各 DAE 独立重构后取平均（提升鲁棒性）。
     DAE：Linear(D->64->32->latent->32->64) + ReLU + Dropout，Decoder Linear(64->D)。
  3. 仅用健康数据训练（MSE 重构），逐时间点（D 维向量）作为样本。
  4. 得分 = 逐（时间点 x 特征）重构误差 |recon - x|，窗口异常得分
     = max_{t,d}(|r_{t,d}| / tau_d(y))，任一特征超限即判异常（单次判定）。
  5. 阈值 = 原文 2D 高斯核 KDE 条件置信区间：对每特征在健康训练集上拟合
     (输入 y, 残差 r) 的联合 KDE，沿残差轴取 95% 条件分位作为随输入变化的
     阈值曲线 tau_d(y)，score > 1 判异常。

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --epochs 30 --max-windows 100000
"""

import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import gaussian_kde

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C


# ---------------------------------------------------------------------------
# 模型
# ---------------------------------------------------------------------------
class DenoisingAutoencoder(nn.Module):
    def __init__(self, input_dim, latent_nodes=10, dropout_rate=0.1):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64), nn.ReLU(), nn.Dropout(dropout_rate),
            nn.Linear(64, 32), nn.ReLU(), nn.Dropout(dropout_rate),
            nn.Linear(32, latent_nodes), nn.ReLU(), nn.Dropout(dropout_rate),
            nn.Linear(latent_nodes, 32), nn.ReLU(), nn.Dropout(dropout_rate),
            nn.Linear(32, 64), nn.ReLU(), nn.Dropout(dropout_rate),
        )
        self.decoder = nn.Sequential(nn.Linear(64, input_dim))

    def forward(self, x):
        return self.decoder(self.encoder(x))


class EnsembleDenoisingAutoencoder(nn.Module):
    def __init__(self, input_dim, num_models=5, noise_ratio=0.1,
                 dropout_rate=0.1, latent_nodes=10):
        super().__init__()
        self.models = nn.ModuleList(
            [DenoisingAutoencoder(input_dim, latent_nodes, dropout_rate)
             for _ in range(num_models)])
        self.noise_ratio = noise_ratio

    def forward(self, x):
        outputs = [m(x + torch.randn_like(x) * self.noise_ratio) for m in self.models]
        return torch.mean(torch.stack(outputs), dim=0)


# ---------------------------------------------------------------------------
# 得分 / 条件 KDE 阈值
# ---------------------------------------------------------------------------
def residual_points(model, x_pts, device, batch_size):
    """x_pts: (N, D)（已标准化）-> 逐特征重构误差 |recon - x| (N, D)。"""
    model.eval()
    res = []
    with torch.no_grad():
        for i in range(0, len(x_pts), batch_size):
            xb = torch.from_numpy(x_pts[i:i + batch_size]).to(device)
            recon = model(xb)
            res.append(torch.abs(recon - xb).cpu().numpy())
    return np.concatenate(res, axis=0)


def _fit_conditional_threshold(y, r, n_x=40, n_y=120, conf=0.95,
                               max_points=20000, seed=0):
    """对单特征拟合 (输入 y, 残差 r) 的 2D KDE 条件 95% 分位阈值曲线。

    返回 (x_grid, thr_grid)（长度 n_x 的 float32 数组），用于测试时 np.interp。
    """
    y = np.asarray(y, dtype=np.float64).ravel()
    r = np.asarray(r, dtype=np.float64).ravel()
    if len(y) > max_points:
        idx = np.random.default_rng(seed).choice(len(y), max_points, replace=False)
        y, r = y[idx], r[idx]
    # 残差退化（几乎为 0）时退化为常数阈值
    if r.std() < 1e-12:
        return np.array([y.min(), y.max()], dtype=np.float32), \
               np.zeros(2, dtype=np.float32)
    X = np.vstack([y, r])
    try:
        kde = gaussian_kde(X)
    except Exception:
        return np.array([y.min(), y.max()], dtype=np.float32), \
               np.full(2, float(r.max()), dtype=np.float32)

    y_span = float(y.max() - y.min()) + 1e-12
    r_span = float(r.max() - r.min()) + 1e-12
    x_min, x_max = float(y.min()) - 0.05 * y_span, float(y.max()) + 0.05 * y_span
    y_min, y_max = float(r.min()) - 0.05 * r_span, float(r.max()) + 0.05 * r_span
    x_grid = np.linspace(x_min, x_max, n_x)
    y_grid = np.linspace(y_min, y_max, n_y)
    thr = np.empty(n_x, dtype=np.float64)
    for i, xx in enumerate(x_grid):
        pos = np.vstack([np.full(n_y, xx), y_grid])
        dens = kde(pos)
        cdf = np.cumsum(dens)
        cdf /= (cdf[-1] + 1e-8)
        j = int(np.searchsorted(cdf, conf))
        thr[i] = y_grid[min(j, n_y - 1)]
    return x_grid.astype(np.float32), thr.astype(np.float32)


def _interp_threshold(xval, thr_x, thr_y):
    """xval: (..., D) -> 逐特征条件阈值 (..., D)。thr_x/thr_y: (D, n_x)。"""
    D = xval.shape[-1]
    flat = xval.reshape(-1, D)
    out = np.empty_like(flat, dtype=np.float32)
    for d in range(D):
        out[:, d] = np.interp(flat[:, d], thr_x[d], thr_y[d])
    return out.reshape(xval.shape)


def score_windows(model, windows, std, thr_x, thr_y, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,) = max_{t,d} |r_{t,d}| / tau_d(y)。
    对应原文「任一特征残差超条件阈值即判异常」，单次判定。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    model.eval()
    scores = []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)      # (B, T, D)
            B = xb.shape[0]
            xp = xb.reshape(-1, D)                                     # (B*T, D)
            recon = model(xp)
            r = torch.abs(recon - xp).cpu().numpy().reshape(B, T, D)   # (B, T, D)
            xval = xp.cpu().numpy().reshape(B, T, D)                   # (B, T, D)
            tau = _interp_threshold(xval, thr_x, thr_y)                # (B, T, D)
            ratio = r / (tau + 1e-8)
            scores.append(ratio.reshape(B, -1).max(axis=1))
    return np.concatenate(scores)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]

    # 1) 健康窗口 + 标准化
    x_all = C.load_healthy_windows(dataset, window=C.WINDOW, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr_pts = std.transform(w_tr).reshape(-1, D).astype(np.float32)     # (n_tr*T, D)
    va_pts = std.transform(w_va).reshape(-1, D).astype(np.float32)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) D={D}")

    # 2) 模型
    model = EnsembleDenoisingAutoencoder(
        D, num_models=args.num_models, noise_ratio=args.noise_ratio,
        dropout_rate=args.dropout_rate, latent_nodes=args.latent_nodes).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or 512

    tr_t = torch.from_numpy(tr_pts)
    va_t = torch.from_numpy(va_pts)
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr} "
          f"num_models={args.num_models}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            optimizer.zero_grad()
            loss = nn.functional.mse_loss(model(xb), xb)
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            v = nn.functional.mse_loss(model(va_t.to(device)), va_t.to(device)).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total / len(tr_t):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 3) 阈值：对每特征拟合 (输入 y, 残差 r) 的 2D KDE 条件 95% 分位曲线
    n_kde = min(len(tr_pts), args.kde_max_points)
    idx_k = np.random.default_rng(args.seed).choice(len(tr_pts), n_kde, replace=False) \
        if len(tr_pts) > n_kde else np.arange(len(tr_pts))
    y_kde = tr_pts[idx_k]
    r_kde = residual_points(model, y_kde, device, bs)
    thr_x = np.empty((D, args.kde_nx), dtype=np.float32)
    thr_y = np.empty((D, args.kde_nx), dtype=np.float32)
    for d in range(D):
        thr_x[d], thr_y[d] = _fit_conditional_threshold(
            y_kde[:, d], r_kde[:, d], n_x=args.kde_nx, n_y=args.kde_ny,
            conf=args.kde_conf, max_points=args.kde_max_points, seed=args.seed)
    print(f"[阈值] 条件 KDE {args.kde_conf:g} 分位曲线（D={D} 特征，每特征 n_x={args.kde_nx}） "
          f"(每特征阈值均值={thr_y.mean(axis=1).mean():.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"input_dim": D, "num_models": args.num_models,
                         "noise_ratio": args.noise_ratio,
                         "dropout_rate": args.dropout_rate,
                         "latent_nodes": args.latent_nodes},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold_x": thr_x,
        "threshold_y": thr_y,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, std, thr_x, thr_y


def main():
    ap = argparse.ArgumentParser(description="EDAE 集成降噪自编码器训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1.2e-4)
    ap.add_argument("--num-models", type=int, default=5)
    ap.add_argument("--noise-ratio", type=float, default=0.1)
    ap.add_argument("--dropout-rate", type=float, default=0.1)
    ap.add_argument("--latent-nodes", type=int, default=10)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--kde-max-points", type=int, default=20000,
                    help="KDE 阈值拟合的健康点子上限（提速/稳定）")
    ap.add_argument("--kde-nx", type=int, default=40, help="条件阈值曲线 x 网格点数")
    ap.add_argument("--kde-ny", type=int, default=120, help="条件阈值曲线 y 网格点数")
    ap.add_argument("--kde-conf", type=float, default=0.95, help="KDE 置信水平")
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
