# -*- coding: utf-8 -*-
"""
TS-TCC —— 时序对比学习 + 重构（Time-Series Temporal & Contextual Contrasting）训练脚本
========================================================================================

方法要点（TS-TCC 自监督表示 + 重构做异常检测）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 编码器 = 3 层 1D CNN，输入 (B, D, T) -> 特征图 (B, C_out, T)。
  3. 阶段一（对比预训练）：对同一窗口做「弱增强(scaling+jitter) / 强增强
     (permutation+jitter)」两个视图，用 NT-Xent（InfoNCE）损失拉近同一样本的
     两个视图、推远不同样本（即 TS-TCC 的上下文对比损失）。
  4. 阶段二（重构）：冻结编码器，训练 MLP 解码器把编码特征重建回 (D, T)。
  5. 得分 = 每个窗口的重构误差 MSE（对 (D, T) 取平均）。
  6. 阈值 = 健康训练集窗口得分的百分位（原文在训练集分布上网格搜索百分位，
     此处取固定 P95 作为其自身阈值策略，避免用测试标签选阈值），score > tau 判异常。

（TS-TCC 原文还含「时序对比 TC 自回归模块」，此处按无监督重构基线保留其核心
  上下文对比预训练 + 重构解码两阶段，适配 D=8/15、T=10。）

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --max-windows 100000
"""

import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C


# ---------------------------------------------------------------------------
# 模型
# ---------------------------------------------------------------------------
class TSEncoder(nn.Module):
    """3 层 1D CNN 编码器，(B, D, T) -> (B, C_out, T)。"""

    def __init__(self, input_channels, out_channels=128, kernel_size=3, dropout=0.2):
        super().__init__()
        self.conv_block = nn.Sequential(
            nn.Conv1d(input_channels, 32, kernel_size, padding=1),
            nn.BatchNorm1d(32), nn.ReLU(), nn.Dropout(dropout),
            nn.Conv1d(32, 64, kernel_size, padding=1),
            nn.BatchNorm1d(64), nn.ReLU(), nn.Dropout(dropout),
            nn.Conv1d(64, out_channels, kernel_size, padding=1),
            nn.BatchNorm1d(out_channels), nn.ReLU(),
        )

    def forward(self, x):                      # (B, D, T)
        return self.conv_block(x)              # (B, C_out, T)


class MLPDecoder(nn.Module):
    """把展平特征 (B, C_out*T) 重建回 (B, D, T)。"""

    def __init__(self, feat_dim, D, T):
        super().__init__()
        self.D, self.T = D, T
        self.decoder = nn.Sequential(
            nn.Linear(feat_dim, 256), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(256, 512), nn.ReLU(),
            nn.Linear(512, D * T),                     # 线性输出（z-score 值域可超 [-1,1]）
        )

    def forward(self, x):
        return self.decoder(x).view(-1, self.D, self.T)


# ---------------------------------------------------------------------------
# 数据增强 + 对比损失
# ---------------------------------------------------------------------------
def _aug_views(x: np.ndarray, rng, jitter_ratio=0.005, scale_ratio=1.1, max_seg=3):
    """x: (B, D, T) -> (weak, strong) 两个视图（弱：scaling+jitter；强：permutation+jitter）。"""
    B, D, T = x.shape
    weak = x * rng.normal(1.0, scale_ratio, size=(B, D, 1)).astype(np.float32)
    weak = weak + rng.normal(0.0, jitter_ratio, size=weak.shape).astype(np.float32)

    strong = x.copy()
    for i in range(B):
        n_seg = rng.integers(1, max_seg + 1)
        if n_seg > 1 and T > n_seg:
            segs = np.array_split(strong[i], n_seg, axis=-1)
            rng.shuffle(segs)
            strong[i] = np.concatenate(segs, axis=-1)
    strong = strong + rng.normal(0.0, jitter_ratio, size=strong.shape).astype(np.float32)
    return weak, strong


def nt_xent(z1, z2, temperature=0.05):
    """NT-Xent（InfoNCE）：z1/z2 为同批两视图的 (B, F) 向量。"""
    B = z1.shape[0]
    z = F.normalize(torch.cat([z1, z2], dim=0), dim=1)       # (2B, F)
    sim = (z @ z.T) / temperature
    sim = sim.masked_fill(torch.eye(2 * B, device=z.device).bool(), float("-inf"))
    labels = torch.cat([torch.arange(B, 2 * B), torch.arange(B)], dim=0).to(z.device)
    return F.cross_entropy(sim, labels)


# ---------------------------------------------------------------------------
# 得分
# ---------------------------------------------------------------------------
def score_windows(encoder, decoder, windows, std, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,)。重构 MSE 对 (D, T) 平均。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D).transpose(0, 2, 1)  # (N, D, T)
    encoder.eval()
    decoder.eval()
    scores = []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)
            feat = encoder(xb).reshape(xb.shape[0], -1)
            recon = decoder(feat)
            scores.append(((recon - xb) ** 2).mean(dim=(1, 2)).cpu().numpy())
    return np.concatenate(scores)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW

    x_all = C.load_healthy_windows(dataset, window=T, stride=1,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32).transpose(0, 2, 1)   # (n_tr, D, T)
    va = std.transform(w_va).astype(np.float32).transpose(0, 2, 1)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) D={D} T={T}")

    encoder = TSEncoder(D, out_channels=args.out_channels, kernel_size=args.kernel_size,
                        dropout=args.dropout).to(device)
    decoder = MLPDecoder(args.out_channels * T, D, T).to(device)
    bs = args.batch_size or 256
    tr_t = torch.from_numpy(tr)
    va_t = torch.from_numpy(va)

    # 阶段一：上下文对比预训练（NT-Xent）
    opt_enc = torch.optim.Adam(encoder.parameters(), lr=args.lr,
                               betas=(0.9, 0.99), weight_decay=1e-4)
    print(f"[训练] device={device} 阶段一(对比) epochs={args.cont_epochs} batch={bs} lr={args.lr}")
    for epoch in range(1, args.cont_epochs + 1):
        encoder.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].cpu().numpy()
            weak, strong = _aug_views(xb, rng, args.jitter_ratio, args.scale_ratio, args.max_seg)
            w = torch.from_numpy(weak).to(device)
            s = torch.from_numpy(strong).to(device)
            opt_enc.zero_grad()
            zw = encoder(w).mean(dim=2)     # (B, C_out)
            zs = encoder(s).mean(dim=2)
            loss = nt_xent(zw, zs)
            loss.backward()
            opt_enc.step()
            total += loss.item() * len(xb)
        if epoch % 10 == 0 or epoch == args.cont_epochs:
            print(f"  对比 Epoch {epoch:>3d}/{args.cont_epochs}  loss={total / len(tr_t):.4f}")

    # 阶段二：冻结编码器，训练重构解码器
    for p in encoder.parameters():
        p.requires_grad = False
    encoder.eval()
    opt_dec = torch.optim.Adam(decoder.parameters(), lr=args.dec_lr, weight_decay=1e-5)
    print(f"[训练] 阶段二(重构) epochs={args.dec_epochs} batch={bs} lr={args.dec_lr}")
    best_val, best_dec = float("inf"), None
    for epoch in range(1, args.dec_epochs + 1):
        decoder.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            opt_dec.zero_grad()
            with torch.no_grad():
                feat = encoder(xb).reshape(xb.shape[0], -1)
            recon = decoder(feat)
            loss = F.mse_loss(recon, xb)
            loss.backward()
            opt_dec.step()
            total += loss.item() * len(xb)
        decoder.eval()
        with torch.no_grad():
            feat = encoder(va_t.to(device)).reshape(va_t.shape[0], -1)
            v = F.mse_loss(decoder(feat), va_t.to(device)).item()
        if v < best_val:
            best_val = v
            best_dec = {k: t.detach().cpu().clone() for k, t in decoder.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.dec_epochs:
            print(f"  重构 Epoch {epoch:>3d}/{args.dec_epochs}  train_mse={total / len(tr_t):.6f}  "
                  f"val_mse={v:.6f}")

    decoder.load_state_dict(best_dec)
    decoder.eval()

    scores = score_windows(encoder, decoder, x_all, std, device, bs)
    thr = float(np.percentile(scores, args.thr_percentile))
    print(f"[阈值] tau=P{args.thr_percentile:g}(健康窗口得分)={thr:.6f}  "
          f"(健康得分 mean={scores.mean():.6f})")

    ckpt = {
        "encoder_state_dict": encoder.state_dict(),
        "decoder_state_dict": decoder.state_dict(),
        "encoder_config": {"input_channels": D, "out_channels": args.out_channels,
                           "kernel_size": args.kernel_size, "dropout": args.dropout},
        "decoder_config": {"feat_dim": args.out_channels * T, "D": D, "T": T},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return encoder, decoder, std, thr


def main():
    ap = argparse.ArgumentParser(description="TS-TCC 训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--cont-epochs", type=int, default=100, help="对比预训练轮数")
    ap.add_argument("--dec-epochs", type=int, default=100, help="重构解码器训练轮数")
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-3, help="对比预训练学习率")
    ap.add_argument("--dec-lr", type=float, default=1e-3, help="解码器学习率")
    ap.add_argument("--out-channels", type=int, default=128)
    ap.add_argument("--kernel-size", type=int, default=3)
    ap.add_argument("--dropout", type=float, default=0.2)
    ap.add_argument("--jitter-ratio", type=float, default=0.005)
    ap.add_argument("--scale-ratio", type=float, default=1.1)
    ap.add_argument("--max-seg", type=int, default=3)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--thr-percentile", type=float, default=95.0)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
