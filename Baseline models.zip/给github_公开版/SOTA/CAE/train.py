# -*- coding: utf-8 -*-
"""
CAE —— 统计特征自编码器（Convolutional/Statistical-feature Autoencoder）训练脚本
================================================================================

方法要点（原文使用「窗口统计特征 + 单隐层自编码器」做无监督重构）：
  1. 对每个窗口 (T, D) 逐特征计算 5 个统计量：峰度、偏度、波形因子、
     脉冲因子、裕度因子 → 展平成 (5*D,) 向量（统计量本身无量纲，故无需 z-score）。
  2. 自编码器：Encoder Linear(5D -> 150) + Sigmoid；Decoder Linear(150 -> 5D)。
  3. 仅用健康数据训练（MSE 重构）。
  4. 得分 = 逐统计特征重构误差 |recon - x|（对 5D 维逐维计算），窗口异常得分
     = max_j(|r_j| / tau_j)，即「任一特征超限即判异常」（单次判定，1 次）。
  5. 阈值 = 健康训练集「逐特征」重构误差的第 95 百分位 tau（原文 threshold_keth
     为逐特征分位向量，非单一标量），score > 1 判异常。

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --epochs 200 --max-windows 50000
"""

import argparse
import os
import sys
import time
import warnings

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import kurtosis, skew

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C


# ---------------------------------------------------------------------------
# 模型
# ---------------------------------------------------------------------------
class ConvDAE(nn.Module):
    """统计特征自编码器（原文命名 ConvDAE，实为单隐层 MLP AE）。"""

    def __init__(self, input_dim, hidden_num=150):
        super().__init__()
        self.input_dim = input_dim
        self.encoder = nn.Sequential(nn.Linear(input_dim, hidden_num), nn.Sigmoid())
        self.decoder = nn.Sequential(nn.Linear(hidden_num, input_dim))

    def forward(self, x):
        return self.decoder(self.encoder(x))


# ---------------------------------------------------------------------------
# 统计特征（窗口 -> 5 个统计量 x D）
# ---------------------------------------------------------------------------
def stat_features(x: np.ndarray) -> np.ndarray:
    """x: (N, T, D) -> (N, 5*D) float32。逐特征计算 5 个无量纲统计量。"""
    x = np.asarray(x, dtype=np.float32)
    m = np.max(np.abs(x), axis=1)                                   # (N, D)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)             # 常量列（如桨距角）会触发精度警告
        kurt = np.nan_to_num(kurtosis(x, axis=1), nan=0.0, posinf=0.0, neginf=0.0)
        sk = np.nan_to_num(skew(x, axis=1), nan=0.0, posinf=0.0, neginf=0.0)
    shape = np.mean(np.abs(x), axis=1) / (np.sqrt(np.mean(x ** 2, axis=1)) + 1e-8)
    impulse = m / (np.mean(np.abs(x), axis=1) + 1e-8)
    margin = m / (np.mean(np.sqrt(np.abs(x)), axis=1) ** 2 + 1e-8)
    feat = np.stack([kurt, sk, shape, impulse, margin], axis=1)     # (N, 5, D)
    return feat.reshape(len(x), -1).astype(np.float32)


def residual_features(model, feat: np.ndarray, device, batch_size):
    """feat: (N, 5D) -> 逐统计特征重构误差 |recon - x| (N, 5D)。"""
    model.eval()
    res = []
    with torch.no_grad():
        for i in range(0, len(feat), batch_size):
            xb = torch.from_numpy(feat[i:i + batch_size]).to(device)
            recon = model(xb)
            res.append(torch.abs(recon - xb).cpu().numpy())
    return np.concatenate(res, axis=0)


def score_windows(model, windows, thr, device, batch_size):
    """windows: (N, T, D) -> 得分 (N,) = max_j |r_j| / tau_j（超限比）。
    score > 1 等价于「任一统计特征重构误差超其自身阈值」（单次判定）。"""
    R = residual_features(model, stat_features(windows), device, batch_size)
    tau = np.asarray(thr, dtype=np.float32)
    return np.max(R / (tau + 1e-8), axis=1)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]

    # 1) 健康窗口（原始量纲）
    x_all = C.load_healthy_windows(dataset, window=C.WINDOW, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    feat = stat_features(x_all)
    n = len(feat)
    n_train = int(n * args.train_ratio)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    feat_tr, feat_va = feat[idx[:n_train]], feat[idx[n_train:]]
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) "
          f"D={D} 特征维={feat.shape[1]}")

    # 2) 模型
    model = ConvDAE(feat.shape[1], hidden_num=args.hidden_num).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or min(4096, max(256, n_train // 200))

    tr_t = torch.from_numpy(feat_tr)
    va_t = torch.from_numpy(feat_va)
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            optimizer.zero_grad()
            recon = model(xb)
            loss = nn.functional.mse_loss(recon, xb)
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            v = nn.functional.mse_loss(model(va_t.to(device)), va_t.to(device)).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total / len(tr_t):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 3) 阈值：逐统计特征 95% 重构误差分位（原文 threshold_keth：每特征取 |error| 的第 95 百分位）
    R = residual_features(model, feat, device, bs)
    thr = np.percentile(R, args.thr_percentile, axis=0).astype(np.float32)   # (5D,)
    print(f"[阈值] 逐特征 tau=P{args.thr_percentile:g}(|重构误差|)  shape={thr.shape}  "
          f"(均值={thr.mean():.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"input_dim": feat.shape[1], "hidden_num": args.hidden_num},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, thr


def main():
    ap = argparse.ArgumentParser(description="CAE 统计特征自编码器训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=150)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden-num", type=int, default=150)
    ap.add_argument("--stride", type=int, default=1, help="健康数据滑窗步长")
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速；传更大值用全量）")
    ap.add_argument("--train-ratio", type=float, default=0.85, help="健康数据 train/val 划分比例")
    ap.add_argument("--thr-percentile", type=float, default=95.0)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
