# -*- coding: utf-8 -*-
"""
PatchTST —— 自监督掩码 Patch 重建（ICLR 2023）训练脚本
=========================================================

方法要点（PatchTST 的自监督版：通道独立 + patch 化 + 掩码重建）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 每个通道（传感器）作为一维序列独立 patch 化（patch_len / stride），
     通道间共享同一套 Transformer 权重（channel-independence）。
  3. 自监督训练：随机掩码部分 patch（置 0），Transformer 重建被掩码 patch，
     仅对掩码 patch 计算 MSE 损失。
  4. 得分 = 逐 patch 掩码重建误差的平均（对每个 patch 依次单独掩码推理，
     取该 patch 重建 MSE 的平均），作为该窗口的异常得分。
  5. 阈值 = 健康训练集窗口得分的百分位（原文在训练集分布上网格搜索百分位，
     此处取固定 P95 作为其自身阈值策略，避免用测试标签选阈值），score > tau 判异常。

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --max-windows 100000
"""

import argparse
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C


# ---------------------------------------------------------------------------
# 模型（自包含精简版 PatchTST：共享 patch 嵌入 + 位置编码 + Transformer + 重建头）
# ---------------------------------------------------------------------------
class PatchTST(nn.Module):
    def __init__(self, c_in, patch_len, stride, num_patch, d_model=64,
                 n_heads=4, n_layers=2, d_ff=128, dropout=0.1):
        super().__init__()
        self.patch_len = patch_len
        self.num_patch = num_patch
        self.W_P = nn.Linear(patch_len, d_model)                 # 共享嵌入
        self.W_pos = nn.Parameter(torch.randn(1, num_patch, 1, d_model) * 0.02)
        self.dropout = nn.Dropout(dropout)
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=d_model, nhead=n_heads,
                                       dim_feedforward=d_ff, dropout=dropout,
                                       batch_first=True),
            num_layers=n_layers)
        self.head = nn.Linear(d_model, patch_len)                # 重建 patch

    def forward(self, z):
        # z: (B, num_patch, c_in, patch_len) -> (B, num_patch, c_in, patch_len)
        B, num_patch, c_in, pl = z.shape
        x = self.W_P(z)                                          # (B, num_patch, c_in, d_model)
        x = x + self.W_pos
        x = x.permute(0, 2, 1, 3)                                # (B, c_in, num_patch, d_model)
        u = self.dropout(x.reshape(B * c_in, num_patch, -1))     # (B*c_in, num_patch, d_model)
        u = self.encoder(u)                                      # (B*c_in, num_patch, d_model)
        u = u.reshape(B, c_in, num_patch, -1).permute(0, 2, 1, 3)  # (B, num_patch, c_in, d_model)
        return self.head(u)                                      # (B, num_patch, c_in, patch_len)


# ---------------------------------------------------------------------------
# patch 化 / 得分
# ---------------------------------------------------------------------------
def patchify(x: np.ndarray, patch_len, stride) -> np.ndarray:
    """x: (N, T, D) -> (N, num_patch, D, patch_len)。"""
    N, T, D = x.shape
    num_patch = (T - patch_len) // stride + 1
    out = np.empty((N, num_patch, D, patch_len), dtype=np.float32)
    for i in range(num_patch):
        s = i * stride
        out[:, i, :, :] = x[:, s:s + patch_len, :].transpose(0, 2, 1)
    return out


def score_windows(model, windows, std, device, batch_size, patch_len, stride):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,)。逐 patch 掩码重建 MSE 平均。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    patches = torch.from_numpy(patchify(x, patch_len, stride)).to(device)  # (N, P, D, pl)
    num_patch = patches.shape[1]
    model.eval()
    scores = []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            pb = patches[i:i + batch_size]                       # (B, P, D, pl)
            errs = torch.zeros(pb.shape[0], num_patch, device=device)
            for p in range(num_patch):
                inp = pb.clone()
                inp[:, p, :, :] = 0.0
                pred = model(inp)
                errs[:, p] = ((pred[:, p] - pb[:, p]) ** 2).mean(dim=(1, 2))
            scores.append(errs.mean(dim=1).cpu().numpy())
    return np.concatenate(scores)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW
    patch_len = args.patch_len
    stride = args.stride
    num_patch = (T - patch_len) // stride + 1
    assert num_patch >= 1, f"patch_len={patch_len} 太大（T={T}）"

    x_all = C.load_healthy_windows(dataset, window=T, stride=1,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32)
    va = std.transform(w_va).astype(np.float32)
    tr_p = torch.from_numpy(patchify(tr, patch_len, stride))
    va_p = torch.from_numpy(patchify(va, patch_len, stride))
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) "
          f"D={D} T={T} patch={patch_len}/stride={stride} num_patch={num_patch}")

    model = PatchTST(D, patch_len, stride, num_patch, d_model=args.d_model,
                     n_heads=args.n_heads, n_layers=args.n_layers,
                     d_ff=args.d_ff, dropout=args.dropout).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or 256
    n_mask = max(1, int(num_patch * args.mask_ratio))

    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr} "
          f"mask_ratio={args.mask_ratio}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_p))
        total = 0.0
        for i in range(0, len(tr_p), bs):
            pb = tr_p[perm[i:i + bs]].to(device)
            inp = pb.clone()
            # 逐样本随机掩码 n_mask 个 patch
            for b in range(inp.shape[0]):
                m = torch.randperm(num_patch)[:n_mask]
                inp[b, m, :, :] = 0.0
            mask = (inp != pb)
            optimizer.zero_grad()
            pred = model(inp)
            loss = nn.functional.mse_loss(pred[mask], pb[mask])
            loss.backward()
            optimizer.step()
            total += loss.item() * len(pb)
        model.eval()
        with torch.no_grad():
            inp = va_p.to(device).clone()
            for b in range(inp.shape[0]):
                m = torch.randperm(num_patch)[:n_mask]
                inp[b, m, :, :] = 0.0
            mask = (inp != va_p.to(device))
            v = nn.functional.mse_loss(model(inp)[mask], va_p.to(device)[mask]).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total / len(tr_p):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    scores = score_windows(model, x_all, std, device, bs, patch_len, stride)
    thr = float(np.percentile(scores, args.thr_percentile))
    print(f"[阈值] tau=P{args.thr_percentile:g}(健康窗口得分)={thr:.6f}  "
          f"(健康得分 mean={scores.mean():.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"c_in": D, "patch_len": patch_len, "stride": stride,
                         "num_patch": num_patch, "d_model": args.d_model,
                         "n_heads": args.n_heads, "n_layers": args.n_layers,
                         "d_ff": args.d_ff, "dropout": args.dropout},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "patch_len": patch_len,
        "stride": stride,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, std, thr


def main():
    ap = argparse.ArgumentParser(description="PatchTST 自监督训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--patch-len", type=int, default=4)
    ap.add_argument("--stride", type=int, default=2)
    ap.add_argument("--mask-ratio", type=float, default=0.4)
    ap.add_argument("--d-model", type=int, default=64)
    ap.add_argument("--n-heads", type=int, default=4)
    ap.add_argument("--n-layers", type=int, default=2)
    ap.add_argument("--d-ff", type=int, default=128)
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--thr-percentile", type=float, default=95.0)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
