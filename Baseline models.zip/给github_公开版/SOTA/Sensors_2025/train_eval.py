# -*- coding: utf-8 -*-
"""
Sensors 2025 —— 风力发电机故障检测 (MLP 自编码器) 复现脚本
================================================================

按照 methodology.md 的通用方法学实现：

    [健康数据提取] -> [Z-Score 标准化] -> [MLP 自编码器训练(仅健康数据)]
              -> [重构误差 MSE] -> [窗口均值分数 + 适中百分位阈值] -> [异常判定]

* 模型：多层感知机自编码器 (MLP Autoencoder)，仅用健康（正常）数据无监督训练。
* 检测：重构误差 MSE -> 窗口均值分数 + 适中百分位阈值。

数据集：
    dataset1 : 1 分钟级，8 维，来自 _shared/data/raw_data.npy（去掉末 2 列非特征列）
    dataset2 : 秒级，   15 维，来自 _shared/data/new_raw_data.npy（全部 15 列）

测试集（最终评估）：
    阈值实验/测试集数据/dataset{1,2}/test_seed{seed}.npz（自包含：x / y_true / ...）

用法（解释器见 README）：
    python train_eval.py                                        # 默认：两个数据集 + 全部测试 seed + 对比表
    python train_eval.py --dataset dataset1
    python train_eval.py --dataset dataset2 --max-train-samples 200000 --epochs 150
    python test.py                                              # 只测试（加载已训练模型，不训练）
"""

import argparse
import json
import os
import random
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)

# ---------------------------------------------------------------------------
# 路径
# ---------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))          # .../与已有方法比较/Sensors_2025
ROOT = os.path.dirname(os.path.dirname(HERE))              # .../阈值实验
SHARED_DATA = os.path.join(ROOT, "_shared", "data")
TEST_DATA = os.path.join(ROOT, "测试集数据")
MODELS_DIR = os.path.join(HERE, "models")
RESULTS_DIR = os.path.join(HERE, "results")

DATASETS = {
    "dataset1": {"raw": "raw_data.npy",     "dim": 8,  "new_format": False},
    "dataset2": {"raw": "new_raw_data.npy", "dim": 15, "new_format": True},
}
TEST_SEEDS = [42, 123, 2024, 7, 999]
WINDOW = 10          # 测试集窗口长度（10 个采样点/窗口）


# ---------------------------------------------------------------------------
# 标准化器（Z-Score，仅用健康训练集拟合 mean/std）
# ---------------------------------------------------------------------------
class Standardizer:
    def __init__(self, mean, std, eps=1e-8):
        self.mean = np.asarray(mean, dtype=np.float32)
        self.std = np.asarray(std, dtype=np.float32)
        self.eps = eps

    @staticmethod
    def fit(x: np.ndarray, eps: float = 1e-8) -> "Standardizer":
        mean = x.mean(axis=0)
        std = x.std(axis=0)
        std = np.where(std < eps, 1.0, std)
        return Standardizer(mean, std, eps)

    def transform(self, x: np.ndarray) -> np.ndarray:
        return (x - self.mean) / (self.std + self.eps)


# ---------------------------------------------------------------------------
# 模型：MLP 自编码器（methodology 3.1）
#   低维输入 N_in<=5 : Encoder N_in->3->2, Decoder 2->3->N_out, 隐藏节点 (3,2,3)
#   较高维输入 N_in>=6: Encoder N_in->5->3->2, Decoder 2->3->5->N_out, 隐藏节点 (5,3,2,3,5)
# ---------------------------------------------------------------------------
class MLPAutoencoder(nn.Module):
    def __init__(self, input_dim: int, leaky_slope: float = 0.01):
        super().__init__()
        self.input_dim = input_dim
        if input_dim <= 5:
            enc_hidden, dec_hidden = [3, 2], [3]
        else:
            enc_hidden, dec_hidden = [5, 3, 2], [3, 5]

        # Encoder
        enc_layers, prev = [], input_dim
        for h in enc_hidden:
            enc_layers += [nn.Linear(prev, h), nn.LeakyReLU(leaky_slope)]
            prev = h
        self.encoder = nn.Sequential(*enc_layers)

        # Decoder（最后一层不加激活，线性重构输出）
        dec_layers, prev = [], enc_hidden[-1]
        for h in dec_hidden:
            dec_layers += [nn.Linear(prev, h), nn.LeakyReLU(leaky_slope)]
            prev = h
        dec_layers.append(nn.Linear(prev, input_dim))
        self.decoder = nn.Sequential(*dec_layers)

        self._init_weights()

    def _init_weights(self):
        # HeNormal 初始化（kaiming normal, a=0）
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight, a=0, mode="fan_in",
                                        nonlinearity="relu")
                nn.init.zeros_(m.bias)

    def forward(self, x):
        return self.decoder(self.encoder(x))


# ---------------------------------------------------------------------------
# 数据
# ---------------------------------------------------------------------------
def load_healthy(dataset: str) -> np.ndarray:
    """读取健康（正常）数据，返回 (T, D) float32。"""
    info = DATASETS[dataset]
    path = os.path.join(SHARED_DATA, info["raw"])
    data = np.load(path, allow_pickle=True)
    data = np.asarray(data, dtype=np.float32)
    if not info["new_format"]:
        data = data[:, :-2]  # 去掉末 2 列非特征列
    assert data.shape[1] == info["dim"], f"{dataset} 特征维 {data.shape[1]} != {info['dim']}"
    return data


def split_train_val_test(x: np.ndarray, seed: int, ratios=(0.70, 0.15, 0.15)):
    """按 methodology 3.2 划分 70% / 15% / 15%（随机打散）。"""
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(x))
    n = len(x)
    n_train = int(round(n * ratios[0]))
    n_val = int(round(n * ratios[1]))
    tr = idx[:n_train]
    va = idx[n_train:n_train + n_val]
    te = idx[n_train + n_val:]
    return x[tr], x[va], x[te]


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def auto_batch_size(n_train):
    """按训练样本数自动选 batch：目标每 epoch ~200 个 batch，夹在 [256, 8192]。"""
    target = n_train // 200
    return int(max(256, min(8192, target)))


def train(dataset, args):
    set_seed(args.seed)
    device = torch.device(args.device if args.device else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    info = DATASETS[dataset]
    D = info["dim"]

    # 1) 健康数据
    x_all = load_healthy(dataset)
    if args.max_train_samples and len(x_all) > args.max_train_samples:
        rng = np.random.default_rng(args.seed)
        x_all = x_all[rng.choice(len(x_all), args.max_train_samples, replace=False)]
        print(f"[数据] 子采样健康样本到 {len(x_all)}")

    # 2) 划分
    x_tr, x_va, x_te = split_train_val_test(x_all, args.seed)
    batch_size = args.batch_size or auto_batch_size(len(x_tr))
    print(f"[数据] {dataset} 健康样本: train={len(x_tr)} val={len(x_va)} "
          f"internal_test={len(x_te)}  D={D}  batch={batch_size}")

    # 3) 标准化（仅用健康训练集拟合）
    std = Standardizer.fit(x_tr)
    x_tr_n = std.transform(x_tr).astype(np.float32)
    x_va_n = std.transform(x_va).astype(np.float32)

    train_loader = DataLoader(TensorDataset(torch.from_numpy(x_tr_n)),
                              batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(torch.from_numpy(x_va_n)),
                            batch_size=batch_size, shuffle=False)

    # 4) 模型
    model = MLPAutoencoder(D, leaky_slope=args.leaky_slope).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    best_val = float("inf")
    best_state = None
    arch = [D, 5, 3, 2, 3, 5, D] if D > 5 else [D, 3, 2, 3, D]
    print(f"[训练] device={device} epochs={args.epochs} batch={batch_size} "
          f"lr={args.lr} l1={args.l1} arch=({'->'.join(str(h) for h in arch)})")

    for epoch in range(1, args.epochs + 1):
        model.train()
        total = 0.0
        for (xb,) in train_loader:
            xb = xb.to(device)
            optimizer.zero_grad()
            recon = model(xb)
            mse = F.mse_loss(recon, xb)
            l1 = sum(p.abs().sum() for p in model.parameters())
            loss = mse + args.l1 * l1
            loss.backward()
            optimizer.step()
            total += mse.item()
        model.eval()
        v = 0.0
        with torch.no_grad():
            for (xb,) in val_loader:
                xb = xb.to(device)
                v += F.mse_loss(model(xb), xb).item()
        v /= len(val_loader)
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total/len(train_loader):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 5) 阈值：健康训练+验证集「窗口均值重构误差」的适中百分位（默认 P95）
    x_trva_n = np.concatenate([x_tr_n, x_va_n], axis=0)
    thr = compute_threshold(model, x_trva_n, device, batch_size,
                            window=args.window, percentile=args.thr_percentile)

    # 内部健康集（15%）的重构误差，仅作参考
    x_te_n = std.transform(x_te).astype(np.float32)
    te_err = recon_error(model, x_te_n, device, batch_size)
    print(f"[阈值] tau=P{args.thr_percentile:g}(窗口均值)={thr:.6f}  "
          f"(健康内部测试集逐点重构误差 mean={te_err.mean():.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"input_dim": D, "leaky_slope": args.leaky_slope},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": float(thr),
        "best_val_mse": float(best_val),
        "args": vars(args),
    }
    os.makedirs(MODELS_DIR, exist_ok=True)
    ckpt_path = os.path.join(MODELS_DIR, f"{dataset}_mlp_ae.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] 模型已保存: {ckpt_path}")

    return model, std, thr, device, batch_size


def recon_error(model, x_np, device, batch_size):
    """逐样本重构误差 MSE：(N,) 标量。"""
    model.eval()
    errs = []
    with torch.no_grad():
        for i in range(0, len(x_np), batch_size):
            xb = torch.from_numpy(x_np[i:i + batch_size]).to(device)
            recon = model(xb)
            errs.append(((recon - xb) ** 2).mean(dim=1).cpu().numpy())
    return np.concatenate(errs)


def compute_threshold(model, x_std, device, batch_size,
                      window=WINDOW, percentile=95.0):
    """阈值 = 健康「窗口均值重构误差」的适中百分位（默认 P95）。

    论文原文用逐点 P99.7，但该阈值对这套数据过严（异常信号为整窗中等偏高，
    够不到极端尾部），导致 recall=0。改为窗口均值分数 + 适中百分位。

    x_std : (T, D) 已用健康训练集标准化器标准化后的健康数据。
    """
    err = recon_error(model, x_std, device, batch_size)      # (T,) 逐点
    n_win = len(err) // window
    if n_win == 0:
        raise ValueError("健康样本不足以切分窗口")
    win_score = err[:n_win * window].reshape(n_win, window).mean(axis=1)
    return float(np.percentile(win_score, percentile))


# ---------------------------------------------------------------------------
# 评估
# ---------------------------------------------------------------------------
def evaluate(model, std, thr, dataset, test_seed, device, batch_size):
    path = os.path.join(TEST_DATA, dataset, f"test_seed{test_seed}.npz")
    z = np.load(path, allow_pickle=False)
    x_raw = z["x"].astype(np.float32)          # (N, 10, D) 原始量纲
    y_true = z["y_true"].astype(np.int64)      # 0=正常 / 1=异常
    N, T, D = x_raw.shape

    # 用本方法（健康训练集拟合）的标准化器，而非测试集内携带的 LSTM 标准化器
    x_std = std.transform(x_raw.reshape(-1, D)).reshape(N, T, D)

    # 逐样本重构误差 (N, T)
    err = recon_error(model, x_std.reshape(-1, D), device, batch_size).reshape(N, T)

    # 窗口分数（连续量，用于 AUC 与判定）= 窗口内逐点重构误差的均值
    score = err.mean(axis=1)

    # 判定：窗口均值分数 > 阈值 τ（τ 为健康窗口均值分数的适中百分位）
    y_pred = (score > thr).astype(np.int64)

    return compute_metrics(y_true, y_pred, score), score, y_pred, y_true


def compute_metrics(y_true, y_pred, score):
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    specificity = tn / max(tn + fp, 1)
    recall = tp / max(tp + fn, 1)
    precision = tp / max(tp + fp, 1)
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    try:
        auc = roc_auc_score(y_true, score)
    except ValueError:
        auc = float("nan")
    return {
        "accuracy": float(accuracy),
        "specificity": float(specificity),
        "recall": float(recall),
        "precision": float(precision),
        "f1_score": float(f1),
        "auc_roc": float(auc),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp),
                             "fn": int(fn), "tp": int(tp)},
    }


def print_metrics(dataset, test_seed, m):
    print(f"\n[结果] {dataset} / test_seed={test_seed}")
    print(f"  Accuracy   = {m['accuracy']:.4f}")
    print(f"  Specificity= {m['specificity']:.4f}")
    print(f"  Recall     = {m['recall']:.4f}")
    print(f"  Precision  = {m['precision']:.4f}")
    print(f"  F1         = {m['f1_score']:.4f}")
    print(f"  AUC-ROC    = {m['auc_roc']:.4f}")
    cm = m["confusion_matrix"]
    print(f"  [TN={cm['tn']} FP={cm['fp']} | FN={cm['fn']} TP={cm['tp']}]")


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# ---------------------------------------------------------------------------
# 汇总
# ---------------------------------------------------------------------------
METRIC_KEYS = ["accuracy", "specificity", "recall", "precision", "f1_score", "auc_roc"]


def summarize(all_metrics):
    """all_metrics: list[dict] -> {key: {mean, std}}"""
    summary = {}
    for k in METRIC_KEYS:
        vals = np.array([m[k] for m in all_metrics], dtype=float)
        summary[k] = {"mean": float(np.nanmean(vals)), "std": float(np.nanstd(vals))}
    return summary


def print_summary(title, all_metrics):
    s = summarize(all_metrics)
    print(f"\n{title}（n={len(all_metrics)} 个测试 seed）")
    for k in METRIC_KEYS:
        print(f"  {k:<12} {s[k]['mean']:.4f} ± {s[k]['std']:.4f}")
    return s


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def run_dataset(dataset, args):
    """训练 + 测试集评估一个数据集，返回 (per_seed_metrics, summary)。"""
    t0 = time.time()
    model, std, thr, device, batch_size = train(dataset, args)

    seeds = TEST_SEEDS if args.test_seed is None else [args.test_seed]
    all_metrics = []
    for ts in seeds:
        m, score, y_pred, y_true = evaluate(
            model, std, thr, dataset, ts, device, batch_size)
        print_metrics(dataset, ts, m)
        all_metrics.append(m)

        os.makedirs(RESULTS_DIR, exist_ok=True)
        out = {"dataset": dataset, "test_seed": ts, "threshold": thr,
               "metrics": m, "args": vars(args)}
        with open(os.path.join(RESULTS_DIR, f"{dataset}_seed{ts}_metrics.json"),
                  "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)

    summary = print_summary(f"[{dataset}] 跨测试 seed 汇总", all_metrics) \
        if len(all_metrics) > 1 else summarize(all_metrics)
    with open(os.path.join(RESULTS_DIR, f"{dataset}_summary.json"),
              "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"[{dataset}] 训练+评估耗时 {time.time() - t0:.1f}s")
    return all_metrics, summary


def main():
    ap = argparse.ArgumentParser(description="Sensors 2025 MLP-AE 故障检测复现")
    ap.add_argument("--dataset", type=str, default="all",
                    choices=["all"] + list(DATASETS),
                    help="数据集（默认 all = 依次跑 dataset1 与 dataset2）")
    ap.add_argument("--test-seed", type=int, default=None,
                    help=f"单个测试 seed（默认 None = 全部 {TEST_SEEDS} 个并汇总 mean±std）")
    ap.add_argument("--seed", type=int, default=42, help="训练划分/初始化随机种子")
    ap.add_argument("--epochs", type=int, default=150, help="训练轮数（methodology: 150）")
    ap.add_argument("--batch-size", type=int, default=None,
                    help="batch 大小（默认 None=自动：目标每 epoch ~200 个 batch，夹在 [256,8192]）")
    ap.add_argument("--lr", type=float, default=1e-3, help="Adam 学习率")
    ap.add_argument("--l1", type=float, default=1e-3, help="L1 权重正则系数（methodology: 0.001）")
    ap.add_argument("--leaky-slope", type=float, default=0.01, help="LeakyReLU 负斜率")
    ap.add_argument("--thr-percentile", type=float, default=95.0,
                    help="阈值分位（作用于健康「窗口均值」重构误差，默认 95=适中；"
                         "论文原文 99.7 过严会致 recall≈0）")
    ap.add_argument("--window", type=int, default=WINDOW,
                    help="窗口长度（采样点数，默认 10，与测试集一致）")
    ap.add_argument("--max-train-samples", type=int, default=None,
                    help="健康训练样本上限（dataset2 约 123 万样本，可用其提速）")
    ap.add_argument("--device", type=str, default="", help="cuda / cpu（默认自动）")
    args = ap.parse_args()

    datasets = list(DATASETS) if args.dataset == "all" else [args.dataset]
    all_summaries = {}
    for ds in datasets:
        all_summaries[ds] = run_dataset(ds, args)[1]

    if len(datasets) > 1:
        print("\n" + "=" * 72)
        print("两个数据集结果对比（mean ± std over 测试 seed）")
        print("=" * 72)
        header = f"{'指标':<12}" + "".join(f"{ds:>24}" for ds in datasets)
        print(header)
        print("-" * 72)
        for k in METRIC_KEYS:
            row = f"{k:<12}"
            for ds in datasets:
                s = all_summaries[ds]
                row += f"  {s[k]['mean']:.4f} ± {s[k]['std']:.4f}"
            print(row)
        print("=" * 72)
        with open(os.path.join(RESULTS_DIR, "all_datasets_summary.json"),
                  "w", encoding="utf-8") as f:
            json.dump(all_summaries, f, ensure_ascii=False, indent=2)
        print("对比汇总已保存: results/all_datasets_summary.json")


if __name__ == "__main__":
    main()
