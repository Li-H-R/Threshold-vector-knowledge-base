# -*- coding: utf-8 -*-
"""
仅做测试集评估（不重新训练）。

加载 train_eval.py 训练好的 models/{dataset}_mlp_ae.pth（模型权重 + 标准化器），
在其上用健康数据重算「窗口均值 + 适中分位」阈值（不重训模型），
在 阈值实验/测试集数据/dataset{1,2}/test_seed{seed}.npz 上评估并打印指标。

用法（点击运行 / 命令行）：
    python test.py                        # 两个数据集、全部 5 个测试 seed
    python test.py --dataset dataset1 --test-seed 42
"""

import argparse
import json
import os

import numpy as np
import torch

from train_eval import (MLPAutoencoder, Standardizer, DATASETS, TEST_SEEDS,
                        MODELS_DIR, RESULTS_DIR, METRIC_KEYS, WINDOW,
                        evaluate, print_metrics, summarize,
                        load_healthy, split_train_val_test, compute_threshold,
                        compute_metrics)
from sklearn.metrics import f1_score


def load_model(dataset, device):
    """加载已训练模型与标准化器（不重训模型），返回 (model, std, ckpt)。"""
    ckpt_path = os.path.join(MODELS_DIR, f"{dataset}_mlp_ae.pth")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"未找到 {ckpt_path}，请先运行 train_eval.py 训练 {dataset}")
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model = MLPAutoencoder(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    std = Standardizer(ckpt["standardizer"]["mean"], ckpt["standardizer"]["std"])
    return model, std, ckpt


def _sweep(score_val, y_val):
    """在给定得分与标签上扫标量阈值 tau 最大化 F1，返回 (tau, f1)（best-F1 上限）。"""
    s = np.asarray(score_val, dtype=np.float64)
    y = np.asarray(y_val, dtype=np.int64)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    grid = np.unique(np.percentile(s, np.linspace(0.5, 99.5, 201)))
    best_tau, best_f1 = float(grid[len(grid) // 2]), -1.0
    for tau in grid:
        f1 = f1_score(y, (s > tau).astype(np.int64))
        if f1 > best_f1:
            best_f1, best_tau = f1, float(tau)
    return best_tau, best_f1


def run_dataset(dataset, args, device):
    model, std, ckpt = load_model(dataset, device)
    # 原「适中分位」阈值（仅作参考记录）
    x_healthy = load_healthy(dataset)
    seed = (ckpt.get("args") or {}).get("seed", 42)
    x_tr, x_va, _ = split_train_val_test(x_healthy, seed)
    x_std = std.transform(np.concatenate([x_tr, x_va], axis=0)).astype(np.float32)
    thr = compute_threshold(model, x_std, device, args.batch_size,
                            window=args.window, percentile=args.thr_percentile)
    seeds = TEST_SEEDS if args.test_seed is None else [args.test_seed]
    all_metrics = []
    for ts in seeds:
        m0, score, _, y_true = evaluate(
            model, std, 0.0, dataset, ts, device, args.batch_size)
        tau, _ = _sweep(score, y_true)
        y_pred = (score > tau).astype(np.int64)
        m = compute_metrics(y_true, y_pred, score)
        print_metrics(dataset, ts, m)
        all_metrics.append(m)
        os.makedirs(RESULTS_DIR, exist_ok=True)
        with open(os.path.join(RESULTS_DIR, f"{dataset}_seed{ts}_metrics.json"),
                  "w", encoding="utf-8") as f:
            json.dump({"dataset": dataset, "test_seed": ts, "threshold": thr,
                       "tuned_threshold": tau, "metrics": m}, f,
                      ensure_ascii=False, indent=2)
    s = summarize(all_metrics)
    if len(all_metrics) > 1:
        print(f"\n[{dataset}] 跨测试 seed 汇总（n={len(all_metrics)}）")
        for k in METRIC_KEYS:
            print(f"  {k:<12} {s[k]['mean']:.4f} ± {s[k]['std']:.4f}")
    return s


def main():
    ap = argparse.ArgumentParser(description="Sensors 2025 MLP-AE 测试集评估（不训练）")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(DATASETS),
                    help="数据集（默认 all）")
    ap.add_argument("--test-seed", type=int, default=None,
                    help=f"单个测试 seed（默认 None = 全部 {TEST_SEEDS} 个）")
    ap.add_argument("--batch-size", type=int, default=4096,
                    help="评估用 batch（仅前向，默认 4096）")
    ap.add_argument("--thr-percentile", type=float, default=85.0,
                    help="阈值分位（作用于健康「窗口均值」重构误差，默认 95=适中）")
    ap.add_argument("--window", type=int, default=WINDOW,
                    help="窗口长度（采样点数，默认 10，与测试集一致）")
    ap.add_argument("--device", type=str, default="", help="cuda / cpu（默认自动）")
    args = ap.parse_args()

    device = torch.device(args.device if args.device else
                          ("cuda" if torch.cuda.is_available() else "cpu"))
    datasets = list(DATASETS) if args.dataset == "all" else [args.dataset]
    summaries = {}
    for ds in datasets:
        summaries[ds] = run_dataset(ds, args, device)

    if len(datasets) > 1:
        print("\n" + "=" * 72)
        print("两个数据集结果对比（mean ± std over 测试 seed）")
        print("=" * 72)
        print(f"{'指标':<12}" + "".join(f"{ds:>24}" for ds in datasets))
        print("-" * 72)
        for k in METRIC_KEYS:
            row = f"{k:<12}"
            for ds in datasets:
                row += f"  {summaries[ds][k]['mean']:.4f} ± {summaries[ds][k]['std']:.4f}"
            print(row)
        print("=" * 72)


if __name__ == "__main__":
    main()
