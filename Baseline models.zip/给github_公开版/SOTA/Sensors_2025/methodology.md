# 风力发电机故障检测模型复现指南 (通用版本)

本文档提炼自论文 *Wind Turbine Fault Detection Through Autoencoder-Based Neural Network and FMSA* (Sensors 2025)，抽取了基于自编码器 (Autoencoder) 进行无监督故障检测的通用方法学流程。

## 1. 整体架构与策略

本方法采用 **“单设备/组件 - 单故障模式” 的专用自编码器** 组合策略。

* **模型类型**：多层感知机自编码器 (MLP Autoencoder)。

* **训练原则**：**仅使用健康（正常运行）数据** 进行无监督训练。

* **检测逻辑**：利用重构误差 (Reconstruction Error, MSE) 配合百分位数阈值与时间持久性 (Temporal Persistence) 规则判定异常。

```
[传感数据采集与 Z-Score 标准化]
              │
              ▼ (仅健康数据训练)
[自编码器模型训练 (MLP Autoencoder)]
              │
              ▼ (计算重构误差 MSE)
[异常阈值判定 (P99.7) + 20点时间持久性过滤] ──► [故障诊断输出]
```

## 2. 通用数据预处理 (Data Preprocessing)

1. **健康数据提取**：

   * 提取无故障历史时段的数据用于训练模型。

2. **Z-Score 标准化**：

   * **仅基于健康训练集** 计算特征均值 $\mu$ 与标准差 $\sigma$，对所有数据集（训练集、验证集、测试集）进行统一标准化：
     

     $$
     z = \frac{x - \mu}{\sigma}
     $$

## 3. 通用自编码器模型配置 (Autoencoder Architecture)

### 3.1 网络结构设计

采用对称式瓶颈 (Bottleneck) 结构，隐藏层层数一般为 3~5 层：

* **低维输入 (特征数** $N_{in} \le 5$**)**：

  * **Encoder**: $N_{in} \to 3 \to 2$ (Bottleneck)

  * **Decoder**: $2 \to 3 \to N_{out}$ ($N_{out} = N_{in}$)

  * **隐藏层节点**: `(3, 2, 3)`

* **较高维输入 (特征数** $N_{in} \ge 6$**)**：

  * **Encoder**: $N_{in} \to 5 \to 3 \to 2$ (Bottleneck)

  * **Decoder**: $2 \to 3 \to 5 \to N_{out}$ ($N_{out} = N_{in}$)

  * **隐藏层节点**: `(5, 3, 2, 3, 5)`

### 3.2 超参数 (Hyperparameters)

* **损失函数 (Loss Function)**：均方误差 MSE
  

  $$
  \text{MSE} = \frac{1}{n} \sum_{i=1}^{n} (x_i - \hat{x}_i)^2
  $$

* **优化器 (Optimizer)**：Adam

* **激活函数 (Activation Function)**：LeakyReLU

* **权重初始化 (Initializer)**：HeNormal

* **正则化 (Regularization)**：L1 权重正则化 (`l1=0.001`)

* **训练轮数 (Epochs)**：150

* **数据集划分**：训练集 70% | 验证集 15% | 测试集 15%

## 4. 故障检测与持久性判定规则 (Fault Detection Strategy)

### 4.1 阈值确定 (Threshold $\tau$)

模型训练完成后，输入**健康训练/验证集**数据，计算所有健康样本的重构误差集合 $\epsilon = \{\epsilon_1, \epsilon_2, \dots, \epsilon_k\}$。采用非参数百分位数法取 **99.7% 分位数** 作为异常判定上限：

$$
\tau = P_{99.7}(\epsilon)
$$

### 4.2 时间持久性规则 (Temporal Persistence Rule)

为了过滤瞬态波动与传感器噪声，采用固定大小的滑动窗口 $n$（论文中取 $n = 20$ 个连续采样点）：

* **触发故障状态 (**$0 \to 1$**)**：
  当连续 $n$ 个样本的重构误差**全部**超过阈值（$\epsilon_j > \tau$）时，系统切换为 **Fault (1)** 状态。

* **恢复正常状态 (**$1 \to 0$**)**：
  当连续 $n$ 个样本的重构误差**全部**低于阈值（$\epsilon_j < \tau$）时，系统切回 **Normal (0)** 状态。