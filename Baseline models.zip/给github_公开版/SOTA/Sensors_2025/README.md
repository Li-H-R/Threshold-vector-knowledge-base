# Sensors 2025 —— MLP 自编码器故障检测复现

复现论文 *Wind Turbine Fault Detection Through Autoencoder-Based Neural Network and FMSA*
(Sensors 2025) 的通用方法学（见 [methodology.md](methodology.md)）：

```text
[健康数据提取] -> [Z-Score 标准化] -> [MLP 自编码器训练(仅健康数据)]
        -> [重构误差 MSE] -> [窗口均值分数 + 适中百分位阈值] -> [异常判定]
```

## 方法要点（对应 methodology.md 章节）

| 组件 | 取值 |
| --- | --- |
| 模型 | MLP 自编码器，仅用健康数据无监督训练 |
| 结构（N_in≥6） | Encoder `N_in→5→3→2`，Decoder `2→3→5→N_out`，隐藏节点 `(5,3,2,3,5)` |
| 结构（N_in≤5） | Encoder `N_in→3→2`，Decoder `2→3→N_out`，隐藏节点 `(3,2,3)` |
| 损失 / 优化器 | MSE + L1 权重正则(0.001) / Adam |
| 激活 / 初始化 | LeakyReLU / HeNormal(kaiming normal, a=0) |
| 轮数 / 划分 | 150 epoch / 70%·15%·15% |
| 阈值 | 健康训练+验证集**窗口均值**重构误差的 **适中百分位（默认 P95，可调）** |
| 判定 | 窗口均值分数 > 阈值 τ 即判异常（窗口长度 10；论文的逐点 P99.7+持久性见下方说明） |

## 数据集与测试集

| 数据集 | 时间分辨率 | 特征维 D | 训练（健康）数据 | 测试集 |
| --- | --- | --- | --- | --- |
| `dataset1` | 1 分钟级 | 8 | `_shared/data/raw_data.npy`（去掉末 2 列非特征列） | `测试集数据/dataset1/test_seed{seed}.npz` |
| `dataset2` | 秒级 | 15 | `_shared/data/new_raw_data.npy`（全部 15 列） | `测试集数据/dataset2/test_seed{seed}.npz` |

- 训练数据均为**健康（正常）运行**数据（异常在独立的《真实异常数据》标注集里，测试集已含正常+异常）。
- 测试集 `test_seed{seed}.npz` 自包含：`x`(原始量纲 N×10×D) / `y_true`(0 正常 / 1 异常) / `y_type` / `mean` / `std`。
  **注意**：测试集内携带的 `mean/std` 来自本项目 LSTM 管线的标准化器；本复现按 methodology
  要求**只用健康训练集重新拟合 mean/std**，对测试 `x` 自行标准化（不用测试集内的 `x_std`）。

## 关于「窗口均值分数 + 适中阈值」（对论文判定规则的改动）

论文 4.2 的判定是「逐点重构误差超过 P99.7 阈值 + 连续 n=20 点持久性」。但对本仓库这两套
测试数据，该规则实测会得到 **recall=0**：

- dataset1 的异常信号是**整窗一致性的中等偏高**（窗口均值重构误差 0.65 vs 正常 0.056），
  但**没有任何单个点**能摸到 P99.7 阈值（τ≈5.5），所以逐点判定 + 20 连点持久性完全失明。
- dataset2 本身无信号（AUC≈0.54），任何阈值都救不回来。

因此本复现把判定层改为「**窗口均值分数 + 适中百分位阈值**」：

1. 分数 = 每个测试窗口内 10 个采样点重构误差的**均值**（窗口均值本身就起平滑/持久性作用）。
2. 阈值 τ = 健康训练+验证集「窗口均值分数」的适中百分位（默认 **P95**，`--thr-percentile` 可调）。
3. `score > τ` → 异常。

默认 P95 在本数据上的效果（5 个测试 seed 汇总）：

| 数据集 | AUC | Recall | Specificity | F1 |
| --- | --- | --- | --- | --- |
| dataset1 | 0.86 | 0.54 | 0.92 | 0.67 |
| dataset2 | 0.54 | 0.27 | 0.84 | 0.38 |

分位越低召回越高、误报越多：dataset1 用 `--thr-percentile 90` 可达 F1≈0.73（Recall 0.63 /
Specificity 0.90），`--thr-percentile 99` 则回落到 F1≈0.47。dataset2 无论怎么调都在随机附近。

## 运行

> 请使用已安装 PyTorch、NumPy 和 scikit-learn 的 Python 环境。

```bash
# 点运行 / 直接运行：依次训练并评估两个数据集（默认对全部 5 个测试 seed 汇总），
# 最后打印两数据集对比表
python train_eval.py

# 只跑单个数据集
python train_eval.py --dataset dataset1

# 已训练好后，只做测试集评估（不重复训练）
python test.py

# 数据集二样本多（约 123 万），可子采样提速
python train_eval.py \
    --max-train-samples 200000 --epochs 150

# 阈值分位默认 P95（适中）；调低提召回、调高降误报
python train_eval.py --thr-percentile 90
```

主要参数：`--dataset`(all/dataset1/dataset2)、`--test-seed`(None=全部 5 个)、
`--epochs`、`--batch-size`、`--lr`、`--l1`、`--leaky-slope`、`--thr-percentile`(默认 95)、
`--window`(默认 10)、`--max-train-samples`、`--device`。

> **速度**：`--batch-size` 默认自动——目标每 epoch ~200 个 batch、夹在 [256, 8192]，
> dataset1 自动 256、dataset2 自动约 4327，避免 dataset2 小 batch 跑 50 万步。
> 也可手动指定，如 `--batch-size 8192`。

## 两个脚本

- `train_eval.py`：训练 + 测试集评估，默认跑两个数据集并输出对比表。
- `test.py`：只加载 `models/{dataset}_mlp_ae.pth` 做测试集评估（不训练），
  「测试集代码」都在这里——`evaluate()` 读 `测试集数据/dataset{1,2}/test_seed{seed}.npz`。

## 输出

- `models/{dataset}_mlp_ae.pth`：模型权重 + 结构 + 标准化器 + 阈值 τ。
- `results/{dataset}_seed{seed}_metrics.json`：Accuracy / Specificity / Recall /
  Precision / F1 / AUC-ROC / 混淆矩阵。
- `results/{dataset}_summary.json`：跨测试 seed 的 mean±std。
- `results/all_datasets_summary.json`：两数据集对比表。
