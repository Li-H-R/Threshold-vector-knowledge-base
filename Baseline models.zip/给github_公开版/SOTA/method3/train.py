# -*- coding: utf-8 -*-
"""
CA-SCINet —— 坐标注意力 + 堆叠式 SCINet + MC Dropout/KDE 自适应阈值 训练脚本
=============================================================================
方法来源：Condition monitoring of wind turbine based on a novel spatio-temporal
feature aggregation network integrated with adaptive threshold interval（AEI 2024）。

方法要点（保留原文完整阈值策略）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 坐标注意力（CA，1D 版）：沿「通道」与「时间」两方向全局池化 + 独立映射 +
     Sigmoid，生成 g_c ⊗ g_t 两方向注意力加权输入（对应原文 CA 对空间/通道依赖编码）。
  3. SCIBlock：奇偶子序列拆分 → 交叉缩放 odd ⊙ exp(φ(even)) → 交叉加减 ±ρ/η →
     交错还原。逐块堆叠 num_blocks 层。
  4. 原文为「输入 128 步预测未来 6 步」；为适配平衡测试集（独立窗口、无未来上下文）
     改为「窗口自重构」监督，但保留其在线 MC Dropout 不确定性量化：
     对同一窗口做 mc_samples 次启用 Dropout 的随机前向，得到预测均值 ŷ 与标准差 σ。
  5. 得分 = 每个窗口的标准化重构残差 mean(|x - ŷ| / (σ + eps))（对应原文用 T 次
     MC Dropout 预测的 KDE 分布衡量「实际值离预测分布多远」）。
  6. 阈值 = 高斯核 KDE 的 (1-α) 置信区间半宽 z_{1-α/2}（默认 α=0.05 → 1.96），
     score > z_{1-α/2} 判异常（对应原文「测量值超出 95% 置信区间」）。
     （原文「连续 6 点越界报警」已按要求改为单次越界（1 次）判定：窗口得分
       score 一次性与阈值比较，不要求连续多点越界。）

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --epochs 100 --mc-samples 20
"""

import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import norm

SOTA_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "..", "SOTA"))
sys.path.insert(0, SOTA_DIR)
import common as C


# ---------------------------------------------------------------------------
# 基础卷积模块（ReplicationPad -> DilatedConv -> Mish -> Dropout -> Conv -> Tanh）
# ---------------------------------------------------------------------------
class ConvModule(nn.Module):
    def __init__(self, in_ch, out_ch, kernel=5, kernel2=3, dilation=2, dropout=0.2):
        super().__init__()
        pad_d = (kernel - 1) * dilation
        self.pad1 = nn.ReplicationPad1d((pad_d // 2, pad_d - pad_d // 2))
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel, dilation=dilation)
        self.mish = nn.Mish()
        self.dropout = nn.Dropout(dropout)
        pad2 = kernel2 - 1
        self.pad2 = nn.ReplicationPad1d((pad2 // 2, pad2 - pad2 // 2))
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel2)

    def forward(self, x):
        x = self.conv1(self.pad1(x))
        x = self.mish(x)
        x = self.dropout(x)
        x = self.conv2(self.pad2(x))
        return torch.tanh(x)


# ---------------------------------------------------------------------------
# 坐标注意力（1D 版）
# ---------------------------------------------------------------------------
class CoordAtt(nn.Module):
    """沿通道与时间两方向做全局池化 + 独立映射 + Sigmoid，加权输入特征图。"""

    def __init__(self, channels, T, reduction=4):
        super().__init__()
        self.fc_c = nn.Sequential(
            nn.Linear(channels, max(1, channels // reduction)), nn.ReLU(),
            nn.Linear(max(1, channels // reduction), channels))
        self.fc_t = nn.Sequential(
            nn.Linear(T, max(1, T // reduction)), nn.ReLU(),
            nn.Linear(max(1, T // reduction), T))

    def forward(self, x):
        # x: (B, C, T)
        g_c = torch.sigmoid(self.fc_c(x.mean(dim=2))).unsqueeze(-1)   # (B, C, 1)
        g_t = torch.sigmoid(self.fc_t(x.mean(dim=1))).unsqueeze(1)    # (B, 1, T)
        return x * g_c * g_t


# ---------------------------------------------------------------------------
# SCI 交互块（无门控）
# ---------------------------------------------------------------------------
class SCIBlock(nn.Module):
    """长度保持的 SCIBlock：奇偶拆分 -> 交叉缩放/加减 -> 交错还原。"""

    def __init__(self, channels, kernel=5, kernel2=3, dilation=2, dropout=0.2):
        super().__init__()
        self.phi = ConvModule(channels, channels, kernel, kernel2, dilation, dropout)
        self.delta = ConvModule(channels, channels, kernel, kernel2, dilation, dropout)
        self.rho = ConvModule(channels, channels, kernel, kernel2, dilation, dropout)
        self.eta = ConvModule(channels, channels, kernel, kernel2, dilation, dropout)

    def forward(self, x):
        B, C, L = x.shape
        odd = x[:, :, 0::2]
        even = x[:, :, 1::2]

        odd_s = odd * torch.exp(self.phi(even))
        even_s = even * torch.exp(self.delta(odd))

        odd2 = odd_s + self.rho(even_s)
        even2 = even_s - self.eta(odd_s)

        out = x.new_empty((B, C, L))
        out[:, :, 0::2] = odd2
        out[:, :, 1::2] = even2
        return out


# ---------------------------------------------------------------------------
# CA-SCINet 网络
# ---------------------------------------------------------------------------
class CA_SCINet(nn.Module):
    def __init__(self, D, T, hidden=16, num_blocks=3, kernel=5, kernel2=3,
                 dilation=2, dropout=0.2):
        super().__init__()
        self.embed = nn.Conv1d(D, hidden, 1)
        self.ca = CoordAtt(hidden, T)
        self.blocks = nn.ModuleList(
            [SCIBlock(hidden, kernel, kernel2, dilation, dropout) for _ in range(num_blocks)])
        self.head = nn.Conv1d(hidden, D, 1)

    def forward(self, x):
        # x: (B, T, D) -> (B, T, D) 自重构
        x = x.transpose(1, 2)                    # (B, D, T)
        h = self.embed(x)                        # (B, hidden, T)
        h = self.ca(h)
        for blk in self.blocks:
            h = blk(h)
        return self.head(h).transpose(1, 2)      # (B, T, D)


# ---------------------------------------------------------------------------
# MC Dropout 不确定性
# ---------------------------------------------------------------------------
def mc_predict(model, x, mc_samples):
    """x: (B, T, D) 标准化 -> (mean, sigma) 各 (B, T, D)。mc_samples 次随机前向。"""
    device = next(model.parameters()).device
    model.train()                               # 启用 dropout
    xb = torch.from_numpy(x).to(device)
    preds = []
    with torch.no_grad():
        for _ in range(mc_samples):
            preds.append(model(xb))
    preds = torch.stack(preds)                  # (S, B, T, D)
    return preds.mean(dim=0).cpu().numpy(), preds.std(dim=0).cpu().numpy()


# ---------------------------------------------------------------------------
# 得分（标准化重构残差）
# ---------------------------------------------------------------------------
def score_windows(model, windows, std, device, batch_size, mc_samples, seed):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,) = mean(|x-ŷ|/(σ+eps))。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    scores = []
    for i in range(0, N, batch_size):
        xb = x[i:i + batch_size]
        mean, sigma = mc_predict(model, xb, mc_samples)
        res = np.abs(xb - mean) / (sigma + 1e-6)
        scores.append(res.reshape(len(xb), -1).mean(axis=1))
    model.eval()
    return np.concatenate(scores)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW

    x_all = C.load_healthy_windows(dataset, window=T, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32)
    va = std.transform(w_va).astype(np.float32)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) D={D} T={T}")

    model = CA_SCINet(D, T, hidden=args.hidden, num_blocks=args.num_blocks,
                      kernel=args.kernel, kernel2=args.kernel2,
                      dilation=args.dilation, dropout=args.dropout).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or 256

    tr_t = torch.from_numpy(tr)
    va_t = torch.from_numpy(va)
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr} "
          f"hidden={args.hidden} blocks={args.num_blocks}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            optimizer.zero_grad()
            loss = nn.functional.mse_loss(model(xb), xb)
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            v = nn.functional.mse_loss(model(va_t.to(device)), va_t.to(device)).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total / len(tr_t):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # KDE 置信区间半宽：高斯核 KDE 的 (1-α) 置信区间对应标准化残差阈值 z_{1-α/2}
    thr = float(norm.ppf(1.0 - args.alpha / 2.0))
    print(f"[阈值] KDE 置信区间半宽 z_{{1-alpha/2}}={thr:.6f}  (alpha={args.alpha}, 95% 置信水平)")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"D": D, "T": T, "hidden": args.hidden,
                         "num_blocks": args.num_blocks, "kernel": args.kernel,
                         "kernel2": args.kernel2, "dilation": args.dilation,
                         "dropout": args.dropout},
        "scoring": {"mc_samples": args.mc_samples, "seed": args.seed},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, std, thr


def main():
    ap = argparse.ArgumentParser(description="CA-SCINet 训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden", type=int, default=16)
    ap.add_argument("--num-blocks", type=int, default=3)
    ap.add_argument("--kernel", type=int, default=5)
    ap.add_argument("--kernel2", type=int, default=3)
    ap.add_argument("--dilation", type=int, default=2)
    ap.add_argument("--dropout", type=float, default=0.2)
    ap.add_argument("--mc-samples", type=int, default=20, help="MC Dropout 随机前向次数")
    ap.add_argument("--alpha", type=float, default=0.05, help="KDE 置信区间显著性水平")
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
