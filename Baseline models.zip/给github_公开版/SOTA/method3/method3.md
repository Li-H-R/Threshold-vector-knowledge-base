# 风力涡轮机状态监测论文复现：完整方法指南

**原始论文：** *Condition monitoring of wind turbine based on a novel spatio-temporal feature aggregation network integrated with adaptive threshold interval*（Elsevier AEI，2024）

---

## 1. 总体系统架构与运行流程

该状态监测框架分为两个主要阶段：**离线训练（Offline Training）**和**在线测试（Online Testing）**。

### 1.1 系统工作流程

```text
       离线训练（OFFLINE TRAINING）                 在线测试（ONLINE TESTING）

┌──────────────────────────────┐       ┌──────────────────────────────┐
│        历史 SCADA 数据        │       │         在线 SCADA 数据       │
└──────────────┬───────────────┘       └──────────────┬───────────────┘
               │                                      │
┌──────────────▼───────────────┐       ┌──────────────▼───────────────┐
│       卡尔曼滤波去噪          │       │       卡尔曼滤波去噪          │
└──────────────┬───────────────┘       └──────────────┬───────────────┘
               │                                      │
┌──────────────▼───────────────┐       ┌──────────────▼───────────────┐
│       Pearson 变量选择        │       │       变量选择与归一化        │
└──────────────┬───────────────┘       └──────────────┬───────────────┘
               │                                      │
┌──────────────▼───────────────┐       ┌──────────────▼───────────────┐
│   堆叠式 CA-SCINet 模型训练   │──────►│   堆叠式 CA-SCINet 模型推理   │
└──────────────────────────────┘       │    （启用蒙特卡洛 Dropout）   │
                                       └──────────────┬───────────────┘
                                                      │
                                       ┌──────────────▼───────────────┐
                                       │      高斯核密度估计（KDE）    │
                                       └──────────────┬───────────────┘
                                                      │
                                       ┌──────────────▼───────────────┐
                                       │       自适应阈值区间          │
                                       │       （95% 置信水平）        │
                                       └──────────────┬───────────────┘
                                                      │
                                       ┌──────────────▼───────────────┐
                                       │ 是否连续超出阈值区间？        │
                                       │       （≥ 6 个时间步）        │
                                       └──────┬───────────────┬──────┘
                                              │否             │是
                                              ▼               ▼
                                          （正常状态）      【故障报警】
```

---

## 2. 数据预处理与变量选择

### 2.1 卡尔曼滤波去噪

为了消除瞬态不稳定扰动和传感器测量噪声，对时间序列应用无监督卡尔曼滤波器。

**预测步骤（Prediction Step）：**

\[
\hat{x}_{t|t-1} = A\hat{x}_{t-1|t-1} + Bu_t
\]

\[
P_{t|t-1} = AP_{t-1|t-1}A^T + Q
\]

**更新步骤（Update Step）：**

\[
K_t = P_{t|t-1}H^T(HP_{t|t-1}H^T + R)^{-1}
\]

\[
\hat{x}_{t|t} = \hat{x}_{t|t-1} + K_t(z_t - H\hat{x}_{t|t-1})
\]

**变量与参数说明：**

- \(\hat{x}_{t|t-1}\)：时刻 \(t\) 的先验状态估计值。
- \(P_{t|t-1}\)：先验状态协方差矩阵。
- \(A\)：状态转移矩阵。
- \(u_t\)：控制信号。
- \(B\)：控制输入矩阵。
- \(Q\)：过程噪声协方差矩阵。
- \(K_t\)：卡尔曼增益。
- \(H\)：观测矩阵。
- \(R\)：观测噪声协方差矩阵。
- \(z_t\)：时刻 \(t\) 的观测测量信号。
- \(\hat{x}_{t|t}\)：时刻 \(t\) 的滤波后状态估计值。

---

### 2.2 特征选择与归一化

1. **Pearson 相关系数筛选**

   为减少特征冗余并避免欠拟合，计算各变量与目标状态之间的 Pearson 相关系数，并选择与目标状态相关性较高的特征：

   \[
   r =
   \frac{\sum_{i=1}^{n}(X_i-\bar{X})(Y_i-\bar{Y})}
   {\sqrt{\sum_{i=1}^{n}(X_i-\bar{X})^2}
   \sqrt{\sum_{i=1}^{n}(Y_i-\bar{Y})^2}}
   \]

2. **Min-Max 归一化**

   将筛选后的变量缩放至 \([0,1]\) 区间，以提高模型训练的稳定性：

   \[
   x_{\text{norm}} = \frac{x-x_{\text{min}}}{x_{\text{max}}-x_{\text{min}}}
   \]

---

### 2.3 案例研究中的特征与目标变量集合

#### 案例 I：变桨系统异常（Pitch System Anomaly）

- **选定输入特征（\(X_{\text{case1}}\)）：** 共 10 个变量：

  \[
  [X_5, X_7, X_8, X_9, X_{17}, X_{18}, X_{19}, X_{20}, X_{21}, X_{22}]
  \]

  - \(X_5\)：环境温度（Ambient temperature）
  - \(X_7\)：轮毂温度（Hub temperature）
  - \(X_8\)：轮毂控制柜温度（Hub control cabinet temperature）
  - \(X_9\)：机舱温度（Cabin temperature）
  - \(X_{17}, X_{18}, X_{19}\)：叶片 1/2/3 电池箱温度
  - \(X_{20}, X_{21}, X_{22}\)：叶片 1/2/3 变桨电机温度

- **输出目标（\(Y_{\text{case1}}\)）：** 机舱温度（\(X_9\)）。

#### 案例 II：变流器系统异常（Converter System Anomaly）

- **选定输入特征（\(X_{\text{case2}}\)）：** 共 11 个变量：

  \[
  [X_1, X_2, X_3, X_4, X_6, X_8, X_9, X_{10}, X_{11}, X_{21}, X_{22}]
  \]

  - \(X_1\)：轮毂转速（Hub speed）
  - \(X_2\)：超速传感器检测值（Overspeed sensor detection）
  - \(X_3\)：风速（Wind speed）
  - \(X_4\)：变流器电网侧电流（Converter grid-side current）
  - \(X_6\)：变流器电网侧有功功率（Converter grid-side active power）
  - \(X_8\)：变流器发电机侧功率（Converter generator-side power）
  - \(X_9\)：发电机转速（Generator speed）
  - \(X_{10}\)：发电机电流（Generator current）
  - \(X_{11}\)：发电机转矩（Generator torque）
  - \(X_{21}\)：变流器 INU 温度（Converter INU temperature）
  - \(X_{22}\)：变流器 ISU 温度（Converter ISU temperature）

- **输出目标（\(Y_{\text{case2}}\)）：** 变流器发电机侧有功功率（\(X_8\)）。

---

## 3. 深度学习架构：堆叠式 CA-SCINet

核心预测模型将坐标注意力（Coordinate Attention，CA）机制集成到 SCINet 的二叉树式“下采样—卷积—交互”结构中。

### 3.1 CA-SCINet 结构流程

```text
                   ┌─────────────────────────┐
                   │         输入张量         │
                   └────────────┬────────────┘
                                │
                   ┌────────────▼────────────┐
                   │       坐标注意力（CA）   │
                   └────────────┬────────────┘
                                │
                   ┌────────────▼────────────┐
                   │         奇偶拆分         │
                   └──────┬───────────┬──────┘
                          │           │
                 X_odd    │           │    X_even
                          ▼           ▼
                    ┌──────────┐ ┌──────────┐
                    │    φ     │ │    δ     │
                    └────┬─────┘ └────┬─────┘
                         │    Exp     │    Exp
                         └─────┐  ┌───┘
                               ▼  ▼
                        ┌─────────────┐
                        │      ⊙      │  （交互缩放）
                        └──────┬──────┘
                               │
                    ┌──────────┴──────────┐
                    │ X'_odd      X'_even │
                    └──────┬───────────┬──┘
                           │           │
                    ┌──────▼───┐   ┌───▼──────┐
                    │    η     │   │    ρ     │
                    └──────┬───┘   └───┬──────┘
                           └─────┐ ┌───┘
                                 ▼ ▼
                          ┌───────────┐
                          │     ⊕     │  （交互相加）
                          └─────┬─────┘
                                │
                   ┌────────────▼────────────┐
                   │ X''_odd      X''_even   │
                   └─────────────────────────┘
```

### 3.2 坐标注意力（CA）机制

CA 通过沿空间方向计算一维特征图，对空间依赖关系和通道依赖关系进行编码。

1. **方向性全局池化（Directional Global Pooling）**

   \[
   z_c^h(h) = \frac{1}{W}\sum_{0 \le i < W}x_c(h,i)
   \]

   \[
   z_c^w(w) = \frac{1}{H}\sum_{0 \le j < H}x_c(j,w)
   \]

2. **特征聚合（Feature Aggregation）**

   沿空间维度拼接特征，并应用 \(1\times1\) 卷积：

   \[
   f = \delta\left(F\left([z^h,z^w]\right)\right)
   \]

   其中，\(\delta\) 为 Sigmoid 激活函数，且：

   \[
   f \in \mathbb{R}^{(C/r)\times(H+W)}
   \]

   \(r\) 为通道缩减率。

3. **拆分与注意力权重生成（Split & Attention Weight Generation）**

   将 \(f\) 拆分为：

   \[
   f^h \in \mathbb{R}^{(C/r)\times H},\qquad
   f^w \in \mathbb{R}^{(C/r)\times W}
   \]

   随后计算：

   \[
   g^h = \delta(F_h(f^h))
   \]

   \[
   g^w = \delta(F_w(f^w))
   \]

   \[
   M(i,j)=g^h(i)\times g^w(j)
   \]

4. **输出特征图（Output Feature Map）**

   \[
   Y(i,j)=X(i,j)\times M(i,j)
   \]

---

### 3.3 CA-SCIBlock 模块

1. **奇偶下采样（Parity Downsampling）**

   将时间序列 \(X\in\mathbb{R}^{n\times t}\) 拆分为奇数位置子序列 \(X_{\text{odd}}\) 和偶数位置子序列 \(X_{\text{even}}\)：

   \[
   X_{\text{odd}}=[x_1,x_3,\dots,x_{2k-1}]
   \]

   \[
   X_{\text{even}}=[x_2,x_4,\dots,x_{2k}]
   \]

2. **一维卷积模块结构（1D Convolutional Module Structure）**

   每个卷积块由以下操作组成：

   \[
   \begin{aligned}
   &\text{ReplicationPad1D}\\
   &\rightarrow \text{1D-Dilated Conv (dilation=2, kernel=k)}\\
   &\rightarrow \text{Mish Activation}\\
   &\rightarrow \text{Dropout}(p)\\
   &\rightarrow \text{Conv1D (kernel=k)}\\
   &\rightarrow \text{Tanh}
   \end{aligned}
   \]

   从数学角度看，时间特征提取函数 \(\phi(x)\) 定义为：

   \[
   \phi(x)=\tanh\left(
   \text{Conv1D}\left(
   \text{Dropout}\left(
   \text{Mish}\left(\text{DilatedConv1D}(x)\right)
   \right)\right)\right)
   \]

3. **交互学习（Interactive Learning）**

   子序列通过逐元素缩放和相加交换特征。

   - **交叉缩放（Cross-scaling）：**

     \[
     X'_{\text{odd}} =
     X_{\text{odd}}\odot\exp(\varphi(X_{\text{even}}))
     \]

     \[
     X'_{\text{even}} =
     X_{\text{even}}\odot\exp(\delta(X_{\text{odd}}))
     \]

   - **交叉相加（Cross-addition）：**

     \[
     X''_{\text{odd}} =
     X'_{\text{odd}}\pm\rho(X'_{\text{even}})
     \]

     \[
     X''_{\text{even}} =
     X'_{\text{even}}\pm\eta(X'_{\text{odd}})
     \]

   其中，\(\varphi,\delta,\rho,\eta\) 表示不同的一维卷积模块；\(\odot\) 表示逐元素 Hadamard 积（逐元素乘积）。

---

### 3.4 堆叠网络与多阶段中间损失

1. **网络堆叠（Network Stacking）**

   将中间 CA-SCINet 模块的输出与原始输入中的目标切片拼接，然后输入后续 CA-SCINet 模块，以增加特征表示的深度。

2. **损失函数（Loss Function）**

   \[
   \mathcal{L}_{\text{total}} =
   \frac{1}{\lambda}
   \sum_{l=1}^{L}\sum_{i=0}^{\lambda}
   \left\Vert \hat{X}_i^l-X_i\right\Vert
   \]

   其中：

   - \(L\)：堆叠的 CA-SCINet 模块数量，\(L=2\)。
   - \(\lambda\)：中间阶段的输出长度。

---

## 4. 离线训练算法

```python
# 算法 1：所提出的堆叠式 CA-SCINet 的离线训练

输入：
    预处理后的数据集 X
    训练轮数 D
    学习率 r
    模块数量 L = 2
    CA-SCIBlock 层数 k = 3

输出：
    训练完成的网络模型 θ

1.  对数据集 X 进行归一化，并初始化网络参数 θ
2.  for epoch d = 1 to D do:
3.      for step = 1 to T do:
4.          for l = 1 to L do:
5.              计算 CA 注意力矩阵：
                M(i, j) = g^h(i) * g^w(j)
6.              应用 CA 加权：
                Y(i, j) = X(i, j) * M(i, j)
7.              应用 CA-SCIBlock 下采样与交互学习：
                X'_odd  = X_odd  ⊙ exp(φ(X_even))
                X'_even = X_even ⊙ exp(δ(X_odd))
                X''_odd  = X'_odd  ± ρ(X'_even)
                X''_even = X'_even ± η(X'_odd)
8.              计算第 l-1 个模块的输出 Y_(l-1)
9.          end for
10.         计算最终输出：
            Y_L = Y_(L-1) + X
11.         计算总损失：
            L_total = (1 / λ) * Σ_(l=1)^L Σ_(i=0)^λ
                      || X_hat_i^l - X_i ||
12.         更新梯度：
            θ = θ - r * ∇L_total
13.     end for
14. end for
```

---

## 5. 自适应故障阈值区间生成

### 5.1 在线概率推理策略

```text
                    在线输入向量
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
   前向传播 1          前向传播 2          前向传播 T
 （启用 Dropout）     （启用 Dropout）     （启用 Dropout）
        │                 │                 │
      Pred_1            Pred_2             Pred_T
        └─────────────────┼─────────────────┘
                          ▼
                 【KDE 概率密度曲线】
                          │
                          ▼
                    计算累积分布函数
                          │
                 ┌────────┴────────┐
                 ▼                 ▼
              Alpha/2          1-Alpha/2
              （下界 C1）       （上界 C2）
```

### 5.2 蒙特卡洛 Dropout 不确定性量化

在在线测试期间，保持 Dropout 层处于激活状态，将网络参数视为随机抽样结果：

\[
W_i\sim\text{Bernoulli}(p)
\]

给定 \(T\) 次随机推理：

- **预测均值（Predictive Point Mean）：**

  \[
  \hat{y}(x)=\frac{1}{T}\sum_{i=1}^{T}f(x,W_i)
  \]

- **预测模型不确定性方差（Predictive Model Uncertainty Variance）：**

  \[
  \sigma^2=\frac{1}{T}\sum_{i=1}^{T}
  \left(f(x,W_i)-\hat{y}(x)\right)^2
  \]

### 5.3 核密度估计（KDE）

利用 \(T\) 次预测结果：

\[
\{f(x,W_1),\dots,f(x,W_T)\}
\]

通过高斯核构建连续概率密度函数（PDF）：

\[
F(x,W_i)=\frac{1}{Th}
\sum_{i=1}^{T}
K\left(\frac{x-f(x,W_i)}{h}\right)
\]

高斯核函数为：

\[
K(u)=\frac{1}{\sqrt{2\pi}}
\exp\left(-\frac{u^2}{2}\right)
\]

其中，\(h\) 为带宽参数（bandwidth parameter）。

### 5.4 自适应阈值上下界与报警条件

1. **置信区间（Confidence Interval，CI）**

   给定显著性水平 \(\alpha\)（对于 95% 置信区间，\(\alpha=0.05\)）：

   \[
   \text{CI}=[C_1,C_2]
   =
   \left[
   F^{-1}\left(\frac{\alpha}{2}\right),
   F^{-1}\left(1-\frac{\alpha}{2}\right)
   \right]
   \]

   其中，\(F^{-1}\) 表示分位数函数（即累积分布函数 CDF 的反函数）。

2. **故障报警规则（Fault Alarm Rule）**

   当连续 \(N_{\text{consec}}\geq6\) 个测试点超出阈值区间时，确认发生异常：

   \[
   \text{Alarm}_t=
   \begin{cases}
   \text{True},&
   \text{若对所有 }\tau\in[t-5,t],\
   x_\tau<C_{1,\tau}\text{ 或 }x_\tau>C_{2,\tau}\\
   \text{False},&\text{否则}
   \end{cases}
   \]

---

## 6. 实现超参数规格

| 参数组件 | 指标 / 数值 | 说明 |
|---|---:|---|
| **输入窗口大小（Input Window Size）** | 128 | 输入序列的时间步数（\(N_{\text{in}}\)） |
| **输出目标步数（Output Target Steps）** | 6 | 多步预测长度（\(N_{\text{out}}\)） |
| **训练轮数（Training Epochs）** | 100 | 模型训练迭代轮数 |
| **批次大小（Batch Size）** | 32 | 小批量训练样本数 |
| **学习率（Learning Rate）** | \(1\times10^{-5}\) | Adam 优化器的学习率 |
| **优化器（Optimizer）** | Adam | 随机梯度优化器 |
| **MC Dropout 率（\(p\)）** | 0.2 | Dropout 随机丢弃权重的概率 |
| **CA-SCIBlock 层数（\(k\)）** | 3 | 每个模块内部的树结构层级参数 |
| **堆叠 SCINet 模块数（\(L\)）** | 2 | 级联 CA-SCINet 模块的数量 |
| **膨胀卷积核大小（Dilated Conv Kernel Size）** | 5 | 膨胀卷积的卷积核宽度 |
| **膨胀卷积膨胀率（Dilated Conv Dilation Rate）** | 2 | 膨胀系数 |
| **一维卷积核大小（1D Conv Kernel Size）** | 3 | 交互式一维卷积的卷积核宽度 |
| **阈值置信水平（Threshold Confidence Level）** | 95%（\(\alpha=0.05\)） | 阈值区间的置信水平 |
| **连续故障计数（Consecutive Fault Count）** | 连续 6 个时间步 | 触发故障报警所需的连续超限次数 |

---

## 7. 模型评估指标

使用四种标准回归指标对模型性能进行定量评估。

1. **平均绝对误差（Mean Absolute Error，MAE）**

   \[
   \text{MAE}=\frac{1}{n}\sum_{i=1}^{n}|y_i-y_i'|
   \]

2. **均方误差（Mean Square Error，MSE）**

   \[
   \text{MSE}=\frac{1}{n}\sum_{i=1}^{n}(y_i-y_i')^2
   \]

3. **均方根误差（Root Mean Square Error，RMSE）**

   \[
   \text{RMSE}=
   \sqrt{\frac{1}{n}\sum_{i=1}^{n}(y_i-y_i')^2}
   \]

4. **决定系数（Coefficient of Determination，\(R^2\)）**

   \[
   R^2=
   1-
   \frac{\sum_{i=1}^{n}(y_i-y_i')^2}
   {\sum_{i=1}^{n}(y_i-\bar{y}_i)^2}
   \]

---

## 说明

- 本中文版本依据用户提供的英文 Markdown 文档翻译并整理，保留了原文的章节结构、变量符号、数学公式、算法步骤和超参数数值。
- CA、SCINet、SCADA、KDE、MC Dropout、MAE、MSE、RMSE 等专业缩写保留，以便与论文和代码实现对应。
- 原文中的公式与算法表达按原意保留；本文件不对原论文内容作额外验证或补充。
