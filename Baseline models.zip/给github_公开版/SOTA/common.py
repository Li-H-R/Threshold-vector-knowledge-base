# -*- coding: utf-8 -*-
"""
SOTA 方法统一工具模块（非运行脚本，被各方法的 train.py / test.py 复用）
================================================================

统一负责：
  1. 路径与数据集配置（dataset1 / dataset2）
  2. 健康数据读取 + 切窗
  3. Z-Score 标准化器（仅用健康训练集拟合 mean/std）
  4. 平衡测试集读取（测试集数据/dataset{1,2}/test_seed{seed}.npz）
  5. 检测指标 + 逐异常类型 Recall + 跨 seed 汇总

与 Sensors_2025 的 train_eval.py 保持同一套协议：
  * 训练数据 = _shared/data 的两个健康数据集（raw_data.npy / new_raw_data.npy）
  * 测试数据 = 测试集数据/dataset{1,2}/test_seed{seed}.npz（自包含平衡测试集，
    其「异常」部分即来自《真实异常数据》normalized_labeled_dataset.npy，
    「正常」部分来自 _shared/data 健康数据；x 为原始量纲，需用本方法自拟合的
    标准化器重新标准化，不使用测试集内携带的 x_std/mean/std）。
  * 每个方法负责定义「模型结构 + 窗口得分（重构误差）+ 自身阈值策略」。
     阈值不再统一取 P95，而是按各方法原文的阈值策略实现：CAE 逐特征分位、
     EDAE 条件 KDE、MDAE_DTAD 的 UT 统计量、ST-GNN 的 mean+k*sigma、
     PatchTST / TS-TCC 的训练集得分百分位等。
"""

import os
import json
import random

import numpy as np
import torch
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)

# ---------------------------------------------------------------------------
# 路径
# ---------------------------------------------------------------------------
HERE = os.path.dirname(os.path.abspath(__file__))          # .../与已有方法比较/SOTA
ROOT = os.path.dirname(os.path.dirname(HERE))              # .../阈值实验
SHARED_DATA = os.path.join(ROOT, "_shared", "data")
TEST_DATA = os.path.join(ROOT, "测试集数据")

# 真实异常数据（仅作说明/溯源；实际测试集已把它们的异常窗口打包进 test_seed*.npz）
ANOMALY_DATA = {
    "dataset1": os.path.join(ROOT, "条件重构模型实验", "真实异常数据",
                             "normalized_labeled_dataset.npy"),
    "dataset2": os.path.join(ROOT, "条件重构模型实验_new", "真实异常数据",
                             "new_normalized_labeled_dataset.npy"),
}

DATASETS = {
    "dataset1": {"raw": "raw_data.npy",     "dim": 8,  "new_format": False},
    "dataset2": {"raw": "new_raw_data.npy", "dim": 15, "new_format": True},
}

TEST_SEEDS = [42, 123, 2024, 7, 999]
WINDOW = 10                       # 窗口长度（采样点数，与测试集一致）

METRIC_KEYS = ["accuracy", "specificity", "recall", "precision", "f1_score", "auc_roc"]


# ---------------------------------------------------------------------------
# 随机种子
# ---------------------------------------------------------------------------
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def get_device(device_arg=""):
    return torch.device(device_arg if device_arg else
                        ("cuda" if torch.cuda.is_available() else "cpu"))


# ---------------------------------------------------------------------------
# 标准化器（Z-Score，仅用健康训练集拟合）
# ---------------------------------------------------------------------------
class Standardizer:
    def __init__(self, mean, std, eps=1e-8):
        self.mean = np.asarray(mean, dtype=np.float32)
        self.std = np.asarray(std, dtype=np.float32)
        self.eps = eps

    @staticmethod
    def fit(x: np.ndarray, eps: float = 1e-8) -> "Standardizer":
        """x: 任意 (..., D) 数组，按最后一维拟合 mean/std。"""
        x2 = x.reshape(-1, x.shape[-1])
        mean = x2.mean(axis=0)
        std = x2.std(axis=0)
        std = np.where(std < eps, 1.0, std)
        return Standardizer(mean.astype(np.float32), std.astype(np.float32), eps)

    def transform(self, x: np.ndarray) -> np.ndarray:
        """x: (..., D)，广播到相同形状。"""
        x = np.asarray(x, dtype=np.float32)
        shape = x.shape
        x2 = x.reshape(-1, shape[-1])
        out = (x2 - self.mean) / (self.std + self.eps)
        return out.reshape(shape).astype(np.float32)


# ---------------------------------------------------------------------------
# 健康数据读取 + 切窗
# ---------------------------------------------------------------------------
def load_healthy(dataset: str) -> np.ndarray:
    """读取健康（正常）原始数据，返回 (T, D) float32。"""
    info = DATASETS[dataset]
    path = os.path.join(SHARED_DATA, info["raw"])
    data = np.load(path, allow_pickle=True)
    data = np.asarray(data, dtype=np.float32)
    if not info["new_format"]:
        data = data[:, :-2]              # dataset1 去掉末 2 列非特征列
    assert data.shape[1] == info["dim"], \
        f"{dataset} 特征维 {data.shape[1]} != {info['dim']}"
    return data


def make_windows(series: np.ndarray, window: int, stride: int) -> np.ndarray:
    """把 (T, D) 序列切成 (N, window, D) 滑窗。"""
    T = len(series)
    if T < window:
        raise ValueError(f"序列长度 {T} < 窗口 {window}")
    starts = np.arange(0, T - window + 1, stride)
    idx = starts[:, None] + np.arange(window)[None, :]
    return series[idx].astype(np.float32)


def load_healthy_windows(dataset: str, window: int = WINDOW, stride: int = 1,
                         max_windows: int = None, seed: int = 42) -> np.ndarray:
    """健康数据滑窗 (N, window, D)，可选子采样（dataset2 样本多时可提速）。"""
    x = load_healthy(dataset)
    wins = make_windows(x, window, stride)
    if max_windows is not None and len(wins) > max_windows:
        rng = np.random.default_rng(seed)
        wins = wins[rng.choice(len(wins), max_windows, replace=False)]
    return wins


# ---------------------------------------------------------------------------
# 测试集
# ---------------------------------------------------------------------------
def load_test_set(dataset: str, seed: int) -> dict:
    """读取自包含平衡测试集。返回 dict(x, x_std, y_true, y_type, mean, std, ...)。"""
    path = os.path.join(TEST_DATA, dataset, f"test_seed{seed}.npz")
    z = np.load(path, allow_pickle=False)
    return {
        "x": z["x"].astype(np.float32),          # (N, 10, D) 原始量纲
        "y_true": z["y_true"].astype(np.int64),  # 0=正常 / 1=异常
        "y_type": z["y_type"],                   # 异常类型名（正常="normal"）
    }


# ---------------------------------------------------------------------------
# 指标
# ---------------------------------------------------------------------------
def compute_metrics(y_true, y_pred, score):
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    specificity = tn / max(tn + fp, 1)
    recall = tp / max(tp + fn, 1)
    precision = tp / max(tp + fp, 1)
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    try:
        auc = roc_auc_score(y_true, score)
    except ValueError:
        auc = float("nan")
    return {
        "accuracy": float(accuracy),
        "specificity": float(specificity),
        "recall": float(recall),
        "precision": float(precision),
        "f1_score": float(f1),
        "auc_roc": float(auc),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp),
                             "fn": int(fn), "tp": int(tp)},
    }


def per_type_recall(y_true, y_type, y_pred):
    """逐异常类型 Recall（正常窗口聚合为一行 normal）。"""
    rows = []
    for t in np.unique(y_type):
        mask = y_type == t
        if str(t) == "normal":
            # 正常类的“recall”实为 specificity（1 - 误报率）
            val = float(1.0 - np.mean(y_pred[mask]))
        else:
            val = float(np.mean(y_pred[mask]))
        rows.append({"type": str(t), "recall": val, "n_samples": int(np.sum(mask))})
    return rows


def print_metrics(dataset, seed, m):
    print(f"\n[结果] {dataset} / test_seed={seed}")
    print(f"  Accuracy   = {m['accuracy']:.4f}")
    print(f"  Specificity= {m['specificity']:.4f}")
    print(f"  Recall     = {m['recall']:.4f}")
    print(f"  Precision  = {m['precision']:.4f}")
    print(f"  F1         = {m['f1_score']:.4f}")
    print(f"  AUC-ROC    = {m['auc_roc']:.4f}")
    cm = m["confusion_matrix"]
    print(f"  [TN={cm['tn']} FP={cm['fp']} | FN={cm['fn']} TP={cm['tp']}]")


def summarize(all_metrics):
    summary = {}
    for k in METRIC_KEYS:
        vals = np.array([m[k] for m in all_metrics], dtype=float)
        summary[k] = {"mean": float(np.nanmean(vals)), "std": float(np.nanstd(vals))}
    return summary


def print_summary(title, all_metrics):
    s = summarize(all_metrics)
    print(f"\n{title}（n={len(all_metrics)} 个测试 seed）")
    for k in METRIC_KEYS:
        print(f"  {k:<12} {s[k]['mean']:.4f} ± {s[k]['std']:.4f}")
    return s


def sweep_scalar_threshold(score_val: np.ndarray, y_val: np.ndarray):
    """在给定得分与标签上扫标量阈值 tau，最大化 F1，返回 (best_tau, best_f1)。

    用于报告「best-F1（最优阈值上限）」：各方法在其测试集得分上选使 F1 最大的阈值，
    与 AUC-ROC（阈值无关）并列，作为阈值无关的公平对比指标。
    score_val: (N,) 异常得分（越大越异常），可含 NaN（会被剔除）。
    """
    s = np.asarray(score_val, dtype=np.float64)
    y = np.asarray(y_val, dtype=np.int64)
    ok = np.isfinite(s)
    if ok.sum() < 2:
        return float(np.nanmedian(s)), 0.0
    s, y = s[ok], y[ok]
    grid = np.unique(np.percentile(s, np.linspace(0.5, 99.5, 201)))
    best_tau, best_f1 = float(grid[len(grid) // 2]), -1.0
    for tau in grid:
        f1 = f1_score(y, (s > tau).astype(np.int64))
        if f1 > best_f1:
            best_f1, best_tau = f1, float(tau)
    return best_tau, best_f1


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
