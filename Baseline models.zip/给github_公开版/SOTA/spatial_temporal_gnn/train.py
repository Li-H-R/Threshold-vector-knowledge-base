# -*- coding: utf-8 -*-
"""
ST-GNN —— 时空图神经网络（Spatio-Temporal Graph Neural Network）训练脚本
==========================================================================

方法要点（把每个传感器当作图节点，做「空间图注意力 + 时序 Transformer」重构）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 节点 = D 个传感器，每个时刻每个节点为标量 → 嵌入到 H 维。
  3. 空间图注意力：每个时间步，D 个节点相互注意力（全连接图，自环不计）。
  4. 时序 Transformer：对每个节点的 T 步序列做自注意力。
  5. 仅用健康数据训练（MSE 重构回 (T, D)）。
  6. 得分 = 逐（时间点 x 传感器）重构误差 |recon - x|，窗口异常得分
     = max_{t,d}(|r_{t,d}| / tau_d)，即「任一元素超限即判异常」（单次判定，
     原文 80% 连续越界规则已按要求改为 1 次）。
  7. 阈值 = 逐传感器重构误差的 mean + k*sigma（原文 dynamical_residual_threshold
     取 k=3，逐特征统计自健康训练集），score > 1 判异常。

（原文基于 FFT 的自相关注意力实现较脆弱，此处以等价的标准多头注意力复现
   「空间 GNN + 时间 Transformer」重构思想，适配 D=8/15、T=10。）

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
"""

import argparse
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C


# ---------------------------------------------------------------------------
# 模型
# ---------------------------------------------------------------------------
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]


class SpatioTemporalGNN(nn.Module):
    def __init__(self, num_nodes, T, hidden=64, num_heads=4, num_layers=2, dropout=0.1):
        super().__init__()
        self.num_nodes = num_nodes
        self.embed = nn.Linear(1, hidden)
        self.spatial = nn.MultiheadAttention(hidden, num_heads, batch_first=True)
        self.norm_sp = nn.LayerNorm(hidden)
        self.temporal = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=hidden, nhead=num_heads,
                                       dim_feedforward=hidden * 2, dropout=dropout,
                                       batch_first=True),
            num_layers=num_layers)
        self.pos = PositionalEncoding(hidden)
        self.decoder = nn.Linear(hidden, 1)

    def forward(self, x):
        # x: (B, T, D, 1)
        B, T, D, _ = x.shape
        h = self.embed(x)                                   # (B, T, D, H)

        # 空间图注意力（逐时间步，D 节点相互注意力）
        h = h.reshape(B * T, D, -1)
        h_sp, _ = self.spatial(h, h, h)
        h = self.norm_sp(h + h_sp).reshape(B, T, D, -1)     # (B, T, D, H)

        # 时序 Transformer（逐节点，T 步自注意力）
        h = h.permute(0, 2, 1, 3).reshape(B * D, T, -1)     # (B*D, T, H)
        h = self.temporal(self.pos(h)).reshape(B, D, T, -1)
        h = h.permute(0, 2, 1, 3)                           # (B, T, D, H)

        out = self.decoder(h).squeeze(-1)                   # (B, T, D)
        return out


# ---------------------------------------------------------------------------
# 得分
# ---------------------------------------------------------------------------
def residual_cells(model, windows, std, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 逐元素重构误差 |recon - x| (N, T, D)。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    model.eval()
    res = []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device).unsqueeze(-1)
            recon = model(xb)
            res.append(torch.abs(recon - xb.squeeze(-1)).cpu().numpy())   # (B, T, D)
    return np.concatenate(res, axis=0)


def score_windows(model, windows, std, thr, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,) = max_{t,d} |r_{t,d}| / tau_d。
    对应原文「逐元素超限即判异常」，且按要求改为单次判定（1 次）。"""
    R = residual_cells(model, windows, std, device, batch_size)           # (N, T, D)
    tau = np.asarray(thr, dtype=np.float32)                               # (D,)
    ratio = R / (tau + 1e-8)                                              # (N, T, D)
    return ratio.reshape(len(R), -1).max(axis=1)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW

    x_all = C.load_healthy_windows(dataset, window=T, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32)
    va = std.transform(w_va).astype(np.float32)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) D={D} T={T}")

    model = SpatioTemporalGNN(D, T, hidden=args.hidden, num_heads=args.num_heads,
                              num_layers=args.num_layers, dropout=args.dropout).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or 256

    tr_t = torch.from_numpy(tr)
    va_t = torch.from_numpy(va)
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device).unsqueeze(-1)
            optimizer.zero_grad()
            recon = model(xb)
            loss = nn.functional.mse_loss(recon, xb.squeeze(-1))
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            v = nn.functional.mse_loss(model(va_t.to(device).unsqueeze(-1)),
                                       va_t.to(device)).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_mse={total / len(tr_t):.6f}  "
                  f"val_mse={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 原文 dynamical_residual_threshold：逐传感器 mean + k*sigma（k=3）
    R = residual_cells(model, x_all, std, device, bs).reshape(-1, D)       # (N*T, D)
    thr = (R.mean(axis=0) + args.k_sigma * R.std(axis=0)).astype(np.float32)
    print(f"[阈值] 逐传感器 mean+{args.k_sigma:g}*sigma  shape={thr.shape}  "
          f"(均值={thr.mean():.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"num_nodes": D, "T": T, "hidden": args.hidden,
                         "num_heads": args.num_heads, "num_layers": args.num_layers,
                         "dropout": args.dropout},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, std, thr


def main():
    ap = argparse.ArgumentParser(description="ST-GNN 训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--num-heads", type=int, default=4)
    ap.add_argument("--num-layers", type=int, default=2)
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--k-sigma", type=float, default=3.0,
                    help="动态残差阈值的标准差倍数 k（原文 k=3）")
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
