# -*- coding: utf-8 -*-
"""
MDAE-DTAD —— 多任务降噪自编码器 + 时序 Transformer 训练脚本
===============================================================

方法要点（MDAE_DTAD：Masked/Deep 自编码器 + 时序 Transformer 联合重构）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. MDAE：把窗口展平 (T*D) 经瓶颈 (16->16->8) 自编码器重构回 (T, D)。
  3. TimeTransModel：把 [原始窗口 | 残差] 拼接后经 Transformer 编码器预测窗口。
  4. 仅用健康数据联合训练（MSE 重构损失）。
  5. 得分 = 0.2 * MSE(x_recon, x) + 1.0 * MSE(prediction, x)（逐特征计算，
     窗口异常得分 = max_d(逐特征得分)，任一特征超限即判异常，单次判定）。
  6. 阈值 = 原文 UT 统计量 tau = mean(u) + sqrt(mean(var(u, dim=1)))（u 为健康
     训练集逐特征得分，非百分位），score > tau 判异常。

（原文的 MK-MMD 正则项与「正常/异常判别器」需要异常训练样本，此处按无监督
  重构版复现：仅保留 MDAE + Transformer 两支重构通道。）

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
"""

import argparse
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import common as C


# ---------------------------------------------------------------------------
# 模型
# ---------------------------------------------------------------------------
class MDAE(nn.Module):
    """把展平窗口 (T*D) 经瓶颈重构。"""

    def __init__(self, in_features):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(in_features, 16), nn.Tanh(),
            nn.Linear(16, 16), nn.Tanh(),
            nn.Linear(16, 8), nn.Tanh(),
        )
        self.decoder = nn.Sequential(
            nn.Linear(8, 16), nn.Tanh(),
            nn.Linear(16, 16), nn.Tanh(),
            nn.Linear(16, in_features), nn.Sigmoid(),
        )

    def forward(self, x_flat):
        return self.decoder(self.encoder(x_flat))


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]


class TimeTransModel(nn.Module):
    """把 [x | residual] (T, 2D) 经 Transformer 编码器重构回 (T, D)。"""

    def __init__(self, input_dim, d_model=32, nhead=4, num_layers=2, dim_ff=64, dropout=0.1):
        super().__init__()
        self.embed = nn.Linear(input_dim * 2, d_model)
        self.pos = PositionalEncoding(d_model)
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=d_model, nhead=nhead,
                                       dim_feedforward=dim_ff, dropout=dropout,
                                       batch_first=True),
            num_layers=num_layers)
        self.predictor = nn.Linear(d_model, input_dim)

    def forward(self, x, residual):
        src = torch.cat([x, residual], dim=-1)          # (B, T, 2D)
        h = self.pos(self.embed(src))
        h = self.encoder(h)
        return self.predictor(h)                        # (B, T, D)


class MDAE_DT_AD(nn.Module):
    def __init__(self, D, T, d_model=32, nhead=4, num_layers=2):
        super().__init__()
        self.mdae = MDAE(T * D)
        self.transformer = TimeTransModel(D, d_model=d_model, nhead=nhead,
                                          num_layers=num_layers)

    def forward(self, x):
        B, T, D = x.shape
        x_recon = self.mdae(x.reshape(B, -1)).view(B, T, D)
        prediction = self.transformer(x, x - x_recon)
        return x_recon, prediction


# ---------------------------------------------------------------------------
# 得分
# ---------------------------------------------------------------------------
def feature_scores(model, windows, std, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 逐特征得分 (N, D)。0.2*MSE(mdae) + MSE(trans)。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    model.eval()
    scores = []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)
            x_recon, prediction = model(xb)
            s = 0.2 * ((x_recon - xb) ** 2).mean(dim=1) \
                + ((prediction - xb) ** 2).mean(dim=1)      # (B, D)
            scores.append(s.cpu().numpy())
    return np.concatenate(scores, axis=0)


def score_windows(model, windows, std, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,) = max_d(逐特征得分)。
    对应原文「任一特征超限即判异常」（u_score 逐特征与标量阈值比较，单次判定）。"""
    S = feature_scores(model, windows, std, device, batch_size)
    return S.max(axis=1)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW

    x_all = C.load_healthy_windows(dataset, window=T, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32)
    va = std.transform(w_va).astype(np.float32)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) D={D} T={T}")

    model = MDAE_DT_AD(D, T, d_model=args.d_model, nhead=args.nhead,
                       num_layers=args.num_layers).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    bs = args.batch_size or 256

    tr_t = torch.from_numpy(tr)
    va_t = torch.from_numpy(va)
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            optimizer.zero_grad()
            x_recon, prediction = model(xb)
            loss = nn.functional.mse_loss(x_recon, xb) \
                + nn.functional.mse_loss(prediction, xb)
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            r, p = model(va_t.to(device))
            v = (nn.functional.mse_loss(r, va_t.to(device))
                 + nn.functional.mse_loss(p, va_t.to(device))).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_loss={total / len(tr_t):.6f}  "
                  f"val_loss={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 原文 UT 阈值：tau = mean(u) + sqrt(mean(var(u, dim=1)))，u 为逐特征得分
    S = feature_scores(model, x_all, std, device, bs)                     # (N, D)
    thr = float(S.mean() + np.sqrt(np.mean(np.var(S, axis=1))))
    print(f"[阈值] UT tau=mean(u)+sqrt(mean(var(u)))={thr:.6f}  "
          f"(u mean={S.mean():.6f}, mean(per-sample std)={np.sqrt(np.mean(np.var(S, axis=1))):.6f})")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"D": D, "T": T, "d_model": args.d_model,
                         "nhead": args.nhead, "num_layers": args.num_layers},
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, std, thr


def main():
    ap = argparse.ArgumentParser(description="MDAE-DTAD 训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--d-model", type=int, default=32)
    ap.add_argument("--nhead", type=int, default=4)
    ap.add_argument("--num-layers", type=int, default=2)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
