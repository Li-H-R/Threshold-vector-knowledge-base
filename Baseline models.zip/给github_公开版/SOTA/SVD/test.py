# -*- coding: utf-8 -*-
"""
DUA-SVDD 测试脚本（不重新训练，加载 models/{dataset}.pth 在平衡测试集上评估）。

用法：
  python test.py                          # 两个数据集、全部 5 个测试 seed
  python test.py --dataset dataset1 --test-seed 42
"""

import argparse
import csv
import os
import sys

import numpy as np
import torch

SOTA_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "..", "SOTA"))
sys.path.insert(0, SOTA_DIR)
import common as C
from train import DUA_SVDD, score_windows

HERE = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(HERE, "models")
RESULTS_DIR = os.path.join(HERE, "results")


def load_model(dataset, device):
    ckpt_path = os.path.join(MODELS_DIR, f"{dataset}.pth")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"未找到 {ckpt_path}，请先运行 train.py")
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model = DUA_SVDD(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    center = torch.from_numpy(np.asarray(ckpt["center"], dtype=np.float32)).to(device)
    sd = ckpt["standardizer"]
    std = C.Standardizer(sd["mean"], sd["std"])
    return model, center, std, ckpt


def run_dataset(dataset, args, device):
    model, center, std, ckpt = load_model(dataset, device)
    thr = ckpt["threshold"]
    seeds = C.TEST_SEEDS if args.test_seed is None else [args.test_seed]
    all_metrics, all_type_rows = [], []
    for ts in seeds:
        ts_data = C.load_test_set(dataset, ts)
        x, y_true, y_type = ts_data["x"], ts_data["y_true"], ts_data["y_type"]
        score = score_windows(model, center, x, std, device, args.batch_size)
        tau, _ = C.sweep_scalar_threshold(score, y_true)
        y_pred = (score > tau).astype(np.int64)
        m = C.compute_metrics(y_true, y_pred, score)
        C.print_metrics(dataset, ts, m)
        all_metrics.append(m)
        for r in C.per_type_recall(y_true, y_type, y_pred):
            all_type_rows.append({"dataset": dataset, "test_seed": ts, **r})

        C.save_json(os.path.join(RESULTS_DIR, f"{dataset}_seed{ts}_metrics.json"),
                    {"dataset": dataset, "test_seed": ts,
                     "threshold": thr, "tuned_threshold": tau, "metrics": m})

    s = C.summarize(all_metrics)
    if len(all_metrics) > 1:
        C.print_summary(f"[{dataset}] 跨测试 seed 汇总", all_metrics)
    C.save_json(os.path.join(RESULTS_DIR, f"{dataset}_summary.json"), s)

    with open(os.path.join(RESULTS_DIR, f"{dataset}_per_type_recall.csv"),
              "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["dataset", "test_seed", "type", "recall", "n_samples"])
        w.writeheader()
        for r in all_type_rows:
            w.writerow(r)
    return s


def main():
    ap = argparse.ArgumentParser(description="DUA-SVDD 测试集评估")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--test-seed", type=int, default=None)
    ap.add_argument("--batch-size", type=int, default=4096)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    device = C.get_device(args.device)
    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    summaries = {}
    for ds in datasets:
        summaries[ds] = run_dataset(ds, args, device)

    if len(datasets) > 1:
        print("\n" + "=" * 72)
        print("两个数据集结果对比（mean ± std over 测试 seed）")
        print("=" * 72)
        print(f"{'指标':<12}" + "".join(f"{ds:>24}" for ds in datasets))
        print("-" * 72)
        for k in C.METRIC_KEYS:
            row = f"{k:<12}"
            for ds in datasets:
                row += f"  {summaries[ds][k]['mean']:.4f} ± {summaries[ds][k]['std']:.4f}"
            print(row)
        print("=" * 72)
        C.save_json(os.path.join(RESULTS_DIR, "all_datasets_summary.json"), summaries)


if __name__ == "__main__":
    main()
