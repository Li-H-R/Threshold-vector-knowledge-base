# -*- coding: utf-8 -*-
"""
DUA-SVDD —— 重构 + 深度 SVDD 超球体联合优化训练脚本
=====================================================
方法来源：Reconstruction-based Deep Unsupervised Adaptive Threshold Support Vector
Data Description（DUA-SVDD，旋转机械无监督异常检测）。

方法要点（卷积自编码器重构 + DeepSVDD 边界约束联合训练）：
  1. 数据 z-score 标准化（仅用健康训练集拟合 mean/std）。
  2. 编码器 = 1D 卷积自编码器（Conv1D(6)→MaxPool→Conv1D(16)→Dense 128→64→24），
     把窗口 (T, D) 映射到潜空间 z（维度 24）。
  3. 联合损失 L_total = (1-γ)·MSE(x̂, x) + γ·mean(||z - c||²)，
     其中 c 为潜空间超球中心（训练前由健康样本潜特征均值初始化并冻结）。
     重构项强制潜特征不退化，从根本上消除 DeepSVDD 的超球塌陷问题（论文核心贡献）。
  4. 得分 = 潜特征到超球中心的距离平方 mean(||z - c||²)（DeepSVDD 异常评分）。
  5. 阈值 = 伪异常自适应 R*：在验证集正常样本上加高斯噪声生成伪异常，在伪验证集上
     选使整体分类准确率最高的得分阈值（对应原文最优决策半径 R* 的平方），
     score > R*² 判异常。

用法：
  python train.py                          # 依次训练 dataset1 / dataset2
  python train.py --dataset dataset1
  python train.py --dataset dataset2 --epochs 100 --gamma 0.8 --pseudo-noise 1.0
"""

import argparse
import os
import sys
import time

import numpy as np
import torch
import torch.nn as nn

SOTA_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "..", "SOTA"))
sys.path.insert(0, SOTA_DIR)
import common as C


# ---------------------------------------------------------------------------
# 模型
# ---------------------------------------------------------------------------
class Encoder(nn.Module):
    """1D 卷积编码器 (B, D, T) -> (B, latent)。"""

    def __init__(self, D, T, latent=24):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(D, 6, kernel_size=5, padding=2), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(6, 16, kernel_size=5, padding=2), nn.ReLU(),
        )
        self.fc = nn.Sequential(
            nn.Linear(16 * (T // 2), 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, latent),
        )

    def forward(self, x):
        x = x.transpose(1, 2)          # (B, T, D) -> (B, D, T)
        h = self.conv(x).flatten(1)
        return self.fc(h)


class Decoder(nn.Module):
    """把潜特征 z (B, latent) 重建回 (B, T, D)。"""

    def __init__(self, D, T, latent=24):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(latent, 64), nn.ReLU(),
            nn.Linear(64, 128), nn.ReLU(),
            nn.Linear(128, D * T),
        )
        self.D, self.T = D, T

    def forward(self, z):
        out = self.fc(z).view(-1, self.D, self.T)   # (B, D, T)
        return out.transpose(1, 2)                  # (B, T, D)


class DUA_SVDD(nn.Module):
    def __init__(self, D, T, latent=24):
        super().__init__()
        self.encoder = Encoder(D, T, latent)
        self.decoder = Decoder(D, T, latent)

    def forward(self, x):
        z = self.encoder(x)
        return z, self.decoder(z)

    def encode(self, x):
        return self.encoder(x)


# ---------------------------------------------------------------------------
# 得分
# ---------------------------------------------------------------------------
def _encode_scores(model, center, x, device, batch_size):
    """x: (N, T, D)（已标准化）-> 得分 (N,) = mean(||z - c||²)。"""
    model.eval()
    scores = []
    with torch.no_grad():
        for i in range(0, len(x), batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)
            z = model.encode(xb)
            scores.append(((z - center) ** 2).mean(dim=1).cpu().numpy())
    return np.concatenate(scores)


def score_windows(model, center, windows, std, device, batch_size):
    """windows: (N, T, D)（原始量纲）-> 得分 (N,) = mean(||z - c||²)。"""
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    return _encode_scores(model, center, x, device, batch_size)


# ---------------------------------------------------------------------------
# 训练
# ---------------------------------------------------------------------------
def train(dataset, args):
    C.set_seed(args.seed)
    device = C.get_device(args.device)
    D = C.DATASETS[dataset]["dim"]
    T = C.WINDOW

    x_all = C.load_healthy_windows(dataset, window=T, stride=args.stride,
                                   max_windows=args.max_windows, seed=args.seed)
    n = len(x_all)
    rng = np.random.default_rng(args.seed)
    idx = rng.permutation(n)
    n_train = int(n * args.train_ratio)
    w_tr, w_va = x_all[idx[:n_train]], x_all[idx[n_train:]]

    std = C.Standardizer.fit(w_tr)
    tr = std.transform(w_tr).astype(np.float32)
    va = std.transform(w_va).astype(np.float32)
    print(f"[数据] {dataset} 健康窗口 N={n} (train={n_train} val={n - n_train}) D={D} T={T}")

    model = DUA_SVDD(D, T, latent=args.latent).to(device)
    tr_t = torch.from_numpy(tr)
    va_t = torch.from_numpy(va)

    # 超球中心 c：健康样本潜特征均值（初始化后冻结）
    with torch.no_grad():
        model.eval()
        nc = min(len(tr_t), 4000)
        center = model.encode(tr_t[:nc].to(device)).mean(dim=0)
    center = center.detach()

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    bs = args.batch_size or 128
    gamma = args.gamma
    best_val, best_state = float("inf"), None
    print(f"[训练] device={device} epochs={args.epochs} batch={bs} lr={args.lr} gamma={gamma}")
    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(len(tr_t))
        total = 0.0
        for i in range(0, len(tr_t), bs):
            xb = tr_t[perm[i:i + bs]].to(device)
            optimizer.zero_grad()
            z, recon = model(xb)
            loss = (1 - gamma) * nn.functional.mse_loss(recon, xb) \
                 + gamma * ((z - center) ** 2).mean()
            loss.backward()
            optimizer.step()
            total += loss.item() * len(xb)
        model.eval()
        with torch.no_grad():
            z, recon = model(va_t.to(device))
            v = ((1 - gamma) * nn.functional.mse_loss(recon, va_t.to(device))
                 + gamma * ((z - center) ** 2).mean()).item()
        if v < best_val:
            best_val = v
            best_state = {k: t.detach().cpu().clone() for k, t in model.state_dict().items()}
        if epoch % 10 == 0 or epoch == args.epochs:
            print(f"  Epoch {epoch:>3d}/{args.epochs}  train_loss={total / len(tr_t):.6f}  "
                  f"val_loss={v:.6f}")

    model.load_state_dict(best_state)
    model.eval()

    # 伪异常自适应阈值 R*：在验证集正常样本上加高斯噪声生成伪异常，
    # 在伪验证集上选使整体分类准确率最高的得分阈值（= R*²）。
    s_norm = _encode_scores(model, center, va, device, bs)
    pseudo = va + rng.normal(0.0, args.pseudo_noise, size=va.shape).astype(np.float32)
    s_pseudo = _encode_scores(model, center, pseudo, device, bs)
    s_all = np.concatenate([s_norm, s_pseudo])
    y_all = np.concatenate([np.zeros_like(s_norm), np.ones_like(s_pseudo)])
    cands = np.percentile(s_all, np.linspace(0, 100, 401))
    best_acc, thr = -1.0, float(np.percentile(s_norm, 95.0))
    for t in cands:
        acc = float(((s_all > t).astype(np.int64) == y_all).mean())
        if acc > best_acc:
            best_acc, thr = acc, float(t)
    print(f"[阈值] 伪异常自适应 R*^2={thr:.6f}（伪验证集准确率={best_acc:.4f}）")

    ckpt = {
        "model_state_dict": model.state_dict(),
        "model_config": {"D": D, "T": T, "latent": args.latent},
        "center": center.cpu().numpy(),
        "standardizer": {"mean": std.mean, "std": std.std},
        "threshold": thr,
        "args": vars(args),
    }
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
    os.makedirs(model_dir, exist_ok=True)
    ckpt_path = os.path.join(model_dir, f"{dataset}.pth")
    torch.save(ckpt, ckpt_path)
    print(f"[保存] {ckpt_path}")
    return model, center, std, thr


def main():
    ap = argparse.ArgumentParser(description="DUA-SVDD 训练")
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--latent", type=int, default=24)
    ap.add_argument("--gamma", type=float, default=0.8,
                    help="SVDD 边界损失权重（1-gamma 为重构权重）")
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--max-windows", type=int, default=200000,
                    help="健康窗口子采样上限（dataset2 样本多，默认 200000 提速）")
    ap.add_argument("--train-ratio", type=float, default=0.85)
    ap.add_argument("--pseudo-noise", type=float, default=1.0,
                    help="伪异常生成时叠加的高斯噪声标准差（原文 sigma=1）")
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]
    for ds in datasets:
        t0 = time.time()
        train(ds, args)
        print(f"[{ds}] 训练耗时 {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
