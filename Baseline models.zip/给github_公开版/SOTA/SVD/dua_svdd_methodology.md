# Reconstruction-based Deep Unsupervised Adaptive Threshold Support Vector Data Description (DUA-SVDD)

## 1. 概述与核心思想

**DUA-SVDD** 是一种专为风力发电机组（Wind Turbine）等旋转机械异常检测（Anomaly Detection, AD）设计的无监督深度学习模型。

传统 DeepSVDD 在无监督训练过程中极易遭遇**超球体塌陷（Hypersphere Collapse）**问题（即网络权重全收敛为 0，将所有输入映射到同一点），导致模型失效。DUA-SVDD 通过将**卷积自编码器（CAE）的重构机制**与**DeepSVDD 的边界约束机制**进行联合优化（Joint Optimization），成功解决了这一瓶颈。

### 核心创新点：
1. **重构与边界联合优化**：结合基于重构（Reconstruction-based）与基于距离/边界（Distance/Boundary-based）的异常检测范式，同时最小化重构误差与潜空间超球体体积。
2. **彻底解决超球体塌陷**：从数学上证明了重构损失的引入可防止潜空间特征退化为常数，从而消除超球体塌陷风险。
3. **基于伪数据的自适应阈值算法**：无需真实故障样本，通过引入高斯噪声生成伪异常数据建立验证集，自适应确定最佳决策边界半径 $R^*$。

---

## 2. DUA-SVDD 理论模型与算法架构

整个异常检测框架包含三个阶段：**数据采集与标准化**、**训练阶段**、**应用阶段**。

```
[SCADA 监控数据] --> [Z-Score 标准化] 
                        |
                        v
              [DUA-SVDD 联合优化训练]
              /                      \
   [Encoder E(x)]                [Decoder D(z)]
         |                              |
  潜空间特征 z=E(x)               重构数据 x̂=D(z)
         |                              |
  SVDD Loss: L_svdd              MSE Loss: L_ae
         \                      /
     Total Loss: L_total = (1-γ)L_ae + γ L_svdd
                        |
                        v
            [伪数据自适应阈值计算 R*]
                        |
                        v
              [在线测试与异常评分]
```

### 2.1 联合优化损失函数 (Joint Optimization Loss)

给定无标签训练数据集 $X = \{x_1, x_2, ..., x_n\} \in \mathbb{R}^{n \times k}$，Encoder 将输入 $x_i$ 映射至潜空间（Latent Space）特征 $z_i$：
$$z_i = E(x_i; w_e, b_e)$$

Decoder 将潜特征 $z_i$ 重构还原为输入维度 $\hat{x}_i$：
$$\hat{x}_i = D(z_i; w_d, b_d)$$

DUA-SVDD 的总损失函数由**重构 MSE 损失**与**SVDD 边界约束损失**加权组成：

$$\mathcal{L}_{\text{total}} = (1 - \gamma) \mathcal{L}_{\text{ae}} + \gamma \mathcal{L}_{\text{svdd}}$$

其中 $\gamma \in [0, 1]$ 为平衡超参数。

1. **自编码器重构损失 $\mathcal{L}_{\text{ae}}$**（确保提取局部与全局结构信息，防止特征退化）：
   $$\mathcal{L}_{\text{ae}} = \frac{1}{n} \sum_{i=1}^{n} \| x_i - D(E(x_i; w_e, b_e); w_d, b_d) \|_2^2$$

2. **SVDD 约束损失 $\mathcal{L}_{\text{svdd}}$**（收缩潜空间正常特征的超球体体积）：
   $$\mathcal{L}_{\text{svdd}} = \frac{1}{n} \sum_{i=1}^{n} \| E(x_i; w_e, b_e) - c \|_2^2$$

其中 $c$ 为预先设定或固定的潜空间超球体中心。

---

## 3. 解决超球体塌陷的理论证明 (Theory Proof)

### 反证法证明 (Proof by Contradiction)

若发生超球体塌陷，网络权重全为 0（$w_e = 0$），使得对于任意输入 $x_i, x_j \in X$，Encoder 的潜空间输出均为恒定常数 $c_0$：
$$z_i = E(x_i; w_e, b_e) = E(x_j; w_e, b_e) = c_0$$

若 $c_0$ 等于超球体中心 $c$（即 $c = c_0$），则 SVDD 损失降为 0，半径 $R = 0$，超球体完全塌陷。

此时，由于输入潜空间的值始终为常数 $c_0$，Decoder 的输出也必然为恒定常数 $d$：
$$\hat{x}_i = D(z_i; w_d, b_d) = D(c_0; w_d, b_d) = d$$

根据偏差-方差分解（Bias-Variance Decomposition），均方误差 MSE 可写为：
$$\text{MSE} = (\mu - d)^2 + \sigma^2$$
其中 $\mu$ 为输入数据集 $X$ 的均值，$\sigma^2$ 为方差。

由于实际监控 SCADA 数据具有较高的固有方差 $\sigma^2$，恒定的预测值 $d$ 必然导致**极其巨大的重构误差 MSE**。这与优化目标（最小化 $\mathcal{L}_{\text{total}}$ 中的 MSE）相矛盾。

此外，从信息论角度分析：
- 恒定重构信号的熵 $H(\hat{x}_i) = 0$。
- 输入与重构信号的互信息 $MI(x_i, \hat{x}_i) = H(x_i) - H(x_i | \hat{x}_i) = 0$，代表极其严重的严重信息丢失。

**结论**：重构损失 $\mathcal{L}_{\text{ae}}$ 的存在强制网络权重不能全为 0，保证了潜空间特征的多样性与信息量，**从根本上消除了 DeepSVDD 的超球体塌陷问题**。

---

## 4. 基于伪数据的自适应阈值设置算法 (Pseudo Data-based Adaptive Threshold)

在无监督学习中，选择最佳超球体半径/阈值 $R^*$ 至关重要。DUA-SVDD 提出了通过生成伪异常数据（Pseudo Anomaly Data）构建验证集的方法。

### 4.1 伪数据生成逻辑
风机正常运行时各 SCADA 传感器参数间存在强物理耦合关系（如风速与功率）。通过加入高斯随机噪声，可破坏这种耦合关系，从而模拟潜在异常：

1. 从未参与训练的正常数据中随机抽取样本 $x_i$。
2. 生成均值为 0、标准差为 1 的高斯噪声 $\epsilon_i \sim \mathcal{N}(0, 1)$。
3. 叠加噪声生成伪异常样本 $x_i'$：
   $$x_i' = x_i + \epsilon_i$$
4. 组合伪异常样本与正常样本，构建伪验证集（Pseudo-Validation Set）。

### 4.2 最佳半径 $R^*$ 的确定
在伪验证集上，按最小化总错检/漏检成本原则选择最佳半径 $R^*$：
$$\text{Total Cost} = (1 - acc_{\text{normal}}) \cdot c_1 + (1 - acc_{\text{anomalous}}) \cdot c_2$$
在假设误报成本 $c_1$ 与漏报成本 $c_2$ 相等的情况下，即选取使伪验证集整体分类准确率最高时的半径作为最佳决策阈值 $R^*$。

---

## 5. 在线评估与异常评分 (Online Evaluation)

在测试/应用阶段，对于输入的测试样本 $x_t \in \mathbb{R}^k$，计算其潜空间表示与超球中心 $c$ 的欧氏距离平方，作为**异常评分（Anomaly Score）**：

$$s(x_t) = \| E(x_t; w_e^*, b_e^*) - c \|_2^2$$

### 决策规则：
- 若 $s(x_t) \le (R^*)^2$ $\rightarrow$ **正常样本 (Normal)**
- 若 $s(x_t) > (R^*)^2$ $\rightarrow$ **异常样本 (Abnormal)**

---

## 6. 算法伪代码 (Algorithm Description)

```text
Algorithm 1: Train and Evaluation Procedure of DUA-SVDD Model
--------------------------------------------------------------------------------
Input: 
  - Training set X (Normal SCADA data)
  - Pseudo validation set
  - Test sample x_t
  - Training epochs
  - Loss weight γ (e.g., γ = 0.8)

1: Initialize model parameters w_e, b_e, w_d, b_d and hypersphere center c.
2: while no convergence achieved do
3:    Randomly select mini-batch from X.
4:    Optimize w_e, b_e, w_d, b_d by minimizing:
         L_total = (1 - γ) * (1/n) * Σ || x_i - D(E(x_i)) ||^2 
                 + γ * (1/n) * Σ || E(x_i) - c ||^2
5: end while
6: Output trained parameters w_e*, b_e*, w_d*, b_d*.
7: Calculate anomaly scores for all training data.
8: Obtain optimal radius R* using the pseudo validation set.

9: for each test sample x_t do
10:   Calculate anomaly score: s(x_t) = || E(x_t; w_e*, b_e*) - c ||^2
11:   if s(x_t) <= (R*)^2 then
12:       Classify x_t as Normal
13:   else
14:       Classify x_t as Abnormal
15:   end if
16: end for
```

---

## 7. 具体实现参数配置 (Implementation Details)

基于 26 维 SCADA 特征输入的典型网络参数配置如下：

- **Encoder 结构**：
  - Conv1D-1: 6 个卷积核，Kernel Size = $1 \times 5$，ReLU 激活，Max-pooling ($1 \times 2$)。（采用较宽卷积核提升抑噪能力）
  - Conv1D-2: 16 个卷积核，Kernel Size = $1 \times 5$，ReLU 激活。
  - Dense Layers: 全连接层节点数依次为 128 $\rightarrow$ 64 $\rightarrow$ 24（潜空间维度 Latent Dimension = 24）。
- **Decoder 结构**：
  - 对称采用转置卷积（Deconvolution）与上采样（Upsampling），还原至 $1 \times 26$ 维。
- **训练超参数**：
  - 优化器：Adam ($\eta = 0.0001$)
  - Batch Size：128
  - Epochs：300
  - 损失权重 $\gamma$：0.8