# Wind Turbine Anomaly Detection — Reproduction Code

This repository contains model implementations, training/evaluation scripts, and
method descriptions for the proposed methods and comparison methods.

## Contents

- `method2`, `method3`, `SVD`: proposed/reproduced method code and methodology.
- `Sensors_2025`: MLP autoencoder reproduction.
- `SOTA`: baseline implementations and shared utilities. The duplicated upstream
  `_original` trees and trained checkpoints are not included.
- `method4`: selected model/training parameter records; sample-level output files
  and checkpoints are not included.
- `先进方法替换为所提阈值`, `其他阈值策略对比`: threshold-comparison code and
  method descriptions.

## Data and checkpoints

Datasets, trained weights, and sample-level predictions are intentionally not
distributed. Prepare data that you are authorized to use and configure each
script's expected input path/format locally. Do not commit private or restricted
data, checkpoints, or generated sample-level results.

Training scripts generally expect healthy training data and separate validation,
calibration, and test inputs. See each method's documentation and `--help` output
for its model parameters and command-line options. The scripts cannot run end to
end until the required data is supplied.

## Reproducibility

Use Python with the dependencies imported by the relevant script (including
PyTorch, NumPy, scikit-learn, and SciPy where required). Seeds and key
hyperparameters are exposed in the training scripts. Check the method-specific
documentation for architecture, data-window, threshold, and evaluation details.

```bash
python method2/train.py --help
python method3/train.py --help
python SVD/train.py --help
```

The folders contain independent experiments and may have different dependency
requirements. No dataset or trained checkpoint is required to inspect the model
definitions and reported training parameters.
