# -*- coding: utf-8 -*-
"""
把「所提逐簇 98 分位阈值策略」套用到 9 个对比方法的统一实验脚本
================================================================

目标：验证所提阈值策略（逐簇 98 分位 + max-ratio 判定）是可迁移的「配方」，
      把 9 个对比方法（CAE / EDAE / MDAE_DTAD / ST-GNN / PatchTST / TS-TCC /
      Sensors_2025(MLP-AE) / RESCINet / CA-SCINet）各自原生的阈值方案，
      替换为「在其自身嵌入上 KMeans(500) 聚类 → 逐簇逐特征 98 分位阈值 →
      score = max_d(residual_d / threshold_d)，score > 1 判异常」。

与所提方法完全一致的判定口径：
  * 嵌入来自各方法自身的 latent / 编码器输出 / 隐藏状态（不是复用 LSTM latent）。
  * 残差：
      - 重构类方法（CAE/EDAE/MDAE/ST-GNN/PatchTST/TS-TCC/MLP-AE）：重构残差；
      - 预测类方法（RESCINet/CA-SCINet）：预测残差 |ŷ − x|（换口径，单次前向）；
      - CAE 残差在 5 个统计特征（5D 维）上（无时间维）；MDAE 残差取其 AE 分支
        逐时间点重构残差 |x_recon − x|（transformer 预测支路不参与阈值替换）。
  * 逐簇阈值 = 该簇残差逐特征的 98 分位（沿 N×T 展平，与所提方法 get_residual_stats 一致）。
  * 判定 = 逐窗口残差「时间维取均值」后逐特征除以阈值，max > 1 判异常。

用法（请使用安装了项目依赖的 Python 环境）：
  python run_per_cluster.py --method cae --dataset dataset1
  python run_per_cluster.py --method all --dataset all   # 9 方法 × 2 数据集全跑
"""

import argparse
import importlib.util
import json
import os
import sys

import numpy as np
import torch
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist

HERE = os.path.dirname(os.path.abspath(__file__))          # .../先进方法替换为所提阈值
CMP = os.path.dirname(HERE)                                 # .../与已有方法比较
SOTA = os.path.join(CMP, "SOTA")
for p in (SOTA, CMP):
    if p not in sys.path:
        sys.path.insert(0, p)
import common as C

RESULTS_DIR = os.path.join(HERE, "results")

# ---------------------------------------------------------------------------
# 通用：逐簇阈值拟合 + 逐簇打分
# ---------------------------------------------------------------------------
def fit_cluster_thresholds(emb, residual, k, seed=42, percentile=98.0):
    """在健康数据嵌入上 KMeans(k)，逐簇逐特征取 residual 的 percentile 分位。
    emb: (N, E)；residual: (N, T, D) 或 (N, D)。返回 (centers(K',E), thresholds{dict})。
    剔除样本数<2 的簇（与所提方法一致）。"""
    emb = np.asarray(emb, dtype=np.float32)
    residual = np.asarray(residual, dtype=np.float32)
    n = len(emb)
    if k > n:
        k = max(2, n // 2)
        print(f"  [警告] 聚类数 k 超过样本数，下调为 {k}")
    kmeans = KMeans(n_clusters=k, random_state=seed, n_init=3, max_iter=300).fit(emb)
    labels = kmeans.labels_
    centers = kmeans.cluster_centers_
    unique, counts = np.unique(labels, return_counts=True)
    valid = unique[counts >= 2]
    thresholds = {}
    for new_id, old_id in enumerate(valid):
        r = residual[labels == old_id]
        if r.ndim == 3:
            r = r.reshape(-1, r.shape[-1])
        thresholds[new_id] = np.percentile(r, percentile, axis=0).astype(np.float32)
    print(f"  有效簇 {len(valid)}/{k}（剔除样本数<2 的簇）")
    return centers[valid].astype(np.float32), thresholds


def score_per_cluster(emb, residual, centers, thresholds):
    """逐窗口按最近簇打分 score = max_d(residual_d / threshold_d)。
    residual: (N, T, D) -> 先时间维取均值；(N, D) -> 直接使用。"""
    emb = np.asarray(emb, dtype=np.float32)
    residual = np.asarray(residual, dtype=np.float32)
    c = np.argmin(cdist(emb, centers), axis=1)
    scores = np.empty(len(residual), dtype=np.float32)
    for i in range(len(residual)):
        r = residual[i]
        if r.ndim == 2:
            r = r.mean(axis=0)
        t = thresholds[c[i]]
        scores[i] = float(np.max(r / (t + 1e-8)))
    return scores


# ---------------------------------------------------------------------------
# 工具：以独立模块名加载某方法的 train.py / train_eval.py
# ---------------------------------------------------------------------------
def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------------------
# 各方法：load + embed_residual
# ---------------------------------------------------------------------------
def _load_ckpt(method_dir, dataset, fname):
    return torch.load(os.path.join(method_dir, "models", fname),
                      map_location="cpu", weights_only=False)


def _std(ckpt):
    return C.Standardizer(ckpt["standardizer"]["mean"], ckpt["standardizer"]["std"])


# --- CAE ---
def load_cae(dataset, device):
    d = os.path.join(SOTA, "CAE")
    M = load_module("cae_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.ConvDAE(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, None, {"M": M}


def cae_embed_residual(model, std, windows, cfg, device, batch_size):
    M = cfg["M"]
    feat = M.stat_features(windows)                     # (N, 5D)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, len(feat), batch_size):
            xb = torch.from_numpy(feat[i:i + batch_size]).to(device)
            z = model.encoder(xb)
            recon = model.decoder(z)
            emb.append(z.cpu().numpy())
            res.append(torch.abs(recon - xb).cpu().numpy())
    return np.concatenate(emb), np.concatenate(res)


# --- EDAE ---
def load_edae(dataset, device):
    d = os.path.join(SOTA, "EDAE")
    M = load_module("edae_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.EnsembleDenoisingAutoencoder(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, _std(ckpt), {"M": M}


def edae_embed_residual(model, std, windows, cfg, device, batch_size):
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)     # (b, T, D)
            b = xb.shape[0]
            xp = xb.reshape(-1, D)
            z = model.models[0].encoder[:9](xp)                        # 瓶颈 latent (b*T,10)
            emb.append(z.reshape(b, T, -1).mean(dim=1).cpu().numpy())  # (b,10)
            recon = model(xp)                                          # 集成均值(带噪声注入)
            res.append(torch.abs(recon - xp).reshape(b, T, D).cpu().numpy())
    return np.concatenate(emb), np.concatenate(res)


# --- MDAE_DTAD ---
def load_mdae(dataset, device):
    d = os.path.join(SOTA, "MDAE_DTAD")
    M = load_module("mdae_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.MDAE_DT_AD(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, _std(ckpt), {"M": M}


def mdae_embed_residual(model, std, windows, cfg, device, batch_size):
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)      # (b, T, D)
            b = xb.shape[0]
            z = model.mdae.encoder(xb.reshape(b, -1))                   # 瓶颈 (b,8)
            emb.append(z.cpu().numpy())
            x_recon, _ = model(xb)
            res.append(torch.abs(x_recon - xb).cpu().numpy())           # (b, T, D) 重构残差
    return np.concatenate(emb), np.concatenate(res)


# --- ST-GNN ---
def load_stgnn(dataset, device):
    d = os.path.join(SOTA, "spatial_temporal_gnn")
    M = load_module("stgnn_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.SpatioTemporalGNN(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, _std(ckpt), {"M": M}


def stgnn_embed_residual(model, std, windows, cfg, device, batch_size):
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    emb, res = [], []
    holder = {}

    def hook(m, inp, out):
        holder["h"] = inp[0]                                  # 解码前隐藏态 (b,T,D,H)

    handle = model.decoder.register_forward_hook(hook)
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device).unsqueeze(-1)
            recon = model(xb)
            h = holder["h"]
            emb.append(h.mean(dim=(1, 2)).cpu().numpy())      # (b,H)
            res.append(torch.abs(recon - xb.squeeze(-1)).cpu().numpy())
    handle.remove()
    return np.concatenate(emb), np.concatenate(res)


# --- PatchTST ---
def load_patchtst(dataset, device):
    d = os.path.join(SOTA, "PatchTST")
    M = load_module("patchtst_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.PatchTST(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, _std(ckpt), {"M": M, "patch_len": ckpt["patch_len"],
                               "stride": ckpt["stride"]}


def patchtst_embed_residual(model, std, windows, cfg, device, batch_size):
    M = cfg["M"]
    patch_len, stride = cfg["patch_len"], cfg["stride"]
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    patches = torch.from_numpy(M.patchify(x, patch_len, stride)).to(device)  # (N,P,D,pl)
    P = patches.shape[1]
    emb, res = [], []
    holder = {}

    def hook(m, inp, out):
        holder["u"] = out                                    # (b*D, P, d_model)

    handle = model.encoder.register_forward_hook(hook)
    with torch.no_grad():
        for i in range(0, N, batch_size):
            pb = patches[i:i + batch_size]                   # (b,P,D,pl)
            b = pb.shape[0]
            _ = model(pb)                                    # 无掩码前向取 patch 嵌入
            u = holder["u"].reshape(b, D, P, -1).mean(dim=(1, 2))  # (b,d_model)
            emb.append(u.cpu().numpy())
            errs = torch.zeros(b, P, D, device=device)
            for p in range(P):
                inp = pb.clone()
                inp[:, p] = 0.0
                pred = model(inp)
                errs[:, p] = torch.abs(pred[:, p] - pb[:, p]).mean(dim=2)  # (b,D)
            res.append(errs.cpu().numpy())                   # (b,P,D) 逐 patch 重构残差
    handle.remove()
    return np.concatenate(emb), np.concatenate(res)


# --- TS-TCC ---
def load_tstcc(dataset, device):
    d = os.path.join(SOTA, "TS-TCC")
    M = load_module("tstcc_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    encoder = M.TSEncoder(**ckpt["encoder_config"]).to(device)
    encoder.load_state_dict(ckpt["encoder_state_dict"]); encoder.eval()
    decoder = M.MLPDecoder(**ckpt["decoder_config"]).to(device)
    decoder.load_state_dict(ckpt["decoder_state_dict"]); decoder.eval()
    return (encoder, decoder), _std(ckpt), {"M": M}


def tstcc_embed_residual(model, std, windows, cfg, device, batch_size):
    encoder, decoder = model
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D).transpose(0, 2, 1)  # (N,D,T)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)   # (b,D,T)
            feat = encoder(xb)
            emb.append(feat.mean(dim=2).cpu().numpy())              # (b,C_out)
            recon = decoder(feat.reshape(feat.shape[0], -1))
            res.append(torch.abs(recon - xb).transpose(1, 2).cpu().numpy())  # (b,T,D)
    return np.concatenate(emb), np.concatenate(res)


# --- Sensors_2025 (MLP-AE) ---
def load_mlpae(dataset, device):
    d = os.path.join(CMP, "Sensors_2025")
    M = load_module("sensors_train_eval", os.path.join(d, "train_eval.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}_mlp_ae.pth")
    model = M.MLPAutoencoder(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    std = M.Standardizer(ckpt["standardizer"]["mean"], ckpt["standardizer"]["std"])
    return model, std, {"M": M}


def mlpae_embed_residual(model, std, windows, cfg, device, batch_size):
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)   # (b,T,D)
            b = xb.shape[0]
            xp = xb.reshape(-1, D)
            z = model.encoder(xp)                                    # 瓶颈 (b*T,2)
            emb.append(z.reshape(b, T, -1).mean(dim=1).cpu().numpy())
            recon = model.decoder(z)
            res.append(torch.abs(recon - xp).reshape(b, T, D).cpu().numpy())
    return np.concatenate(emb), np.concatenate(res)


# --- RESCINet (method2) ---
def load_rescinet(dataset, device):
    d = os.path.join(CMP, "method2")
    M = load_module("rescinet_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.RESCINet(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, _std(ckpt), {"M": M}


def rescinet_embed_residual(model, std, windows, cfg, device, batch_size):
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)   # (b,T,D)
            pred = model(xb)                                         # 预测残差口径
            h = model.embed(xb.transpose(1, 2))
            for blk in model.blocks:
                h = blk(h)
            emb.append(h.mean(dim=2).cpu().numpy())                  # (b,hidden)
            res.append(torch.abs(pred - xb).cpu().numpy())
    return np.concatenate(emb), np.concatenate(res)


# --- CA-SCINet (method3) ---
def load_cascinet(dataset, device):
    d = os.path.join(CMP, "method3")
    M = load_module("cascinet_train", os.path.join(d, "train.py"))
    ckpt = _load_ckpt(d, dataset, f"{dataset}.pth")
    model = M.CA_SCINet(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"]); model.eval()
    return model, _std(ckpt), {"M": M}


def cascinet_embed_residual(model, std, windows, cfg, device, batch_size):
    N, T, D = windows.shape
    x = std.transform(windows.reshape(-1, D)).reshape(N, T, D)
    emb, res = [], []
    with torch.no_grad():
        for i in range(0, N, batch_size):
            xb = torch.from_numpy(x[i:i + batch_size]).to(device)
            pred = model(xb)
            h = model.embed(xb.transpose(1, 2))
            h = model.ca(h)
            for blk in model.blocks:
                h = blk(h)
            emb.append(h.mean(dim=2).cpu().numpy())
            res.append(torch.abs(pred - xb).cpu().numpy())
    return np.concatenate(emb), np.concatenate(res)


# ---------------------------------------------------------------------------
# 方法注册表
# ---------------------------------------------------------------------------
METHODS = {
    "cae":       (load_cae,       cae_embed_residual),
    "edae":      (load_edae,      edae_embed_residual),
    "mdae":      (load_mdae,      mdae_embed_residual),
    "stgnn":     (load_stgnn,     stgnn_embed_residual),
    "patchtst":  (load_patchtst,  patchtst_embed_residual),
    "tstcc":     (load_tstcc,     tstcc_embed_residual),
    "mlpae":     (load_mlpae,     mlpae_embed_residual),
    "rescinet":  (load_rescinet,  rescinet_embed_residual),
    "cascinet":  (load_cascinet,  cascinet_embed_residual),
}


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def run_method(method, dataset, args, device):
    loader, embed_residual = METHODS[method]
    model, std, cfg = loader(dataset, device)

    # 1) 健康窗口 -> 嵌入 + 残差 -> 逐簇 98 分位阈值
    healthy = C.load_healthy_windows(dataset, window=C.WINDOW, stride=1,
                                     max_windows=args.max_windows, seed=42)
    print(f"[{method}/{dataset}] 健康窗口 {len(healthy)} -> 提取嵌入与残差 ...")
    emb_tr, res_tr = embed_residual(model, std, healthy, cfg, device, args.batch_size)
    print(f"  嵌入 {emb_tr.shape}  残差 {res_tr.shape}")
    centers, thresholds = fit_cluster_thresholds(emb_tr, res_tr, args.k,
                                                 seed=42, percentile=args.percentile)

    # 2) 平衡测试集（5 seed）-> 逐簇打分 -> score>1 判异常
    seeds = C.TEST_SEEDS if args.test_seed is None else [args.test_seed]
    all_metrics = []
    for ts in seeds:
        td = C.load_test_set(dataset, ts)
        x, y_true = td["x"], td["y_true"]
        emb_te, res_te = embed_residual(model, std, x, cfg, device, args.batch_size)
        score = score_per_cluster(emb_te, res_te, centers, thresholds)
        y_pred = (score > 1.0).astype(np.int64)
        m = C.compute_metrics(y_true, y_pred, score)
        C.print_metrics(dataset, ts, m)
        all_metrics.append(m)

        os.makedirs(RESULTS_DIR, exist_ok=True)
        C.save_json(os.path.join(RESULTS_DIR, f"{method}_{dataset}_seed{ts}_metrics.json"),
                    {"method": method, "dataset": dataset, "test_seed": ts,
                     "k": args.k, "percentile": args.percentile,
                     "n_valid_clusters": len(thresholds), "metrics": m})

    s = C.summarize(all_metrics)
    if len(all_metrics) > 1:
        C.print_summary(f"[{method}/{dataset}] 跨测试 seed 汇总", all_metrics)
    C.save_json(os.path.join(RESULTS_DIR, f"{method}_{dataset}_summary.json"),
                {"method": method, "dataset": dataset, "k": args.k,
                 "percentile": args.percentile,
                 "n_valid_clusters": len(thresholds), "summary": s})
    return s


def main():
    ap = argparse.ArgumentParser(description="所提逐簇阈值策略 × 9 对比方法")
    ap.add_argument("--method", default="all", choices=["all"] + sorted(METHODS))
    ap.add_argument("--dataset", default="all", choices=["all"] + list(C.DATASETS))
    ap.add_argument("--test-seed", type=int, default=None)
    ap.add_argument("--k", type=int, default=500, help="聚类数（默认 500，与所提方法一致）")
    ap.add_argument("--percentile", type=float, default=98.0, help="逐簇阈值分位")
    ap.add_argument("--max-windows", type=int, default=50000,
                    help="拟合逐簇阈值的健康窗口子采样上限（dataset1 全量约 19684）")
    ap.add_argument("--batch-size", type=int, default=1024)
    ap.add_argument("--device", type=str, default="")
    args = ap.parse_args()

    device = C.get_device(args.device)
    methods = sorted(METHODS) if args.method == "all" else [args.method]
    datasets = list(C.DATASETS) if args.dataset == "all" else [args.dataset]

    all_summaries = {}
    for ds in datasets:
        for method in methods:
            s = run_method(method, ds, args, device)
            all_summaries[f"{method}/{ds}"] = s

    if len(all_summaries) > 1:
        print("\n" + "=" * 80)
        print("全部方法 × 数据集 汇总（mean over 测试 seed，判定 score>1）")
        print("=" * 80)
        print(f"{'方法/数据集':<18}" + "".join(f"{k:>16}" for k in C.METRIC_KEYS))
        print("-" * 80)
        for key, s in all_summaries.items():
            row = f"{key:<18}"
            for k in C.METRIC_KEYS:
                row += f"  {s[k]['mean']:>12.4f}"
            print(row)
        print("=" * 80)
        C.save_json(os.path.join(RESULTS_DIR, "all_summary.json"), all_summaries)


if __name__ == "__main__":
    main()
