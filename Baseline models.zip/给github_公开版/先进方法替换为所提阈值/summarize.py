# -*- coding: utf-8 -*-
"""聚合 run_per_cluster.py 产出的 results/*_summary.json 成 Markdown 表格。"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, "results")

METHODS = ["cae", "edae", "mdae", "stgnn", "patchtst", "tstcc", "mlpae",
           "rescinet", "cascinet"]
METHOD_LABEL = {
    "cae": "CAE", "edae": "EDAE", "mdae": "MDAE_DTAD", "stgnn": "ST-GNN",
    "patchtst": "PatchTST", "tstcc": "TS-TCC", "mlpae": "Sensors_2025(MLP-AE)",
    "rescinet": "RESCINet", "cascinet": "CA-SCINet",
}
KEYS = ["accuracy", "specificity", "recall", "precision", "f1_score", "auc_roc"]


def load(method, dataset):
    p = os.path.join(RESULTS, f"{method}_{dataset}_summary.json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        d = json.load(f)
    return d


def main():
    for dataset in ["dataset1", "dataset2"]:
        rows = []
        for m in METHODS:
            d = load(m, dataset)
            if d is None:
                print(f"[跳过] {m}/{dataset} 无结果")
                continue
            s = d["summary"]
            rows.append((METHOD_LABEL[m], s, d.get("n_valid_clusters")))
        rows.sort(key=lambda r: -r[1]["f1_score"]["mean"])

        print(f"\n## {dataset}（逐簇阈值 score>1 判定，5 种子 mean，按 F1 降序）")
        print("| 方法 | Accuracy | Specificity | Recall | Precision | F1 | AUC-ROC | 有效簇 |")
        print("| --- | --- | --- | --- | --- | --- | --- | --- |")
        for label, s, nk in rows:
            print(f"| {label} | {s['accuracy']['mean']:.4f} | {s['specificity']['mean']:.4f} | "
                  f"{s['recall']['mean']:.4f} | {s['precision']['mean']:.4f} | "
                  f"{s['f1_score']['mean']:.4f} | {s['auc_roc']['mean']:.4f} | {nk} |")


if __name__ == "__main__":
    main()
